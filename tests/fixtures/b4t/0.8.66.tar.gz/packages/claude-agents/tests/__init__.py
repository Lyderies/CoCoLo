"""Offline package tests."""
