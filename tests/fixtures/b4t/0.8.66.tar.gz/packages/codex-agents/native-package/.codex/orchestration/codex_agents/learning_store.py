"""Owner-only state, SQLite ledger, and bounded local collector protocol."""

from __future__ import annotations

from .store_fence import StoreFence, EPOCH_SCHEMA, FENCE_MESSAGE

import contextlib
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import socket
import collections.abc
import sqlite3
import stat
import sys
import threading
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterator

try:  # AF_UNIX collector is currently supported on POSIX hosts.
    import fcntl
except ImportError:  # pragma: no cover - Windows has no supported collector transport yet.
    fcntl = None  # type: ignore[assignment]

from .compatibility_message import compatibility_message
from .collector_paths import (
    StateError as StateError,
    UNMOVED_STATE as UNMOVED_STATE,
    _assert_no_symlink_components as _assert_no_symlink_components,
    _canonical_project_root as _canonical_project_root,
    _check_owner_mode as _check_owner_mode,
    _unmoved_legacy_state as _unmoved_legacy_state,
    default_state_root as default_state_root,
)
from .collector_runtime import (
    validate_collector_runtime as validate_collector_runtime,
    CLIENT_HEALTH_CODES as CLIENT_HEALTH_CODES,
    COLLECTOR_AUTHORIZATION_SCHEMA_VERSION as COLLECTOR_AUTHORIZATION_SCHEMA_VERSION,
    HOOK_INGEST_REASON_CODES as HOOK_INGEST_REASON_CODES,
    _client_health_data as _client_health_data,
    _collector_runtime_authorization as _collector_runtime_authorization,
    _start_collector_locked as _start_collector_locked,
    authorized_collector_runtime as authorized_collector_runtime,
    client_health_clear as client_health_clear,
    client_health_increment as client_health_increment,
    client_health_snapshot as client_health_snapshot,
    ensure_collector as ensure_collector,
    require_authorized_collector_runtime as require_authorized_collector_runtime,
)
from .collector_client import (
    COLLECTOR_RUNTIME_DIGEST as COLLECTOR_RUNTIME_DIGEST,
    PACKAGE_VERSION as PACKAGE_VERSION,
    CollectorClient as CollectorClient,
    collector_code_stale as collector_code_stale,
    empty_ingestion_snapshot as empty_ingestion_snapshot,
)
from .active_run_capacity import CAPACITY_OBJECTS, CAPACITY_SCHEMA, CAPACITY_PARENT_SCHEMA, CAPACITY_COMPLETIONS_SCHEMA, CAPACITY_EXECUTIONS_SCHEMA
from .active_run_capacity import INSTALLED_ACTIVE_RUN_LIMITS
from .learning_cycle_core import LEARNING_RETENTION_MS, MAX_CASES as CYCLE_MAX_CASES, MAX_OUTCOMES as CYCLE_MAX_OUTCOMES
from .active_run_capacity import CRASHED_CLAIM_GRACE_MS as CRASHED_CLAIM_GRACE_MS, crashed_claim
from .active_run_capacity import LEGACY_RUN_MAX_MS as LEGACY_RUN_MAX_MS
from .owned_execution import ExecutionCustodyError, OwnedExecutionKey, OwnedExecutionRegistry
from .capacity_status_contracts import CapacityStatusInput, checked_capacity_status
from .account_open_schema import HISTORY_OWNER_COLUMN, OPEN_OBJECTS, assert_open_schema, install_open_schema
from .account_cleanup_schema import RELEASE_COLUMN, RELEASE_COLUMNS, RELEASE_SCHEMA, assert_cleanup_schema, check_cleanup_coverage, install_cleanup_schema
from .account_observation_schema import (OBSERVATION_COLUMNS, OBSERVATION_SCHEMA, assert_observation_schema,
                                         OBSERVATION_ORIGIN_COLUMNS, OBSERVATION_ORIGIN_SCHEMA,
                                         check_observation_coverage, install_observation_schema)
from .phase_report import report_phase
from .run_holds_schema import (  # O0b RS-A
    DECISION_RELEASED, RUN_HOLDS_OBJECTS, assert_run_holds_schema, check_run_holds_consistency, install_run_holds_schema,
)
from .admission_evidence_schema import (
    ADMISSION_EVIDENCE_SCHEMA, assert_admission_evidence_schema, check_admission_evidence_coverage, install_admission_evidence_schema,
)
from .billing_probe_schema import (BILLING_PROBE_COLUMNS, BILLING_PROBE_ORIGIN_COLUMNS,
                                   BILLING_PROBE_OBJECTS, assert_billing_probe_schema,
                                   check_billing_probe_coverage, install_billing_probe_schema)
from .collector_contracts import (
    COLLECTOR_MUTATING_OPERATIONS,
    RUNTIME_UPDATE_COMMAND,
    RUNTIME_UPGRADE_MESSAGE,
    COLLECTOR_PROTOCOL_VERSION as COLLECTOR_PROTOCOL_VERSION,
    LEDGER_SCHEMA_VERSION as LEDGER_SCHEMA_VERSION,
    MAX_REQUEST_BYTES as MAX_REQUEST_BYTES,
    CollectorAuthorizationError as CollectorAuthorizationError,
    CollectorBuildConflictError as CollectorBuildConflictError,
    CollectorError as CollectorError,
    CollectorNewerVersionError as CollectorNewerVersionError,
    CollectorRestartError as CollectorRestartError,
    CollectorUpgradeRequired as CollectorUpgradeRequired,
    CollectorVersionError as CollectorVersionError,
    _version_tuple,
)
from .contracts import (
    LedgerError as LedgerError,
    HOST_OUTCOME_DIGEST,
    RESULT_VALIDATION_REASON_CODES,
    ContractError,
    result_axes,
    routing_task_slice,
    validate_assignment_shape,
    validate_assignment_execution_limits,
    validate_result,
    validate_task,
)
from .project_host_client import probe_deadline, project_host_serving
from .learning_contracts import (
    validate_outcome,
    PRODUCER_AUTHORITY as PRODUCER_AUTHORITY,
    PROVIDER_OBSERVATION_TYPES as PROVIDER_OBSERVATION_TYPES,
    DISPATCH_RESULT_SCHEMA_VERSION,
    MAX_RECORD_BYTES,
    RECORD_TYPES,
    canonical_json, route_identity,
    content_digest,
    external_id,
    keyed_digest,
    parse_bounded_json,
    provider_for_model,
    validate_learning_record,
    validate_event,
    validate_execution_configuration,
)
from .learning_adapters import (
    HOOK_EVENTS, TOKEN_USAGE_FIELDS, empty_usage, load_client_capabilities, reconcile_run, token_usage_known,
)
from .learning_eligibility import (
    EligibilityError, check_candidate_eligibility, check_evaluation_case,
)
from .admission_metadata import EVIDENCE_HORIZON_MS as EVIDENCE_HORIZON_MS
from .provider_restrictions import (
    BILLING_RANK as BILLING_RANK,
    CLAUDE_STATUS_RANK as CLAUDE_STATUS_RANK,
    _effective_window_reset as _effective_window_reset,
    _merged_restriction as _merged_restriction,
    _more_restrictive as _more_restrictive,
    _restriction_windows as _restriction_windows,
    _window_covered as _window_covered,
)
from .owner_key_contracts import (
    OWNER_SIGNER_LINE as OWNER_SIGNER_LINE,
    OWNER_SIGNERS_MAX_BYTES as OWNER_SIGNERS_MAX_BYTES,
    _is_minimal_positive_integer as _is_minimal_positive_integer,
    _owner_key_identity as _owner_key_identity,
    _require_canonical_key as _require_canonical_key,
    _signer_fingerprint as _signer_fingerprint,
    _ssh_key_parts as _ssh_key_parts,
)
from .result_contracts import MAX_RESULT_BODY_BYTES
from .sql_read_budget import SQLReadConnection, SQLReadError
from . import ledger_waits
from .health_containers import ContainerCheck
from .health_monitor import HealthMonitor
from .ledger_waits import LEDGER_LOCK_WAIT_MS, LEDGER_REQUEST_WAIT_MS  # noqa: F401 -- E1a, named here too
from .account_claim_contracts import (
    CLAIM_DENIAL_CODES, MAX_CLAIM_INTEGER, RECEIPT_DENIAL_CODES, ClaimError, LaunchClaimInput,
    _DIGEST as _CLAIM_DIGEST, _REQUEST_ID as _CLAIM_REQUEST_ID, _PROJECT as _CLAIM_PROJECT,
    _RUN as _CLAIM_RUN,
    checked_claim_receipt, matches as claim_matches,
)

# The one line `install_owner_public_key` writes; the allowed-signers file holds nothing else.
# The owner's allowed-signers file is read whole up to this size; anything longer refuses.
OWNER_KEY_REPLACE_HINT = "run ./setup.sh and choose Configure, then Replace a lost owner key"
DEFAULT_RETENTION_MS = LEARNING_RETENTION_MS
# A project whose learning history moved to its own project store. The ledger
# keeps that project's account rows and account-owned evidence; it accepts no
# further learning records for it.
# The first release whose collector hosts the account service that claims and
# counts runs; an older collector's stop cannot take a run's account away.
FIRST_RUN_DRIVING_VERSION = (0, 8, 13)
LEARNING_MOVED_KEY = "project_learning_moved_v1:"
# Set with the moved marker by a migration that still has to switch the copied
# history on in the project store, and cleared when that is done.
LEARNING_ACTIVATION_PENDING_KEY = "project_learning_activation_pending_v1:"
LEARNING_MOVED_ERROR = "project learning has moved to its project store"
LEARNING_MOVED_TYPES = frozenset({
    "outcome", "feedback", "evaluation_case", "evaluation_assignment", "qa_evidence",
    "evidence_review", "evaluation_trial", "candidate", "comparison", "canary_report",
    "grader_calibration", "owner_grant", "promotion", "learning_export",
})
# A worker result kept for its verifier is raw child text, so it lives only while
# its orchestration is open, and never longer than this; only digests stay.
WORKER_RESULT_RETENTION_MS = 7 * 24 * 60 * 60 * 1000
# The persistent collector deletes expired worker results this often, so the
# limit holds even while no lifecycle command opens the ledger.
WORKER_RESULT_SWEEP_SECONDS = 60.0
# O0b RS-A round 1 F12: while due account holds remain, the next batch runs this soon after the last, with
# the ledger lock released in between, so a 1,000-hold burst clears well inside 60 s (draft 3 item 6); a
# busy cycle (the ledger held, or a reader inside) is retried this soon, not an interval later.
# F15 (scripts/measure_release_batches.py, 2026-11-21): on 1,001 due holds a batch of 64 took at most 5.3 ms
# (mean 1.6 ms) and the longest lock hold was 5.4 ms; RS-A-7 allows 50 ms and 750 ms.
ACCOUNT_HOLD_RELEASE_BATCH = 64
# RS-E E2a: the projects' wake rows (E2a-1, E2a-6, E2a-9). The launch columns are machine-local, never in a backup.
WAKE_STATES = ("pending", "exact", "clean_stop")
WAKE_RECONCILE_BATCH = 64
LOCAL_PROJECT_COLUMNS = frozenset({"launch_copy", "launch_digest"})
# 0.8.60 full-run fixes (E2a-1): the machine-local tables, by their exact columns. A backup, a restore and the learning
# move never carry them (they hold this machine's wake, epoch and starter state, and a path-bearing launch record);
# a check that refuses unknown tables accepts exactly these, and only with exactly these columns.
LOCAL_TABLE_COLUMNS = {
    "project_wake": ("project_id", "allocated_epoch", "epoch", "seq", "state", "next_due_at_ms", "body_digest",
                     "due_at_ms", "refused", "updated_at_ms"),
    "project_wake_instances": ("project_id", "instance", "epoch"),
    "project_starts": ("project_id", "attempt", "claimed_at_ms", "child_pid", "failures", "streak_first_ms",
                       "next_start_at_ms", "parked_reason", "parked_digest", "outcome", "reason", "outcome_at_ms",
                       "started_at_ms", "probation_attempt", "probation_pid", "probation_until_ms", "updated_at_ms"),
}
# 0.8.60 final fix (decision 249): the tables a ledger holds outside the backup and the learning move besides the
# machine-local ones, by the exact columns of the product's own CREATE statements (derived, never retyped).
_OWNER_KEY_HISTORY_SCHEMA = (  # the exact text SQLite stores in the ledger: a layout check compares it
    "CREATE TABLE IF NOT EXISTS owner_key_history (\n"
    "                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,\n"
    "                    signer_line BLOB NOT NULL,\n"
    "                    reason TEXT NOT NULL CHECK(reason IN ('enrolled','replaced')),\n"
    "                    recorded_at_ms INTEGER NOT NULL\n"
    "                )")
_ADDITIVE_MIGRATIONS_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS additive_migrations (\n"
    "                        feature_key TEXT PRIMARY KEY\n"
    "                    )")


def _other_table_columns() -> dict[str, tuple[str, ...]]:
    reference = sqlite3.connect(":memory:")
    try:
        for statement in (_OWNER_KEY_HISTORY_SCHEMA, _ADDITIVE_MIGRATIONS_SCHEMA, ADMISSION_EVIDENCE_SCHEMA, EPOCH_SCHEMA):
            reference.execute(statement)
        return {table: tuple(row[1] for row in reference.execute(f"PRAGMA table_xinfo({table})"))
                for table in ("additive_migrations", "owner_key_history", "admission_evidence", "runtime_takeover")}
    finally:
        reference.close()


class _LazyTableColumns(collections.abc.Mapping):
    """The extra tables' exact columns, derived on first use: importing this module must not touch
    any database (a normal client's import is checked for persistence access; decision 251)."""

    def __init__(self) -> None:
        self._value: dict[str, tuple[str, ...]] | None = None

    def _resolved(self) -> dict[str, tuple[str, ...]]:
        if self._value is None:
            self._value = _other_table_columns()
        return self._value

    def __getitem__(self, key: str) -> tuple[str, ...]:
        return self._resolved()[key]

    def __iter__(self):
        return iter(self._resolved())

    def __len__(self) -> int:
        return len(self._resolved())


OTHER_TABLE_COLUMNS = _LazyTableColumns()
_WAKE_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS project_wake("
    "project_id TEXT PRIMARY KEY REFERENCES projects(project_id) ON DELETE CASCADE,"
    "allocated_epoch INTEGER NOT NULL DEFAULT 0 CHECK(allocated_epoch>=0),"
    "epoch INTEGER CHECK(epoch IS NULL OR epoch>=1),seq INTEGER CHECK(seq IS NULL OR seq>=1),"
    "state TEXT CHECK(state IS NULL OR state IN ('pending','exact','clean_stop')),"
    "next_due_at_ms INTEGER,body_digest TEXT,due_at_ms INTEGER,"
    "refused INTEGER NOT NULL DEFAULT 0 CHECK(refused>=0),updated_at_ms INTEGER NOT NULL)",
    "CREATE INDEX IF NOT EXISTS project_wake_due ON project_wake(due_at_ms) WHERE due_at_ms IS NOT NULL",
    # E2a-6 (review round 1, decision 179): each service instance's own allocated epoch, so a retry of an
    # allocation whose acknowledgement was lost gets that same epoch, and an older instance retrying after its
    # successor never gets a newer one (machine-local). A row goes once its instance publishes with its epoch.
    "CREATE TABLE IF NOT EXISTS project_wake_instances("
    "project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,"
    "instance TEXT NOT NULL,epoch INTEGER NOT NULL CHECK(epoch>=1),PRIMARY KEY(project_id,instance))",
)
# RS-E E2c: the starter's own row per project (machine-local, never in a backup): the outstanding claim (attempt id,
# claim time, child pid), the failure streak and backoff (E2c-4), the park (owner decision 143), the last outcome
# the status line reads (E2c-9) and a started host's probation (review round 1, HIGH 4: the attempt, its child and
# when probation ends, so a collector restart reconciles it). Additive; no schema version change.
_START_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS project_starts("
    "project_id TEXT PRIMARY KEY REFERENCES projects(project_id) ON DELETE CASCADE,"
    "attempt TEXT,claimed_at_ms INTEGER,child_pid INTEGER CHECK(child_pid IS NULL OR child_pid>1),"
    "failures INTEGER NOT NULL DEFAULT 0 CHECK(failures>=0),streak_first_ms INTEGER,next_start_at_ms INTEGER,"
    "parked_reason TEXT,parked_digest TEXT,outcome TEXT,reason TEXT,outcome_at_ms INTEGER,started_at_ms INTEGER,"
    "probation_attempt TEXT,probation_pid INTEGER CHECK(probation_pid IS NULL OR probation_pid>1),"
    "probation_until_ms INTEGER,updated_at_ms INTEGER NOT NULL)",
    "CREATE INDEX IF NOT EXISTS project_starts_outstanding ON project_starts(attempt) WHERE attempt IS NOT NULL",
    "CREATE INDEX IF NOT EXISTS project_starts_probation ON project_starts(probation_attempt) "
    "WHERE probation_attempt IS NOT NULL",
)
# E2c-2: the starter's one locked read: due rows by the due index, not parked (unless setup recorded a new launch
# digest since), not backing off, not in a started host's probation and with no start outstanding. Parameters: now,
# now, limit. START_CLAIM_AFTER_SQL (review round 1, HIGH 1) reads the same rows after the starter's cursor (due
# time, project): one pass walks every due row once before any is read again, so a retry never goes ahead of a
# project not yet tried. Parameters: now, cursor due, cursor due, cursor project, now, limit.
_START_CLAIM_SELECT = (
    "SELECT w.project_id,w.due_at_ms,p.canonical_root,p.launch_copy,p.launch_digest,s.parked_reason "
    "FROM project_wake w JOIN projects p ON p.project_id=w.project_id "
    "LEFT JOIN project_starts s ON s.project_id=w.project_id WHERE w.due_at_ms IS NOT NULL AND w.due_at_ms<=? ")
_START_CLAIM_ELIGIBLE = (
    "AND p.status='active' AND (s.project_id IS NULL OR (s.attempt IS NULL AND s.probation_attempt IS NULL AND "
    "(s.next_start_at_ms IS NULL OR s.next_start_at_ms<=?) AND (s.parked_reason IS NULL "
    "OR s.parked_digest IS NOT p.launch_digest))) ORDER BY w.due_at_ms,w.project_id LIMIT ?")
START_CLAIM_SQL = _START_CLAIM_SELECT + _START_CLAIM_ELIGIBLE
START_CLAIM_AFTER_SQL = (_START_CLAIM_SELECT + "AND w.due_at_ms>=? AND (w.due_at_ms>? OR w.project_id>?) "
                         + _START_CLAIM_ELIGIBLE)


@dataclass(frozen=True)
class StartClaim:
    """E2c-2: one claimed start: the project, its root and launch record (None when setup recorded none)."""
    project_id: str
    root: str
    copy: str | None
    digest: str | None
    attempt: str
    due_at_ms: int | None = None  # the claimed wake row's due time: the starter's cursor (HIGH 1)


START_OUTCOMES = frozenset({"failed", "started", "no_record", "install_changed", "handover", "migration", "serving",
                            "unauthorized"})
# E2a-9 (review round 1): a reconcile pass reads pages of WAKE_RECONCILE_BATCH project rows (rows examined, not
# rows matched), each in its own short ledger hold; the startup pass before ready probes for at most this long and
# the wake thread finishes the rest at once.
WAKE_STARTUP_SECONDS = 1.0
WAKE_PASS_SECONDS = 5.0
SWEEP_BATCH_GAP_SECONDS = 0.01
SWEEP_BUSY_RETRY_SECONDS = 1.0
# O0b RS-A round 2 G6: while idle, due account holds are checked this often (one indexed read, no
# transaction), so a burst arriving at any moment starts draining within this and clears well inside 60 s;
# the other sweeps keep WORKER_RESULT_SWEEP_SECONDS.
SWEEP_IDLE_CHECK_SECONDS = 5.0
# S1-H1a-6: the health route waits at most this for the ledger lock, well inside the client's
# 1-second health timeout; what it cannot read in time it leaves out (`ledger_busy`).
HEALTH_LEDGER_WAIT_MS = 250
# A collector request must arrive whole within this, well inside the sweep
# interval, so a slow or stalled sender can never postpone a sweep.
COLLECTOR_REQUEST_DEADLINE_SECONDS = 5.0
# Registered worker results: their raw text, kept for a verifier in the same
# orchestration; the select yields project, path and orchestration status.
_WORKER_RESULT_FILES = (
    "SELECT s.project_id,s.relative_path,s.expires_at_ms,o.status FROM stored_files s "
    "LEFT JOIN records r ON r.project_id=s.project_id AND r.record_id=s.source_record_id "
    "LEFT JOIN host_run_bindings b ON b.project_id=r.project_id "
    "AND b.run_id=json_extract(CAST(r.content AS TEXT),'$.run_id') "
    "LEFT JOIN orchestrations o ON o.project_id=b.project_id "
    "AND o.orchestration_id=b.orchestration_id "
    "WHERE s.kind='artifact' AND substr(s.file_id,1,12)='host_result_'"
)
REPAIR_RECEIPT_TTL_MS = 24 * 60 * 60 * 1000
MAX_PENDING_REPAIR_RECEIPTS = 4096
MAX_PENDING_HOST_RUNS = 4096
# O0b RS-A (F7): a binding the register released (expired) never counts again, whatever the wall clock says.
# Round 2 G12: every binding cap counts from held register rows (run_holds_due), so the work is bounded by the
# holds still held, never by released history a clock rollback brings back inside its expiry. Parameters: the
# project and the time; the count equals "pending, not past expiry, not released by the register", as every
# pending binding has its register row (check_run_holds_consistency).
LIVE_BINDINGS = ("FROM run_holds r INDEXED BY run_holds_due CROSS JOIN host_run_bindings h "
                 "ON h.project_id=r.project_id AND h.handle_digest=r.identity WHERE r.state<>'released' "
                 "AND r.kind='binding' AND r.project_id=? AND h.binding_state='pending' AND h.expires_at_ms>?")
HOST_RUN_TTL_MS = 24 * 60 * 60 * 1000
# OP-2: how long a finished open (request, receipt and binding) is kept after its binding's expiry and its own
# deadline, whichever is later. As long as a kept worker result (WORKER_RESULT_RETENTION_MS), whose orchestration
# the result sweep reads through the run's binding; a replay later than this answers open_expired.
OPEN_REQUEST_RETENTION_MS = 7 * 24 * 60 * 60 * 1000
OPERATIONAL_CHECK_TTL_MS = 60 * 60 * 1000
UPGRADE_RECONCILIATION_TTL_MS = 10 * 60 * 1000
MAX_PENDING_OPERATIONAL_CHECKS = 256
# The CLI reads a result as at most this many bytes, so a kept worker result
# never needs more.
MAX_WORKER_RESULT_BYTES = MAX_RESULT_BODY_BYTES
INGESTION_FRESH_MS = 30 * 60 * 1000
# Runs opened with this client are bridged: only `dispatch` may run their child.
BRIDGE_CLIENT_VERSION = "bridge-v1"
# Billing evidence younger than this is reused instead of probing again.
PROBE_REUSE_SECONDS = 300
# A launched probe reserves its account for this long, whatever it returned.
PROBE_COOLDOWN_SECONDS = 300
# Decision 50 (BR-22): the window of the denial-record bound (one record per reason and account per window).
PROBE_DENIAL_WINDOW_MS = PROBE_COOLDOWN_SECONDS * 1000
# A run keeps only rate-limit events more restrictive than those it already
# recorded, so this cap is reached only by a stream that keeps escalating.
MAX_RUN_RATE_LIMIT_RECORDS = 64
# How long after its hard deadline an unsettled claimed run still counts against
# the account's active-run limits (a crashed project host never settles it).
INSTALLED_ROUTING_POLICY = (
    Path(__file__).resolve().parent.parent / "config" / "routing-policy.json"
)
# How long each raw event is kept: a weight per event code, from the installed policy.
INSTALLED_RETENTION_POLICY = (
    Path(__file__).resolve().parent.parent / "config" / "retention-policy.json"
)
RETENTION_WEIGHTS = ("low", "medium", "high")
MAX_EVENT_KEEP_DAYS = 365
MAX_SUMMARY_KEEP_DAYS = 3650
# The collector removes at most this many expired raw events per sweep.
EVENT_SWEEP_BATCH = 500
# One learning-expire call summarises at most this many expired raw events (its work under the exclusive
# lock is bounded); the rest wait for the next call, which the report's `more` asks for.
EXPIRE_SUMMARY_BATCH = 500
# How many windows of rows it cannot summarise a sweep reads past before it stops.
EVENT_SWEEP_SCAN_FACTOR = 20

# O0c P8: the learning cycle reads LEARNING_RETENTION_MS of outcomes, and the cases and candidates of that
# window plus the ones kept for a reason; the collector sweep removes the rest, a small batch at a time.
LEARNING_SWEEP_BATCH = 100


def _kept_learning_sql(alias: str) -> str:
    """The cases and candidates the sweep never removes, and the cycle reads whatever their age: a case in a
    controlled corpus (promoted policy), and any record a later record names (a record link from it: the case
    another case supersedes, the case or candidate of an assignment, trial, comparison or promotion), a granted
    candidate, an owner-attested record."""
    link = (f"EXISTS (SELECT 1 FROM record_links l WHERE l.project_id={alias}.project_id "
            f"AND l.from_record_id={alias}.record_id)")
    grant = (f"({alias}.record_type='candidate' AND EXISTS (SELECT 1 FROM consumed_grants g "
             f"WHERE g.project_id={alias}.project_id AND g.candidate_digest="
             f"json_extract(CAST({alias}.content AS TEXT),'$.candidate_digest')))")
    attested = (f"EXISTS (SELECT 1 FROM owner_attestations a WHERE a.project_id={alias}.project_id "
                f"AND a.subject_record_id={alias}.record_id)")
    controlled = (f"({alias}.record_type='evaluation_case' AND "
                  f"json_extract(CAST({alias}.content AS TEXT),'$.corpus_state')!='development')")
    return f"({controlled} OR {link} OR {grant} OR {attested})"

def _cited_sql(alias: str) -> str:
    """A record something else still names, in any table that references records (review rev040o0ccapsr1 M2):
    a record link in either direction, a consumed grant (as the grant or as its promotion record), a stored
    file's source. Such a record is never deleted by a sweep whose only reason is that a later one supersedes it."""
    project, record = f"{alias}.project_id", f"{alias}.record_id"
    return ("(EXISTS (SELECT 1 FROM record_links l WHERE l.project_id=" + project + " AND "
            "(l.from_record_id=" + record + " OR l.to_record_id=" + record + ")) "
            "OR EXISTS (SELECT 1 FROM consumed_grants g WHERE g.project_id=" + project + " AND "
            "(g.grant_id=" + record + " OR g.promotion_record_id=" + record + ")) "
            "OR EXISTS (SELECT 1 FROM stored_files f WHERE f.project_id=" + project + " AND "
            "f.source_record_id=" + record + "))")

_DAY_MS = 24 * 60 * 60 * 1000


@dataclass(frozen=True)
class RetentionPolicy:
    """Milliseconds to keep each hook or app-server event code, and each event summary."""

    event_keep_ms: dict
    summary_keep_ms: int


def _run_changed():
    """A stale claim whose own run rows changed: a new admission capture cannot mend it, so the claim
    job does not prepare it again (0.4.0 FR1, review 040-fr-stale). Same public reason code."""
    error = ClaimError("claim_preparation_stale")
    error.run_changed = True
    return error


def load_retention_policy(path: Path = INSTALLED_RETENTION_POLICY) -> RetentionPolicy:
    """The installed retention policy; one that misses, repeats or invents a code is refused."""
    from .learning_contracts import EVENT_CODES

    try:
        value = json.loads(Path(path).read_bytes())
    except (OSError, ValueError):
        raise LedgerError("retention policy is unavailable") from None

    def days(item, maximum):
        if type(item) is not int or not 1 <= item <= maximum:
            raise LedgerError("retention policy is invalid")
        return item * _DAY_MS

    if (not isinstance(value, dict)
            or set(value) != {"version", "weights", "events", "host_events", "summary_keep_days"}
            or value["version"] != 1 or type(value["version"]) is not int
            or value["host_events"] != "run_bound"
            or not isinstance(value["weights"], dict) or set(value["weights"]) != set(RETENTION_WEIGHTS)
            or not isinstance(value["events"], dict) or set(value["events"]) != set(RETENTION_WEIGHTS)):
        raise LedgerError("retention policy is invalid")
    keep = {}
    for weight in RETENTION_WEIGHTS:
        setting, codes = value["weights"][weight], value["events"][weight]
        if not isinstance(setting, dict) or set(setting) != {"keep_days"} or not isinstance(codes, list):
            raise LedgerError("retention policy is invalid")
        period = days(setting["keep_days"], MAX_EVENT_KEEP_DAYS)  # Checked even for a weight with no codes.
        for code in codes:
            if type(code) is not str or code not in EVENT_CODES or code in keep:
                raise LedgerError("retention policy is invalid")
            keep[code] = period
    if set(keep) != set(EVENT_CODES):
        raise LedgerError("retention policy is invalid")
    return RetentionPolicy(keep, days(value["summary_keep_days"], MAX_SUMMARY_KEEP_DAYS))


_RETENTION_POLICY: list[RetentionPolicy] = []


def _retention_policy() -> RetentionPolicy:
    if not _RETENTION_POLICY:
        _RETENTION_POLICY.append(load_retention_policy())
    return _RETENTION_POLICY[0]
SOURCE_BY_PRODUCER = {
    "hook": "hook",
    "app_server": "app_server",
    "host": "host",
    "evaluator": "evaluator",
    "verifier": "verifier",
    "owner": "owner",
    "lifecycle": "lifecycle",
    "provider": "provider",
}
HOOK_EVENT_CODES = tuple(value[0] for value in HOOK_EVENTS.values())
HOOK_REJECTION_CODES = {
    "hook_normalization_rejected",
    "hook_binding_rejected",
    "hook_ingest_rejected",
}






class OwnerSignerNotConfigured(StateError):
    """The checked signer file is empty; other unsafe states stay distinct."""


class ProjectNotRegisteredError(LedgerError):
    """Raised when an exact project root has no active registration."""


_BACKUP_PROJECT_COLUMNS = (
    "project_id", "canonical_root", "root_digest", "status", "created_at_ms",
    "deleted_at_ms",
)
_BACKUP_TABLE_COLUMNS = {
    "sessions": ("session_digest", "producer", "created_at_ms"),
    "run_provenance": (
        "run_id", "producer", "client_version", "session_digest", "created_at_ms",
    ),
    "records": (
        "record_id", "record_type", "source", "source_sequence", "observed_at_ms",
        "ingested_at_ms", "expires_at_ms", "content", "content_digest", "late", "probe_id",
    ),
    "record_links": ("from_record_id", "to_record_id", "relation"),
    "stored_files": (
        "file_id", "kind", "relative_path", "content_digest", "source_record_id",
        "expires_at_ms",
    ),
    "collector_health": ("code", "count", "updated_at_ms"),
    "consumed_grants": (
        "grant_id", "promotion_record_id", "candidate_digest", "action",
        "consumed_at_ms",
    ),
    "owner_attestations": ("subject_record_id", "signature", "attested_at_ms"),
    "repair_receipts": (
        "receipt_id", "assignment_digest", "reason_code", "issued_at_ms",
        "expires_at_ms", "consumed_at_ms", "run_id",
    ),
    "launch_claims": ("handle_digest", "run_id", "kind", "claimed_at_ms", "bridge_run_id"),
    "launch_inputs": ("handle_digest", "run_id", "runtime_digest", "provider", "model", "effort", "hard_timeout_seconds"),
    "launch_observations": ("handle_digest", "identity_digest", "observed_at_ms"),
    "launch_receipts": ("scope_digest", "request_digest", "parameters_digest", "handle_digest", "receipt_digest",
                        "run_id", "state", "reason_code", "bridge_run_id", "deadline_at_ms", "recorded_at_ms"),
    "active_run_capacity": ("handle_digest", "run_id", "bridge_run_id", "kind", "provider", "account_fingerprint",
                            "runtime_digest", "policy_digest", "claimed_at_ms", "deadline_at_ms",
                            "clock_reference_ns", "execution_deadline_ns", "clock_owner_digest", "released_at_ms", "release_digest"),
    "capacity_completions": ("handle_digest", "run_id", "bridge_run_id", "terminal_record_id", "terminal_content_digest",
                             "released_at_ms", "receipt_digest"),
    "capacity_executions": ("handle_digest", "run_id", "bridge_run_id", "owner_digest", "cleanup_reservation_digest"),
    "account_cleanup_receipts": RELEASE_COLUMNS,
    "account_observation_origins": OBSERVATION_ORIGIN_COLUMNS,
    "account_observation_requests": OBSERVATION_COLUMNS,
    "account_billing_probe_origins": BILLING_PROBE_ORIGIN_COLUMNS,
    "account_billing_probe_requests": BILLING_PROBE_COLUMNS,
    # O0b RS-A: from schema 15; a crashed or lost release cannot be derived again, so it is backed up.
    "run_holds": ("kind", "identity", "state", "generation", "taken_at_ms", "released_at_ms", "release_kind", "receipt", "evidence", "next_check_ms"),
    "host_run_bindings": (
        "handle_digest", "run_id", "assignment_digest", "task_digest",
        "task_id_digest", "route_digest", "configuration_digest", "client_version",
        "created_at_ms", "expires_at_ms", "consumed_at_ms", "orchestration_id",
        "native_assignment_id", "agent_type", "usage_complete", "binding_state",
        "abandoned_reason", "observation_started_at_ms",
        "observation_deadline_at_ms", "last_progress_at_ms", "deadline_observed",
        "history_owner",
    ),
    "hook_ingestion": ("event_code", "accepted_count", "last_accepted_at_ms"),
    "orchestrations": (
        "orchestration_id", "handle_digest", "client_version", "status",
        "started_at_ms", "ended_at_ms", "goal_tokens_used",
        "goal_time_used_seconds", "expires_at_ms",
    ),
    "orchestration_checkpoints": (
        "orchestration_id", "sequence", "status", "goal_tokens_used",
        "goal_time_used_seconds", "observed_at_ms",
    ),
    "operational_qa": (
        "qa_id", "qa_digest", "host_outcome_digest",
        "verifier_host_outcome_digest", "accepted", "observed_at_ms", "content",
    ),
    "operational_check_receipts": (
        "receipt_id", "report_digest", "host_outcome_digest",
        "verifier_host_outcome_digest", "orchestration_id", "issued_at_ms",
        "expires_at_ms", "consumed_at_ms", "report",
    ),
    "tombstones": ("deletion_id", "deleted_at_ms"),
    "account_open_receipts": ("handle_digest", "run_id", "request_key", "scope_digest", "parameters_digest", "content", "content_seal"),
    "account_open_requests": ("request_key", "original_key", "parameters_digest", "handle_digest", "run_id", "state", "opened_at_ms",
                              "observation_deadline_at_ms", "receipt_digest", "request_seal"),
}
_BACKUP_V5_HOST_COLUMNS = tuple(
    column for column in _BACKUP_TABLE_COLUMNS["host_run_bindings"]
    if column not in {
        "binding_state", "abandoned_reason", "observation_started_at_ms",
        "observation_deadline_at_ms", "last_progress_at_ms", "deadline_observed",
        "history_owner",
    }
)
_BACKUP_ORDER_COLUMNS = {
    "sessions": ("session_digest", "producer"),
    "run_provenance": ("run_id", "producer"),
    "records": ("source_sequence",),
    "record_links": ("from_record_id", "to_record_id", "relation"),
    "stored_files": ("file_id",),
    "collector_health": ("code",),
    "consumed_grants": ("grant_id",),
    "owner_attestations": ("subject_record_id",),
    "repair_receipts": ("receipt_id",),
    "host_run_bindings": ("created_at_ms", "run_id"),
    "launch_claims": ("handle_digest",),
    "launch_inputs": ("handle_digest",),
    "launch_observations": ("handle_digest",),
    "launch_receipts": ("scope_digest", "request_digest"),
    "active_run_capacity": ("handle_digest",),
    "capacity_completions": ("handle_digest",),
    "capacity_executions": ("handle_digest",),
    "account_cleanup_receipts": ("handle_digest",),
    "account_observation_origins": ("request_key",),
    "account_observation_requests": ("request_key",),
    "account_billing_probe_origins": ("request_key",),
    "account_billing_probe_requests": ("request_key",),
    "run_holds": ("kind", "identity"),
    "hook_ingestion": ("event_code",),
    "orchestrations": ("started_at_ms", "orchestration_id"),
    "orchestration_checkpoints": ("orchestration_id", "sequence"),
    "operational_qa": ("observed_at_ms", "qa_id"),
    "operational_check_receipts": ("issued_at_ms", "receipt_id"),
    "tombstones": ("deletion_id",),
    "account_open_receipts": ("handle_digest",),
    "account_open_requests": ("request_key",),
}
_BACKUP_BYTES_KEY = "$codex_agents_bytes_base64"


def _backup_encode_value(value: Any) -> Any:
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {_BACKUP_BYTES_KEY: base64.b64encode(bytes(value)).decode("ascii")}
    return value


def _backup_decode_value(value: Any) -> Any:
    if isinstance(value, dict) and set(value) == {_BACKUP_BYTES_KEY}:
        encoded = value[_BACKUP_BYTES_KEY]
        if not isinstance(encoded, str):
            raise LedgerError("project backup byte encoding is invalid")
        try:
            return base64.b64decode(encoded, validate=True)
        except (ValueError, TypeError) as exc:
            raise LedgerError("project backup byte encoding is invalid") from exc
    if isinstance(value, dict):
        raise LedgerError("project backup contains an unsupported object value")
    if not isinstance(value, (str, int, float, bool, type(None))):
        raise LedgerError("project backup contains an unsupported value")
    return value


def _backup_expected_columns(schema_version: int, table: str) -> tuple[str, ...]:
    if schema_version < 16 and table == "records":
        return _BACKUP_TABLE_COLUMNS[table][:-1]
    if schema_version < 15 and table == "run_holds":
        return ()
    if schema_version < 13 and table in {"account_billing_probe_origins", "account_billing_probe_requests"}:
        return ()
    if schema_version < 12 and table in {"account_observation_origins", "account_observation_requests"}:
        return ()
    if schema_version < 11 and table == 'capacity_executions':
        return _BACKUP_TABLE_COLUMNS[table][:-1] if schema_version >= 9 else ()
    if schema_version < 9 and table in {"active_run_capacity", "capacity_completions", "capacity_executions"}:
        return ()
    if schema_version < 8 and table in {"launch_inputs", "launch_observations", "launch_receipts"}:
        return ()
    if schema_version < 7 and table == "launch_claims":
        return ()
    if schema_version == 5:
        if table == "host_run_bindings":
            return _BACKUP_V5_HOST_COLUMNS
        if table == "orchestration_checkpoints":
            return ()
    if schema_version < 10 and table == 'host_run_bindings':
        return tuple(n for n in _BACKUP_TABLE_COLUMNS[table] if n != 'history_owner')
    return _BACKUP_TABLE_COLUMNS[table]


def _backup_tables(schema_version: int) -> tuple[str, ...]:
    # Preserve the exact old manifest. Older verified backups never contained
    # a launch_claims entry, even an empty one.
    return tuple(table for table in _BACKUP_TABLE_COLUMNS
                 if (schema_version >= 7 or table != "launch_claims")
                 and (schema_version >= 8 or table not in {"launch_inputs", "launch_observations", "launch_receipts"})
                 and (schema_version >= 9 or table not in {"active_run_capacity", "capacity_completions", "capacity_executions"})
                 and (schema_version >= 10 or table not in {'account_open_receipts', 'account_open_requests'})
                 and (schema_version >= 11 or table != 'account_cleanup_receipts')
                 and (schema_version >= 12 or table not in {'account_observation_origins', 'account_observation_requests'})
                 and (schema_version >= 13 or table not in {'account_billing_probe_origins', 'account_billing_probe_requests'})
                 and (schema_version >= 15 or table != 'run_holds'))


def _snapshot_project_partition(
    connection: sqlite3.Connection,
    project_id: str,
    *,
    ledger_schema_version: int,
) -> dict[str, Any]:
    project_columns = {
        str(row[1]) for row in connection.execute("PRAGMA table_info(projects)").fetchall()
    }
    # E2a-1: the launch record is machine-local; a backup keeps the six original columns, a restore has none.
    if project_columns - LOCAL_PROJECT_COLUMNS != set(_BACKUP_PROJECT_COLUMNS):
        raise LedgerError("project backup cannot represent projects exactly")
    project = connection.execute(
        f"SELECT {','.join(_BACKUP_PROJECT_COLUMNS)} FROM projects "
        "WHERE project_id=? AND status='active'",
        (project_id,),
    ).fetchone()
    if project is None:
        raise LedgerError("project binding is not active")
    tables: dict[str, list[dict[str, Any]]] = {}
    columns_manifest: dict[str, list[str]] = {}
    for table in _backup_tables(ledger_schema_version):
        exists = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
        ).fetchone()
        available = (
            {str(row[1]) for row in connection.execute(
                f"PRAGMA table_info({table})"
            ).fetchall()}
            if exists is not None else set()
        )
        expected = list(_backup_expected_columns(ledger_schema_version, table))
        expected_available = {"project_id", *expected} if expected else set()
        if available != expected_available:
            raise LedgerError(f"project backup cannot represent {table} exactly")
        columns = expected
        columns_manifest[table] = columns
        if not columns:
            tables[table] = []
            continue
        order = [
            column for column in _BACKUP_ORDER_COLUMNS[table] if column in columns
        ]
        query = (
            f"SELECT {','.join(columns)} FROM {table} WHERE project_id=?"
            + (f" ORDER BY {','.join(order)}" if order else "")
        )
        tables[table] = [
            {
                column: _backup_encode_value(row[column])
                for column in columns
            }
            for row in connection.execute(query, (project_id,)).fetchall()
        ]
    return {
        "schema_version": 2,
        "ledger_schema_version": ledger_schema_version,
        "project": {
            column: _backup_encode_value(project[column])
            for column in _BACKUP_PROJECT_COLUMNS
        },
        "columns": columns_manifest,
        "tables": tables,
        "counts": {name: len(rows) for name, rows in tables.items()},
    }


def _refuse_malformed_rows(connection, project_id, record_type):
    """Fail closed when a project holds an unreadable row of this type (U3 review LOW-1).

    The run-identity expression is guarded with json_valid so an index build and a keyed
    seek never trip over a corrupt row, but then a corrupt row simply fails to match a
    duplicate guard ("already dispatched/recorded"). Before U3 the unguarded read raised
    on it. A corrupt row has a NULL guarded run id, so this seeks the same index for NULL
    (a handful of rows) and refuses when one of them is not valid JSON.
    """
    if connection.execute(
        "SELECT 1 FROM records WHERE project_id=? "
        "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END IS NULL "
        "AND record_type=? AND NOT json_valid(CAST(content AS TEXT)) LIMIT 1",
        (project_id, record_type),
    ).fetchone() is not None:
        raise LedgerError(f"a malformed {record_type} record blocks this check")


def _claim_exists(connection, project_id, handle_digest, run_id):
    """Whether a launch claim holds this handle or this run id.

    Two lookups, one per unique index: with `handle_digest=? OR run_id=?` SQLite chose the
    project_id prefix of a covering index and read every claim of the project (D11).
    """
    return connection.execute(
        "SELECT 1 FROM launch_claims WHERE project_id=? AND handle_digest=? UNION ALL "
        "SELECT 1 FROM launch_claims WHERE project_id=? AND run_id=? LIMIT 1",
        (project_id, handle_digest, project_id, run_id)).fetchone() is not None


def _capacity_exists(connection, project_id, handle_digest, run_id):
    """Whether a capacity row holds this handle or this run id (D11).

    active_run_capacity has no index on run_id, so `handle_digest=? OR run_id=?` scanned the
    project's rows. A capacity row's (handle, run id) must match its launch claim (foreign key),
    so the run id is found through the claim's unique (project_id, run_id) index.
    """
    return connection.execute(
        "SELECT 1 FROM active_run_capacity WHERE project_id=? AND handle_digest=? UNION ALL "
        "SELECT 1 FROM launch_claims c JOIN active_run_capacity a ON a.project_id=c.project_id "
        "AND a.handle_digest=c.handle_digest WHERE c.project_id=? AND c.run_id=? LIMIT 1",
        (project_id, handle_digest, project_id, run_id)).fetchone() is not None


_LAUNCH_CLAIMS_SCHEMA = """
CREATE TABLE IF NOT EXISTS launch_claims (
    project_id TEXT NOT NULL,
    handle_digest TEXT NOT NULL CHECK(typeof(handle_digest)='text' AND length(handle_digest)=64
        AND handle_digest NOT GLOB '*[^0-9a-f]*'),
    run_id TEXT NOT NULL CHECK(typeof(run_id)='text' AND length(run_id) BETWEEN 1 AND 160),
    kind TEXT NOT NULL CHECK(kind IN ('claimed','legacy_fenced')),
    claimed_at_ms INTEGER NOT NULL CHECK(typeof(claimed_at_ms)='integer' AND claimed_at_ms>=0),
    bridge_run_id TEXT,
    PRIMARY KEY(project_id,handle_digest),
    UNIQUE(project_id,run_id),
    CHECK((kind='claimed' AND typeof(bridge_run_id)='text' AND length(bridge_run_id)=36
        AND substr(bridge_run_id,1,4)='brg_' AND substr(bridge_run_id,5) NOT GLOB '*[^0-9a-f]*')
        OR (kind='legacy_fenced' AND bridge_run_id IS NULL)),
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
)
"""


_LAUNCH_INPUTS_SCHEMA = """
CREATE TABLE IF NOT EXISTS launch_inputs (
    project_id TEXT NOT NULL,
    handle_digest TEXT NOT NULL,
    run_id TEXT NOT NULL,
    runtime_digest TEXT NOT NULL CHECK(length(runtime_digest)=64 AND runtime_digest NOT GLOB '*[^0-9a-f]*'),
    provider TEXT NOT NULL CHECK(provider IN ('codex','claude')),
    model TEXT NOT NULL CHECK(typeof(model)='text' AND length(model) BETWEEN 1 AND 160),
    effort TEXT NOT NULL CHECK(typeof(effort)='text' AND length(effort) BETWEEN 1 AND 32),
    hard_timeout_seconds INTEGER NOT NULL CHECK(typeof(hard_timeout_seconds)='integer' AND hard_timeout_seconds>0),
    PRIMARY KEY(project_id,handle_digest),
    UNIQUE(project_id,run_id),
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
)
"""

_LAUNCH_RECEIPT_PARENT_SCHEMA = """
CREATE UNIQUE INDEX IF NOT EXISTS launch_receipt_parent
ON launch_claims(project_id,handle_digest,run_id,bridge_run_id)
"""

_LAUNCH_OBSERVATIONS_SCHEMA = """
CREATE TABLE IF NOT EXISTS launch_observations (
    project_id TEXT NOT NULL,
    handle_digest TEXT NOT NULL,
    identity_digest TEXT NOT NULL CHECK(length(identity_digest)=64 AND identity_digest NOT GLOB '*[^0-9a-f]*'),
    observed_at_ms INTEGER NOT NULL CHECK(typeof(observed_at_ms)='integer' AND observed_at_ms>=0),
    PRIMARY KEY(project_id,handle_digest),
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
)
"""

_LAUNCH_RECEIPTS_SCHEMA = """
CREATE TABLE IF NOT EXISTS launch_receipts (
    project_id TEXT NOT NULL,
    scope_digest TEXT NOT NULL CHECK(length(scope_digest)=64 AND scope_digest NOT GLOB '*[^0-9a-f]*'),
    request_digest TEXT NOT NULL CHECK(length(request_digest)=64 AND request_digest NOT GLOB '*[^0-9a-f]*'),
    parameters_digest TEXT NOT NULL CHECK(length(parameters_digest)=64 AND parameters_digest NOT GLOB '*[^0-9a-f]*'),
    handle_digest TEXT NOT NULL CHECK(length(handle_digest)=64 AND handle_digest NOT GLOB '*[^0-9a-f]*'),
    receipt_digest TEXT NOT NULL CHECK(length(receipt_digest)=64 AND receipt_digest NOT GLOB '*[^0-9a-f]*'),
    run_id TEXT,
    state TEXT NOT NULL CHECK(state IN ('claimed','denied')),
    reason_code TEXT,
    bridge_run_id TEXT,
    deadline_at_ms INTEGER,
    recorded_at_ms INTEGER NOT NULL CHECK(typeof(recorded_at_ms)='integer' AND recorded_at_ms>=0),
    PRIMARY KEY(project_id,scope_digest,request_digest),
    UNIQUE(project_id,receipt_digest),
    CHECK((state='claimed' AND run_id IS NOT NULL AND bridge_run_id IS NOT NULL
        AND typeof(deadline_at_ms)='integer' AND deadline_at_ms>recorded_at_ms AND reason_code IS NULL)
        OR (state='denied' AND bridge_run_id IS NULL AND deadline_at_ms IS NULL AND reason_code IN (
""" + ",".join("'" + code + "'" for code in sorted(RECEIPT_DENIAL_CODES)) + """))),
    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    FOREIGN KEY(project_id,handle_digest,run_id,bridge_run_id)
        REFERENCES launch_claims(project_id,handle_digest,run_id,bridge_run_id)
)
"""

_LAUNCH_CLEANUP_SCHEMA = """
CREATE TRIGGER IF NOT EXISTS cleanup_launch_operation_state
AFTER UPDATE OF status ON projects
WHEN NEW.status='deleted' AND OLD.status<>'deleted'
BEGIN
    DELETE FROM launch_inputs WHERE project_id=NEW.project_id;
    DELETE FROM launch_observations WHERE project_id=NEW.project_id;
    DELETE FROM launch_receipts WHERE project_id=NEW.project_id;
    DELETE FROM launch_claims WHERE project_id=NEW.project_id;
END
"""


_BACKUP_RESTORE_SCHEMA = """
CREATE TABLE projects(project_id TEXT PRIMARY KEY,canonical_root TEXT,root_digest TEXT,
 status TEXT NOT NULL CHECK(status IN ('active','deleted')),created_at_ms INTEGER NOT NULL,
 deleted_at_ms INTEGER);
""" + _LAUNCH_CLAIMS_SCHEMA + ";\n" + _LAUNCH_RECEIPT_PARENT_SCHEMA + ";\n" + _LAUNCH_INPUTS_SCHEMA + ";\n" + _LAUNCH_OBSERVATIONS_SCHEMA + ";\n" + _LAUNCH_RECEIPTS_SCHEMA + ";\n" + CAPACITY_PARENT_SCHEMA + ";\n" + CAPACITY_SCHEMA + ";\n" + CAPACITY_COMPLETIONS_SCHEMA + ";\n" + CAPACITY_EXECUTIONS_SCHEMA + ";\n" + """
CREATE TABLE sessions(project_id TEXT NOT NULL,session_digest TEXT NOT NULL,producer TEXT NOT NULL,
 created_at_ms INTEGER NOT NULL,PRIMARY KEY(project_id,session_digest,producer),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE run_provenance(project_id TEXT NOT NULL,run_id TEXT NOT NULL,producer TEXT NOT NULL,
 client_version TEXT NOT NULL,session_digest TEXT NOT NULL,created_at_ms INTEGER NOT NULL,
 PRIMARY KEY(project_id,run_id,producer),FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE records(project_id TEXT NOT NULL,record_id TEXT NOT NULL,record_type TEXT NOT NULL,
 source TEXT NOT NULL,source_sequence INTEGER NOT NULL,observed_at_ms INTEGER NOT NULL,
 ingested_at_ms INTEGER NOT NULL,expires_at_ms INTEGER,content BLOB NOT NULL,
 content_digest TEXT NOT NULL,late INTEGER NOT NULL CHECK(late IN (0,1)),probe_id TEXT,
 PRIMARY KEY(project_id,record_id),UNIQUE(project_id,source_sequence),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE record_links(project_id TEXT NOT NULL,from_record_id TEXT NOT NULL,to_record_id TEXT NOT NULL,
 relation TEXT NOT NULL,PRIMARY KEY(project_id,from_record_id,to_record_id,relation),
 FOREIGN KEY(project_id,from_record_id) REFERENCES records(project_id,record_id) ON DELETE CASCADE,
 FOREIGN KEY(project_id,to_record_id) REFERENCES records(project_id,record_id) ON DELETE CASCADE);
CREATE TABLE stored_files(project_id TEXT NOT NULL,file_id TEXT NOT NULL,kind TEXT NOT NULL
 CHECK(kind IN ('artifact','export','backup')),relative_path TEXT NOT NULL,content_digest TEXT NOT NULL,
 source_record_id TEXT,expires_at_ms INTEGER,PRIMARY KEY(project_id,file_id),UNIQUE(project_id,relative_path),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
 FOREIGN KEY(project_id,source_record_id) REFERENCES records(project_id,record_id) ON DELETE CASCADE);
CREATE TABLE collector_health(project_id TEXT NOT NULL,code TEXT NOT NULL,count INTEGER NOT NULL,
 updated_at_ms INTEGER NOT NULL,PRIMARY KEY(project_id,code),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE consumed_grants(project_id TEXT NOT NULL,grant_id TEXT NOT NULL,promotion_record_id TEXT NOT NULL,
 candidate_digest TEXT NOT NULL,action TEXT NOT NULL,consumed_at_ms INTEGER NOT NULL,
 PRIMARY KEY(project_id,grant_id),FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
 FOREIGN KEY(project_id,grant_id) REFERENCES records(project_id,record_id) ON DELETE CASCADE,
 FOREIGN KEY(project_id,promotion_record_id) REFERENCES records(project_id,record_id) ON DELETE CASCADE);
CREATE TABLE owner_attestations(project_id TEXT NOT NULL,subject_record_id TEXT NOT NULL,
 signature BLOB NOT NULL,attested_at_ms INTEGER NOT NULL,PRIMARY KEY(project_id,subject_record_id),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
 FOREIGN KEY(project_id,subject_record_id) REFERENCES records(project_id,record_id) ON DELETE CASCADE);
CREATE TABLE repair_receipts(project_id TEXT NOT NULL,receipt_id TEXT NOT NULL,
 assignment_digest TEXT NOT NULL,reason_code TEXT NOT NULL,issued_at_ms INTEGER NOT NULL,
 expires_at_ms INTEGER NOT NULL,consumed_at_ms INTEGER,run_id TEXT,PRIMARY KEY(project_id,receipt_id),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE host_run_bindings(project_id TEXT NOT NULL,handle_digest TEXT NOT NULL,run_id TEXT NOT NULL,
 assignment_digest TEXT NOT NULL,task_digest TEXT NOT NULL,task_id_digest TEXT,route_digest TEXT NOT NULL,
 configuration_digest TEXT NOT NULL,client_version TEXT NOT NULL,created_at_ms INTEGER NOT NULL,
 expires_at_ms INTEGER NOT NULL,consumed_at_ms INTEGER,orchestration_id TEXT,native_assignment_id TEXT,
 agent_type TEXT,usage_complete INTEGER,binding_state TEXT,abandoned_reason TEXT,
 observation_started_at_ms INTEGER,observation_deadline_at_ms INTEGER,last_progress_at_ms INTEGER,
 deadline_observed INTEGER,PRIMARY KEY(project_id,handle_digest),UNIQUE(project_id,run_id),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE hook_ingestion(project_id TEXT NOT NULL,event_code TEXT NOT NULL,
 accepted_count INTEGER NOT NULL CHECK(accepted_count>=0),last_accepted_at_ms INTEGER NOT NULL,
 PRIMARY KEY(project_id,event_code),FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE orchestrations(project_id TEXT NOT NULL,orchestration_id TEXT NOT NULL,handle_digest TEXT NOT NULL,
 client_version TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN
 ('active','paused','completed','failed','interrupted','cancelled')),started_at_ms INTEGER NOT NULL,
 ended_at_ms INTEGER,goal_tokens_used INTEGER,goal_time_used_seconds INTEGER,expires_at_ms INTEGER NOT NULL,
 PRIMARY KEY(project_id,orchestration_id),UNIQUE(project_id,handle_digest),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE orchestration_checkpoints(project_id TEXT NOT NULL,orchestration_id TEXT NOT NULL,
 sequence INTEGER NOT NULL,status TEXT NOT NULL,goal_tokens_used INTEGER,goal_time_used_seconds INTEGER,
 observed_at_ms INTEGER NOT NULL,PRIMARY KEY(project_id,orchestration_id,sequence),
 FOREIGN KEY(project_id,orchestration_id) REFERENCES orchestrations(project_id,orchestration_id) ON DELETE CASCADE);
CREATE TABLE operational_qa(project_id TEXT NOT NULL,qa_id TEXT NOT NULL,qa_digest TEXT NOT NULL,
 host_outcome_digest TEXT NOT NULL,verifier_host_outcome_digest TEXT NOT NULL,accepted INTEGER NOT NULL
 CHECK(accepted IN (0,1)),observed_at_ms INTEGER NOT NULL,content BLOB NOT NULL,
 PRIMARY KEY(project_id,qa_id),UNIQUE(project_id,host_outcome_digest),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE operational_check_receipts(project_id TEXT NOT NULL,receipt_id TEXT NOT NULL,
 report_digest TEXT NOT NULL,host_outcome_digest TEXT NOT NULL,verifier_host_outcome_digest TEXT NOT NULL,
 orchestration_id TEXT NOT NULL,issued_at_ms INTEGER NOT NULL,expires_at_ms INTEGER NOT NULL,
 consumed_at_ms INTEGER,report BLOB NOT NULL,PRIMARY KEY(project_id,receipt_id),
 FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE);
CREATE TABLE tombstones(project_id TEXT NOT NULL,deletion_id TEXT NOT NULL,deleted_at_ms INTEGER NOT NULL,
 PRIMARY KEY(project_id,deletion_id));
"""


_BACKUP_RESTORE_SCHEMA += ('\nALTER TABLE host_run_bindings ADD COLUMN '+HISTORY_OWNER_COLUMN+';\n'
                           + ';\n'.join(sql for _, _, sql in OPEN_OBJECTS)+';\n')
_BACKUP_RESTORE_SCHEMA += ('\n' + RELEASE_SCHEMA + ';\nALTER TABLE capacity_executions ADD COLUMN '
                           + RELEASE_COLUMN + ';\n')


_BACKUP_RESTORE_SCHEMA += '\n' + OBSERVATION_ORIGIN_SCHEMA + ';\n' + OBSERVATION_SCHEMA + ';\n'
_BACKUP_RESTORE_SCHEMA += '\n' + ';\n'.join(sql for _, _, sql in BILLING_PROBE_OBJECTS) + ';\n'
# O0b RS-A: the hold register's table and index, not its triggers (a backup's rows are copied as they are).
_BACKUP_RESTORE_SCHEMA += '\n' + ';\n'.join(sql for kind, _, sql in RUN_HOLDS_OBJECTS if kind != 'trigger') + ';\n'

def _check_backup_coverage(restored: sqlite3.Connection, schema_version: int) -> None:
    """The cross-table coverage a restored partition of this ledger version must keep."""
    if schema_version >= 9 and restored.execute(
        "SELECT 1 FROM launch_claims c LEFT JOIN active_run_capacity a "
        "ON a.project_id=c.project_id AND a.handle_digest=c.handle_digest "
        "WHERE a.run_id IS NULL OR a.run_id<>c.run_id OR a.bridge_run_id IS NOT c.bridge_run_id LIMIT 1"
    ).fetchone() is not None:
        raise LedgerError("project backup capacity coverage is incomplete")
    if schema_version >= 9 and restored.execute(
        "SELECT 1 FROM active_run_capacity a LEFT JOIN capacity_completions c "
        "ON c.project_id=a.project_id AND c.handle_digest=a.handle_digest "
        "AND c.run_id=a.run_id AND c.bridge_run_id=a.bridge_run_id "
        "LEFT JOIN capacity_executions e ON e.project_id=a.project_id AND e.handle_digest=a.handle_digest "
        "AND e.run_id=a.run_id AND e.bridge_run_id=a.bridge_run_id "
        "WHERE (a.released_at_ms IS NOT c.released_at_ms OR a.release_digest IS NOT c.receipt_digest "
        "OR (a.released_at_ms IS NOT NULL AND e.owner_digest IS NULL)) "
        # O0b RS-A (F2): a slot released by a matching lost or crashed decision keeps its completion apart: no
        # completion yet, or a late one that still has its execution owner.
        # O0b RS-A round 2 G7: a completion exists once its terminal is stored, settled or not.
        + (f"AND NOT ({DECISION_RELEASED} AND (c.terminal_record_id IS NULL OR e.owner_digest IS NOT NULL)) "
           if schema_version >= 15 else "")
        + "LIMIT 1"
    ).fetchone() is not None:
        raise LedgerError("project backup completion coverage is incomplete")
    if schema_version >= 11 and not check_cleanup_coverage(restored):
        raise LedgerError('project backup cleanup coverage is incomplete')
    if schema_version >= 12 and not check_observation_coverage(restored):
        raise LedgerError('account observation coverage is unavailable')
    if schema_version >= 13 and not check_billing_probe_coverage(restored):
        raise LedgerError('project backup billing probe coverage is incomplete')
    if schema_version >= 15 and not check_run_holds_consistency(restored):
        raise LedgerError('project backup run hold coverage is incomplete')


def _verify_project_backup_body(
    body: Any,
    *,
    expected_project_id: str | None = None,
    expected_ledger_schema_version: int | None = None,
) -> dict[str, int]:
    if not isinstance(body, dict) or set(body) != {
        "schema_version", "ledger_schema_version", "project", "columns", "tables",
        "counts",
    }:
        raise LedgerError("project backup body is invalid")
    schema_version = body["ledger_schema_version"]
    if body["schema_version"] != 2 or schema_version not in {5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17}:
        raise LedgerError("project backup body is invalid")
    if (
        expected_ledger_schema_version is not None
        and schema_version != expected_ledger_schema_version
    ):
        raise LedgerError("project backup ledger version is invalid")
    project = body["project"]
    if not isinstance(project, dict) or set(project) != set(_BACKUP_PROJECT_COLUMNS):
        raise LedgerError("project backup project row is invalid")
    project_id = project.get("project_id")
    if not isinstance(project_id, str) or (
        expected_project_id is not None and project_id != expected_project_id
    ):
        raise LedgerError("project backup project partition is invalid")
    tables, counts, columns = body["tables"], body["counts"], body["columns"]
    expected_tables = set(_backup_tables(schema_version))
    if (
        not isinstance(tables, dict) or set(tables) != expected_tables
        or not isinstance(counts, dict) or set(counts) != expected_tables
        or not isinstance(columns, dict) or set(columns) != expected_tables
    ):
        raise LedgerError("project backup table manifest is invalid")
    restored = sqlite3.connect(":memory:")
    restored.row_factory = sqlite3.Row
    restored.execute("PRAGMA foreign_keys = ON")
    try:
        restored.executescript(_BACKUP_RESTORE_SCHEMA)
        project_values = [_backup_decode_value(project[name]) for name in _BACKUP_PROJECT_COLUMNS]
        restored.execute(
            f"INSERT INTO projects({','.join(_BACKUP_PROJECT_COLUMNS)}) VALUES(?,?,?,?,?,?)",
            project_values,
        )
        decoded_by_table: dict[str, list[dict[str, Any]]] = {}
        for table in _backup_tables(schema_version):
            declared = columns[table]
            expected = list(_backup_expected_columns(schema_version, table))
            rows = tables[table]
            if declared != expected or not isinstance(rows, list) or counts[table] != len(rows):
                raise LedgerError("project backup count or column manifest is invalid")
            if not declared and rows:
                raise LedgerError("project backup absent table has rows")
            decoded_rows = []
            for row in rows:
                if not isinstance(row, dict) or set(row) != set(declared):
                    raise LedgerError("project backup row shape is invalid")
                decoded = {name: _backup_decode_value(row[name]) for name in declared}
                decoded_rows.append(decoded)
                if table == "records":
                    try:
                        content = validate_learning_record(json.loads(bytes(decoded["content"])), stored=True)
                    except (ContractError, json.JSONDecodeError, TypeError, ValueError) as exc:
                        raise LedgerError("project backup contains a corrupt learning record") from exc
                    if content_digest(content) != decoded["content_digest"]:
                        raise LedgerError("project backup contains a corrupt learning record")
            decoded_by_table[table] = decoded_rows
            if declared:
                placeholders = ",".join("?" for _ in range(len(declared) + 1))
                try:
                    restored.executemany(
                        f"INSERT INTO {table}(project_id,{','.join(declared)}) VALUES({placeholders})",
                        [
                            [project_id, *(row[name] for name in declared)]
                            for row in decoded_rows
                        ],
                    )
                except sqlite3.IntegrityError as exc:
                    raise LedgerError("isolated project backup restoration rejected a row") from exc
        foreign_keys = restored.execute("PRAGMA foreign_key_check").fetchall()
        if foreign_keys:
            raise LedgerError("isolated project backup foreign-key check failed")
        _check_backup_coverage(restored, schema_version)
        integrity = restored.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise LedgerError("isolated project backup integrity check failed")
        for table, declared in columns.items():
            if not declared:
                continue
            actual = [
                {name: _backup_encode_value(row[name]) for name in declared}
                for row in restored.execute(
                    f"SELECT {','.join(declared)} FROM {table} WHERE project_id=?",
                    (project_id,),
                ).fetchall()
            ]
            expected_rows = tables[table]
            if sorted(canonical_json(row) for row in actual) != sorted(
                canonical_json(row) for row in expected_rows
            ):
                raise LedgerError("isolated project backup restoration changed rows")
    finally:
        restored.close()
    return {name: int(counts[name]) for name in _backup_tables(schema_version)}


def _verify_backup_envelope(
    raw: bytes,
    *,
    expected_project_id: str | None = None,
    expected_ledger_schema_version: int | None = None,
) -> tuple[dict[str, Any], dict[str, int], str]:
    try:
        envelope = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise LedgerError("project backup is invalid") from exc
    if not isinstance(envelope, dict) or set(envelope) != {"backup_sha256", "body"}:
        raise LedgerError("project backup envelope is invalid")
    manifest_digest = envelope["backup_sha256"]
    body = envelope["body"]
    if (
        not isinstance(manifest_digest, str)
        or hashlib.sha256(canonical_json(body)).hexdigest() != manifest_digest
    ):
        raise LedgerError("project backup manifest digest is invalid")
    counts = _verify_project_backup_body(
        body,
        expected_project_id=expected_project_id,
        expected_ledger_schema_version=expected_ledger_schema_version,
    )
    return body, counts, manifest_digest




def _prepare_default_state_root() -> Path:
    """The default state root, its missing parent folders created owner-only."""

    from .host_paths import HostPathError, prepare_default_state_root

    try:
        return prepare_default_state_root()
    except HostPathError as exc:
        raise StateError(str(exc)) from None


# The pre-0.8.10 macOS folder (host_paths.legacy_state_root) is moved once, by the
# owner's `learning-register`; every other use of the default state refuses while
# only the old folder exists, so nothing starts a second, empty state beside it.
BOTH_STATES = (
    "the learning state exists both in its old macOS folder "
    "(~/Library/Application Support/codex-agents) and in its new one "
    "(~/.local/state/codex-agents, or $XDG_STATE_HOME/codex-agents); keep the one in "
    "use, move the other out of both places, then run ./setup.sh (collector step) again"
)
STATE_MOVE_FAILED = (
    "the learning state could not be copied from ~/Library/Application Support/codex-agents "
    "to ~/.local/state/codex-agents (or $XDG_STATE_HOME/codex-agents), for example because "
    "the disk is full; the old folder was not changed. Fix the cause, then run ./setup.sh "
    "(collector step) again"
)
LINKED_STATE = (
    "the old learning state folder holds a file with a second hard link, a symbolic link "
    "or a special file, which something else could still use to change the state; nothing "
    "was copied. Remove the extra link or file, then run ./setup.sh (collector step) again"
)
STATE_IN_USE = (
    "the old learning state is still in use by another process; close every Codex and "
    "Claude session, then run ./setup.sh (collector step) again"
)
STATE_COPY_INVALID = (
    "the copied learning state did not pass its checks (permissions, owner key or database "
    "integrity); the old folder was not changed. Run ./setup.sh (collector step) again, "
    "and report it if it repeats"
)
LEGACY_NOT_REVIEWED = (
    "the learning state is still in its old macOS folder "
    "(~/Library/Application Support/codex-agents), and it is moved only after you have "
    "reviewed it: run ./setup.sh (collector step), which shows its owner key and asks first"
)
LEGACY_CHANGED = (
    "the owner key record in the old macOS learning state folder is not the one you "
    "reviewed (it changed, or something else was approved); nothing was moved. Run "
    "./setup.sh (collector step) again and check it before moving"
)
STATE_SOCKET_TOO_LONG = (
    "the new learning state folder's path is too long for the collector's local socket; "
    "set XDG_STATE_HOME to a shorter folder, or unset it, then run ./setup.sh "
    "(collector step) again"
)
# sun_path holds 104 bytes on macOS and 108 on Linux, with a terminating NUL.
UNIX_SOCKET_PATH_MAX = 103 if sys.platform == "darwin" else 107




# Not copied: the stale socket, lock files (recreated on use), the database and
# its journals (copied through SQLite's backup API), and transient scratch.
_STATE_COPY_SKIPPED = frozenset({
    "collector.sock", "collector.lock", "collector-runtime.lock",
    "collector-client-health.lock", "scratch", "learning.sqlite3",
    "learning.sqlite3-wal", "learning.sqlite3-shm", "learning.sqlite3-journal",
})
_STATE_COPY_CHUNK = 1 << 20


def _authoritative_file(info: os.stat_result) -> bool:
    """A regular file of this user with exactly one hard link."""

    return stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == os.geteuid()


def _copy_state_tree(source: int, target: int, *, top: bool) -> None:
    """Copy a state folder into fresh inodes, refusing links and special files.

    Every file is opened without following symlinks and recreated with
    O_EXCL|O_NOFOLLOW (0600), every folder with 0700, so no hard link or
    descriptor taken on the old files reaches the copy.
    """

    with os.scandir(source) as entries:
        names = sorted(entry.name for entry in entries)
    for name in names:
        if top and name in _STATE_COPY_SKIPPED:
            continue
        info = os.stat(name, dir_fd=source, follow_symlinks=False)
        if stat.S_ISDIR(info.st_mode) and info.st_uid == os.geteuid():
            os.mkdir(name, 0o700, dir_fd=target)
            child_source = os.open(
                name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=source
            )
            try:
                child_target = os.open(
                    name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=target
                )
                try:
                    os.fchmod(child_target, 0o700)
                    _copy_state_tree(child_source, child_target, top=False)
                finally:
                    os.close(child_target)
            finally:
                os.close(child_source)
            continue
        if not _authoritative_file(info):
            raise StateError(LINKED_STATE)
        _copy_state_file(source, target, name)


def _copy_state_file(source: int, target: int, name: str) -> None:
    reader = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=source)
    try:
        if not _authoritative_file(os.fstat(reader)):
            raise StateError(LINKED_STATE)
        writer = os.open(
            name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=target
        )
        try:
            os.fchmod(writer, 0o600)
            while chunk := os.read(reader, _STATE_COPY_CHUNK):
                view = memoryview(chunk)
                while view:
                    view = view[os.write(writer, view):]
            os.fsync(writer)
        finally:
            os.close(writer)
    finally:
        os.close(reader)


def _backup_state_database(old: "LearningState", staged: Path) -> None:
    """Copy the ledger consistently into a fresh file with SQLite's backup API.

    The backup proceeds page by page, so the ledger is never read into memory
    at once; the copy must pass `quick_check`.
    """

    for suffix in ("", "-wal", "-shm", "-journal"):
        path = Path(str(old.database) + suffix)
        try:
            info = os.lstat(path)
        except FileNotFoundError:
            continue
        if not _authoritative_file(info):
            raise StateError(LINKED_STATE)
    target = staged / old.database.name
    os.close(os.open(
        target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600
    ))
    if not old.database.exists():
        return
    source = sqlite3.connect(old.database, timeout=5)
    try:
        copy = sqlite3.connect(target)
        try:
            source.backup(copy, pages=4096)
            if copy.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise StateError(STATE_COPY_INVALID)
        finally:
            copy.close()
    finally:
        source.close()
    os.chmod(target, 0o600)


def _validate_staged_state(staged: Path) -> None:
    """The copy's folders, files, owner key and digest key pass the usual checks."""

    try:
        state = LearningState(staged, create=False)
        for current, folders, files in os.walk(staged, followlinks=False):
            for name in folders:
                _check_owner_mode(Path(current) / name, directory=True)
            for name in files:
                _check_owner_mode(Path(current) / name, directory=False)
        if state.key_path.exists():
            state.digest_key()
        if state.allowed_signers_path.exists() and state.allowed_signers_path.stat().st_size:
            state.owner_allowed_signers()
        state.harden_database_files()
    except (StateError, OSError) as exc:
        raise StateError(STATE_COPY_INVALID) from exc


LEGACY_SIGNERS_READ_LIMIT = 65_536


def legacy_signers_digest(root: Path) -> str:
    """SHA-256 of `<root>/owner-allowed-signers` as the owner reviewed it, or "none".

    Read through a no-follow descriptor, bounded; anything but a regular file refuses.
    """

    try:
        descriptor = os.open(root / "owner-allowed-signers", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return "none"
    except OSError as exc:
        raise StateError(LEGACY_CHANGED) from exc
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise StateError(LEGACY_CHANGED)
        # Bounded well above a valid record, so an oversized one still fails the copy's
        # own checks (with their message) rather than this one.
        content = os.read(descriptor, LEGACY_SIGNERS_READ_LIMIT + 1)
    finally:
        os.close(descriptor)
    if len(content) > LEGACY_SIGNERS_READ_LIMIT:
        raise StateError(LEGACY_CHANGED)
    return hashlib.sha256(content).hexdigest()


def migrate_legacy_state(
    cli_path: Path, project_root: Path, approved_signers: str | None = None
) -> Path | None:
    """Copy the pre-0.8.10 macOS learning state to the default folder, once (owner).

    Only the owner's `learning-register` calls this, and only while the old
    folder is the only one. With the collector stopped and its maintenance
    lock held (CollectorMaintenance, as for registration) and the ledger's
    writer lock taken, every file is copied into fresh inodes in an owner-only
    staging folder beside the new location (the ledger through SQLite's backup
    API); a file with a second hard link, a symlink or a special file refuses
    first, since a link or descriptor taken on the old files must not reach the
    new state. The staged copy is checked, renamed into place in one step, and
    the old folder is renamed to `codex-agents.moved-<UTC time>` beside itself,
    inert. On any failure the staging folder is removed and the old folder is
    left as it was. Returns the old copy's new path, or None when nothing was
    moved; both folders present refuses.

    The old folder sits where a session opened on `~/Library` could have created
    it, so it moves only with the owner's approval: `approved_signers` is the
    SHA-256 of its `owner-allowed-signers` (or "none") that the wizard showed the
    owner with that key's fingerprint. Without it the move refuses, and the staged
    copy's signer file must match it before anything is renamed.
    """

    from .host_paths import (
        HostPathError,
        _open_verified_directory,
        legacy_state_root,
        remove_tree_at,
    )

    legacy = legacy_state_root()
    if legacy is None or not os.path.lexists(legacy):
        return None
    target = default_state_root()
    if os.path.lexists(target):
        raise StateError(BOTH_STATES)
    if approved_signers is None:
        raise StateError(LEGACY_NOT_REVIEWED)
    if approved_signers != "none" and (
        len(approved_signers) != 64 or any(ch not in "0123456789abcdef" for ch in approved_signers)
    ):
        raise StateError(LEGACY_CHANGED)
    if legacy_signers_digest(legacy) != approved_signers:
        raise StateError(LEGACY_CHANGED)
    if len(os.fsencode(str(target / "collector.sock"))) > UNIX_SOCKET_PATH_MAX:
        raise StateError(STATE_SOCKET_TOO_LONG)
    old = LearningState(legacy, create=False)
    _prepare_default_state_root()
    if _inside_git_tree(target.parent):
        raise StateError("state root must be outside a Git working tree")
    try:
        parent, parent_path = _open_verified_directory(target.parent)
    except (HostPathError, OSError) as exc:
        raise StateError(STATE_MOVE_FAILED) from exc
    staging_name = f".{target.name}.staging-{secrets.token_hex(6)}"
    staged = parent_path / staging_name
    aside = old.root.with_name(
        f"{old.root.name}.moved-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}"
    )
    try:
        maintenance = CollectorMaintenance.acquire(
            old, cli_path, project_root, owner_registration=True
        )
        moved = False
        writer = None
        try:
            if fcntl is not None:
                writer = os.open(
                    old.lock, os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600
                )
                try:
                    fcntl.flock(writer, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError as exc:
                    raise StateError(STATE_IN_USE) from exc
            if os.path.lexists(target) or os.path.lexists(aside):
                raise StateError(BOTH_STATES)
            os.mkdir(staging_name, 0o700, dir_fd=parent)
            try:
                source = os.open(old.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                try:
                    staging = os.open(
                        staging_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                        dir_fd=parent,
                    )
                    try:
                        os.fchmod(staging, 0o700)
                        _copy_state_tree(source, staging, top=True)
                    finally:
                        os.close(staging)
                finally:
                    os.close(source)
                _backup_state_database(old, staged)
                # The fresh copy, which nothing else can reach, is what the owner approved.
                if legacy_signers_digest(staged) != approved_signers:
                    raise StateError(LEGACY_CHANGED)
                _validate_staged_state(staged)
                os.rename(staging_name, target.name, src_dir_fd=parent, dst_dir_fd=parent)
                try:
                    os.rename(old.root, aside)
                except OSError:
                    os.rename(target.name, staging_name, src_dir_fd=parent, dst_dir_fd=parent)
                    raise
                moved = True
            except StateError:
                raise
            except (OSError, sqlite3.Error) as exc:
                raise StateError(STATE_MOVE_FAILED) from exc
            finally:
                if not moved:
                    with contextlib.suppress(OSError):
                        remove_tree_at(parent, staging_name)
        finally:
            if writer is not None:
                with contextlib.suppress(OSError):
                    fcntl.flock(writer, fcntl.LOCK_UN)
                os.close(writer)
            if moved:
                # Never restart a collector at the old folder; registration starts it.
                maintenance.restart = False
                maintenance.resume()
            else:
                with contextlib.suppress(CollectorError, OSError):
                    maintenance.resume()
    finally:
        os.close(parent)
    LearningState(target, create=False)
    return aside


def _inside_git_tree(path: Path) -> bool:
    return any((parent / ".git").exists() for parent in (path, *path.parents))








# The folder setup keeps for itself in the state root (scripts/install.py OwnerState.FOLDER).
INSTALLER_FOLDER = "installer"
# Where the whole ledger is copied before the owner's approved upgrade, and how long
# the per-project copies taken with it are kept.
UPGRADE_COPY_FOLDER = "ledger-before-upgrade"
UPGRADE_BACKUP_MS = 30 * 24 * 60 * 60 * 1000
# A project backup is streamed (project_backup.py), so memory never bounds it.
# This bounds one project's planned file, and the disk must hold every planned
# file twice over (each is checked before the next is written) plus a margin.
MAX_PROJECT_BACKUP_BYTES = 16 * 1024 ** 3
BACKUP_SPACE_FACTOR = 2
BACKUP_SPACE_MARGIN_BYTES = 256 * 1_048_576


class LedgerCapacityError(LedgerError):
    """A backup cannot be made: one project is over the limit, or the disk is too small.

    Raised before any backup file is written. It carries sizes and a project's
    position in backup order, never an identifier, root or record.
    """

    def __init__(self, *, projects: int, project_number: int | None = None, needed_bytes: int,
                 limit_bytes: int | None = None, available_bytes: int | None = None):
        self.capacity = {"projects": projects, "project_number": project_number, "needed_bytes": needed_bytes,
                         "limit_bytes": limit_bytes, "available_bytes": available_bytes}
        super().__init__("project backup does not fit" if available_bytes is None
                         else "project backups do not fit in the free disk space")


def project_backup_bytes(connection: sqlite3.Connection, project_id: str, schema_version: int) -> int:
    """The planned size of one project's backup in this ledger version."""
    from .project_backup import estimate_bytes

    return estimate_bytes(connection, project_id, schema_version)


def _file_identity(info: os.stat_result) -> tuple:
    """Which file, and whether it changed: a swapped-in copy differs in inode or change time."""
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def _free_backup_bytes(path: Path) -> int:
    return int(shutil.disk_usage(path).free)


def _schema_behind(database: Path) -> int | None:
    """The schema requiring a project-record upgrade, else None (additive, current, newer, new or absent).

    A ledger that is there but cannot be read is an error, never taken for a current one.
    """

    try:
        if not database.is_file() or not database.stat().st_size:
            return None
        # The path goes in as a URI built from the path itself, so no character
        # in it can name another file or an option.
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=5)
        try:
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        finally:
            connection.close()
    except (OSError, sqlite3.Error, TypeError, ValueError) as error:
        raise LedgerError("the ledger cannot be read to check which version wrote it") from error
    # Step 16->17 adds only the machine-local owner epoch, like the additive
    # launch/wake steps: no project records change or need upgrade consent.
    return version if 5 <= version < LEDGER_SCHEMA_VERSION and version != 16 else None


def ledger_schema_behind(state: "LearningState") -> int | None:
    """This ledger's schema when a project-record upgrade needs consent, else None."""

    return _schema_behind(state.database)


def legacy_ledger_schema_behind() -> int | None:
    """The same for the pre-0.8.10 macOS folder while it is the only state there is.

    Read only once the owner has approved that folder as theirs, so that both of
    the owner's decisions (move it, upgrade it) are in hand before either is acted on.
    """

    from .host_paths import legacy_state_root

    legacy = legacy_state_root()
    if legacy is None or not os.path.lexists(legacy) or os.path.lexists(default_state_root()):
        return None
    return _schema_behind(Path(legacy) / "learning.sqlite3")


def copy_ledger_before_upgrade(state: "LearningState", schema_version: int) -> Path:
    """Copy the whole ledger, checked, before an upgrade changes it; the copy's path.

    Called with the collector stopped. The copy is what puts everything back as it
    was: SQLite writes it page by page from a consistent view, and it is accepted
    only if it is sound, names the same schema and holds the same number of rows in
    every table. It stays until the owner deletes it.
    """

    folder = state.root / UPGRADE_COPY_FOLDER
    folder.mkdir(mode=0o700, exist_ok=True)
    _assert_no_symlink_components(folder)
    _check_owner_mode(folder, directory=True)
    target = folder / f"learning-schema{schema_version}-{time.time_ns() // 1_000_000}.sqlite3"
    descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    os.close(descriptor)

    def counts(connection: sqlite3.Connection) -> dict[str, int]:
        tables = [str(row[0]) for row in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        return {name: int(connection.execute(f'SELECT count(*) FROM "{name}"').fetchone()[0]) for name in tables}

    try:
        source = sqlite3.connect(state.database.as_uri() + "?mode=ro", uri=True, timeout=5)
        try:
            copy = sqlite3.connect(target)
            try:
                source.backup(copy)
                sound = (copy.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
                         and int(copy.execute("PRAGMA user_version").fetchone()[0]) == schema_version
                         and counts(copy) == counts(source))
            finally:
                copy.close()
        finally:
            source.close()
        if not sound:
            raise LedgerError("the ledger could not be copied before its upgrade; nothing was changed")
        os.chmod(target, 0o600)
        descriptor = os.open(folder, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except BaseException as error:
        with contextlib.suppress(OSError):
            target.unlink()
        if isinstance(error, (OSError, ValueError, sqlite3.Error)):
            raise LedgerError("the ledger could not be copied before its upgrade; nothing was changed") from error
        raise
    return target


class LearningState:
    """Validated paths and the local keyed-digest secret."""

    def __init__(self, root: Path | None = None, *, create: bool = True) -> None:
        if root is None:
            if _unmoved_legacy_state():
                raise StateError(UNMOVED_STATE)
            # The folders above the default state are checked, and created
            # owner-only, before the state itself.
            requested = _prepare_default_state_root() if create else default_state_root()
        else:
            requested = root.expanduser()
        if not requested.is_absolute():
            raise StateError("state root must be absolute")
        _assert_no_symlink_components(requested)
        if _inside_git_tree(requested):
            raise StateError("state root must be outside a Git working tree")
        existed = requested.exists()
        if create:
            requested.mkdir(parents=True, exist_ok=True, mode=0o700)
            if not existed:
                os.chmod(requested, 0o700)
        if not requested.is_dir():
            raise StateError("state root must be a directory")
        resolved = requested.resolve(strict=True)
        _assert_no_symlink_components(resolved)
        _check_owner_mode(resolved, directory=True)
        self.root = resolved
        self.artifacts = self._directory("artifacts", create=create)
        self.exports = self._directory("exports", create=create)
        self.backups = self._directory("backups", create=create)
        self.database = self.root / "learning.sqlite3"
        self.socket = self.root / "collector.sock"
        self.lock = self.root / "collector.lock"
        self.runtime_lock = self.root / "collector-runtime.lock"
        self.collector_authorization = self.root / "collector-authorization.json"
        self.client_health_lock = self.root / "collector-client-health.lock"
        self.client_health = self.root / "collector-client-health.json"
        self.key_path = self.root / "digest.key"
        self.allowed_signers_path = self.root / "owner-allowed-signers"
        self.initializing = self.root / "ledger-initializing"
        self.initialized = self.root / "ledger-initialized"
        self._prepare_database(create=create)
        if create:
            self._create_empty_file(self.database)
            self._create_key(self.key_path)
            self._create_empty_file(self.allowed_signers_path)
        if create:
            _check_owner_mode(self.database, directory=False)
            _check_owner_mode(self.key_path, directory=False)
            _check_owner_mode(self.allowed_signers_path, directory=False)

    def _marker_exists(self, path: Path) -> bool:
        if not os.path.lexists(path):
            return False
        _assert_no_symlink_components(path)
        _check_owner_mode(path, directory=False)
        if not path.is_file():
            raise StateError("ledger initialization marker is invalid")
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        with os.fdopen(descriptor, "rb") as handle:
            if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode) or handle.read(3) != b"1\n":
                raise StateError("ledger initialization marker is invalid")
        return True

    def _write_marker(self, path: Path) -> None:
        if not self._marker_exists(path):
            temporary = self.root / f".{path.name}.{secrets.token_hex(8)}.tmp"
            try:
                descriptor = os.open(
                    temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                    0o600,
                )
                with os.fdopen(descriptor, "wb") as handle:
                    handle.write(b"1\n")
                    handle.flush()
                    os.fsync(handle.fileno())
                # Publish only the complete, durable contents. Process death
                # while writing leaves no invalid authoritative marker.
                os.replace(temporary, path)
            finally:
                temporary.unlink(missing_ok=True)
        self._sync_root()

    def _initial_bootstrap_entry(self, path: Path) -> bool:
        if path in (self.artifacts, self.exports, self.backups):
            return path.is_dir() and not any(path.iterdir())
        if path == self.root / INSTALLER_FOLDER:
            # Setup's own folder (which deny rules it added to each project). Setup
            # installs a project before it first registers one, so a new owner's
            # root already holds it. It is no part of a ledger and is never read here.
            _assert_no_symlink_components(path)
            _check_owner_mode(path, directory=True)
            return path.is_dir()
        if path in (self.client_health, self.client_health_lock):
            # Counters a client kept when it found no collector yet: not authority either.
            _assert_no_symlink_components(path)
            _check_owner_mode(path, directory=False)
            return path.is_file()
        if re.fullmatch(r"\.ledger-initializing\.[0-9a-f]{16}\.tmp", path.name):
            # A crash before initial publication can leave this untrusted
            # scratch file. Preserve it; never read it or treat it as proof.
            _assert_no_symlink_components(path)
            _check_owner_mode(path, directory=False)
            return path.is_file()
        return False

    def _sync_root(self) -> None:
        descriptor = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _prepare_database(self, *, create: bool) -> None:
        initialized = self._marker_exists(self.initialized)
        pending = self._marker_exists(self.initializing)
        if os.path.lexists(self.database):
            if self.database.is_symlink():
                raise StateError("database path is unsafe")
            _assert_no_symlink_components(self.database)
            _check_owner_mode(self.database, directory=False)
            if not self.database.is_file():
                raise StateError("database path is unsafe")
            if self.database.stat().st_size:
                # An existing ledger must never receive a replacement digest key.
                for path in (self.key_path, self.allowed_signers_path):
                    _assert_no_symlink_components(path)
                    try:
                        _check_owner_mode(path, directory=False)
                    except OSError as exc:
                        raise StateError("existing ledger authority file is unavailable") from exc
                return
        if initialized:
            raise StateError("initialized ledger database is missing or empty; verified recovery is required")
        if pending and (create or self.database.is_file()):
            return
        # Only an otherwise empty owner root can begin an initial bootstrap.
        # Existing keys, authorization or backup material are not proof of a new store.
        if create and all(
            self._initial_bootstrap_entry(path)
            for path in self.root.iterdir()
        ):
            self._write_marker(self.initializing)
            return
        raise StateError("ledger database is missing or empty; verified recovery is required")

    def mark_initialized(self) -> None:
        self._write_marker(self.initialized)
        self.initializing.unlink(missing_ok=True)
        self._sync_root()

    @staticmethod
    def _create_key(path: Path) -> None:
        if path.exists():
            return
        descriptor = os.open(
            path,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(secrets.token_bytes(32))
            handle.flush()
            os.fsync(handle.fileno())

    @staticmethod
    def _create_empty_file(path: Path) -> None:
        if path.exists():
            return
        descriptor = os.open(
            path,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        os.close(descriptor)

    def _directory(self, name: str, *, create: bool) -> Path:
        path = self.root / name
        if path.is_symlink():
            raise StateError("state path contains a symlink component")
        existed = path.exists()
        if create:
            path.mkdir(mode=0o700, exist_ok=True)
            if not existed:
                os.chmod(path, 0o700)
        if path.exists():
            _assert_no_symlink_components(path)
            _check_owner_mode(path, directory=True)
        return path

    def digest_key(self) -> bytes:
        key = self._read_key(self.key_path, "digest")
        return key

    @staticmethod
    def _read_key(path: Path, label: str) -> bytes:
        if path.is_symlink():
            raise StateError(f"{label} key path is unsafe")
        _check_owner_mode(path, directory=False)
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        with os.fdopen(descriptor, "rb") as handle:
            if os.fstat(handle.fileno()).st_nlink != 1:
                raise StateError(f"{label} key path is unsafe")
            key = handle.read(33)
        if len(key) != 32:
            raise StateError(f"{label} key has an invalid length")
        return key

    @staticmethod
    def _owner_signer_content(public_key: str) -> bytes:
        """The one canonical signer line for a public SSH key."""

        fields = public_key.strip().split()
        allowed_types = {
            "ssh-ed25519", "sk-ssh-ed25519@openssh.com", "ssh-rsa",
            "ecdsa-sha2-nistp256", "sk-ecdsa-sha2-nistp256@openssh.com",
        }
        if (
            len(fields) < 2
            or fields[0] not in allowed_types
            or not fields[1]
            or any(character not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" for character in fields[1])
            or "PRIVATE" in public_key
        ):
            raise StateError("owner public key is invalid")
        try:
            blob = base64.b64decode(fields[1], validate=True)
            parts = _ssh_key_parts(blob)
            _require_canonical_key(fields[0], parts)
        except ValueError as exc:
            raise StateError("owner public key is invalid") from exc
        if base64.b64encode(blob).decode("ascii") != fields[1]:
            raise StateError("owner public key is invalid")
        return f"codex-agents-owner {fields[0]} {fields[1]}\n".encode("ascii")

    def install_owner_public_key(self, public_key: str) -> Path:
        """Install one public SSH key; private signing material never enters state.

        Only the first key: once the ledger has recorded one, an emptied file does not
        open the door to another, and the same key may only be put back.
        """

        content = self._owner_signer_content(public_key)
        # Looked at and written in one turn: of two first configurations at the same
        # moment, the second finds the first one's key and follows the rule above.
        with self._owner_key_turn():
            existing = self.allowed_signers_path.read_bytes()
            if existing:
                if existing == content:
                    return self.allowed_signers_path
                raise StateError(
                    f"owner public key is already configured; to change it, {OWNER_KEY_REPLACE_HINT}"
                )
            recorded = self.recorded_owner_key()
            if recorded is not None and recorded["signer_line"] != content:
                raise StateError(
                    f"an owner key is already on record; to change it, {OWNER_KEY_REPLACE_HINT}"
                )
            return self._write_owner_signers(content)

    @contextlib.contextmanager
    def _owner_key_turn(self) -> Iterator[None]:
        """One change of the owner's signer file at a time, across threads and processes.

        Held on the state root itself, so it needs no file of its own there.
        """

        descriptor = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            if fcntl is not None:
                deadline = time.monotonic() + OWNER_KEY_TURN_SECONDS
                while True:
                    try:
                        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except OSError as error:
                        if time.monotonic() >= deadline:
                            raise StateError("another owner key change is in progress; try again") from error
                        time.sleep(0.01)
            # Every writer holds this turn for as long as its temporary file exists, so
            # one found now was left by a write that was interrupted (by this version or,
            # under one fixed name, an earlier one). They hold a public key and were never
            # the signer file.
            for leftover in self.root.glob(".owner-allowed-signers*.tmp"):
                with contextlib.suppress(OSError):
                    leftover.unlink()
            yield
        finally:
            os.close(descriptor)

    def _write_owner_signers(self, content: bytes) -> Path:
        # A name of its own, so no other writer's file is ever the one removed or renamed.
        temporary = self.root / f".owner-allowed-signers.{secrets.token_hex(8)}.tmp"
        descriptor = os.open(
            temporary,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.allowed_signers_path)
            os.chmod(self.allowed_signers_path, 0o600)
        except BaseException:
            with contextlib.suppress(OSError):
                temporary.unlink()
            raise
        return self.allowed_signers_path

    def owner_allowed_signers(self) -> Path:
        """The allowed-signers file, only while it passes `owner_signer_line`."""

        self.owner_signer_line()
        return self.allowed_signers_path

    def _owner_signer_bytes(self) -> bytes:
        """Bounded checked signer-file bytes; the persistence owner checks history.

        It must be exactly the single canonical line `install_owner_public_key` writes:
        `ssh-keygen -Y verify` accepts a signature from any key the file lists, so a second
        line, options or a comment would let another key sign as the owner.
        """

        if self.allowed_signers_path.is_symlink():
            raise StateError("owner allowed-signers path is unsafe")
        # One owner-only file with a single hard link: a second link (say, in a
        # project) would let whoever holds it replace the owner's key.
        _check_owner_mode(self.allowed_signers_path, directory=False)
        expected = self.allowed_signers_path.lstat()
        if not stat.S_ISREG(expected.st_mode):
            raise StateError("owner allowed-signers path is unsafe")
        descriptor = os.open(
            self.allowed_signers_path,
            os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0),
        )
        with os.fdopen(descriptor, "rb") as handle:
            actual = os.fstat(handle.fileno())
            if (
                not stat.S_ISREG(actual.st_mode) or actual.st_nlink != 1
                or stat.S_IMODE(actual.st_mode) != 0o600
                or (hasattr(os, "getuid") and actual.st_uid != os.getuid())
                or (actual.st_dev, actual.st_ino) != (expected.st_dev, expected.st_ino)
            ):
                raise StateError("owner allowed-signers path is unsafe")
            content = handle.read(OWNER_SIGNERS_MAX_BYTES + 1)
        if not content:
            raise OwnerSignerNotConfigured("owner public key is not configured")
        # The whole file must be the one line: ssh-keygen reads all of it, and a
        # key after an over-long first line would otherwise go unchecked.
        if len(content) > OWNER_SIGNERS_MAX_BYTES or OWNER_SIGNER_LINE.fullmatch(content) is None:
            raise StateError("owner allowed-signers must name exactly one owner key")
        return content

    def owner_signer_line(self) -> bytes:
        """The checked signer line only while it agrees with recorded owner history."""

        content = self._owner_signer_bytes()
        recorded = self.recorded_owner_key()
        if recorded is not None and recorded["signer_line"] != content:
            raise StateError(
                f"owner allowed-signers is not the owner key on record; {OWNER_KEY_REPLACE_HINT}"
            )
        return content

    def recorded_owner_key(self) -> dict[str, Any] | None:
        """The owner key the ledger last recorded, or None before one is recorded.

        Read fresh every time, so a long-running collector sees what the file is checked
        against now. A ledger that cannot be read fails closed.
        """

        if self.database.is_symlink():
            raise StateError("database path is unsafe")
        if not self.database.is_file() or self.database.stat().st_size == 0:
            return None
        try:
            connection = sqlite3.connect(f"{self.database.as_uri()}?mode=ro", uri=True, timeout=1)
            try:
                if connection.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='owner_key_history'"
                ).fetchone() is None:
                    return None
                row = connection.execute(
                    "SELECT signer_line,recorded_at_ms FROM owner_key_history "
                    "ORDER BY sequence DESC LIMIT 1"
                ).fetchone()
                replaced = connection.execute(
                    "SELECT COUNT(*),MAX(recorded_at_ms) FROM owner_key_history "
                    "WHERE reason='replaced'"
                ).fetchone()
            finally:
                connection.close()
        except sqlite3.Error as exc:
            raise StateError("the owner key record could not be read") from exc
        if row is None:
            return None
        return {
            "signer_line": bytes(row[0]),
            "recorded_at_ms": int(row[1]),
            "replacements": int(replaced[0]),
            "last_replaced_at_ms": replaced[1],
        }

    def owner_key_report(self) -> dict[str, Any]:
        """Which owner key is in force and when it last changed; public material only."""

        report: dict[str, Any] = {
            "state": "not_configured", "fingerprint": None,
            "replacements": 0, "last_replaced_at_ms": None,
        }
        recorded = None
        try:
            recorded = self.recorded_owner_key()
            if recorded is not None:
                report.update(
                    fingerprint=_signer_fingerprint(recorded["signer_line"]),
                    replacements=recorded["replacements"],
                    last_replaced_at_ms=recorded["last_replaced_at_ms"],
                )
            self.owner_allowed_signers()
            report["state"] = "ok"
        except (StateError, OSError, ValueError) as exc:
            not_configured = recorded is None and (
                isinstance(exc, FileNotFoundError) or "not configured" in str(exc)
            )
            report["state"] = "not_configured" if not_configured else "mismatch"
        return report

    def harden_database_files(self) -> None:
        for suffix in ("", "-wal", "-shm", "-journal"):
            path = Path(str(self.database) + suffix)
            if path.exists():
                if path.is_symlink() or not path.is_file():
                    raise StateError("database state contains an unsafe path")
                _check_owner_mode(path, directory=False)


def registered_project_roots() -> list[Path]:
    """Active registered project roots, read-only, for the wizard's session warning.

    Read from whichever folder holds the owner's state now
    (host_paths.owner_state_root); an unreadable ledger gives none.
    """

    from .host_paths import HostPathError, owner_state_root

    try:
        state = LearningState(owner_state_root(), create=False)
        if state.database.is_symlink() or not state.database.is_file():
            return []
        connection = sqlite3.connect(f"{state.database.as_uri()}?mode=ro", uri=True, timeout=1)
        try:
            rows = connection.execute(
                "SELECT canonical_root FROM projects WHERE status='active' "
                "AND canonical_root IS NOT NULL LIMIT 256"
            ).fetchall()
        finally:
            connection.close()
    except (StateError, HostPathError, OSError, sqlite3.Error):
        return []
    return [
        Path(row[0]) for row in rows if isinstance(row[0], str) and os.path.isabs(row[0])
    ]










def authorize_collector_runtime(
    state: LearningState, cli_path: Path, *, project_root: Path | None = None
) -> dict[str, str | int]:
    """Authorize one validated runtime during explicit owner registration."""

    identity = validate_collector_runtime(cli_path)
    current: dict[str, str | int] | None = None
    if (
        state.collector_authorization.exists()
        or state.collector_authorization.is_symlink()
    ):
        current = _collector_runtime_authorization(state, allow_quiesced=True)
    if current is not None:
        current_version = _version_tuple(current["runtime_version"])
        requested_version = _version_tuple(identity["runtime_version"])
        if current_version is None or requested_version is None:  # validated above
            raise CollectorAuthorizationError("collector runtime version is invalid")
        if current_version > requested_version:
            raise CollectorNewerVersionError(
                compatibility_message(current["runtime_version"], project_root=project_root,
                                      orchestration_root=cli_path.parent),
                code="runtime_newer",
            )
        if current_version == requested_version:
            if current["runtime_digest"] != identity["runtime_digest"]:
                raise CollectorBuildConflictError(
                    "authorized collector build conflicts with this package version",
                    code="runtime_conflict",
                )
            if current.get("quiesced_for_upgrade") is not True:
                return current
    temporary = state.root / f".collector-authorization.{secrets.token_hex(8)}.tmp"
    descriptor = os.open(
        temporary,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(canonical_json(identity) + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, state.collector_authorization)
        os.chmod(state.collector_authorization, 0o600)
        root_descriptor = os.open(state.root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(root_descriptor)
        finally:
            os.close(root_descriptor)
    finally:
        with contextlib.suppress(FileNotFoundError):
            temporary.unlink()
    return identity




@dataclass(frozen=True)
class SessionBinding:
    token: str
    project_id: str
    session_digest: str
    producer: str
    root_run_id: str
    coverage: str
    event_codes: frozenset[str]
    expires_at_ms: int


class _RecheckDenied(Exception):
    """An open's locked admission re-check denied; carries the decision to store."""

    def __init__(self, decision: dict[str, Any]) -> None:
        super().__init__(decision["reason_code"])
        self.decision = decision


@dataclass(frozen=True, repr=False)
class _PreparedAttestations:
    """Owner-local verification work, not a serializable/native caller grant."""

    origin: object
    project_id: str
    provider: str
    owner: tuple[int, bytes, str, int] | None
    signer: bytes | None
    rows: tuple[tuple[str, int, bytes, str, str, bytes | None], ...]
    verified: frozenset[str]


@dataclass(frozen=True, repr=False)
class _ClaimRequest:
    """Captured owner-local request data; never a launch or caller capability."""

    origin: object
    project_id: str
    runtime_digest: str
    caller_scope: str
    request_id: str
    launch: LaunchClaimInput
    handle: str
    scope: str
    request: str
    parameters: str
    run_context: tuple | None = None
    storage_required: bool = False
    storage_binding: object = None
    storage_evidence: bytes | None = None


# S1-H1a: SQLite VM steps allowed for one slot-health read.
SLOT_HEALTH_STEPS = 200_000

class LearningLedger:
    """The only SQLite writer. Callers receive scoped repositories, never its connection."""

    def __init__(
        self,
        state: LearningState,
        *,
        client_capabilities: dict[str, dict[str, Any]] | None = None,
        admission_policy: dict[str, Any] | None = None,
        allow_schema_upgrade: bool = False,
        backup_before_upgrade: bool = False,
    ) -> None:
        if type(allow_schema_upgrade) is not bool or type(backup_before_upgrade) is not bool or (
                backup_before_upgrade and not allow_schema_upgrade):
            raise LedgerError('ledger schema upgrade option is invalid')
        self._allow_schema_upgrade = allow_schema_upgrade
        # The owner's approved upgrade (setup's registration): each active project's
        # records are first kept as they are, then the migration checks those copies.
        self._backup_before_upgrade = backup_before_upgrade
        self.state = state
        # Admission settings come from the installed routing policy, read at
        # each decision; a caller-supplied policy is for tests only.
        self._admission_policy = admission_policy
        self._lock = threading.RLock()
        self._attestation_origin = object()
        self._capacity_executions = OwnedExecutionRegistry()
        self._capacity_execution_origin = secrets.token_hex(32)
        self._active_readers = 0
        # E1a revision 3: readers are counted under their own lock, so a reader's exit never waits for
        # the ledger. Order: the ledger lock, then this one, never the reverse.
        self._readers_lock = threading.Lock()
        self._lock_waits = ledger_waits.LockWaits()
        self._client_capabilities = (
            client_capabilities
            if client_capabilities is not None
            else load_client_capabilities(
                Path(__file__).resolve().parent.parent / "config" / "learning-clients.json"
            )
        )
        self._collector_active = False
        self._writer_descriptor: int | None = None
        if fcntl is None:
            raise LedgerError(FENCE_MESSAGE)
        if fcntl is not None:
            descriptor: int | None = None
            try:
                descriptor = os.open(
                    self.state.lock,
                    os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0),
                    0o600,
                )
                info = os.fstat(descriptor)
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
                    raise OSError("unsafe writer lock")
                os.fchmod(descriptor, 0o600)
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._writer_descriptor = descriptor
            except BaseException as exc:
                if descriptor is not None:
                    with contextlib.suppress(OSError):
                        os.close(descriptor)
                if isinstance(exc, OSError):
                    raise LedgerError("another learning writer owns this state root. Run: ./setup.sh --update") from exc
                raise
        try:
            self._fence = StoreFence(self.state.lock, self._writer_descriptor, COLLECTOR_RUNTIME_DIGEST,
                                     lambda: LedgerError(FENCE_MESSAGE))
            self._connection = self._connect()
            self._connection.share_with_lock(self._lock, waits=self._lock_waits)
            self._fence.legacy = self._connection.execute("PRAGMA user_version").fetchone()[0] < LEDGER_SCHEMA_VERSION
            self._fence.connection = self._connection
            self._connection._write_fence = self._fence
            self._migrate()
            # O10 AP: after every migration path (each returns early), one additive index lets an
            # append find the project's latest observed time from an index end, not by reading every
            # record. No schema version change: an older version opens the ledger and ignores it.
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_observed_at ON records(project_id, observed_at_ms)"
            )
            # O10 AP5 (with U9): a lookup of one record type, per project or (the start-up
            # admission-evidence check) across the ledger, reads only that type's records.
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_type_project ON records(record_type, project_id)"
            )
            # AP5-2: evidence names content identities, so seek just those within the project.
            # Additive and non-unique: existing ledgers and older same-schema readers stay valid.
            # Both pinned candidate queries rely on every normal open completing this DDL;
            # losing the index on an open connection gives a LedgerError asking for reopen.
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_project_digest ON records(project_id, content_digest)"
            )
            # U3: independent keys for a run, an account-wide time window,
            # foreign decisions, and still-live cleanup receipts. Existing AP/AP5
            # type, observed-time and project/digest indexes remain in use.
            # Additive on every open, after migration; no schema-version change.
            # Guard JSON so corrupt retained rows remain readable/refusable by
            # their existing validation paths rather than preventing index build.
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_run ON records(project_id, "
                "CASE WHEN json_valid(CAST(content AS TEXT)) THEN "
                "json_extract(CAST(content AS TEXT),'$.run_id') END, record_type)"
            )
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_candidate ON records(project_id, "
                "CASE WHEN json_valid(CAST(content AS TEXT)) THEN "
                "json_extract(CAST(content AS TEXT),'$.candidate_digest') END, record_type) WHERE record_type='candidate'"
            )
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_type_observed ON records(record_type, observed_at_ms)"
            )
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS records_foreign_admissions ON records(project_id) "
                "WHERE record_type='admission_decision' AND source<>'lifecycle'"
            )
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS account_cleanup_receipts_unreleased "
                "ON account_cleanup_receipts(project_id) WHERE released_at_ms IS NULL"
            )
            # O0b B0-1 (narrowed): the open-time cap reads only live pending bindings, so expired ones
            # piling up never slow it (additive, as above).
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS host_run_bindings_live ON host_run_bindings(project_id, expires_at_ms) "
                "WHERE binding_state='pending'"
            )
            # O0b B0-5 (narrowed; review 040-b0n-code): the probe cap and its status count read only
            # probes in progress, never the finished ones kept for replay.
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS billing_probes_in_progress ON account_billing_probe_requests(project_id) "
                "WHERE state<>'committed'"
            )
            # RSA3-4 (F9): each release batch seeks reserved probes, never their committed history.
            # The SELECT has no ORDER BY (as before); in practice equal-state rows are visited in rowid order,
            # as the former table scan did, so LIMIT picks the same rows (RSA3-5 tests it).
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS billing_probe_reserved ON account_billing_probe_requests(state) "
                "WHERE state='reserved'"
            )
            # OP-1: the open-time cap and its status count read only open requests in flight, never the finished
            # ones; OP-2: the retention sweep reads only committed requests old enough (additive, as above).
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS account_open_requests_in_flight "
                "ON account_open_requests(project_id, observation_deadline_at_ms) WHERE state='pending'"
            )
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS account_open_requests_finished "
                "ON account_open_requests(opened_at_ms) WHERE state='committed'"
            )
            self._connection.execute(  # O0c P0: the purge of opens that never finished
                "CREATE INDEX IF NOT EXISTS account_open_requests_unfinished "
                "ON account_open_requests(observation_deadline_at_ms) WHERE state='pending'"
            )
            self._connection.execute(  # O0c P0 (review rev040o0ccapsr1 M1): the purge of denied opens, by expiry
                "CREATE INDEX IF NOT EXISTS account_open_requests_committed_expiry "
                "ON account_open_requests(observation_deadline_at_ms) WHERE state='committed'"
            )
            self._initialize_launch_and_wake()  # RS-E E2a-1: additive, no schema version change
            self._record_first_owner_key()
            from .attestation_capture import initialize
            initialize(self._connection)
            self.state.mark_initialized()
            self._reconcile_managed_files()
        except BaseException:
            connection = getattr(self, "_connection", None)
            if connection is not None:
                with contextlib.suppress(sqlite3.Error):
                    connection.close()
            if self._writer_descriptor is not None:
                with contextlib.suppress(OSError):
                    os.close(self._writer_descriptor)
                self._writer_descriptor = None
            raise

    def _connect(self) -> sqlite3.Connection:
        # Never let sqlite3 implicitly recreate a lost initialized database.
        self.state._prepare_database(create=True)
        if self.state.database.is_symlink():
            raise StateError("database path is unsafe")
        connection = sqlite3.connect(
            self.state.database.as_uri() + "?mode=rw",
            uri=True,
            timeout=5,
            isolation_level=None,
            check_same_thread=False,
            factory=SQLReadConnection,
        )
        try:
            connection.row_factory = sqlite3.Row
            # O0b RS-A (F5): the register's triggers record releases at the ledger's own clock.
            def ledger_now_ms():
                migration = getattr(connection, '_hold_migration', None)
                return self._clock_ms() if migration is None else migration.now_ms
            connection.create_function("ledger_now_ms", 0, ledger_now_ms)
            from .legacy_slots import register_legacy_functions
            register_legacy_functions(connection)
            version = connection.execute('PRAGMA user_version').fetchone()[0]
            if version > LEDGER_SCHEMA_VERSION:
                raise LedgerError('ledger schema is newer than this package')
            if (5 <= version < LEDGER_SCHEMA_VERSION and version != 16
                    and not self._allow_schema_upgrade):
                raise LedgerError('ledger schema upgrade requires explicit drained-owner authorization and verified backups')
            connection.execute("PRAGMA foreign_keys = ON")
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("PRAGMA synchronous = FULL")
            connection.execute("PRAGMA secure_delete = ON")
            connection.execute("PRAGMA busy_timeout = 5000")
            self.state.harden_database_files()
            # New service wrappers must inherit the connection's actual origin, not
            # adopt it on their construction thread or after a fork. Legacy collector
            # paths still serialize cross-thread use themselves; this stamp does not
            # change their contract. A Thread object avoids recycled numeric IDs.
            self._connection_origin = (os.getpid(), threading.current_thread())
        except BaseException:
            # Until this function returns, __init__ cannot reach this connection.
            with contextlib.suppress(sqlite3.Error):
                connection.close()
            raise
        return connection

    def _record_first_owner_key(self) -> None:
        """Record the key in force the first time a ledger sees one.

        From then on the signer file must match this record. The history only grows.
        """

        with self._held(), self._connection:
            self._connection.executescript(
                _OWNER_KEY_HISTORY_SCHEMA + """;
                CREATE TRIGGER IF NOT EXISTS owner_key_history_no_update
                BEFORE UPDATE ON owner_key_history
                BEGIN SELECT RAISE(ABORT,'owner key history is append-only'); END;
                CREATE TRIGGER IF NOT EXISTS owner_key_history_no_delete
                BEFORE DELETE ON owner_key_history
                BEGIN SELECT RAISE(ABORT,'owner key history is append-only'); END;
                """
            )
            if self._connection.execute(
                "SELECT 1 FROM owner_key_history LIMIT 1"
            ).fetchone() is not None:
                return
            try:
                content = self.state._owner_signer_bytes()
            except (StateError, OSError):
                return  # opening the ledger must not depend on a damaged signer file
            self._connection.execute(
                "INSERT INTO owner_key_history(signer_line,reason,recorded_at_ms) "
                "VALUES(?,'enrolled',?)",
                (content, time.time_ns() // 1_000_000),
            )

    def replace_owner_key(self, public_key: str, *, now_ms: int | None = None) -> dict[str, Any]:
        """Make a new key the owner key, for an owner who cannot use the old one.

        The old key is not asked for, since it is what was lost. The record is committed
        first and the signer file follows: an interruption between them fails closed until
        the same replacement is run again, and that run finishes it. Billing statements the
        old key signed stop counting, because admission checks them against the current key,
        and a key once replaced cannot come back, which would revive them. With no record
        yet, a signer file that holds anything can be replaced; an empty one is first setup.
        """

        self._fence.check(self._connection)
        content = self.state._owner_signer_content(public_key)
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        path = self.state.allowed_signers_path
        damaged = path.is_dir() and not path.is_symlink()
        if damaged:
            os.rmdir(path)  # refuses a non-empty one, before anything is recorded
        with self._held(), self._connection:
            self._connection.execute("BEGIN IMMEDIATE")
            row = self._connection.execute(
                "SELECT signer_line FROM owner_key_history ORDER BY sequence DESC LIMIT 1"
            ).fetchone()
            if row is None and not (
                damaged
                or path.is_symlink()
                or (path.exists() and (not path.is_file() or path.stat().st_size > 0))
            ):
                raise LedgerError("no owner key is on record, so there is nothing to replace")
            if row is None or bytes(row["signer_line"]) != content:
                identity = _owner_key_identity(content)
                if any(
                    _owner_key_identity(bytes(earlier["signer_line"])) == identity
                    for earlier in self._connection.execute(
                        "SELECT signer_line FROM owner_key_history"
                    ).fetchall()
                ):
                    raise LedgerError("that key was replaced earlier; use a new key")
                self._connection.execute(
                    "INSERT INTO owner_key_history(signer_line,reason,recorded_at_ms) "
                    "VALUES(?,'replaced',?)",
                    (content, timestamp),
                )
        # BR-15: the signer file is written under the ledger lock (then the state turn, the order a billing
        # judgment's final check uses), so no judgment commits between the history record and the file.
        with self._held(), self.state._owner_key_turn():
            self.state._write_owner_signers(content)
        self.state.harden_database_files()
        return self.state.owner_key_report()

    def _expire_worker_results_locked(self, now: int) -> list[tuple[str, str]]:
        """Mark the worker results that may no longer be kept; return them.

        Every kept result's expiry is first clamped to its outcome's ingestion
        time plus the retention, which also shortens results an earlier
        version kept for 90 days. A result whose orchestration has closed is
        marked expired now. Registrations stay until the file is really gone
        (`sweep_worker_results`), and an expired one is never read. Returns the
        (project, relative path) pairs due for deletion.
        """

        self._connection.execute(
            "UPDATE stored_files SET expires_at_ms=("
            "SELECT MIN(COALESCE(stored_files.expires_at_ms, r.ingested_at_ms + ?),"
            "r.ingested_at_ms + ?) FROM records r WHERE r.project_id=stored_files.project_id "
            "AND r.record_id=stored_files.source_record_id) "
            "WHERE kind='artifact' AND substr(file_id,1,12)='host_result_' AND EXISTS("
            "SELECT 1 FROM records r WHERE r.project_id=stored_files.project_id "
            "AND r.record_id=stored_files.source_record_id)",
            (WORKER_RESULT_RETENTION_MS, WORKER_RESULT_RETENTION_MS),
        )
        due = []
        for row in self._connection.execute(_WORKER_RESULT_FILES).fetchall():
            if row["status"] in {"active", "paused"} and (
                row["expires_at_ms"] is not None and int(row["expires_at_ms"]) > now
            ):
                continue
            self._connection.execute(
                "UPDATE stored_files SET expires_at_ms=MIN(COALESCE(expires_at_ms,?),?) "
                "WHERE project_id=? AND relative_path=?",
                (now, now, str(row["project_id"]), str(row["relative_path"])),
            )
            due.append((str(row["project_id"]), str(row["relative_path"])))
        # VF-INV-a: kept child answers carry their own expiry and no orchestration.
        for row in self._connection.execute(
            "SELECT project_id,relative_path FROM stored_files WHERE kind='artifact' "
            "AND substr(file_id,1,13)='child_answer_' AND expires_at_ms IS NOT NULL AND expires_at_ms<=?",
            (now,),
        ).fetchall():
            due.append((str(row["project_id"]), str(row["relative_path"])))
        return due

    def sweep_account_retention(self, *, now_ms: int | None = None, batch: int = EVENT_SWEEP_BATCH) -> int:
        """Remove finished account rows past their retention, a small batch of each kind at a time (0.3.4 R6:
        observations; OP-2: finished opens, with their binding and receipt); returns how many went. Skipped
        while a reader or a transaction is active."""
        from .account_observation import purge_old_observations
        from .account_original_open import purge_finished_opens

        with self._held():
            if self._readers() or self._connection.in_transaction:
                return 0
            now = self._clock_ms() if now_ms is None else now_ms
            return purge_old_observations(self, now, batch) + purge_finished_opens(self, now, batch)

    def sweep_learning_retention(self, *, now_ms: int | None = None, batch: int = LEARNING_SWEEP_BATCH) -> int:
        """Remove up to `batch` unpromoted cases and candidates past the learning retention; returns how many.

        O0c P8, for projects whose learning is still in the ledger (one moved to its project store is that
        store's own cleanup). Kept, however old: a case in a controlled corpus, and any record a later record
        names, a granted candidate, an owner-attested record (`_kept_learning_sql`), so the cycle's window and
        this sweep agree. The kept rows are left out in the query, so they never use up a batch. Outcomes are
        not touched; the owner's learning-expire removes those. Skipped while a reader or a transaction is
        active.
        """
        with self._held():
            if self._readers() or self._connection.in_transaction:
                return 0
            now = self._clock_ms() if now_ms is None else now_ms
            rows = self._connection.execute(
                "SELECT r.project_id,r.record_id FROM records r "
                "JOIN projects p ON p.project_id=r.project_id AND p.status='active' "
                "WHERE r.record_type IN ('evaluation_case','candidate') AND r.ingested_at_ms<=? "
                f"AND NOT {_kept_learning_sql('r')} "
                "AND NOT EXISTS (SELECT 1 FROM additive_migrations m WHERE m.feature_key=?||r.project_id) "
                "ORDER BY r.project_id,r.source_sequence LIMIT ?",
                (now - LEARNING_RETENTION_MS, LEARNING_MOVED_KEY, batch),
            ).fetchall()
            if not rows:
                return 0
            with self._account_transaction():
                self._connection.executemany(
                    "DELETE FROM records WHERE project_id=? AND record_id=?",
                    [(str(row[0]), str(row[1])) for row in rows])
            return len(rows)

    def sweep_superseded_attestations(self, *, batch: int = LEARNING_SWEEP_BATCH) -> int:
        """P9: bounded verified supersession; cited history stays readable."""
        from .attestation_capture import sweep
        return sweep(self, batch, _cited_sql)

    def sweep_event_retention(self, *, now_ms: int | None = None, batch: int = EVENT_SWEEP_BATCH) -> int:
        """Summarise, then remove, up to `batch` expired raw events; returns how many were removed.

        Only hook and app-server events past their expiry that nothing else
        names are taken: a record link, a stored file, a grant or an owner
        attestation keeps an event for the owner's learning-expire, which also
        follows lineage and removes files. Each run's events of one UTC day
        become one event_summary. All of a sweep's summaries and removals are
        one transaction; a group that cannot be summarised is left as it was and
        the others still go. Backups keep their own lifetime.
        """
        with self._held():
            if self._readers() or self._connection.in_transaction:
                return 0
            now = self._clock_ms() if now_ms is None else now_ms
            readable, scanned, after = [], 0, ("", 0)
            # Read past rows that cannot be summarised (left for learning-expire), so they
            # never use up a sweep; at most EVENT_SWEEP_SCAN_FACTOR windows are read.
            while len(readable) < batch and scanned < batch * EVENT_SWEEP_SCAN_FACTOR:
                window = self._expired_event_window(now, after, batch)
                if not window:
                    break
                scanned += len(window)
                after = (str(window[-1]["project_id"]), int(window[-1]["source_sequence"]))
                for row in window:
                    try:
                        record = json.loads(bytes(row["content"]))
                        readable.append((row, str(record["run_id"]), str(record["event_code"])))
                    except (ValueError, KeyError, TypeError):
                        continue  # Left for the owner's learning-expire.
                    if len(readable) == batch:
                        break
            groups = self._group_events(readable)
            if not groups:
                return 0
            return self._summarise_and_remove(groups, now)

    def _expired_event_window(self, now: int, after: tuple[str, int], batch: int, project_id: str | None = None):
        """The next expired raw events nothing else names, after `after` (project, sequence), of one project
        when `project_id` is given."""
        return self._connection.execute(
                "SELECT r.project_id,r.record_id,r.source,r.source_sequence,r.observed_at_ms,r.content,"
                "r.content_digest FROM records r "
                "JOIN projects p ON p.project_id=r.project_id AND p.status='active' "
                "WHERE r.record_type='event' AND r.source IN ('hook','app_server') "
                "AND r.expires_at_ms IS NOT NULL AND r.expires_at_ms<=? "
                "AND NOT EXISTS (SELECT 1 FROM record_links l WHERE l.project_id=r.project_id "
                "AND (l.from_record_id=r.record_id OR l.to_record_id=r.record_id)) "
                "AND NOT EXISTS (SELECT 1 FROM stored_files f WHERE f.project_id=r.project_id "
                "AND f.source_record_id=r.record_id) "
                "AND NOT EXISTS (SELECT 1 FROM owner_attestations a WHERE a.project_id=r.project_id "
                "AND a.subject_record_id=r.record_id) "
                "AND NOT EXISTS (SELECT 1 FROM consumed_grants g WHERE g.project_id=r.project_id "
                "AND (g.grant_id=r.record_id OR g.promotion_record_id=r.record_id)) "
                + ("AND (r.project_id>? OR (r.project_id=? AND r.source_sequence>?)) "
                   "ORDER BY r.project_id,r.source_sequence LIMIT ?" if project_id is None else
                   # One project: walk its own (project, sequence) index, so work follows the page.
                   "AND r.project_id=? AND r.source_sequence>? ORDER BY r.source_sequence LIMIT ?"),
                ((now, after[0], after[0], after[1], batch) if project_id is None
                 else (now, project_id, after[1], batch)),
            ).fetchall()

    @staticmethod
    def _group_events(readable) -> dict:
        """Group (row, run_id, event_code) by project, run and UTC day: the one grouping both the collector's
        sweep and learning-expire summarise by."""
        groups: dict[tuple[str, str, str], dict[str, Any]] = {}
        for row, run_id, code in readable:
            observed = int(row["observed_at_ms"])
            day = time.strftime("%Y-%m-%d", time.gmtime(observed / 1000))
            group = groups.setdefault((str(row["project_id"]), run_id, day), {
                "ids": [], "keys": [], "codes": {}, "sources": {}, "first": observed, "last": observed})
            group["ids"].append(str(row["record_id"]))
            # The exact rows, so ids reused after an expiry never share a summary id with their predecessors.
            group["keys"].append([str(row["record_id"]), int(row["source_sequence"]), str(row["content_digest"])])
            group["codes"][code] = group["codes"].get(code, 0) + 1
            group["sources"][str(row["source"])] = group["sources"].get(str(row["source"]), 0) + 1
            group["first"], group["last"] = min(group["first"], observed), max(group["last"], observed)
        return groups

    @staticmethod
    def _event_summary_record(project_id: str, run_id: str, day: str, group: dict) -> dict[str, Any]:
        from .learning_contracts import validate_learning_record

        identity = hashlib.sha256(canonical_json(
            [project_id, run_id, day, sorted(group["keys"])])).hexdigest()[:32]
        return validate_learning_record({
            "schema_version": 1, "record_type": "event_summary",
            "record_id": "evsum-" + identity, "run_id": run_id, "day": day,
            "observed_at_ms": group["last"], "first_observed_at_ms": group["first"],
            "last_observed_at_ms": group["last"], "span_ms": group["last"] - group["first"],
            "event_count": len(group["ids"]), "event_counts": group["codes"],
            "source_counts": group["sources"]})

    def _write_event_summary(self, project_id: str, summary: dict[str, Any], now: int) -> None:
        """Append one summary; an id already taken (by anything) is refused loudly, never merged or recounted."""
        taken = self._connection.execute(
            "SELECT 1 FROM records WHERE project_id=? AND record_id=?",
            (project_id, summary["record_id"])).fetchone()
        if taken is not None:
            raise LedgerError("event summary identifier is already taken")
        self._append_checked_locked(project_id, summary, producer="lifecycle", timestamp=now)

    def _expire_event_targets(self, project_id: str, now_ms: int, last_sequence: int):
        """The expired raw events learning-expire summarises among its chosen page (those the sweep would
        take, up to `last_sequence`, so at most the page's size). Read before any file registration is
        removed, so an event a file names (erased with that file) is never taken."""
        rows, after = [], (project_id, 0)
        while True:
            window = self._expired_event_window(now_ms, after, EXPIRE_SUMMARY_BATCH, project_id)
            if not window:
                return rows
            after = (project_id, int(window[-1]["source_sequence"]))
            rows.extend(row for row in window if int(row["source_sequence"]) <= last_sequence)
            if after[1] > last_sequence:
                return rows

    def _summarise_expiring_events(self, project_id: str, rows, identifiers: set[str], now_ms: int) -> None:
        """learning-expire (T7 L10.3): roll the chosen expired raw events into event summaries, through the
        sweep's own grouping and summary record, in the caller's transaction. An event whose content cannot
        be read is removed unsummarised."""
        readable = []
        for row in rows:
            if str(row["record_id"]) not in identifiers:
                continue
            try:
                record = json.loads(bytes(row["content"]))
                readable.append((row, str(record["run_id"]), str(record["event_code"])))
            except (ValueError, KeyError, TypeError):
                continue
        for (group_project, run_id, day), group in self._group_events(readable).items():
            self._write_event_summary(
                group_project, self._event_summary_record(group_project, run_id, day, group), now_ms)

    def _summarise_and_remove(self, groups: dict, now: int) -> int:
        """One transaction: each group's summary and removal under its own savepoint."""
        from .contracts import ContractError
        from .learning_contracts import validate_learning_record

        removed = 0
        with self._account_transaction():
            for number, ((project_id, run_id, day), group) in enumerate(groups.items()):
                self._connection.execute(f"SAVEPOINT summary_{number}")
                try:
                    summary = self._event_summary_record(project_id, run_id, day, group)
                    self._write_event_summary(project_id, summary, now)
                except (ContractError, LedgerError, ValueError, KeyError, TypeError, sqlite3.Error):
                    # This group cannot be summarised: it stays, the others go.
                    self._connection.execute(f"ROLLBACK TO summary_{number}")
                    self._connection.execute(f"RELEASE summary_{number}")
                    continue
                self._connection.executemany(
                    "DELETE FROM records WHERE project_id=? AND record_id=?",
                    [(project_id, identifier) for identifier in group["ids"]])
                self._connection.execute(f"RELEASE summary_{number}")
                removed += len(group["ids"])
        return removed

    def keep_child_answer(self, project_id: str, content: bytes) -> str:
        """Keep a bridged child's raw final answer, owner-only, and return its SHA-256 (VF-INV-a).

        The file is named by its digest (`child_answer_<40 hex>`), lives in the project's artifact
        partition like a kept worker result, is registered with an expiry of the worker-result
        retention, and is deleted by `sweep_worker_results` or with the project. The caller has
        already removed credential-shaped text; the size cap is the caller's. The same answer is
        kept once.
        """

        digest = hashlib.sha256(content).hexdigest()
        file_id = f"child_answer_{digest[:40]}"
        with self._held():
            registered = self._connection.execute(
                "SELECT 1 FROM stored_files WHERE project_id=? AND file_id=?", (project_id, file_id),
            ).fetchone()
            if registered is not None:
                return digest
            try:
                path = self._write_owner_file("artifact", project_id, file_id, content)
            except FileExistsError:
                # An unregistered leftover of an interrupted keep: removed at the next ledger start.
                raise LedgerError("a kept child answer is already being written") from None
            try:
                self._register_stored_file(
                    project_id, file_id=file_id, kind="artifact", path=path, digest=digest,
                    expires_at_ms=self._clock_ms() + WORKER_RESULT_RETENTION_MS,
                )
            except Exception:
                with contextlib.suppress(OSError):
                    path.unlink()
                raise
        return digest

    def sweep_worker_results(self) -> int:
        """Delete worker results past their retention or orchestration; return how many.

        A registration is removed only after its file is gone, so a failed
        deletion is retried at the next sweep instead of being forgotten.
        """

        removed = 0
        with self._held():
            with self._connection:
                due = self._expire_worker_results_locked(self._clock_ms())
            for project_id, relative in due:
                try:
                    self._remove_registered_path(project_id, relative)
                except (OSError, LedgerError):
                    continue  # still registered and expired: retried, never read
                with self._connection:
                    self._connection.execute(
                        "DELETE FROM stored_files WHERE project_id=? AND relative_path=?",
                        (project_id, relative),
                    )
                removed += 1
        return removed

    def _reconcile_managed_files(self) -> None:
        """Reconcile crash-orphaned files and registrations before serving work.

        A worker result whose orchestration has closed, or that is past its
        retention, is deleted first (`sweep_worker_results`); one whose file
        cannot be deleted stays registered and expired, so it is retried and
        never read.
        """

        self.sweep_worker_results()
        rows = self._connection.execute(
            "SELECT project_id,relative_path FROM stored_files"
        ).fetchall()
        registered: set[str] = set()
        with self._connection:
            for row in rows:
                relative = str(row["relative_path"])
                candidate = self.state.root / relative
                if candidate.is_symlink():
                    raise StateError("managed storage contains a symlink")
                if not candidate.is_file():
                    self._connection.execute(
                        "DELETE FROM stored_files WHERE project_id=? AND relative_path=?",
                        (str(row["project_id"]), relative),
                    )
                else:
                    registered.add(relative)
        for root in (self.state.artifacts, self.state.exports, self.state.backups):
            for current, directories, files in os.walk(root, topdown=True, followlinks=False):
                current_path = Path(current)
                for directory in directories:
                    if (current_path / directory).is_symlink():
                        raise StateError("managed storage contains a symlink")
                for name in files:
                    candidate = current_path / name
                    if candidate.is_symlink():
                        raise StateError("managed storage contains a symlink")
                    relative = candidate.relative_to(self.state.root).as_posix()
                    if relative not in registered and root != self.state.backups:
                        candidate.unlink()
            for current, directories, files in os.walk(root, topdown=False):
                path = Path(current)
                if path != root and not directories and not files:
                    with contextlib.suppress(OSError):
                        path.rmdir()

    def _require_project_migration_backups(self, schema_version: int, target_version: int) -> None:
        """Refuse migration until each active partition has an exact verified backup.

        Every project is sized, and the disk checked, before any backup is
        written, so a project that cannot fit leaves the ledger unchanged.
        """

        projects = [str(row["project_id"]) for row in self._connection.execute(
            "SELECT project_id FROM projects WHERE status='active' ORDER BY project_id"
        ).fetchall()]
        if self._backup_before_upgrade:
            self._plan_project_backups(projects, schema_version)
            taken_at_ms = time.time_ns() // 1_000_000
            written = []
            try:
                for number, project_id in enumerate(projects, 1):
                    report_phase(f"backing up project {number} of {len(projects)}")
                    written.append(self._write_upgrade_backup(project_id, schema_version, taken_at_ms))
            except BaseException:
                # The upgrade stops before it changes anything: take back this run's copies too.
                for project_id, file_id, path in written:
                    with contextlib.suppress(OSError):
                        path.unlink()
                    with contextlib.suppress(sqlite3.Error):
                        self._connection.execute(
                            "DELETE FROM stored_files WHERE project_id=? AND file_id=? AND kind='backup'",
                            (project_id, file_id))
                raise
        for project_id in projects:
            registrations = self._connection.execute(
                "SELECT file_id,relative_path,content_digest,expires_at_ms FROM stored_files "
                "WHERE project_id=? AND kind='backup' ORDER BY rowid DESC",
                (project_id,),
            ).fetchall()
            verified = False
            for registration in registrations:
                try:
                    expires_at_ms = registration["expires_at_ms"]
                    if (
                        expires_at_ms is not None
                        and int(expires_at_ms) <= time.time_ns() // 1_000_000
                    ):
                        continue
                    path = self.state.root / str(registration["relative_path"])
                    expected_parent = self.state.backups / project_id
                    _assert_no_symlink_components(path)
                    if path.parent != expected_parent or not path.is_file():
                        continue
                    if path.suffix == ".sqlite3":
                        self._verify_streamed_backup(
                            path, project_id, str(registration["content_digest"]),
                            schema_version=schema_version, exclude_file_id=str(registration["file_id"]))
                    elif not self._legacy_backup_matches(path, registration, project_id, schema_version):
                        continue
                except (LedgerError, OSError):
                    continue
                verified = True
                break
            if not verified:
                raise LedgerError(
                    f"schema {target_version} migration requires a registered verified schema {schema_version} "
                    "project backup"
                )
        report_phase("upgrading the records")

    def _legacy_backup_matches(self, path: Path, registration, project_id: str, schema_version: int) -> bool:
        """A format-2 (JSON) backup an earlier release made, read and compared whole."""
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != str(registration["content_digest"]):
            return False
        body, _, _ = _verify_backup_envelope(
            raw, expected_project_id=project_id, expected_ledger_schema_version=schema_version)
        current = _snapshot_project_partition(self._connection, project_id, ledger_schema_version=schema_version)
        file_id = str(registration["file_id"])
        current["tables"]["stored_files"] = [
            row for row in current["tables"]["stored_files"] if row["file_id"] != file_id]
        current["counts"]["stored_files"] = len(current["tables"]["stored_files"])
        return canonical_json(current) == canonical_json(body)

    def _plan_project_backups(self, projects: list[str], schema_version: int) -> None:
        """Refuse, before writing anything, a backup that is over its limit or cannot fit on disk."""
        sizes = [project_backup_bytes(self._connection, project_id, schema_version) for project_id in projects]
        for number, size in enumerate(sizes, 1):
            if size > MAX_PROJECT_BACKUP_BYTES:
                raise LedgerCapacityError(projects=len(projects), project_number=number, needed_bytes=size,
                                          limit_bytes=MAX_PROJECT_BACKUP_BYTES)
        self.state.backups.mkdir(mode=0o700, parents=True, exist_ok=True)
        for project_id in projects:
            self._clear_partial_backups(project_id)
        needed = sum(sizes) * BACKUP_SPACE_FACTOR + BACKUP_SPACE_MARGIN_BYTES
        available = _free_backup_bytes(self.state.backups)
        if needed > available:
            raise LedgerCapacityError(projects=len(projects), needed_bytes=needed, available_bytes=available)

    def _clear_partial_backups(self, project_id: str) -> None:
        """Remove what a stopped backup write left: never registered, never read."""
        partition = self.state.backups / project_id
        if not partition.is_dir() or partition.is_symlink():
            return
        for leftover in partition.glob(".*.partial"):
            if leftover.is_file() and not leftover.is_symlink():
                with contextlib.suppress(OSError):
                    leftover.unlink()

    def _write_upgrade_backup(self, project_id: str, schema_version: int, taken_at_ms: int) -> tuple:
        """Keep one project's records exactly as the earlier version left them.

        The same streamed, registered copy the owner's backup command writes, in
        the layout of the schema being left; the check that follows compares it
        with the records row by row. It expires like any other backup.
        """
        file_id = f"upgrade_schema{schema_version}_{taken_at_ms}"
        path = self._write_streamed_backup(project_id, schema_version, file_id,
                                           expires_at_ms=taken_at_ms + UPGRADE_BACKUP_MS)
        return project_id, file_id, path

    def _write_streamed_backup(self, project_id: str, schema_version: int, file_id: str, *,
                               expires_at_ms: int) -> Path:
        """Copy one partition into a new owner-only backup file, check it, then register it."""
        from . import project_backup

        self._fence.check(self._connection)
        if not file_id or len(file_id) > 160 or not file_id.replace("_", "").isalnum():
            raise LedgerError("stored file identifier is invalid")
        project_backup.check_inventory(self._connection)  # 0.8.60 final fix (decision 249): before anything is created
        partition = self.state.backups / project_id
        partition.mkdir(mode=0o700, parents=True, exist_ok=True)
        _assert_no_symlink_components(partition)
        _check_owner_mode(partition, directory=True)
        path = partition / (file_id + project_backup.SUFFIX)
        partial = partition / f".{file_id}.partial"
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
        if path.exists() or path.is_symlink():
            raise LedgerError("stored file already exists")
        with contextlib.suppress(FileNotFoundError):
            partial.unlink()  # Left by a write that was stopped; never registered.
        os.close(os.open(partial, flags, 0o600))
        published = None  # The identity of the file this call published, once it has (O10 L2).

        def remove_published():
            with contextlib.suppress(OSError):
                info = os.stat(path, follow_symlinks=False)
                if published is not None and (info.st_dev, info.st_ino) == published:
                    path.unlink()

        try:
            project_backup.write(self._connection, partial, project_id, schema_version,
                                 limit_bytes=MAX_PROJECT_BACKUP_BYTES)
            size = os.stat(partial, follow_symlinks=False).st_size
            if size > MAX_PROJECT_BACKUP_BYTES:  # The plan is an estimate; the file is the fact.
                raise LedgerCapacityError(projects=1, needed_bytes=size, limit_bytes=MAX_PROJECT_BACKUP_BYTES)
            descriptor = os.open(partial, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
            try:
                os.fsync(descriptor)
                digest = project_backup.file_digest(descriptor)
            finally:
                os.close(descriptor)
            self._verify_streamed_backup(partial, project_id, digest, schema_version=schema_version)
            try:
                # Never replaces a file that appeared at the name after the check above (O10 L1).
                os.link(partial, path, follow_symlinks=False)
            except FileExistsError:
                raise LedgerError("stored file already exists") from None
            info = os.stat(path, follow_symlinks=False)
            published = (info.st_dev, info.st_ino)  # the same file, whatever its link count
            partial.unlink()
            directory = os.open(partition, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        except BaseException:
            with contextlib.suppress(OSError):
                partial.unlink()
            remove_published()
            raise
        try:
            self._register_stored_file(project_id, file_id=file_id, kind="backup", path=path,
                                       digest=digest, expires_at_ms=expires_at_ms)
        except BaseException:
            remove_published()
            raise
        return path

    def _verify_streamed_backup(self, path: Path, project_id: str, expected_digest: str, *,
                                schema_version: int | None = None, exclude_file_id: str | None = None,
                                compare: bool = True) -> dict[str, Any]:
        """A format-3 backup: its digest, its own checks, and (by default) equality with the records."""
        from . import project_backup

        _assert_no_symlink_components(path)
        try:
            descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        except OSError:  # The filesystem's text names the path (decisions 36, 192).
            raise LedgerError("project backup is unavailable") from None
        try:
            before = os.fstat(descriptor)
            if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid() or before.st_mode & 0o077
                    or before.st_nlink != 1):
                raise LedgerError("project backup file is not private")
            if project_backup.file_digest(descriptor) != expected_digest:
                raise LedgerError("project backup file digest disagrees with its registry")
            result = project_backup.verify(
                path, project_id=project_id, schema_version=schema_version,
                compare=self._connection if compare else None, exclude_file_id=exclude_file_id)
            # The file is read again by path above; it must still be the one that was hashed.
            after = os.stat(path, follow_symlinks=False)
            if (_file_identity(after) != _file_identity(before)
                    or _file_identity(os.fstat(descriptor)) != _file_identity(before)
                    or project_backup.file_digest(descriptor) != expected_digest):
                raise LedgerError("project backup changed while it was checked")
        finally:
            os.close(descriptor)
        return {**result, "backup_sha256": expected_digest}

    def _initialize_launch_claims_locked(self, *, backfill: bool) -> None:
        """Owner-only schema step within the caller's migration transaction.

        Old runs are ambiguous even without a retained intent. Fence all of them
        instead of deriving unused authority from expiring history. Markers do
        not reference expiring records/bindings or grant executable permission.
        """
        self._connection.execute(_LAUNCH_CLAIMS_SCHEMA)
        if backfill:
            self._connection.execute(
                "INSERT INTO launch_claims(project_id,handle_digest,run_id,kind,claimed_at_ms,bridge_run_id) "
                "SELECT project_id,handle_digest,run_id,'legacy_fenced',created_at_ms,NULL FROM host_run_bindings"
            )

    def _assert_launch_schema_locked(self, version: int) -> None:
        schemas = [("table", "launch_claims", _LAUNCH_CLAIMS_SCHEMA)]
        if version >= 8:
            schemas += [("table", "launch_inputs", _LAUNCH_INPUTS_SCHEMA),
                        ("table", "launch_observations", _LAUNCH_OBSERVATIONS_SCHEMA),
                        ("table", "launch_receipts", _LAUNCH_RECEIPTS_SCHEMA),
                        ("index", "launch_receipt_parent", _LAUNCH_RECEIPT_PARENT_SCHEMA),
                        ("trigger", "cleanup_launch_operation_state", _LAUNCH_CLEANUP_SCHEMA)]
        if version >= 9:
            schemas += [entry for entry in CAPACITY_OBJECTS if version < 11 or entry[1] != 'capacity_executions']
        if version >= 15:
            try:
                assert_run_holds_schema(self._connection)
            except ValueError:
                raise LedgerError('run hold schema is unavailable or incompatible') from None
        if version >= 14:
            try:
                assert_admission_evidence_schema(self._connection)
            except ValueError:
                raise LedgerError('admission evidence schema is unavailable or incompatible') from None
        if version >= 13:
            try:
                assert_billing_probe_schema(self._connection)
            except ValueError:
                raise LedgerError('billing probe schema is unavailable or incompatible') from None
        if version >= 12:
            try:
                assert_observation_schema(self._connection)
            except ValueError:
                raise LedgerError("account observation schema is unavailable or incompatible") from None
        if version >= 11:
            try:
                assert_cleanup_schema(self._connection)
            except ValueError:
                raise LedgerError('account cleanup schema is unavailable or incompatible') from None
        if version >= 10:
            try:
                assert_open_schema(self._connection)
            except ValueError:
                raise LedgerError('account original-open schema is unavailable or incompatible') from None

        def normalized(sql):
            return " ".join(sql.replace("IF NOT EXISTS ", "").strip().rstrip(";").split())

        for kind, name, expected in schemas:
            row = self._connection.execute("SELECT sql FROM sqlite_master WHERE type=? AND name=?", (kind, name)).fetchone()
            if row is None or type(row[0]) is not str or normalized(row[0]) != normalized(expected):
                raise LedgerError("launch claim state is unavailable or incompatible")

    def _initialize_launch_operations_locked(self) -> None:
        self._connection.execute(_LAUNCH_RECEIPT_PARENT_SCHEMA)
        self._connection.execute(_LAUNCH_INPUTS_SCHEMA)
        self._connection.execute(_LAUNCH_OBSERVATIONS_SCHEMA)
        self._connection.execute(_LAUNCH_RECEIPTS_SCHEMA)
        self._connection.execute(_LAUNCH_CLEANUP_SCHEMA)
        self._assert_launch_schema_locked(8)

    def _initialize_active_capacity_locked(self):
        for _kind, _name, sql in CAPACITY_OBJECTS:
            self._connection.execute(sql)
        # Historical consumption has no durable proof of confirmed cleanup.
        # Retention, a consumed binding or a result record cannot free capacity.
        self._connection.execute(
            "INSERT INTO active_run_capacity(project_id,handle_digest,run_id,bridge_run_id,kind,claimed_at_ms) "
            "SELECT c.project_id,c.handle_digest,c.run_id,c.bridge_run_id,'legacy_unknown',c.claimed_at_ms "
            "FROM launch_claims c WHERE NOT EXISTS(SELECT 1 FROM active_run_capacity a "
            "WHERE a.project_id=c.project_id AND a.handle_digest=c.handle_digest)"
        )
        self._assert_launch_schema_locked(9)

    def _initialize_account_opens_locked(self):
        try:
            install_open_schema(self._connection)
        except ValueError:
            raise LedgerError('account original-open migration is unavailable or incompatible') from None

    def _initialize_account_cleanup_locked(self):
        try:
            install_cleanup_schema(self._connection)
        except ValueError:
            raise LedgerError('account cleanup migration is unavailable or incompatible') from None

    def _initialize_account_observations_locked(self):
        try:
            install_observation_schema(self._connection)
        except ValueError:
            raise LedgerError("account observation migration is unavailable or incompatible") from None

    def _initialize_billing_probes_locked(self):
        try:
            install_billing_probe_schema(self._connection)
        except ValueError:
            raise LedgerError('billing probe migration is unavailable or incompatible') from None

    def _initialize_admission_evidence_locked(self):
        try:
            install_admission_evidence_schema(self._connection)
        except ValueError:
            raise LedgerError('admission evidence migration is unavailable or incompatible') from None

    def _initialize_run_holds_locked(self):
        """O0b RS-A: the hold register, adopting every existing account hold from its evidence, then (round 1
        F1, before the version is set) releasing the holds today's predicates already treat as ended: a slot
        whose binding was settled service_lost is released `lost` whatever the clocks say; then the sweep's
        own releases (crashed slots, reserved probes past their deadline, expired bindings) until none is due."""
        from .active_run_capacity import LOST_RUN_REASON
        from .hold_migration import HoldMigration

        # Complete fixed DDL before the first durable checkpoint. The schema
        # version then excludes old writers, while progress gates publication.
        self._initialize_probe_ids_locked()
        migration = HoldMigration(self._connection, 'account',
            (('run_slot', 'active_run_capacity'), ('binding', 'host_run_bindings'),
             ('probe', 'account_billing_probe_requests')), self._clock_ms(), LEDGER_SCHEMA_VERSION,
            lambda: LedgerError('run hold migration is unavailable or incompatible'),
            clock_reference_ns=self._capacity_clock_reference(), before_commit=self.state.harden_database_files)
        self._connection._hold_migration = migration

        try:
            try:
                install_run_holds_schema(self._connection)
            except ValueError:
                raise LedgerError('run hold migration is unavailable or incompatible') from None
            now, monotonic = migration.now_ms, migration.clock_reference_ns
            for row in self._connection.execute(
                    "SELECT a.project_id,a.handle_digest FROM active_run_capacity a JOIN host_run_bindings h "
                    "ON h.project_id=a.project_id AND h.handle_digest=a.handle_digest WHERE a.released_at_ms IS NULL "
                    "AND h.binding_state='abandoned' AND h.abandoned_reason=?", (LOST_RUN_REASON,)).fetchall():
                self._release_slot_locked(row["project_id"], row["handle_digest"], "lost", now, monotonic)
            while self._release_due_locked(now, monotonic, 1024) == 1024:
                pass
            self._assert_launch_schema_locked(LEDGER_SCHEMA_VERSION)
            if not (check_run_holds_consistency(self._connection)
                    and check_cleanup_coverage(self._connection)
                    and check_observation_coverage(self._connection)
                    and check_billing_probe_coverage(self._connection)
                    and check_admission_evidence_coverage(self._connection)):
                raise LedgerError('run hold migration validation is unavailable or incompatible')
            migration.finish()
        finally:
            self._connection._hold_migration = None

    def _migrate_six_or_seven_to_current(self, version: int) -> None:
        self._connection.execute("BEGIN IMMEDIATE")
        try:
            self._fence.claim(self._connection)
            self._initialize_launch_claims_locked(backfill=version == 6)
            if version == 7:
                # Preserve existing consumption and fence every older ambiguous
                # pending run; its approved launch inputs were not stored yet.
                self._connection.execute(
                    "INSERT INTO launch_claims(project_id,handle_digest,run_id,kind,claimed_at_ms,bridge_run_id) "
                    "SELECT h.project_id,h.handle_digest,h.run_id,'legacy_fenced',h.created_at_ms,NULL "
                    "FROM host_run_bindings h WHERE NOT EXISTS(SELECT 1 FROM launch_claims c "
                    "WHERE c.project_id=h.project_id AND (c.handle_digest=h.handle_digest OR c.run_id=h.run_id))"
                )
            self._initialize_launch_operations_locked()
            self._initialize_active_capacity_locked()
            self._initialize_account_opens_locked()
            self._initialize_account_cleanup_locked()
            self._initialize_account_observations_locked()
            self._initialize_billing_probes_locked()
            self._initialize_admission_evidence_locked()
            self._initialize_run_holds_locked()  # O0b RS-A
            self._initialize_probe_ids_locked()
            self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
            self.state.harden_database_files()
            self._connection.execute("COMMIT")
        except BaseException:
            with contextlib.suppress(sqlite3.Error):
                self._connection.execute("ROLLBACK")
            raise

    def _migrate_five_to_current(self) -> None:
        """Migrate lifecycle and launch consumption in one rollback-safe unit."""

        self._connection.execute("BEGIN IMMEDIATE")
        try:
            self._fence.claim(self._connection)
            columns = {
                str(row[1])
                for row in self._connection.execute(
                    "PRAGMA table_info(host_run_bindings)"
                ).fetchall()
            }
            additions = {
                "binding_state": "TEXT",
                "abandoned_reason": "TEXT",
                "observation_started_at_ms": "INTEGER",
                "observation_deadline_at_ms": "INTEGER",
                "last_progress_at_ms": "INTEGER",
                "deadline_observed": "INTEGER",
            }
            for name, sql_type in additions.items():
                if name not in columns:
                    self._connection.execute(
                        f"ALTER TABLE host_run_bindings ADD COLUMN {name} {sql_type}"
                    )
            self._connection.execute(
                "UPDATE host_run_bindings SET binding_state=CASE "
                "WHEN consumed_at_ms IS NULL THEN 'pending' ELSE 'terminal' END "
                "WHERE binding_state IS NULL"
            )
            self._connection.execute(
                "UPDATE host_run_bindings SET "
                "observation_started_at_ms=COALESCE(observation_started_at_ms,created_at_ms),"
                "last_progress_at_ms=COALESCE(last_progress_at_ms,created_at_ms),"
                "deadline_observed=COALESCE(deadline_observed,0)"
            )
            self._connection.execute("DROP INDEX IF EXISTS orchestration_status")
            self._connection.execute("DROP TRIGGER IF EXISTS cleanup_orchestrations_state")
            self._connection.execute("ALTER TABLE orchestrations RENAME TO orchestrations_v5")
            self._connection.execute(
                "CREATE TABLE orchestrations("
                "project_id TEXT NOT NULL,orchestration_id TEXT NOT NULL,"
                "handle_digest TEXT NOT NULL,client_version TEXT NOT NULL,"
                "status TEXT NOT NULL CHECK(status IN ('active','paused','completed',"
                "'failed','interrupted','cancelled')),started_at_ms INTEGER NOT NULL,"
                "ended_at_ms INTEGER,goal_tokens_used INTEGER,"
                "goal_time_used_seconds INTEGER,expires_at_ms INTEGER NOT NULL,"
                "PRIMARY KEY(project_id,orchestration_id),"
                "UNIQUE(project_id,handle_digest),FOREIGN KEY(project_id) "
                "REFERENCES projects(project_id) ON DELETE CASCADE)"
            )
            self._connection.execute(
                "INSERT INTO orchestrations SELECT * FROM orchestrations_v5"
            )
            self._connection.execute("DROP TABLE orchestrations_v5")
            self._connection.execute(
                "CREATE INDEX orchestration_status "
                "ON orchestrations(project_id,status,started_at_ms)"
            )
            self._connection.execute(
                "CREATE TRIGGER cleanup_orchestrations_state "
                "AFTER UPDATE OF status ON projects "
                "WHEN NEW.status='deleted' AND OLD.status<>'deleted' BEGIN "
                "DELETE FROM orchestrations WHERE project_id=NEW.project_id;"
                "DELETE FROM operational_qa WHERE project_id=NEW.project_id;"
                "DELETE FROM operational_check_receipts WHERE project_id=NEW.project_id;"
                "END"
            )
            self._connection.execute(
                "DROP TRIGGER IF EXISTS cleanup_host_binding_with_event"
            )
            self._connection.execute(
                "CREATE TABLE IF NOT EXISTS orchestration_checkpoints("
                "project_id TEXT NOT NULL,orchestration_id TEXT NOT NULL,"
                "sequence INTEGER NOT NULL,status TEXT NOT NULL,goal_tokens_used INTEGER,"
                "goal_time_used_seconds INTEGER,observed_at_ms INTEGER NOT NULL,"
                "PRIMARY KEY(project_id,orchestration_id,sequence),"
                "FOREIGN KEY(project_id,orchestration_id) REFERENCES "
                "orchestrations(project_id,orchestration_id) ON DELETE CASCADE)"
            )
            self._connection.execute(
                "INSERT INTO orchestration_checkpoints("
                "project_id,orchestration_id,sequence,status,goal_tokens_used,"
                "goal_time_used_seconds,observed_at_ms) "
                "SELECT project_id,orchestration_id,1,status,goal_tokens_used,"
                "goal_time_used_seconds,COALESCE(ended_at_ms,started_at_ms) "
                "FROM orchestrations"
            )
            self._initialize_launch_claims_locked(backfill=True)
            self._initialize_launch_operations_locked()
            self._initialize_active_capacity_locked()
            self._initialize_account_opens_locked()
            self._initialize_account_cleanup_locked()
            self._initialize_account_observations_locked()
            self._initialize_billing_probes_locked()
            self._initialize_admission_evidence_locked()
            self._initialize_run_holds_locked()  # O0b RS-A
            self._initialize_probe_ids_locked()
            self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
            self.state.harden_database_files()
            self._connection.execute("COMMIT")
        except BaseException:
            with contextlib.suppress(sqlite3.Error):
                self._connection.execute("ROLLBACK")
            raise

    def _initialize_probe_ids_locked(self):
        columns = {row[1] for row in self._connection.execute("PRAGMA table_info(records)")}
        if "probe_id" not in columns:
            # No backfill: old signed bytes carry no common probe provenance.
            self._connection.execute("ALTER TABLE records ADD COLUMN probe_id TEXT")

    def _migrate(self) -> None:
        from .hold_migration import pending, PENDING_MESSAGE

        current = int(self._connection.execute("PRAGMA user_version").fetchone()[0])
        if pending(self._connection):
            if current != LEDGER_SCHEMA_VERSION or not self._allow_schema_upgrade:
                raise LedgerError(PENDING_MESSAGE)
            self._assert_launch_schema_locked(current)
            with self._account_transaction():
                self._initialize_run_holds_locked()
            # Reuse all the ordinary current-store coverage checks as well.
            self._migrate()
            return
        if current == 0 and (
            self.state._marker_exists(self.state.initialized)
            or not self.state._marker_exists(self.state.initializing)
        ):
            raise StateError("initialized ledger schema is missing; verified recovery is required")
        if current > LEDGER_SCHEMA_VERSION:
            raise LedgerError("ledger schema is newer than this package")
        if 0 < current < 5:
            raise LedgerError("legacy ledger requires a verified drained staged migration")
        if current == 5:
            self._require_project_migration_backups(5, LEDGER_SCHEMA_VERSION)
            self._migrate_five_to_current()
            self.state.harden_database_files()
            return
        if current in {6, 7}:
            if current == 7:
                self._assert_launch_schema_locked(7)
            self._require_project_migration_backups(current, LEDGER_SCHEMA_VERSION)
            self._migrate_six_or_seven_to_current(current)
            self.state.harden_database_files()
            return
        if current == 8:
            self._assert_launch_schema_locked(8)
            self._require_project_migration_backups(8, LEDGER_SCHEMA_VERSION)
            with self._account_transaction():
                self._initialize_active_capacity_locked()
                self._initialize_account_opens_locked()
                self._initialize_account_cleanup_locked()
                self._initialize_account_observations_locked()
                self._initialize_billing_probes_locked()
                self._initialize_admission_evidence_locked()
                self._initialize_run_holds_locked()  # O0b RS-A
                self._initialize_probe_ids_locked()
                self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
            return
        if current >= 9:
            self._assert_launch_schema_locked(current)
            if self._connection.execute(
                "SELECT 1 FROM launch_claims c LEFT JOIN active_run_capacity a "
                "ON a.project_id=c.project_id AND a.handle_digest=c.handle_digest "
                "WHERE a.run_id IS NULL OR a.run_id<>c.run_id OR a.bridge_run_id IS NOT c.bridge_run_id LIMIT 1"
            ).fetchone() is not None:
                raise LedgerError("active capacity coverage is unavailable")
            if self._connection.execute(
                "SELECT 1 FROM active_run_capacity a LEFT JOIN capacity_completions c "
                "ON c.project_id=a.project_id AND c.handle_digest=a.handle_digest "
                "AND c.run_id=a.run_id AND c.bridge_run_id=a.bridge_run_id "
                "LEFT JOIN capacity_executions e ON e.project_id=a.project_id AND e.handle_digest=a.handle_digest "
            "AND e.run_id=a.run_id AND e.bridge_run_id=a.bridge_run_id "
            "WHERE (a.released_at_ms IS NOT c.released_at_ms OR a.release_digest IS NOT c.receipt_digest "
            "OR (a.released_at_ms IS NOT NULL AND e.owner_digest IS NULL)) "
            # O0b RS-A (F2, round 2 G7): as in _check_backup_coverage.
            + (f"AND NOT ({DECISION_RELEASED} AND (c.terminal_record_id IS NULL OR e.owner_digest IS NOT NULL)) "
               if current >= 15 else "")
            + "LIMIT 1"
            ).fetchone() is not None:
                raise LedgerError("capacity completion coverage is unavailable")
            if current == 9:
                self._require_project_migration_backups(9, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_account_opens_locked()
                    self._initialize_account_cleanup_locked()
                    self._initialize_account_observations_locked()
                    self._initialize_billing_probes_locked()
                    self._initialize_admission_evidence_locked()
                    self._initialize_run_holds_locked()  # O0b RS-A
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f'PRAGMA user_version = {LEDGER_SCHEMA_VERSION}')
                return
            if current == 10:
                self._require_project_migration_backups(10, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_account_cleanup_locked()
                    self._initialize_account_observations_locked()
                    self._initialize_billing_probes_locked()
                    self._initialize_admission_evidence_locked()
                    self._initialize_run_holds_locked()  # O0b RS-A
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f'PRAGMA user_version = {LEDGER_SCHEMA_VERSION}')
                return
            if current >= 11:
                if not check_cleanup_coverage(self._connection):
                    raise LedgerError('account cleanup coverage is unavailable')
            if current >= 12 and not check_observation_coverage(self._connection):
                raise LedgerError('account observation coverage is unavailable')
            if current == 11:
                self._require_project_migration_backups(11, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_account_observations_locked()
                    self._initialize_billing_probes_locked()
                    self._initialize_admission_evidence_locked()
                    self._initialize_run_holds_locked()  # O0b RS-A
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
                return
            if current >= 13 and not check_billing_probe_coverage(self._connection):
                raise LedgerError('billing probe coverage is unavailable')
            if current == 12:
                self._require_project_migration_backups(12, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_billing_probes_locked()
                    self._initialize_admission_evidence_locked()
                    self._initialize_run_holds_locked()  # O0b RS-A
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
                return
            if current >= 14 and not check_admission_evidence_coverage(self._connection):
                raise LedgerError('admission evidence coverage is unavailable')
            if current == 13:
                self._require_project_migration_backups(13, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_admission_evidence_locked()
                    self._initialize_run_holds_locked()  # O0b RS-A
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
                return
            # O0b RS-A: schema 15 adds the hold register, through the same authorized path.
            if current >= 15 and not check_run_holds_consistency(self._connection):
                raise LedgerError('run hold coverage is unavailable')
            if current == 14:
                self._require_project_migration_backups(14, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_run_holds_locked()
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
                return
            if current == 15:
                self._require_project_migration_backups(15, LEDGER_SCHEMA_VERSION)
                with self._account_transaction():
                    self._initialize_probe_ids_locked()
                    self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
                return
        if current == 16:
            # Epoch-only, additive step. The lifetime lock already proves the
            # prior writer retired; no per-project data is rewritten or backed up.
            with self._account_transaction():
                self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
            return
        with self._account_transaction():
            self._migrate_layout_locked(current)

    def _execute_schema_script_locked(self, script: str) -> None:
        """Execute compiled schema SQL without executescript's implicit COMMIT.

        SQLite's parser recognizes complete trigger bodies and quoted semicolons.
        Only the trusted migration constants below enter this helper.
        """
        if not self._connection.in_transaction:
            raise LedgerError("schema migration requires an owned transaction")
        pending: list[str] = []
        for character in script:
            pending.append(character)
            if character == ";" and sqlite3.complete_statement("".join(pending)):
                self._connection.execute("".join(pending))
                pending.clear()
        if trailing := "".join(pending).strip():
            self._connection.execute(trailing)

    def _migrate_layout_locked(self, current: int) -> None:
        # The caller owns the single transaction, including all additive DDL.
        had_hook_ingestion = self._connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='hook_ingestion'"
        ).fetchone() is not None
        if current == 0:
            with contextlib.nullcontext():
                self._execute_schema_script_locked(
                    """
                    CREATE TABLE projects (
                        project_id TEXT PRIMARY KEY,
                        canonical_root TEXT,
                        root_digest TEXT,
                        status TEXT NOT NULL CHECK(status IN ('active','deleted')),
                        created_at_ms INTEGER NOT NULL,
                        deleted_at_ms INTEGER
                    );
                    CREATE TABLE sessions (
                        project_id TEXT NOT NULL,
                        session_digest TEXT NOT NULL,
                        producer TEXT NOT NULL,
                        created_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, session_digest, producer),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE IF NOT EXISTS run_provenance (
                        project_id TEXT NOT NULL,
                        run_id TEXT NOT NULL,
                        producer TEXT NOT NULL,
                        client_version TEXT NOT NULL,
                        session_digest TEXT NOT NULL,
                        created_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, run_id, producer),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE records (
                        project_id TEXT NOT NULL,
                        record_id TEXT NOT NULL,
                        record_type TEXT NOT NULL,
                        source TEXT NOT NULL,
                        source_sequence INTEGER NOT NULL,
                        observed_at_ms INTEGER NOT NULL,
                        ingested_at_ms INTEGER NOT NULL,
                        expires_at_ms INTEGER,
                        content BLOB NOT NULL,
                        content_digest TEXT NOT NULL,
                        late INTEGER NOT NULL CHECK(late IN (0,1)),
                        PRIMARY KEY(project_id, record_id),
                        UNIQUE(project_id, source_sequence),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE record_links (
                        project_id TEXT NOT NULL,
                        from_record_id TEXT NOT NULL,
                        to_record_id TEXT NOT NULL,
                        relation TEXT NOT NULL,
                        PRIMARY KEY(project_id, from_record_id, to_record_id, relation),
                        FOREIGN KEY(project_id, from_record_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE,
                        FOREIGN KEY(project_id, to_record_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE
                    );
                    CREATE TABLE stored_files (
                        project_id TEXT NOT NULL,
                        file_id TEXT NOT NULL,
                        kind TEXT NOT NULL CHECK(kind IN ('artifact','export','backup')),
                        relative_path TEXT NOT NULL,
                        content_digest TEXT NOT NULL,
                        source_record_id TEXT,
                        expires_at_ms INTEGER,
                        PRIMARY KEY(project_id, file_id),
                        UNIQUE(project_id, relative_path),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
                        FOREIGN KEY(project_id, source_record_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE
                    );
                    CREATE TABLE collector_health (
                        project_id TEXT NOT NULL,
                        code TEXT NOT NULL,
                        count INTEGER NOT NULL,
                        updated_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, code),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE tombstones (
                        project_id TEXT NOT NULL,
                        deletion_id TEXT NOT NULL,
                        deleted_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, deletion_id)
                    );
                    CREATE TABLE consumed_grants (
                        project_id TEXT NOT NULL,
                        grant_id TEXT NOT NULL,
                        promotion_record_id TEXT NOT NULL,
                        candidate_digest TEXT NOT NULL,
                        action TEXT NOT NULL,
                        consumed_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, grant_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
                        FOREIGN KEY(project_id, grant_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE,
                        FOREIGN KEY(project_id, promotion_record_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE
                    );
                    CREATE TABLE owner_attestations (
                        project_id TEXT NOT NULL,
                        subject_record_id TEXT NOT NULL,
                        signature BLOB NOT NULL,
                        attested_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, subject_record_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
                        FOREIGN KEY(project_id, subject_record_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE
                    );
                    CREATE TABLE repair_receipts (
                        project_id TEXT NOT NULL,
                        receipt_id TEXT NOT NULL,
                        assignment_digest TEXT NOT NULL,
                        reason_code TEXT NOT NULL,
                        issued_at_ms INTEGER NOT NULL,
                        expires_at_ms INTEGER NOT NULL,
                        consumed_at_ms INTEGER,
                        run_id TEXT,
                        PRIMARY KEY(project_id, receipt_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    PRAGMA user_version = 4;
                    """
                )
        elif current == 1:
            with contextlib.nullcontext():
                self._execute_schema_script_locked(
                    """
                    CREATE TABLE owner_attestations (
                        project_id TEXT NOT NULL,
                        subject_record_id TEXT NOT NULL,
                        signature BLOB NOT NULL,
                        attested_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, subject_record_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
                        FOREIGN KEY(project_id, subject_record_id)
                            REFERENCES records(project_id, record_id) ON DELETE CASCADE
                    );
                    CREATE TABLE IF NOT EXISTS run_provenance (
                        project_id TEXT NOT NULL,
                        run_id TEXT NOT NULL,
                        producer TEXT NOT NULL,
                        client_version TEXT NOT NULL,
                        session_digest TEXT NOT NULL,
                        created_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, run_id, producer),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE repair_receipts (
                        project_id TEXT NOT NULL,
                        receipt_id TEXT NOT NULL,
                        assignment_digest TEXT NOT NULL,
                        reason_code TEXT NOT NULL,
                        issued_at_ms INTEGER NOT NULL,
                        expires_at_ms INTEGER NOT NULL,
                        consumed_at_ms INTEGER,
                        run_id TEXT,
                        PRIMARY KEY(project_id, receipt_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    PRAGMA user_version = 4;
                    """
                )
        elif current == 2:
            with contextlib.nullcontext():
                self._execute_schema_script_locked(
                    """
                    CREATE TABLE run_provenance (
                        project_id TEXT NOT NULL,
                        run_id TEXT NOT NULL,
                        producer TEXT NOT NULL,
                        client_version TEXT NOT NULL,
                        session_digest TEXT NOT NULL,
                        created_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, run_id, producer),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE repair_receipts (
                        project_id TEXT NOT NULL,
                        receipt_id TEXT NOT NULL,
                        assignment_digest TEXT NOT NULL,
                        reason_code TEXT NOT NULL,
                        issued_at_ms INTEGER NOT NULL,
                        expires_at_ms INTEGER NOT NULL,
                        consumed_at_ms INTEGER,
                        run_id TEXT,
                        PRIMARY KEY(project_id, receipt_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    PRAGMA user_version = 4;
                    """
                )
        elif current == 3:
            with contextlib.nullcontext():
                self._execute_schema_script_locked(
                    """
                    CREATE TABLE repair_receipts (
                        project_id TEXT NOT NULL,
                        receipt_id TEXT NOT NULL,
                        assignment_digest TEXT NOT NULL,
                        reason_code TEXT NOT NULL,
                        issued_at_ms INTEGER NOT NULL,
                        expires_at_ms INTEGER NOT NULL,
                        consumed_at_ms INTEGER,
                        run_id TEXT,
                        PRIMARY KEY(project_id, receipt_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    PRAGMA user_version = 4;
                    """
                )
        # These tables are additive and deliberately keep user_version at 4 so a
        # registered 0.3.0 project can still cold-start the shared collector.
        if current <= LEDGER_SCHEMA_VERSION:
            with contextlib.nullcontext():
                self._execute_schema_script_locked(
                    """
                    CREATE TABLE IF NOT EXISTS host_run_bindings (
                        project_id TEXT NOT NULL,
                        handle_digest TEXT NOT NULL,
                        run_id TEXT NOT NULL,
                        assignment_digest TEXT NOT NULL,
                        task_digest TEXT NOT NULL,
                        task_id_digest TEXT,
                        route_digest TEXT NOT NULL,
                        configuration_digest TEXT NOT NULL,
                        client_version TEXT NOT NULL,
                        created_at_ms INTEGER NOT NULL,
                        expires_at_ms INTEGER NOT NULL,
                        consumed_at_ms INTEGER,
                        PRIMARY KEY(project_id, handle_digest),
                        UNIQUE(project_id, run_id),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    CREATE TABLE IF NOT EXISTS hook_ingestion (
                        project_id TEXT NOT NULL,
                        event_code TEXT NOT NULL CHECK(event_code IN (
                            'session_started','session_ended','turn_started',
                            'turn_stop_observed','turn_interrupted','subagent_started',
                            'subagent_stop_observed','tool_started','tool_output_observed'
                        )),
                        accepted_count INTEGER NOT NULL CHECK(accepted_count>=0),
                        last_accepted_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, event_code),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    """ + _ADDITIVE_MIGRATIONS_SCHEMA + """;
                    CREATE INDEX IF NOT EXISTS hook_event_latest
                    ON records(
                        project_id,
                        json_extract(CAST(content AS TEXT),'$.event_code'),
                        ingested_at_ms DESC
                    )
                    WHERE source='hook' AND record_type='event';
                    CREATE TRIGGER IF NOT EXISTS aggregate_hook_event_insert
                    AFTER INSERT ON records
                    WHEN NEW.source='hook' AND NEW.record_type='event'
                         AND json_extract(CAST(NEW.content AS TEXT),'$.event_code') IN (
                            'session_started','session_ended','turn_started',
                            'turn_stop_observed','turn_interrupted','subagent_started',
                            'subagent_stop_observed','tool_started','tool_output_observed'
                         )
                    BEGIN
                        INSERT INTO hook_ingestion VALUES(
                            NEW.project_id,
                            json_extract(CAST(NEW.content AS TEXT),'$.event_code'),
                            1,
                            NEW.ingested_at_ms
                        )
                        ON CONFLICT(project_id,event_code) DO UPDATE SET
                            accepted_count=accepted_count+1,
                            last_accepted_at_ms=MAX(
                                last_accepted_at_ms,excluded.last_accepted_at_ms
                            );
                    END;
                    CREATE TRIGGER IF NOT EXISTS aggregate_hook_event_delete
                    AFTER DELETE ON records
                    WHEN OLD.source='hook' AND OLD.record_type='event'
                         AND json_extract(CAST(OLD.content AS TEXT),'$.event_code') IN (
                            'session_started','session_ended','turn_started',
                            'turn_stop_observed','turn_interrupted','subagent_started',
                            'subagent_stop_observed','tool_started','tool_output_observed'
                         )
                    BEGIN
                        UPDATE hook_ingestion
                        SET accepted_count=accepted_count-1,
                            last_accepted_at_ms=CASE
                                WHEN OLD.ingested_at_ms<last_accepted_at_ms
                                THEN last_accepted_at_ms
                                ELSE COALESCE(
                                    (
                                        SELECT MAX(ingested_at_ms) FROM records
                                        WHERE project_id=OLD.project_id
                                          AND source='hook' AND record_type='event'
                                          AND json_extract(
                                              CAST(content AS TEXT),'$.event_code'
                                          )=json_extract(
                                              CAST(OLD.content AS TEXT),'$.event_code'
                                          )
                                    ),
                                    0
                                )
                            END
                        WHERE project_id=OLD.project_id
                          AND event_code=json_extract(
                              CAST(OLD.content AS TEXT),'$.event_code'
                          );
                        DELETE FROM hook_ingestion
                        WHERE project_id=OLD.project_id AND accepted_count<=0;
                    END;
                    CREATE TRIGGER IF NOT EXISTS cleanup_additive_learning_state
                    AFTER UPDATE OF status ON projects
                    WHEN NEW.status='deleted' AND OLD.status<>'deleted'
                    BEGIN
                        DELETE FROM host_run_bindings WHERE project_id=NEW.project_id;
                        DELETE FROM hook_ingestion WHERE project_id=NEW.project_id;
                    END;
                    CREATE TRIGGER IF NOT EXISTS cleanup_host_binding_with_event
                    AFTER DELETE ON records
                    WHEN OLD.source='host' AND OLD.record_type='event'
                    BEGIN
                        DELETE FROM host_run_bindings
                        WHERE project_id=OLD.project_id
                          AND run_id=json_extract(
                              CAST(OLD.content AS TEXT),'$.run_id'
                          );
                    END;
                    """
                )
                migration_complete = had_hook_ingestion and self._connection.execute(
                    "SELECT 1 FROM additive_migrations "
                    "WHERE feature_key='hook_ingestion_v1'"
                ).fetchone() is not None
                if not migration_complete:
                    self._connection.execute("DELETE FROM hook_ingestion")
                    aggregates: dict[tuple[str, str], tuple[int, int]] = {}
                    rows = self._connection.execute(
                        "SELECT project_id,content,ingested_at_ms FROM records "
                        "WHERE source='hook' AND record_type='event'"
                    ).fetchall()
                    for row in rows:
                        event_code = json.loads(bytes(row["content"])).get("event_code")
                        if event_code not in HOOK_EVENT_CODES:
                            continue
                        key = (str(row["project_id"]), event_code)
                        prior_count, prior_latest = aggregates.get(key, (0, 0))
                        aggregates[key] = (
                            prior_count + 1,
                            max(prior_latest, int(row["ingested_at_ms"])),
                        )
                    self._connection.executemany(
                        "INSERT INTO hook_ingestion VALUES(?,?,?,?)",
                        [
                            (project_id, event_code, count, latest)
                            for (project_id, event_code), (count, latest)
                            in aggregates.items()
                        ],
                    )
                    self._connection.execute(
                        "INSERT OR REPLACE INTO additive_migrations "
                        "VALUES('hook_ingestion_v1')"
                    )
        with contextlib.nullcontext():
            self._execute_schema_script_locked(
                """
                CREATE TABLE IF NOT EXISTS orchestrations (
                    project_id TEXT NOT NULL,
                    orchestration_id TEXT NOT NULL,
                    handle_digest TEXT NOT NULL,
                    client_version TEXT NOT NULL,
                    status TEXT NOT NULL CHECK(status IN (
                        'active','completed','failed','interrupted','cancelled'
                    )),
                    started_at_ms INTEGER NOT NULL,
                    ended_at_ms INTEGER,
                    goal_tokens_used INTEGER,
                    goal_time_used_seconds INTEGER,
                    expires_at_ms INTEGER NOT NULL,
                    PRIMARY KEY(project_id, orchestration_id),
                    UNIQUE(project_id, handle_digest),
                    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS orchestration_status
                ON orchestrations(project_id,status,started_at_ms);
                CREATE TABLE IF NOT EXISTS operational_qa (
                    project_id TEXT NOT NULL,
                    qa_id TEXT NOT NULL,
                    qa_digest TEXT NOT NULL,
                    host_outcome_digest TEXT NOT NULL,
                    verifier_host_outcome_digest TEXT NOT NULL,
                    accepted INTEGER NOT NULL CHECK(accepted IN (0,1)),
                    observed_at_ms INTEGER NOT NULL,
                    content BLOB NOT NULL,
                    PRIMARY KEY(project_id, qa_id),
                    UNIQUE(project_id, host_outcome_digest),
                    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS operational_check_receipts (
                    project_id TEXT NOT NULL,
                    receipt_id TEXT NOT NULL,
                    report_digest TEXT NOT NULL,
                    host_outcome_digest TEXT NOT NULL,
                    verifier_host_outcome_digest TEXT NOT NULL,
                    orchestration_id TEXT NOT NULL,
                    issued_at_ms INTEGER NOT NULL,
                    expires_at_ms INTEGER NOT NULL,
                    consumed_at_ms INTEGER,
                    report BLOB NOT NULL,
                    PRIMARY KEY(project_id, receipt_id),
                    FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                );
                CREATE TRIGGER IF NOT EXISTS cleanup_orchestrations_state
                AFTER UPDATE OF status ON projects
                WHEN NEW.status='deleted' AND OLD.status<>'deleted'
                BEGIN
                    DELETE FROM orchestrations WHERE project_id=NEW.project_id;
                    DELETE FROM operational_qa WHERE project_id=NEW.project_id;
                    DELETE FROM operational_check_receipts
                    WHERE project_id=NEW.project_id;
                END;
                CREATE TRIGGER IF NOT EXISTS cleanup_operational_qa_with_outcome
                AFTER DELETE ON records
                WHEN OLD.source='host' AND OLD.record_type='outcome'
                BEGIN
                    DELETE FROM operational_qa
                    WHERE project_id=OLD.project_id
                      AND (
                          host_outcome_digest=OLD.content_digest
                          OR verifier_host_outcome_digest=OLD.content_digest
                      );
                    DELETE FROM operational_check_receipts
                    WHERE project_id=OLD.project_id
                      AND (
                          host_outcome_digest=OLD.content_digest
                          OR verifier_host_outcome_digest=OLD.content_digest
                      );
                END;
                """
            )
            orchestration_columns = {
                str(row[1])
                for row in self._connection.execute(
                    "PRAGMA table_info(orchestrations)"
                ).fetchall()
            }
            if "expires_at_ms" not in orchestration_columns:
                self._connection.execute(
                    "ALTER TABLE orchestrations ADD COLUMN expires_at_ms INTEGER"
                )
                self._connection.execute(
                    "UPDATE orchestrations SET expires_at_ms=started_at_ms+? "
                    "WHERE expires_at_ms IS NULL",
                    (DEFAULT_RETENTION_MS,),
                )
            columns = {
                str(row[1])
                for row in self._connection.execute(
                    "PRAGMA table_info(host_run_bindings)"
                ).fetchall()
            }
            additions = {
                "orchestration_id": "TEXT",
                "native_assignment_id": "TEXT",
                "agent_type": "TEXT",
                "usage_complete": "INTEGER",
                "task_id_digest": "TEXT",
                "binding_state": "TEXT",
                "abandoned_reason": "TEXT",
                "observation_started_at_ms": "INTEGER",
                "observation_deadline_at_ms": "INTEGER",
                "last_progress_at_ms": "INTEGER",
                "deadline_observed": "INTEGER",
            }
            for name, sql_type in additions.items():
                if name not in columns:
                    self._connection.execute(
                        f"ALTER TABLE host_run_bindings ADD COLUMN {name} {sql_type}"
                    )
            self._connection.execute(
                "UPDATE host_run_bindings SET binding_state=CASE "
                "WHEN consumed_at_ms IS NULL THEN 'pending' ELSE 'terminal' END "
                "WHERE binding_state IS NULL"
            )
            # O0b RS-A round 2 G11: this layout step runs at every open; it backfills only the rows still missing
            # a value (each writer sets all three), so an open never rewrites every binding.
            self._connection.execute(
                "UPDATE host_run_bindings SET "
                "observation_started_at_ms=COALESCE(observation_started_at_ms,created_at_ms),"
                "last_progress_at_ms=COALESCE(last_progress_at_ms,created_at_ms),"
                "deadline_observed=COALESCE(deadline_observed,0) "
                "WHERE observation_started_at_ms IS NULL OR last_progress_at_ms IS NULL OR deadline_observed IS NULL"
            )
            if current < 6:
                self._execute_schema_script_locked(
                    """
                    DROP TABLE IF EXISTS orchestration_checkpoints;
                    DROP INDEX IF EXISTS orchestration_status;
                    DROP TRIGGER IF EXISTS cleanup_orchestrations_state;
                    ALTER TABLE orchestrations RENAME TO orchestrations_v5;
                    CREATE TABLE orchestrations (
                        project_id TEXT NOT NULL,
                        orchestration_id TEXT NOT NULL,
                        handle_digest TEXT NOT NULL,
                        client_version TEXT NOT NULL,
                        status TEXT NOT NULL CHECK(status IN (
                            'active','paused','completed','failed','interrupted','cancelled'
                        )),
                        started_at_ms INTEGER NOT NULL,
                        ended_at_ms INTEGER,
                        goal_tokens_used INTEGER,
                        goal_time_used_seconds INTEGER,
                        expires_at_ms INTEGER NOT NULL,
                        PRIMARY KEY(project_id, orchestration_id),
                        UNIQUE(project_id, handle_digest),
                        FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
                    );
                    INSERT INTO orchestrations SELECT * FROM orchestrations_v5;
                    DROP TABLE orchestrations_v5;
                    CREATE INDEX orchestration_status
                    ON orchestrations(project_id,status,started_at_ms);
                    CREATE TRIGGER cleanup_orchestrations_state
                    AFTER UPDATE OF status ON projects
                    WHEN NEW.status='deleted' AND OLD.status<>'deleted'
                    BEGIN
                        DELETE FROM orchestrations WHERE project_id=NEW.project_id;
                        DELETE FROM operational_qa WHERE project_id=NEW.project_id;
                        DELETE FROM operational_check_receipts
                        WHERE project_id=NEW.project_id;
                    END;
                    DROP TRIGGER IF EXISTS cleanup_host_binding_with_event;
                    """
                )
            self._execute_schema_script_locked(
                """
                CREATE TABLE IF NOT EXISTS orchestration_checkpoints (
                    project_id TEXT NOT NULL,
                    orchestration_id TEXT NOT NULL,
                    sequence INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    goal_tokens_used INTEGER,
                    goal_time_used_seconds INTEGER,
                    observed_at_ms INTEGER NOT NULL,
                    PRIMARY KEY(project_id, orchestration_id, sequence),
                    FOREIGN KEY(project_id, orchestration_id)
                        REFERENCES orchestrations(project_id, orchestration_id)
                        ON DELETE CASCADE
                );
                """
            )
            if current < 6:
                self._connection.execute(
                    "INSERT INTO orchestration_checkpoints("
                    "project_id,orchestration_id,sequence,status,goal_tokens_used,"
                    "goal_time_used_seconds,observed_at_ms) "
                    "SELECT project_id,orchestration_id,1,status,goal_tokens_used,"
                    "goal_time_used_seconds,COALESCE(ended_at_ms,started_at_ms) "
                    "FROM orchestrations"
                )
            if current < 5:
                self._initialize_launch_claims_locked(backfill=current != 0)
                self._initialize_launch_operations_locked()
                self._initialize_active_capacity_locked()
                self._initialize_account_opens_locked()
                self._initialize_account_cleanup_locked()
                self._initialize_account_observations_locked()
                self._initialize_billing_probes_locked()
                self._initialize_admission_evidence_locked()
                self._initialize_run_holds_locked()  # O0b RS-A
            self._initialize_probe_ids_locked()
            self._connection.execute(f"PRAGMA user_version = {LEDGER_SCHEMA_VERSION}")
        self.state.harden_database_files()

    def close(self) -> None:
        with self._lock:
            self._connection.close()
            descriptor = self._writer_descriptor
            self._writer_descriptor = None
            if descriptor is not None:
                with contextlib.suppress(OSError):
                    if fcntl is not None:
                        fcntl.flock(descriptor, fcntl.LOCK_UN)
                    os.close(descriptor)

    def register_project(self, project_root: Path, *, now_ms: int | None = None) -> str:
        root = _canonical_project_root(project_root)
        root_text = str(root)
        digest = keyed_digest(self.state.digest_key(), root_text)
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held():
            row = self._connection.execute(
                "SELECT project_id FROM projects WHERE root_digest=? AND status='active'",
                (digest,),
            ).fetchone()
            if row:
                return str(row["project_id"])
            project_id = f"prj_{secrets.token_hex(16)}"
            # E2a-2: explicit columns; registration never writes the launch record.
            self._connection.execute(
                "INSERT INTO projects(project_id,canonical_root,root_digest,status,created_at_ms,deleted_at_ms) "
                "VALUES(?,?,?,?,?,NULL)",
                (project_id, root_text, digest, "active", timestamp),
            )
            return project_id

    def _initialize_launch_and_wake(self) -> None:
        """RS-E E2a-1: the launch columns and the wake table, additive and idempotent (no version change)."""
        columns = {row[1] for row in self._connection.execute("PRAGMA table_info(projects)")}
        for name in ("launch_copy", "launch_digest"):
            if name not in columns:
                self._connection.execute(f"ALTER TABLE projects ADD COLUMN {name} TEXT")
        # Decision 179: the review-round-1 form kept one instance per project (never released): replaced.
        if any(row[1] == "instance" and row[5] == 0 for row in self._connection.execute(
                "PRAGMA table_info(project_wake_instances)")):
            self._connection.execute("DROP TABLE project_wake_instances")
        for statement in _WAKE_SCHEMA:
            self._connection.execute(statement)
        for statement in _START_SCHEMA:  # RS-E E2c
            self._connection.execute(statement)

    def active_project_roots(self) -> list[tuple[str, str]]:
        """(project_id, canonical root) of every active project, in project order."""
        with self._held():
            return [(str(row["project_id"]), str(row["canonical_root"])) for row in self._connection.execute(
                "SELECT project_id,canonical_root FROM projects WHERE status='active' ORDER BY project_id")]

    def record_launch(self, project_id: str, launch_copy: str, launch_digest: str) -> None:
        """E2a-3: setup's launch record for one active project. The copy must be named by its digest inside this
        project's digest folder of a runtime container; anything else is refused and nothing changes."""
        if (type(launch_digest) is not str or len(launch_digest) != 64 or not set(launch_digest) <= set("0123456789abcdef")
                or type(launch_copy) is not str or "\0" in launch_copy or len(launch_copy.encode()) > 4096):
            raise LedgerError("launch record is invalid")
        copy = Path(launch_copy)
        with self._held():
            row = self._connection.execute(
                "SELECT canonical_root FROM projects WHERE project_id=? AND status='active'", (project_id,)).fetchone()
            if row is None:
                raise ProjectNotRegisteredError("project is not registered")
            folder = hashlib.sha256(str(row["canonical_root"]).encode("utf-8")).hexdigest()[:12]
            if (not copy.is_absolute() or str(copy) != launch_copy or ".." in copy.parts
                    or copy.name != launch_digest or copy.parent.name != folder
                    or copy.parent.parent.name != "agent-orchestration"):
                raise LedgerError("launch record is invalid")
            self._connection.execute("UPDATE projects SET launch_copy=?,launch_digest=? WHERE project_id=?",
                                     (launch_copy, launch_digest, project_id))

    def launch_record(self, project_id: str) -> tuple[str, str] | None:
        with self._held():
            row = self._connection.execute(
                "SELECT launch_copy,launch_digest FROM projects WHERE project_id=? AND status='active'",
                (project_id,)).fetchone()
        if row is None or row["launch_copy"] is None or row["launch_digest"] is None:
            return None
        return str(row["launch_copy"]), str(row["launch_digest"])

    def publish_wake(self, project_id: str, *, epoch: int | None, seq: int, state: str,
                     next_due_at_ms: int | None, now_ms: int | None = None, instance: str | None = None) -> dict:
        """E2a-6: one wake publication. A null epoch allocates the next durable epoch, unless the project's last
        allocation went to this same `instance` (its acknowledgement was lost): that epoch again. A strictly newer
        generation replaces the row; the same generation and body is a duplicate; anything else is `stale` and only
        counted."""
        if (state not in WAKE_STATES or type(seq) is not int or seq < 1
                or (epoch is not None and (type(epoch) is not int or epoch < 0))
                or (next_due_at_ms is not None and (type(next_due_at_ms) is not int or next_due_at_ms < 0))
                or (instance is not None and (epoch is not None or type(instance) is not str
                                              or re.fullmatch(r"[0-9a-f]{32}", instance) is None))):
            raise LedgerError("wake publication is invalid")
        now = time.time_ns() // 1_000_000 if now_ms is None else now_ms
        body = hashlib.sha256(canonical_json({"state": state, "next_due_at_ms": next_due_at_ms})).hexdigest()
        with self._account_transaction():
            if self._connection.execute("SELECT 1 FROM projects WHERE project_id=? AND status='active'",
                                        (project_id,)).fetchone() is None:
                raise ProjectNotRegisteredError("project is not registered")
            self._connection.execute(
                "INSERT OR IGNORE INTO project_wake(project_id,allocated_epoch,refused,updated_at_ms) VALUES(?,0,0,?)",
                (project_id, now))
            row = self._connection.execute("SELECT * FROM project_wake WHERE project_id=?", (project_id,)).fetchone()
            current = None if row["epoch"] is None else (int(row["epoch"]), int(row["seq"]))
            outcome = "accepted"
            last = None if instance is None else self._connection.execute(
                "SELECT epoch FROM project_wake_instances WHERE project_id=? AND instance=?",
                (project_id, instance)).fetchone()
            if epoch is None and last is not None:
                # This instance's own epoch, allocated before its reply was lost; an older instance's is older than
                # its successor's, so its retry is stale once the successor published (decision 179).
                epoch = int(last["epoch"])
                current_check = current
                if current_check is not None and (epoch, seq) == current_check:
                    outcome = "duplicate" if row["body_digest"] == body else "stale"
                elif current_check is not None and (epoch, seq) < current_check:
                    outcome = "stale"
            elif epoch is None:
                epoch = int(row["allocated_epoch"]) + 1
                self._connection.execute("UPDATE project_wake SET allocated_epoch=? WHERE project_id=?",
                                         (epoch, project_id))
                if instance is not None:
                    self._connection.execute(
                        "INSERT INTO project_wake_instances(project_id,instance,epoch) VALUES(?,?,?)",
                        (project_id, instance, epoch))
            elif epoch < 1 or epoch > int(row["allocated_epoch"]):
                outcome = "stale"
            elif current is not None and (epoch, seq) == current:
                outcome = "duplicate" if row["body_digest"] == body else "stale"
            elif current is not None and (epoch, seq) < current:
                outcome = "stale"
            if instance is None and outcome != "stale":
                # Its instance learned its epoch (it publishes with it): it never asks with a null epoch again.
                self._connection.execute("DELETE FROM project_wake_instances WHERE project_id=? AND epoch=?",
                                         (project_id, epoch))
            if outcome == "accepted":
                self._connection.execute(
                    "UPDATE project_wake SET epoch=?,seq=?,state=?,next_due_at_ms=?,body_digest=?,due_at_ms=?,"
                    "updated_at_ms=? WHERE project_id=?",
                    (epoch, seq, state, next_due_at_ms, body, next_due_at_ms, now, project_id))
            elif outcome == "stale":
                self._connection.execute(
                    "UPDATE project_wake SET refused=refused+1,updated_at_ms=? WHERE project_id=?", (now, project_id))
        return {"epoch": epoch, "seq": seq, "outcome": outcome}

    def wake_reconcile_candidates(self, *, now_ms: int, limit: int = WAKE_RECONCILE_BATCH,
                                  after: str = "") -> list[tuple[str, str, int | None, int | None]]:
        """E2a-9: active projects whose wake state is unknown and not yet due, from `after` in project order:
        (project_id, root, epoch, seq). A matched-rows read for callers that want only candidates; the collector's
        own pass pages by rows examined instead (`wake_reconcile_page`)."""
        with self._held():
            return [(str(row["project_id"]), str(row["canonical_root"]), row["epoch"], row["seq"])
                    for row in self._connection.execute(
                        "SELECT p.project_id,p.canonical_root,w.epoch,w.seq FROM projects p "
                        "LEFT JOIN project_wake w ON w.project_id=p.project_id WHERE p.status='active' "
                        "AND p.project_id>? AND (w.project_id IS NULL OR w.state IS NULL OR w.state<>'clean_stop') "
                        "AND (w.due_at_ms IS NULL OR w.due_at_ms>?) ORDER BY p.project_id LIMIT ?",
                        (after, now_ms, limit))]

    def wake_reconcile_page(self, *, after: str = "", limit: int = WAKE_RECONCILE_BATCH
                            ) -> tuple[list[tuple], str | None]:
        """E2a-9: one page of at most `limit` project rows from `after` in project order (rows examined, by the
        primary key: inactive and settled rows count too), with their wake columns, and the cursor for the next
        page (None once the last page is read). The caller decides off this lock which rows are unknown."""
        with self._held():
            rows = self._connection.execute(
                "SELECT p.project_id,p.canonical_root,p.status,w.epoch,w.seq,w.state,w.due_at_ms FROM projects p "
                "LEFT JOIN project_wake w ON w.project_id=p.project_id WHERE p.project_id>? "
                "ORDER BY p.project_id LIMIT ?", (after, limit)).fetchall()
        page = [(str(row["project_id"]), str(row["canonical_root"]), str(row["status"]), row["epoch"], row["seq"],
                 row["state"], row["due_at_ms"]) for row in rows]
        return page, (page[-1][0] if len(page) == limit else None)

    def mark_wakes_due(self, candidates, *, now_ms: int) -> int:
        """E2a-9: mark these unknown projects due now, unless a publication landed since they were read. A
        candidate is (project_id, root, epoch, seq) or, for a clean stop whose service left an unpublished-write
        marker, (project_id, root, epoch, seq, True)."""
        marked = 0
        with self._account_transaction():
            for candidate in candidates:
                project_id, _root, epoch, seq = candidate[:4]
                marked_stop = len(candidate) > 4 and candidate[4] is True
                if epoch is None:
                    inserted = self._connection.execute(
                        "INSERT OR IGNORE INTO project_wake(project_id,allocated_epoch,refused,due_at_ms,updated_at_ms) "
                        "SELECT project_id,0,0,?,? FROM projects WHERE project_id=? AND status='active'",
                        (now_ms, now_ms, project_id)).rowcount
                    marked += inserted or self._connection.execute(
                        "UPDATE project_wake SET due_at_ms=?,updated_at_ms=? WHERE project_id=? AND epoch IS NULL "
                        "AND (due_at_ms IS NULL OR due_at_ms>?)", (now_ms, now_ms, project_id, now_ms)).rowcount
                else:
                    marked += self._connection.execute(
                        "UPDATE project_wake SET due_at_ms=?,updated_at_ms=? WHERE project_id=? AND epoch=? AND seq=? "
                        "AND (state IS NULL OR state<>'clean_stop' OR ?) AND (due_at_ms IS NULL OR due_at_ms>?)",
                        (now_ms, now_ms, project_id, epoch, seq, 1 if marked_stop else 0, now_ms)).rowcount
        return marked

    # RS-E E2c: the starter's ledger steps. Each is one short hold of the ledger lock; nothing here probes, hashes,
    # spawns or waits (E2c-2).

    def claim_due_starts(self, *, now_ms: int, limit: int,
                         after: tuple[int, str] | None = None) -> list[StartClaim]:
        """E2c-2: claim at most `limit` due projects (one indexed read), each marked outstanding with a fresh attempt
        id and its claim time in the same transaction. A parked project is claimed again only once setup recorded a
        new launch digest, which also starts a fresh streak (owner decision 143). `after`: the starter's cursor
        (due time, project id) of the last row it claimed; only rows after it are read (HIGH 1)."""
        if type(limit) is not int or not 0 < limit <= 64:
            raise LedgerError("start claim limit is invalid")
        if after is None:
            query, parameters = START_CLAIM_SQL, (now_ms, now_ms, limit)
        else:
            if (type(after) is not tuple or len(after) != 2 or type(after[0]) is not int
                    or type(after[1]) is not str):
                raise LedgerError("start claim cursor is invalid")
            query, parameters = START_CLAIM_AFTER_SQL, (now_ms, after[0], after[0], after[1], now_ms, limit)
        claims = []
        with self._account_transaction():
            for row in self._connection.execute(query, parameters).fetchall():
                attempt = secrets.token_hex(16)
                self._connection.execute(
                    "INSERT OR IGNORE INTO project_starts(project_id,failures,updated_at_ms) VALUES(?,0,?)",
                    (row["project_id"], now_ms))
                unpark = row["parked_reason"] is not None
                self._connection.execute(
                    "UPDATE project_starts SET attempt=?,claimed_at_ms=?,child_pid=NULL,outcome='starting',"
                    "reason=NULL,outcome_at_ms=?,updated_at_ms=?" + (
                        ",parked_reason=NULL,parked_digest=NULL,failures=0,streak_first_ms=NULL,next_start_at_ms=NULL"
                        if unpark else "") + " WHERE project_id=?",
                    (attempt, now_ms, now_ms, now_ms, row["project_id"]))
                claims.append(StartClaim(str(row["project_id"]), str(row["canonical_root"]),
                                         None if row["launch_copy"] is None else str(row["launch_copy"]),
                                         None if row["launch_digest"] is None else str(row["launch_digest"]), attempt,
                                         int(row["due_at_ms"])))
        return claims

    def set_start_child(self, project_id: str, attempt: str, pid: int) -> None:
        """E2c-10: the claim's spawned child, kept so a later collector can reconcile a claim this one left."""
        with self._account_transaction():
            self._connection.execute("UPDATE project_starts SET child_pid=? WHERE project_id=? AND attempt=?",
                                     (int(pid), project_id, attempt))

    def _start_row(self, project_id: str) -> dict | None:
        row = self._connection.execute("SELECT * FROM project_starts WHERE project_id=?", (project_id,)).fetchone()
        return None if row is None else dict(row)

    def _count_start_failure(self, project_id: str, reason: str, now_ms: int, *, backoff_first_ms: int,
                             backoff_max_ms: int, park_after_ms: int) -> None:
        """E2c-4: one failure of the streak; past park_after_ms from its first failure, the project parks."""
        row = self._start_row(project_id)
        failures = int(row["failures"]) + 1
        first = now_ms if row["streak_first_ms"] is None else int(row["streak_first_ms"])
        if now_ms - first >= park_after_ms:
            digest = self._connection.execute("SELECT launch_digest FROM projects WHERE project_id=?",
                                              (project_id,)).fetchone()
            self._connection.execute(
                "UPDATE project_starts SET failures=?,streak_first_ms=?,next_start_at_ms=NULL,parked_reason=?,"
                "parked_digest=?,outcome='failed',reason=?,outcome_at_ms=?,updated_at_ms=? WHERE project_id=?",
                (failures, first, reason, None if digest is None else digest["launch_digest"], reason, now_ms, now_ms,
                 project_id))
            return
        wait = min(backoff_max_ms, backoff_first_ms * (2 ** min(failures - 1, 32)))
        self._connection.execute(
            "UPDATE project_starts SET failures=?,streak_first_ms=?,next_start_at_ms=?,outcome='failed',reason=?,"
            "outcome_at_ms=?,updated_at_ms=? WHERE project_id=?",
            (failures, first, now_ms + wait, reason, now_ms, now_ms, project_id))

    def finish_start(self, project_id: str, attempt: str, *, outcome: str, reason: str | None, now_ms: int,
                     backoff_first_ms: int, backoff_max_ms: int, park_after_ms: int, recheck_ms: int,
                     probation_ms: int = 0, child_pid: int | None = None) -> dict | None:
        """E2c-2/4: end this attempt (no other attempt's claim is touched). `failed` counts one failure; `started`
        keeps the streak until its probation ends (`start_probation`): the probation is kept with this attempt, its
        child and its end (now + probation_ms), so a restarted collector reconciles it (review round 1, HIGH 4);
        every other outcome (no record, install changed, handover, migration, serving) is looked at again after
        recheck_ms and counts nothing, and never replaces an active probation. Returns the row, or None when the
        attempt is not outstanding."""
        if outcome not in START_OUTCOMES:
            raise LedgerError("start outcome is invalid")
        with self._account_transaction():
            row = self._start_row(project_id)
            if row is None or row["attempt"] != attempt:
                return None
            self._connection.execute(
                "UPDATE project_starts SET attempt=NULL,claimed_at_ms=NULL,child_pid=NULL WHERE project_id=?",
                (project_id,))
            if outcome == "failed":
                self._count_start_failure(project_id, reason or "service_ended", now_ms,
                                          backoff_first_ms=backoff_first_ms, backoff_max_ms=backoff_max_ms,
                                          park_after_ms=park_after_ms)
            elif outcome == "started":
                pid = None if child_pid is None or int(child_pid) <= 1 else int(child_pid)
                self._connection.execute(
                    "UPDATE project_starts SET next_start_at_ms=NULL,outcome='started',reason=NULL,outcome_at_ms=?,"
                    "started_at_ms=?,probation_attempt=?,probation_pid=?,probation_until_ms=?,updated_at_ms=? "
                    "WHERE project_id=?", (now_ms, now_ms, attempt, pid, now_ms + int(probation_ms), now_ms,
                                          project_id))
            elif row["probation_attempt"] is not None:
                # HIGH 4: a recheck during a started host's probation keeps the probation and its `started` line.
                self._connection.execute(
                    "UPDATE project_starts SET next_start_at_ms=?,updated_at_ms=? WHERE project_id=?",
                    (now_ms + recheck_ms, now_ms, project_id))
            else:
                self._connection.execute(
                    "UPDATE project_starts SET next_start_at_ms=?,outcome=?,reason=?,outcome_at_ms=?,updated_at_ms=? "
                    "WHERE project_id=?", (now_ms + recheck_ms, outcome, reason, now_ms, now_ms, project_id))
            return self._start_row(project_id)

    def release_start(self, project_id: str, attempt: str, *, now_ms: int) -> None:
        """E2c-10: an attempt that never spawned (a stopping collector, or a claim a dead collector left with no
        child) is released as it was claimed: no outcome, no failure."""
        with self._account_transaction():
            self._connection.execute(
                "UPDATE project_starts SET attempt=NULL,claimed_at_ms=NULL,child_pid=NULL,outcome=NULL,"
                "updated_at_ms=? WHERE project_id=? AND attempt=?", (now_ms, project_id, attempt))

    def start_probation(self, project_id: str, *, survived: bool, now_ms: int, backoff_first_ms: int,
                        backoff_max_ms: int, park_after_ms: int, recheck_ms: int = 0, probation_ms: int = 0,
                        attempt: str | None = None) -> dict | None:
        """E2c-4: a started host that served START_PROBATION_SECONDS ends the streak; one that ended sooner counts
        one failure. Only for a probation still kept (HIGH 4), and with `attempt` only for that attempt's; the
        probation ends either way."""
        with self._account_transaction():
            row = self._start_row(project_id)
            if (row is None or row["attempt"] is not None or row["probation_attempt"] is None
                    or (attempt is not None and row["probation_attempt"] != attempt)):
                return row
            self._connection.execute(
                "UPDATE project_starts SET probation_attempt=NULL,probation_pid=NULL,probation_until_ms=NULL "
                "WHERE project_id=?", (project_id,))
            if survived:
                self._connection.execute(
                    "UPDATE project_starts SET failures=0,streak_first_ms=NULL,updated_at_ms=? WHERE project_id=?",
                    (now_ms, project_id))
            else:
                self._count_start_failure(project_id, "service_ended_early", now_ms,
                                          backoff_first_ms=backoff_first_ms, backoff_max_ms=backoff_max_ms,
                                          park_after_ms=park_after_ms)
            return self._start_row(project_id)

    def outstanding_starts(self, *, after: str = "", limit: int = 64) -> list[dict]:
        """E2c-10: one page of outstanding claims after `after` in project order (the partial index), for the
        starter's reconcile, which reads page after page."""
        with self._held():
            return [dict(row) for row in self._connection.execute(
                "SELECT s.project_id,s.attempt,s.claimed_at_ms,s.child_pid,p.canonical_root FROM project_starts s "
                "JOIN projects p ON p.project_id=s.project_id WHERE s.attempt IS NOT NULL AND s.project_id>? "
                "ORDER BY s.project_id LIMIT ?", (after, limit))]

    def probation_starts(self, *, after: str = "", limit: int = 64) -> list[dict]:
        """HIGH 4: one page of kept probations after `after` in project order (their partial index), for the
        starter's reconcile after a restart, which reads page after page."""
        with self._held():
            return [dict(row) for row in self._connection.execute(
                "SELECT s.project_id,s.probation_attempt,s.probation_pid,s.probation_until_ms,p.canonical_root "
                "FROM project_starts s JOIN projects p ON p.project_id=s.project_id "
                "WHERE s.probation_attempt IS NOT NULL AND s.project_id>? ORDER BY s.project_id LIMIT ?",
                (after, limit))]

    def unpark_start(self, project_id: str, *, now_ms: int) -> None:
        """E2c-4 (owner decision 143): the owner's start command ends the park and the streak."""
        with self._account_transaction():
            if self._connection.execute("SELECT 1 FROM projects WHERE project_id=? AND status='active'",
                                        (project_id,)).fetchone() is None:
                raise ProjectNotRegisteredError("project is not registered")
            self._connection.execute(
                "UPDATE project_starts SET parked_reason=NULL,parked_digest=NULL,failures=0,streak_first_ms=NULL,"
                "next_start_at_ms=NULL,outcome=CASE WHEN attempt IS NULL THEN NULL ELSE outcome END,updated_at_ms=? "
                "WHERE project_id=?", (now_ms, project_id))

    def start_record(self, project_id: str) -> dict:
        """E2c-9: what the status line reads: the start row (or {}) and the wake row's due time. No content."""
        with self._held():
            row = self._start_row(project_id) or {}
            wake = self._connection.execute("SELECT due_at_ms FROM project_wake WHERE project_id=?",
                                            (project_id,)).fetchone()
        return {**row, "due_at_ms": None if wake is None else wake["due_at_ms"]}

    def _learning_moved_locked(self, project_id: str) -> bool:
        return self._connection.execute(
            "SELECT 1 FROM additive_migrations WHERE feature_key=?",
            (LEARNING_MOVED_KEY + project_id,),
        ).fetchone() is not None

    def has_learning_history(self, project_id: str) -> bool:
        """Whether the ledger holds any learning record or QA row for the project."""

        types = sorted(LEARNING_MOVED_TYPES)
        with self._held():
            return self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND record_type IN ("
                + ",".join("?" for _ in types) + ") LIMIT 1",
                (project_id, *types),
            ).fetchone() is not None or self._connection.execute(
                "SELECT 1 FROM operational_qa WHERE project_id=? LIMIT 1", (project_id,)
            ).fetchone() is not None

    def drained(self, *, children_only: bool = False) -> bool:
        """No run is active or unsettled anywhere (long-crashed claims aside).

        `children_only`: no child may be running, which is all that replacing the
        collector or a project service needs. A run admitted but never claimed has no
        child (a child launches only after its claim), and runs a 0.2.x version left
        never ran under a collector or a project service.
        """

        from .history_contracts import HistoryError
        from .learning_source_image import _drained

        with self._held():
            try:
                _drained(self._connection, self._clock_ms(), children_only=children_only)
            except HistoryError:
                return False
            return True

    def earlier_version_runs(self) -> dict:
        """Held historical slots; evidence-only holds have no automatic finish time."""
        from .legacy_slots import deadline_sql
        with self._held():
            crashed, parameters = crashed_claim("a", self._clock_ms(), self._capacity_clock_reference())
            rows = self._connection.execute(
                f"SELECT {deadline_sql('a')} AS deadline FROM active_run_capacity a "
                f"WHERE a.kind='legacy_unknown' AND a.released_at_ms IS NULL AND NOT {crashed}", parameters).fetchall()
        deadlines = [row["deadline"] for row in rows]
        return {"holding": len(rows), "finished_by_ms":
                max(deadlines) + CRASHED_CLAIM_GRACE_MS + 1 if deadlines and None not in deadlines else None}

    def mark_learning_moved_if_empty(self, project_id: str) -> bool:
        """Retire the ledger for a project that has no learning history in it.

        There is nothing to copy, so this needs no drain and no offline owner:
        the running collector may do it. Returns whether the project is moved.
        """

        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            if self._learning_moved_locked(project_id):
                return True
            if self.has_learning_history(project_id):
                return False
            # A run an earlier version opened here would still record its outcome in
            # the ledger: while one is unsettled the project is not retired.
            crashed, crashed_parameters = crashed_claim("a", self._clock_ms(), time.monotonic_ns())
            if self._connection.execute(
                "SELECT 1 FROM host_run_bindings h WHERE h.project_id=? "
                "AND h.binding_state='pending' AND NOT EXISTS("
                "SELECT 1 FROM active_run_capacity a WHERE a.project_id=h.project_id "
                f"AND a.handle_digest=h.handle_digest AND (a.released_at_ms IS NOT NULL OR {crashed})) LIMIT 1",
                (project_id, *crashed_parameters),
            ).fetchone() is not None:
                return False
            self._connection.execute(
                "INSERT INTO additive_migrations VALUES(?)", (LEARNING_MOVED_KEY + project_id,)
            )
            return True

    def learning_activation_pending(self, project_id: str) -> bool:
        """Whether a migration retired the ledger but has not yet switched the copy on."""

        with self._held():
            return self._connection.execute(
                "SELECT 1 FROM additive_migrations WHERE feature_key=?",
                (LEARNING_ACTIVATION_PENDING_KEY + project_id,),
            ).fetchone() is not None

    def clear_learning_activation_pending(self, project_id: str) -> None:
        if self._allow_schema_upgrade is not True or self._collector_active is not False:
            raise LedgerError("learning store cutover requires the offline owner")
        with self._held(), self._connection:
            self._connection.execute(
                "DELETE FROM additive_migrations WHERE feature_key=?",
                (LEARNING_ACTIVATION_PENDING_KEY + project_id,),
            )

    def learning_moved(self, project_id: str) -> bool:
        """Whether this project's learning history now lives in its project store."""

        with self._held():
            return self._learning_moved_locked(project_id)

    def set_learning_moved(
        self, project_id: str, moved: bool, *, activation_pending: bool = False
    ) -> bool:
        """Retire (or, for a rollback, restore) the ledger as this project's learning store.

        Offline owner work during a drained migration; returns whether it changed.
        `activation_pending` records, in the same transaction, that a staged copy
        still has to be switched on in the project store.
        """

        if self._allow_schema_upgrade is not True or self._collector_active is not False:
            raise LedgerError("learning store cutover requires the offline owner")
        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            if self._learning_moved_locked(project_id) is moved:
                return False
            if moved:
                self._connection.execute(
                    "INSERT INTO additive_migrations VALUES(?)",
                    (LEARNING_MOVED_KEY + project_id,),
                )
                if activation_pending:
                    self._connection.execute(
                        "INSERT OR IGNORE INTO additive_migrations VALUES(?)",
                        (LEARNING_ACTIVATION_PENDING_KEY + project_id,),
                    )
            else:
                self._connection.execute(
                    "DELETE FROM additive_migrations WHERE feature_key IN (?,?)",
                    (LEARNING_MOVED_KEY + project_id, LEARNING_ACTIVATION_PENDING_KEY + project_id),
                )
            return True

    def project_for_root(self, project_root: Path) -> str:
        root = _canonical_project_root(project_root)
        digest = keyed_digest(self.state.digest_key(), str(root))
        with self._held():
            row = self._connection.execute(
                "SELECT project_id FROM projects WHERE root_digest=? AND status='active'",
                (digest,),
            ).fetchone()
        if not row:
            raise ProjectNotRegisteredError("project is not registered")
        return str(row["project_id"])

    def issue_result_repair_receipt(
        self,
        project_id: str,
        assignment_digest: str,
        reason_code: str,
        *,
        now_ms: int | None = None,
    ) -> str:
        """Issue one opaque, content-free receipt for a validator rejection."""

        if (
            not isinstance(assignment_digest, str)
            or len(assignment_digest) != 64
            or any(character not in "0123456789abcdef" for character in assignment_digest)
            or not isinstance(reason_code, str)
            or reason_code not in RESULT_VALIDATION_REASON_CODES
        ):
            raise LedgerError("repair receipt request is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        receipt_id = f"rpr_{secrets.token_hex(24)}"
        with self._held(), self._connection:
            self._connection.execute(
                "DELETE FROM repair_receipts WHERE project_id=? AND expires_at_ms<=?",
                (project_id, timestamp),
            )
            pending = int(
                self._connection.execute(
                    "SELECT COUNT(*) FROM repair_receipts WHERE project_id=? "
                    "AND consumed_at_ms IS NULL",
                    (project_id,),
                ).fetchone()[0]
            )
            if pending >= MAX_PENDING_REPAIR_RECEIPTS:
                raise LedgerError("pending repair receipt capacity is exhausted")
            self._connection.execute(
                "INSERT INTO repair_receipts VALUES(?,?,?,?,?,?,NULL,NULL)",
                (
                    project_id,
                    receipt_id,
                    assignment_digest,
                    reason_code,
                    timestamp,
                    timestamp + REPAIR_RECEIPT_TTL_MS,
                ),
            )
        return receipt_id

    def bind_session(
        self,
        project_root: Path,
        session_id: str,
        producer: str,
        client_version: str,
        *,
        now_ms: int | None = None,
    ) -> tuple[str, str, str]:
        with self._held():
            if self._connection.in_transaction:
                raise LedgerError("account write transaction is already active")
        if producer not in {"hook", "app_server"}:
            raise LedgerError("collector producer is not authorized")
        if not isinstance(session_id, str) or not session_id or len(session_id) > 1024:
            raise LedgerError("session identifier is invalid")
        if not isinstance(client_version, str) or not client_version or len(client_version) > 160:
            raise LedgerError("client version is invalid")
        project_id = self.project_for_root(project_root)
        session_digest = keyed_digest(self.state.digest_key(), session_id)
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        root_run_id = external_id(
            self.state.digest_key(), "run", f"{client_version}\x00{session_id}\x00root"
        )
        def require_active() -> None:
            row = self._connection.execute("SELECT status FROM projects WHERE project_id=?", (project_id,)).fetchone()
            if row is None or row["status"] != "active":
                raise LedgerError("project binding is not active")

        def root_bindings():
            # At most the two native event producers may share this root.
            # Inspect every existing binding before accepting either producer.
            rows = self._connection.execute(
                "SELECT producer,client_version,session_digest FROM run_provenance "
                "WHERE project_id=? AND run_id=? LIMIT 3",
                (project_id, root_run_id),
            ).fetchall()
            if len(rows) > 2 or any(
                row["producer"] not in {"hook", "app_server"}
                or row["client_version"] != client_version or row["session_digest"] != session_digest
                for row in rows
            ):
                raise LedgerError("session provenance conflicts")
            return rows

        def persist(prepared: _PreparedAttestations | None) -> tuple[str, str, str]:
            with self._account_transaction():
                require_active()
                # Admission belongs to the root run, not each event producer.
                # Legacy provenance without admission remains unadmitted.
                known_root = bool(root_bindings())
                self._connection.execute(
                    "INSERT OR IGNORE INTO sessions VALUES(?,?,?,?)",
                    (project_id, session_digest, producer, timestamp),
                )
                self._connection.execute(
                    "INSERT OR IGNORE INTO run_provenance VALUES(?,?,?,?,?,?)",
                    (project_id, root_run_id, producer, client_version, session_digest, timestamp),
                )
                if not known_root:
                    self._admit_session_run_locked(project_id, root_run_id, prepared)
            return project_id, session_digest, root_run_id

        with self._held():
            require_active()
            bindings = root_bindings()
            if bindings:
                # Most hook binds are already known: no writer or crypto work.
                if any(row["producer"] == producer for row in bindings):
                    complete = self._connection.execute(
                        "SELECT 1 FROM sessions WHERE project_id=? AND session_digest=? AND producer=?",
                        (project_id, session_digest, producer),
                    ).fetchone()
                    if complete is not None:
                        return project_id, session_digest, root_run_id
                return persist(None)
        prepared = self._prepare_attestations(project_id, "codex")
        return persist(prepared)

    def _admit_session_run_locked(
        self, project_id: str, run_id: str, prepared: _PreparedAttestations | None,
    ) -> None:
        """Decide admission once for a collector-bound Codex session run.

        These sessions never pass through open_host_run, so their admission is
        taken when they first bind. Only a pass is stored: a denied session can
        still record events, but its result can never be committed.
        """

        if not self._connection.in_transaction or type(prepared) is not _PreparedAttestations:
            raise LedgerError("session admission preparation is unavailable")
        # The ledger's clock is read under the writer that orders decisions.
        timestamp = self._clock_ms()
        decision = self._evaluate_admission_locked(
            project_id, provider="codex", environ=os.environ, timestamp=timestamp,
            _prepared_attestations=prepared,
        )
        if decision["decision"] == "pass":
            self._store_admission_locked(
                project_id, decision, run_id=run_id, timestamp=timestamp
            )

    def append(
        self,
        project_id: str,
        record: dict[str, Any],
        *,
        producer: str,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        try:
            checked = validate_learning_record(record)
        except ContractError as exc:
            raise LedgerError("record admission rejected") from exc
        allowed = PRODUCER_AUTHORITY.get(producer, set())
        if checked["record_type"] not in allowed:
            raise LedgerError("producer is not authorized for record type")
        if (
            checked["record_type"] == "candidate"
            and checked.get("eligibility_receipt") is None
        ):
            raise LedgerError("candidate lacks a verified eligibility receipt")
        if producer == "owner":
            raise LedgerError("owner records require detached signature verification")
        if checked["record_type"] == "outcome" and producer in {"evaluator", "verifier"}:
            raise LedgerError("outcomes require atomic host result admission")
        if checked["record_type"] in {"qa_evidence", "evidence_review"}:
            raise LedgerError("verification evidence requires controlled admission")
        if checked["record_type"] in PROVIDER_OBSERVATION_TYPES | {
            "admission_decision", "billing_attestation", "dispatch_intent",
            "dispatch_result", "host_run_profile", "route_availability", "probe_admission",
            "verification_binding", "claim_denial_settlement", "host_result_admission", "execution_provenance", "host_open_provenance",
        }:
            raise LedgerError("provider evidence requires ledger-run observation")
        if (
            checked["record_type"] == "promotion"
            and checked["action"] in {"canary_started", "promoted"}
        ):
            raise LedgerError("authorized transition requires atomic grant consumption")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            self._validate_evidence_links_locked(project_id, checked)
            result = self._append_checked_locked(
                project_id, checked, producer=producer, timestamp=timestamp
            )
        self.state.harden_database_files()
        return result

    def _validate_candidate_eligibility_locked(
        self, project_id: str, candidate: dict[str, Any]
    ) -> None:
        """Derive candidate eligibility from persisted admitted outcomes."""

        evidence = candidate["evidence_digests"]
        placeholders = ",".join("?" for _ in evidence)
        rows = self._connection.execute(
            "SELECT content_digest,record_type,content,source_sequence FROM records "
            f"WHERE project_id=? AND content_digest IN ({placeholders})",
            (project_id, *evidence),
        ).fetchall()
        if len(rows) != len(evidence) or any(
            row["record_type"] != "outcome" for row in rows
        ):
            raise LedgerError("candidate evidence is not a complete outcome cohort")
        accepted_operational_qa = {
            str(row["qa_digest"])
            for row in self._connection.execute(
                "SELECT qa_digest FROM operational_qa "
                "WHERE project_id=? AND accepted=1",
                (project_id,),
            ).fetchall()
        }
        accepted_formal_qa = {
            str(row["content_digest"])
            for row in self._connection.execute(
                "SELECT records.content_digest FROM records "
                "JOIN owner_attestations ON "
                "owner_attestations.project_id=records.project_id AND "
                "owner_attestations.subject_record_id=records.record_id "
                "WHERE records.project_id=? AND records.record_type='qa_evidence' "
                "AND json_extract(CAST(records.content AS TEXT),'$.accepted')=1",
                (project_id,),
            ).fetchall()
        }
        lineage_rows = self._connection.execute(
            "SELECT content,source_sequence FROM records WHERE project_id=? "
            "AND record_type='outcome' ORDER BY source_sequence",
            (project_id,),
        ).fetchall()
        try:
            check_candidate_eligibility(
                candidate,
                [
                    (json.loads(bytes(row["content"])), int(row["source_sequence"]))
                    for row in rows
                ],
                accepted_qa=accepted_operational_qa | accepted_formal_qa,
                project_outcomes=(
                    (json.loads(bytes(row["content"])), int(row["source_sequence"]))
                    for row in lineage_rows
                ),
            )
        except EligibilityError as error:
            raise LedgerError(str(error)) from None

    def open_orchestration(
        self,
        project_id: str,
        *,
        client_version: str,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Open one goal-scoped statistics boundary."""

        capability = self._client_capabilities.get(client_version)
        if capability is None or "host" not in capability.get("producers", []):
            raise LedgerError("orchestration client is not authorized")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        handle = f"orc_{secrets.token_hex(24)}"
        handle_digest = keyed_digest(self.state.digest_key(), handle)
        orchestration_id = external_id(self.state.digest_key(), "orc", handle)
        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            self._connection.execute(
                "INSERT INTO orchestrations("
                "project_id,orchestration_id,handle_digest,client_version,status,"
                "started_at_ms,ended_at_ms,goal_tokens_used,goal_time_used_seconds,"
                "expires_at_ms) VALUES(?,?,?,?,?,?,NULL,NULL,NULL,?)",
                (
                    project_id,
                    orchestration_id,
                    handle_digest,
                    client_version,
                    "active",
                    timestamp,
                    timestamp + DEFAULT_RETENTION_MS,
                ),
            )
            self._append_orchestration_checkpoint_locked(
                project_id,
                orchestration_id,
                status="active",
                goal_tokens_used=None,
                goal_time_used_seconds=None,
                observed_at_ms=timestamp,
            )
        self.state.harden_database_files()
        return {
            "orchestration_handle": handle,
            "orchestration_id": orchestration_id,
            "status": "active",
            "started_at_ms": timestamp,
        }

    def _orchestration_for_handle_locked(
        self, project_id: str, handle: str
    ) -> sqlite3.Row:
        if not isinstance(handle, str) or not re.fullmatch(r"orc_[0-9a-f]{48}", handle):
            raise LedgerError("orchestration handle is invalid")
        row = self._connection.execute(
            "SELECT * FROM orchestrations WHERE project_id=? AND handle_digest=?",
            (project_id, keyed_digest(self.state.digest_key(), handle)),
        ).fetchone()
        if row is None:
            raise LedgerError("orchestration handle is unavailable")
        return row

    def _append_orchestration_checkpoint_locked(
        self,
        project_id: str,
        orchestration_id: str,
        *,
        status: str,
        goal_tokens_used: int | None,
        goal_time_used_seconds: int | None,
        observed_at_ms: int,
    ) -> None:
        prior = self._connection.execute(
            "SELECT COALESCE(MAX(sequence),0),MAX(observed_at_ms) "
            "FROM orchestration_checkpoints WHERE project_id=? AND orchestration_id=?",
            (project_id, orchestration_id),
        ).fetchone()
        sequence = int(prior[0]) + 1
        if prior[1] is not None and observed_at_ms < int(prior[1]):
            raise LedgerError("orchestration checkpoint time cannot move backward")
        self._connection.execute(
            "INSERT INTO orchestration_checkpoints VALUES(?,?,?,?,?,?,?)",
            (
                project_id,
                orchestration_id,
                sequence,
                status,
                goal_tokens_used,
                goal_time_used_seconds,
                observed_at_ms,
            ),
        )

    def set_orchestration_paused(
        self,
        project_id: str,
        *,
        orchestration_handle: str,
        paused: bool,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Persist an explicit pause/resume transition without resetting history."""

        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            row = self._orchestration_for_handle_locked(project_id, orchestration_handle)
            expected = "active" if paused else "paused"
            target = "paused" if paused else "active"
            if row["status"] != expected:
                raise LedgerError(f"orchestration must be {expected} for this transition")
            self._connection.execute(
                "UPDATE orchestrations SET status=? WHERE project_id=? "
                "AND orchestration_id=? AND status=?",
                (target, project_id, str(row["orchestration_id"]), expected),
            )
            self._append_orchestration_checkpoint_locked(
                project_id,
                str(row["orchestration_id"]),
                status=target,
                goal_tokens_used=row["goal_tokens_used"],
                goal_time_used_seconds=row["goal_time_used_seconds"],
                observed_at_ms=timestamp,
            )
            orchestration_id = str(row["orchestration_id"])
        self.state.harden_database_files()
        return self.orchestration_report(project_id, orchestration_id)

    def close_orchestration(
        self,
        project_id: str,
        *,
        orchestration_handle: str,
        status: str,
        goal_tokens_used: int | None = None,
        goal_time_used_seconds: int | None = None,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Close one boundary and return its exact aggregate report."""

        if status not in {"completed", "failed", "interrupted", "cancelled"}:
            raise LedgerError("orchestration terminal status is invalid")
        for value, label in (
            (goal_tokens_used, "goal token usage"),
            (goal_time_used_seconds, "goal elapsed time"),
        ):
            if value is not None and (
                not isinstance(value, int) or isinstance(value, bool) or value < 0
            ):
                raise LedgerError(f"{label} is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            row = self._orchestration_for_handle_locked(
                project_id, orchestration_handle
            )
            if row["status"] not in {"active", "paused"}:
                raise LedgerError("orchestration is already closed")
            if timestamp < int(row["started_at_ms"]):
                raise LedgerError("orchestration close time is invalid")
            unfinished = int(
                self._connection.execute(
                    "SELECT COUNT(*) FROM host_run_bindings WHERE project_id=? "
                    "AND orchestration_id=? AND binding_state='pending'",
                    (project_id, str(row["orchestration_id"])),
                ).fetchone()[0]
            )
            if unfinished:
                raise LedgerError("orchestration has unfinished host runs")
            resolved_goal_tokens = (
                goal_tokens_used
                if goal_tokens_used is not None
                else row["goal_tokens_used"]
            )
            resolved_goal_time = (
                goal_time_used_seconds
                if goal_time_used_seconds is not None
                else row["goal_time_used_seconds"]
            )
            for prior, current, label in (
                (row["goal_tokens_used"], resolved_goal_tokens, "goal token usage"),
                (
                    row["goal_time_used_seconds"],
                    resolved_goal_time,
                    "goal elapsed time",
                ),
            ):
                if (
                    prior is not None
                    and current is not None
                    and int(current) < int(prior)
                ):
                    raise LedgerError(f"{label} cannot decrease")
            self._connection.execute(
                "UPDATE orchestrations SET status=?,ended_at_ms=?,"
                "goal_tokens_used=?,goal_time_used_seconds=? "
                "WHERE project_id=? AND orchestration_id=? AND status=?",
                (
                    status,
                    timestamp,
                    resolved_goal_tokens,
                    resolved_goal_time,
                    project_id,
                    str(row["orchestration_id"]),
                    str(row["status"]),
                ),
            )
            orchestration_id = str(row["orchestration_id"])
            self._append_orchestration_checkpoint_locked(
                project_id,
                orchestration_id,
                status=status,
                goal_tokens_used=resolved_goal_tokens,
                goal_time_used_seconds=resolved_goal_time,
                observed_at_ms=timestamp,
            )
        # The boundary's worker results were kept only for its verifiers; now
        # that it is closed, the sweep deletes them (and retries what it cannot).
        self.sweep_worker_results()
        self.state.harden_database_files()
        return self.orchestration_report(project_id, orchestration_id)

    def checkpoint_orchestration(
        self,
        project_id: str,
        *,
        orchestration_handle: str,
        goal_tokens_used: int,
        goal_time_used_seconds: int,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Persist one exact, monotonic native-goal usage checkpoint."""

        for value, label in (
            (goal_tokens_used, "goal token usage"),
            (goal_time_used_seconds, "goal elapsed time"),
        ):
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise LedgerError(f"{label} is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            row = self._orchestration_for_handle_locked(
                project_id, orchestration_handle
            )
            if row["status"] not in {"active", "paused"}:
                raise LedgerError("orchestration is already closed")
            if timestamp < int(row["started_at_ms"]):
                raise LedgerError("orchestration checkpoint time is invalid")
            for prior, current, label in (
                (row["goal_tokens_used"], goal_tokens_used, "goal token usage"),
                (
                    row["goal_time_used_seconds"],
                    goal_time_used_seconds,
                    "goal elapsed time",
                ),
            ):
                if prior is not None and current < int(prior):
                    raise LedgerError(f"{label} cannot decrease")
            self._connection.execute(
                "UPDATE orchestrations SET goal_tokens_used=?,"
                "goal_time_used_seconds=? WHERE project_id=? "
                "AND orchestration_id=? AND status=?",
                (
                    goal_tokens_used,
                    goal_time_used_seconds,
                    project_id,
                    str(row["orchestration_id"]),
                    str(row["status"]),
                ),
            )
            orchestration_id = str(row["orchestration_id"])
            self._append_orchestration_checkpoint_locked(
                project_id,
                orchestration_id,
                status=str(row["status"]),
                goal_tokens_used=goal_tokens_used,
                goal_time_used_seconds=goal_time_used_seconds,
                observed_at_ms=timestamp,
            )
        self.state.harden_database_files()
        return self.orchestration_report(project_id, orchestration_id)

    def bind_host_agent(
        self,
        project_id: str,
        *,
        run_handle: str,
        agent_id: str,
    ) -> dict[str, Any]:
        """Bind a live native agent identifier without storing the raw identifier."""

        if not isinstance(run_handle, str) or not re.fullmatch(
            r"hrn_[0-9a-f]{48}", run_handle
        ):
            raise LedgerError("host run handle is invalid")
        # Native agent IDs are opaque tokens: Codex IDs, Claude Code Agent tool
        # IDs (short hex) and bridge run IDs all fit this bounded form. Codex
        # 0.164 names a spawned child by its agent path (for example
        # /root/<task_name>), so slash-separated paths of the same tokens fit too.
        if not isinstance(agent_id, str) or not re.fullmatch(
            r"[A-Za-z0-9_-]{1,128}|(?=.{1,128}$)(/[A-Za-z0-9_-]+){1,8}", agent_id
        ):
            raise LedgerError("native agent identifier is invalid")
        native_assignment_id = external_id(
            self.state.digest_key(), "asg", agent_id
        )
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._held(), self._connection:
            row = self._connection.execute(
                "SELECT native_assignment_id,consumed_at_ms,binding_state,run_id,"
                "client_version FROM host_run_bindings "
                "WHERE project_id=? AND handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if (
                row is None
                or row["consumed_at_ms"] is not None
                or row["binding_state"] != "pending"
            ):
                raise LedgerError("host run handle is unavailable")
            if str(row["client_version"]) == BRIDGE_CLIENT_VERSION and (
                self._connection.execute(
                    "SELECT 1 FROM records WHERE project_id=? "
                    "AND record_type='dispatch_intent' AND source='lifecycle' "
                    "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=? "
                    "AND json_extract(CAST(content AS TEXT),'$.bridge_run_id')=?",
                    (project_id, str(row["run_id"]), agent_id),
                ).fetchone() is None
            ):
                # A bridged run's only agent is its own dispatched child.
                raise LedgerError("a bridged run binds only its dispatched child")
            if row["native_assignment_id"] not in {None, native_assignment_id}:
                raise LedgerError("host run is already bound to another native agent")
            self._connection.execute(
                "UPDATE host_run_bindings SET native_assignment_id=? "
                "WHERE project_id=? AND handle_digest=?",
                (native_assignment_id, project_id, handle_digest),
            )
        self.state.harden_database_files()
        return {"bound": True, "native_assignment_id": native_assignment_id}

    def classify_host_run_abandoned(
        self,
        project_id: str,
        *,
        run_handle: str,
        reason: str,
    ) -> dict[str, Any]:
        """Classify a pending binding only after its orchestration is paused."""

        if reason not in {
            "host_confirmed_gone", "owner_cancelled", "recovery_unavailable"
        }:
            raise LedgerError("host abandonment reason is invalid")
        if not isinstance(run_handle, str) or not re.fullmatch(
            r"hrn_[0-9a-f]{48}", run_handle
        ):
            raise LedgerError("host run handle is invalid")
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._held(), self._connection:
            row = self._connection.execute(
                "SELECT b.binding_state,o.status FROM host_run_bindings b "
                "JOIN orchestrations o ON o.project_id=b.project_id "
                "AND o.orchestration_id=b.orchestration_id "
                "WHERE b.project_id=? AND b.handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if row is None or row["binding_state"] != "pending":
                raise LedgerError("pending host run is unavailable")
            if row["status"] != "paused":
                raise LedgerError("orchestration must be paused before abandonment")
            self._connection.execute(
                "UPDATE host_run_bindings SET binding_state='abandoned',"
                "abandoned_reason=? WHERE project_id=? AND handle_digest=? "
                "AND binding_state='pending'",
                (reason, project_id, handle_digest),
            )
        self.state.harden_database_files()
        return {"classified": True, "binding_state": "abandoned", "reason": reason}

    def prepare_upgrade_reconciliation(
        self,
        project_id: str,
        *,
        orchestration_id: str,
        run_handle: str,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Describe one pending, stopped child for a detached owner signature."""

        if not isinstance(orchestration_id, str) or not re.fullmatch(
            r"orc:[0-9a-f]{64}", orchestration_id
        ):
            raise LedgerError("orchestration ID is invalid")
        if not isinstance(run_handle, str) or not re.fullmatch(
            r"hrn_[0-9a-f]{48}", run_handle
        ):
            raise LedgerError("host run handle is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._held():
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            orchestration = self._connection.execute(
                "SELECT status,started_at_ms FROM orchestrations WHERE project_id=? "
                "AND orchestration_id=?", (project_id, orchestration_id)
            ).fetchone()
            binding = self._connection.execute(
                "SELECT * FROM host_run_bindings WHERE project_id=? "
                "AND orchestration_id=? AND handle_digest=?",
                (project_id, orchestration_id, handle_digest),
            ).fetchone()
            counts = self._connection.execute(
                "SELECT COUNT(*),SUM(binding_state='pending') FROM host_run_bindings "
                "WHERE project_id=? AND orchestration_id=?",
                (project_id, orchestration_id),
            ).fetchone()
            checkpoint = self._connection.execute(
                "SELECT MAX(sequence) FROM orchestration_checkpoints WHERE project_id=? "
                "AND orchestration_id=?", (project_id, orchestration_id)
            ).fetchone()
        if (
            project is None or project["status"] != "active"
            or orchestration is None
            or orchestration["status"] not in {"active", "paused"}
            or binding is None or binding["binding_state"] != "pending"
            or binding["consumed_at_ms"] is not None
            or int(counts[1] or 0) != 1
            or timestamp < int(orchestration["started_at_ms"])
        ):
            raise LedgerError("exact pending upgrade reconciliation is unavailable")
        return {
            "purpose": "codex_agents_upgrade_superseded_reconciliation_v1",
            "project_id": project_id,
            "orchestration_id": orchestration_id,
            "run_id": str(binding["run_id"]),
            "run_handle_digest": handle_digest,
            "assignment_digest": str(binding["assignment_digest"]),
            "route_digest": str(binding["route_digest"]),
            "configuration_digest": str(binding["configuration_digest"]),
            "client_version": str(binding["client_version"]),
            "binding_created_at_ms": int(binding["created_at_ms"]),
            "native_assignment_id": binding["native_assignment_id"],
            "last_progress_at_ms": int(binding["last_progress_at_ms"]),
            "boundary_status": str(orchestration["status"]),
            "opened_runs": int(counts[0]),
            "checkpoint_sequence": int(checkpoint[0] or 0),
            "owner_assertion": "native_child_stopped_and_result_superseded",
            "abandoned_reason": "upgrade_superseded",
            "terminal_status": "interrupted",
            "issued_at_ms": timestamp,
            "expires_at_ms": timestamp + UPGRADE_RECONCILIATION_TTL_MS,
            "nonce_digest": keyed_digest(self.state.digest_key(), secrets.token_bytes(32)),
        }

    def commit_upgrade_reconciliation(
        self,
        project_id: str,
        *,
        request: dict[str, Any],
        signature: bytes,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Atomically abandon one signed superseded run and interrupt its boundary."""

        expected_fields = {
            "purpose", "project_id", "orchestration_id", "run_id",
            "run_handle_digest", "assignment_digest", "route_digest",
            "configuration_digest", "client_version", "binding_created_at_ms",
            "native_assignment_id", "last_progress_at_ms",
            "boundary_status", "opened_runs", "checkpoint_sequence",
            "owner_assertion", "abandoned_reason", "terminal_status",
            "issued_at_ms", "expires_at_ms", "nonce_digest",
        }
        if not isinstance(request, dict) or set(request) != expected_fields:
            raise LedgerError("upgrade reconciliation request is invalid")
        if (
            request["purpose"] != "codex_agents_upgrade_superseded_reconciliation_v1"
            or request["project_id"] != project_id
            or request["owner_assertion"] != "native_child_stopped_and_result_superseded"
            or request["abandoned_reason"] != "upgrade_superseded"
            or request["terminal_status"] != "interrupted"
            or request["boundary_status"] not in {"active", "paused"}
            or not isinstance(request["orchestration_id"], str)
            or not re.fullmatch(r"orc:[0-9a-f]{64}", request["orchestration_id"])
            or not isinstance(request["run_id"], str)
            or not re.fullmatch(r"run:[0-9a-f]{64}", request["run_id"])
            or not all(
                isinstance(request[key], str)
                and re.fullmatch(r"[0-9a-f]{64}", request[key])
                for key in (
                    "run_handle_digest", "assignment_digest", "route_digest",
                    "configuration_digest", "nonce_digest",
                )
            )
            or not isinstance(request["client_version"], str)
            or not 1 <= len(request["client_version"]) <= 128
            or request["native_assignment_id"] is not None
            and (
                not isinstance(request["native_assignment_id"], str)
                or not re.fullmatch(
                    r"asg:[0-9a-f]{64}", request["native_assignment_id"]
                )
            )
            or not all(
                isinstance(request[key], int) and not isinstance(request[key], bool)
                and request[key] >= 0
                for key in (
                    "binding_created_at_ms", "last_progress_at_ms",
                    "opened_runs", "checkpoint_sequence",
                    "issued_at_ms", "expires_at_ms",
                )
            )
            or request["opened_runs"] < 1
            or request["checkpoint_sequence"] < 1
            or not 0 < request["expires_at_ms"] - request["issued_at_ms"]
            <= UPGRADE_RECONCILIATION_TTL_MS
        ):
            raise LedgerError("upgrade reconciliation request is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        if not request["issued_at_ms"] <= timestamp < request["expires_at_ms"]:
            raise LedgerError("upgrade reconciliation request has expired")
        from .learning_engine import OwnerGrantAuthority

        authority = OwnerGrantAuthority.for_state(self.state)
        if not authority.verify_upgrade_reconciliation_signature(request, signature):
            raise LedgerError("upgrade reconciliation owner signature is invalid")
        with self._held(), self._connection:
            # The ledger uses SQLite autocommit; explicitly begin before rechecks
            # so pause, classification and closure commit or roll back together.
            self._connection.execute("BEGIN IMMEDIATE")
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            orchestration = self._connection.execute(
                "SELECT * FROM orchestrations WHERE project_id=? AND orchestration_id=?",
                (project_id, request["orchestration_id"]),
            ).fetchone()
            binding = self._connection.execute(
                "SELECT * FROM host_run_bindings WHERE project_id=? AND run_id=?",
                (project_id, request["run_id"]),
            ).fetchone()
            counts = self._connection.execute(
                "SELECT COUNT(*),SUM(binding_state='pending') FROM host_run_bindings "
                "WHERE project_id=? AND orchestration_id=?",
                (project_id, request["orchestration_id"]),
            ).fetchone()
            checkpoint = self._connection.execute(
                "SELECT MAX(sequence),MAX(observed_at_ms) FROM orchestration_checkpoints "
                "WHERE project_id=? AND orchestration_id=?",
                (project_id, request["orchestration_id"]),
            ).fetchone()
            if (
                project is None or project["status"] != "active"
                or orchestration is None
                or orchestration["status"] != request["boundary_status"]
                or binding is None or binding["orchestration_id"] != request["orchestration_id"]
                or binding["binding_state"] != "pending"
                or binding["consumed_at_ms"] is not None
                or any(
                    binding[column] != request[key]
                    for column, key in (
                        ("handle_digest", "run_handle_digest"),
                        ("assignment_digest", "assignment_digest"),
                        ("route_digest", "route_digest"),
                        ("configuration_digest", "configuration_digest"),
                        ("client_version", "client_version"),
                        ("created_at_ms", "binding_created_at_ms"),
                        ("native_assignment_id", "native_assignment_id"),
                        ("last_progress_at_ms", "last_progress_at_ms"),
                    )
                )
                or int(counts[0]) != request["opened_runs"]
                or int(counts[1] or 0) != 1
                or int(checkpoint[0] or 0) != request["checkpoint_sequence"]
                or timestamp < int(checkpoint[1] or orchestration["started_at_ms"])
            ):
                raise LedgerError("exact pending upgrade reconciliation is unavailable")
            outcomes = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='outcome' AND source='host'",
                (project_id,),
            ).fetchall()
            if any(
                json.loads(bytes(row["content"])).get("run_id") == request["run_id"]
                for row in outcomes
            ):
                raise LedgerError("superseded run already has a host outcome")
            if orchestration["status"] == "active":
                self._connection.execute(
                    "UPDATE orchestrations SET status='paused' WHERE project_id=? "
                    "AND orchestration_id=? AND status='active'",
                    (project_id, request["orchestration_id"]),
                )
                self._append_orchestration_checkpoint_locked(
                    project_id, request["orchestration_id"], status="paused",
                    goal_tokens_used=orchestration["goal_tokens_used"],
                    goal_time_used_seconds=orchestration["goal_time_used_seconds"],
                    observed_at_ms=timestamp,
                )
            changed = self._connection.execute(
                "UPDATE host_run_bindings SET binding_state='abandoned',"
                "abandoned_reason='upgrade_superseded' WHERE project_id=? AND run_id=? "
                "AND binding_state='pending' AND consumed_at_ms IS NULL",
                (project_id, request["run_id"]),
            ).rowcount
            if changed != 1:
                raise LedgerError("superseded host run was already resolved")
            self._connection.execute(
                "UPDATE orchestrations SET status='interrupted',ended_at_ms=? "
                "WHERE project_id=? AND orchestration_id=? AND status='paused'",
                (timestamp, project_id, request["orchestration_id"]),
            )
            self._append_orchestration_checkpoint_locked(
                project_id, request["orchestration_id"], status="interrupted",
                goal_tokens_used=orchestration["goal_tokens_used"],
                goal_time_used_seconds=orchestration["goal_time_used_seconds"],
                observed_at_ms=timestamp,
            )
        self.state.harden_database_files()
        return {
            "reconciled_run_id": request["run_id"],
            "request_digest": content_digest(request),
            "abandoned_reason": "upgrade_superseded",
            **self.orchestration_report(project_id, request["orchestration_id"]),
        }

    def issue_legacy_fallback_receipt(
        self,
        project_id: str,
        *,
        run_handle: str,
        task: dict[str, Any],
        primary_route: dict[str, Any],
        client_version: str,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Consume one abandoned primary run as trusted fallback authorization."""

        if not isinstance(run_handle, str) or not re.fullmatch(
            r"hrn_[0-9a-f]{48}", run_handle
        ):
            raise LedgerError("fallback source run handle is invalid")
        checked_task = validate_task(task)
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        task_digest = keyed_digest(
            self.state.digest_key(), canonical_json(checked_task)
        )
        route_digest = keyed_digest(
            self.state.digest_key(), canonical_json(route_identity(primary_route))
        )
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            row = self._connection.execute(
                "SELECT b.task_digest,b.route_digest,b.client_version,"
                "b.binding_state,b.abandoned_reason,b.native_assignment_id,"
                "b.consumed_at_ms,b.orchestration_id,o.status "
                "FROM host_run_bindings b "
                "JOIN orchestrations o ON o.project_id=b.project_id "
                "AND o.orchestration_id=b.orchestration_id "
                "WHERE b.project_id=? AND b.handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if row is None:
                raise LedgerError("fallback source run is unavailable")
            if (
                row["binding_state"] != "abandoned"
                or row["abandoned_reason"] != "recovery_unavailable"
                or row["native_assignment_id"] is not None
                or row["consumed_at_ms"] is not None
                or row["status"] != "paused"
            ):
                raise LedgerError(
                    "fallback requires one unbound recovery-unavailable run "
                    "inside a paused orchestration"
                )
            if (
                row["task_digest"] != task_digest
                or row["route_digest"] != route_digest
                or row["client_version"] != client_version
            ):
                raise LedgerError("fallback source does not match the exact primary route")
            self._connection.execute(
                "UPDATE host_run_bindings SET consumed_at_ms=? "
                "WHERE project_id=? AND handle_digest=? AND consumed_at_ms IS NULL",
                (timestamp, project_id, handle_digest),
            )
            authorization_digest = keyed_digest(
                self.state.digest_key(),
                canonical_json(
                    {
                        "task": checked_task,
                        "primary_route": primary_route,
                        "client_version": client_version,
                    }
                ),
            )
            receipt_id = f"fbr_{secrets.token_hex(24)}"
            self._connection.execute(
                "INSERT INTO repair_receipts VALUES(?,?,?,?,?,?,NULL,?)",
                (
                    project_id,
                    receipt_id,
                    authorization_digest,
                    "model_unavailable_fallback",
                    timestamp,
                    timestamp + REPAIR_RECEIPT_TTL_MS,
                    str(row["orchestration_id"]),
                ),
            )
        self.state.harden_database_files()
        return {
            "receipt_id": receipt_id,
            "authorization_digest": authorization_digest,
            "expires_at_ms": timestamp + REPAIR_RECEIPT_TTL_MS,
        }

    def verify_legacy_fallback_receipt(
        self,
        project_id: str,
        *,
        receipt_id: str,
        task: dict[str, Any],
        primary_route: dict[str, Any],
        client_version: str,
    ) -> dict[str, Any]:
        """Verify a previously issued fallback receipt against exact route state."""

        match = re.fullmatch(r"fbr_[0-9a-f]{48}", receipt_id)
        if match is None:
            raise LedgerError("legacy fallback receipt is invalid")
        checked_task = validate_task(task)
        task_digest = keyed_digest(
            self.state.digest_key(), canonical_json(checked_task)
        )
        authorization_digest = keyed_digest(
            self.state.digest_key(),
            canonical_json(
                {
                    "task": checked_task,
                    "primary_route": primary_route,
                    "client_version": client_version,
                }
            ),
        )
        timestamp = time.time_ns() // 1_000_000
        with self._held():
            row = self._connection.execute(
                "SELECT assignment_digest,reason_code,expires_at_ms,consumed_at_ms,"
                "run_id FROM repair_receipts WHERE project_id=? AND receipt_id=?",
                (project_id, receipt_id),
            ).fetchone()
        if (
            row is None
            or row["reason_code"] != "model_unavailable_fallback"
            or row["assignment_digest"] != authorization_digest
            or int(row["expires_at_ms"]) <= timestamp
        ):
            raise LedgerError("legacy fallback receipt does not match trusted host state")
        if row["consumed_at_ms"] is not None:
            with self._held():
                bound = self._connection.execute(
                    "SELECT task_digest,client_version,binding_state "
                    "FROM host_run_bindings WHERE project_id=? AND run_id=?",
                    (project_id, row["run_id"]),
                ).fetchone()
            if (
                bound is None
                or bound["task_digest"] != task_digest
                or bound["client_version"] != client_version
                or bound["binding_state"] not in {"pending", "terminal"}
            ):
                raise LedgerError(
                    "legacy fallback receipt is not bound to its fallback host run"
                )
        return {
            "receipt_id": receipt_id,
            "authorization_digest": authorization_digest,
            "consumed": row["consumed_at_ms"] is not None,
            "verified": True,
        }

    def orchestration_report(
        self, project_id: str, orchestration_id: str
    ) -> dict[str, Any]:
        """Return content-free, non-duplicating statistics for one boundary."""

        with self._held():
            orchestration = self._connection.execute(
                "SELECT * FROM orchestrations WHERE project_id=? AND orchestration_id=?",
                (project_id, orchestration_id),
            ).fetchone()
            if orchestration is None:
                raise LedgerError("orchestration is unavailable")
            bindings = self._connection.execute(
                "SELECT run_id,agent_type,created_at_ms,consumed_at_ms,"
                "native_assignment_id,binding_state,deadline_observed,"
                "observation_deadline_at_ms FROM host_run_bindings "
                "WHERE project_id=? AND orchestration_id=? ORDER BY created_at_ms",
                (project_id, orchestration_id),
            ).fetchall()
            outcome_rows = self._connection.execute(
                "SELECT content,content_digest FROM records WHERE project_id=? "
                "AND record_type='outcome' AND source='host'",
                (project_id,),
            ).fetchall()
            qa_rows = self._connection.execute(
                "SELECT host_outcome_digest,accepted FROM operational_qa "
                "WHERE project_id=?",
                (project_id,),
            ).fetchall()
            checkpoints = self._connection.execute(
                "SELECT sequence,status,goal_tokens_used,goal_time_used_seconds,"
                "observed_at_ms FROM orchestration_checkpoints "
                "WHERE project_id=? AND orchestration_id=? ORDER BY sequence",
                (project_id, orchestration_id),
            ).fetchall()
        outcomes = {
            item["run_id"]: (item, str(row["content_digest"]))
            for row in outcome_rows
            for item in [json.loads(bytes(row["content"]))]
        }
        qa_by_outcome = {
            str(row["host_outcome_digest"]): bool(row["accepted"])
            for row in qa_rows
        }
        usage_fields = tuple(empty_usage())
        usage_totals: dict[str, int | None] = {field: 0 for field in usage_fields}
        usage_unknown_runs = {field: 0 for field in usage_fields}
        by_model: dict[str, int] = {}
        by_effort: dict[str, int] = {}
        by_role: dict[str, int] = {}
        by_agent_type: dict[str, int] = {}
        status_counts: dict[str, int] = {}
        repairs = 0
        no_progress = 0
        astra_runs = 0
        qa_passed = 0
        qa_failed = 0
        qa_pending = 0
        durations: list[int] = []
        for binding in bindings:
            run_id = str(binding["run_id"])
            outcome_entry = outcomes.get(run_id)
            agent_type = str(binding["agent_type"] or "unknown")
            by_agent_type[agent_type] = by_agent_type.get(agent_type, 0) + 1
            terminal = binding["consumed_at_ms"]
            if terminal is not None:
                durations.append(int(terminal) - int(binding["created_at_ms"]))
            if outcome_entry is None:
                lifecycle_status = {
                    "abandoned": "abandoned",
                    "terminal": "terminal_content_unavailable",
                    "pending": "pending",
                }[str(binding["binding_state"])]
                status_counts[lifecycle_status] = (
                    status_counts.get(lifecycle_status, 0) + 1
                )
                if lifecycle_status == "pending":
                    qa_pending += 1
                for field in usage_fields:
                    usage_unknown_runs[field] += 1
                continue
            outcome, outcome_digest = outcome_entry
            if outcome["task_slice"].startswith("verification-"):
                pass
            elif outcome_digest not in qa_by_outcome:
                qa_pending += 1
            elif qa_by_outcome[outcome_digest]:
                qa_passed += 1
            else:
                qa_failed += 1
            for field, target in (
                ("model", by_model),
                ("effort", by_effort),
                ("role", by_role),
            ):
                value = str(outcome[field])
                target[value] = target.get(value, 0) + 1
            status = str(outcome["status"])
            status_counts[status] = status_counts.get(status, 0) + 1
            repairs += int(outcome["repairs"])
            no_progress += int(outcome["no_progress_events"])
            astra_runs += int(outcome["model"] == "gpt-6-astra")
            for field in usage_fields:
                value = outcome["usage"][field]
                if value is None:
                    usage_unknown_runs[field] += 1
                    usage_totals[field] = None
                elif usage_totals[field] is not None:
                    usage_totals[field] = int(usage_totals[field]) + int(value)
        ended = orchestration["ended_at_ms"]
        return {
            "orchestration_id": orchestration_id,
            "status": str(orchestration["status"]),
            "started_at_ms": int(orchestration["started_at_ms"]),
            "ended_at_ms": int(ended) if ended is not None else None,
            "duration_ms": (
                int(ended) - int(orchestration["started_at_ms"])
                if ended is not None else None
            ),
            "runs": {
                "opened": len(bindings),
                "terminal": sum(
                    row["binding_state"] == "terminal" for row in bindings
                ),
                "pending": sum(
                    row["binding_state"] == "pending" for row in bindings
                ),
                "abandoned": sum(
                    row["binding_state"] == "abandoned" for row in bindings
                ),
                "current_active": (
                    sum(row["binding_state"] == "pending" for row in bindings)
                    if orchestration["status"] == "active"
                    else 0
                ),
                # Native or bridged: a bridged run binds its bridge run ID here.
                "agent_bound": sum(
                    row["native_assignment_id"] is not None for row in bindings
                ),
                "deadlines_observed": sum(
                    bool(row["deadline_observed"]) for row in bindings
                ),
            },
            "checkpoints": [
                {
                    "sequence": int(row["sequence"]),
                    "status": str(row["status"]),
                    "goal_tokens_used": row["goal_tokens_used"],
                    "goal_time_used_seconds": row["goal_time_used_seconds"],
                    "observed_at_ms": int(row["observed_at_ms"]),
                }
                for row in checkpoints
            ],
            "by_model": dict(sorted(by_model.items())),
            "by_effort": dict(sorted(by_effort.items())),
            "by_role": dict(sorted(by_role.items())),
            "by_agent_type": dict(sorted(by_agent_type.items())),
            "outcome_status": dict(sorted(status_counts.items())),
            "repairs": repairs,
            "no_progress_events": no_progress,
            "astra_runs": astra_runs,
            "qa": {
                "passed": qa_passed,
                "failed": qa_failed,
                "pending": qa_pending,
                "attention_required": qa_failed > 0 or qa_pending > 0,
            },
            "run_duration_ms": {
                "total": sum(durations),
                "minimum": min(durations) if durations else None,
                "maximum": max(durations) if durations else None,
            },
            "usage": {
                "host_run_totals": usage_totals,
                "unknown_runs": usage_unknown_runs,
                "goal_total_tokens": orchestration["goal_tokens_used"],
                "goal_time_used_seconds": orchestration["goal_time_used_seconds"],
                "goal_usage_source": (
                    "host_reported"
                    if orchestration["goal_tokens_used"] is not None
                    or orchestration["goal_time_used_seconds"] is not None
                    else "unavailable"
                ),
                "child_attribution": (
                    "complete"
                    if bindings and all(usage_unknown_runs[field] == 0 for field in TOKEN_USAGE_FIELDS)
                    else "unknown"
                ),
            },
        }

    @contextlib.contextmanager
    def _held(self, label: str | None = None, *, on_refused=None) -> Iterator[None]:
        """M4b E1a-1: the ledger lock, waited for at most ledger_waits.wait_seconds(); re-entry by the
        holder is immediate. A wait that runs out is counted by the caller's name and refused with
        today's busy refusal before anything runs (E1a-2); `on_refused` first undoes what the caller
        made outside the ledger before asking (review 040-m4b-e1a-code)."""
        if not self._lock.acquire(timeout=ledger_waits.wait_seconds()):
            self._lock_waits.refused(label or sys._getframe(2).f_code.co_name)
            if on_refused is not None:
                on_refused()
            raise SQLReadError("sql_read_busy")
        try:
            yield
        finally:
            self._lock.release()

    def _readers(self) -> int:
        """The readers registered now, read under their own lock (E1a revision 3)."""
        with self._readers_lock:
            return self._active_readers

    def lock_refusals(self) -> dict[str, int]:
        """E1a-3: refused waits by caller, read without the ledger lock."""
        return self._lock_waits.snapshot()

    @contextlib.contextmanager
    def _write_unit(self) -> Iterator[None]:
        """BR-15: the records of one write are one unit under the ledger lock: all of them or none.
        Inside an already open transaction the caller's unit is the unit; otherwise one is begun here."""

        with self._held(sys._getframe(2).f_code.co_name):
            if self._connection.in_transaction:
                yield
            else:
                with self._account_transaction():
                    yield

    @contextlib.contextmanager
    def _account_transaction(self) -> Iterator[None]:
        """Own one explicit account write unit; never borrow an outer transaction.

        This connection uses autocommit. A connection context alone does not
        begin a transaction. Call only locked helpers without connection contexts
        here: an inner context could otherwise commit the outer unit early.
        """

        with self._held(sys._getframe(2).f_code.co_name):
            if self._connection.in_transaction:
                raise LedgerError("account write transaction is already active")
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                self._fence.claim(self._connection)
                yield
                # Check the fixed database/WAL paths before making the unit
                # durable, so a mode/path refusal cannot lose a committed handle.
                self.state.harden_database_files()
                self._connection.commit()
            except BaseException as original:
                # Restoration can already have poisoned/closed this connection.
                # Trusted cleanup must not replace the operation's interruption
                # with the ordinary wrapper's unusable-connection error.
                cleanup_failure = None
                try:
                    sqlite3.Connection.rollback(self._connection)
                except BaseException as rollback_failure:
                    cleanup_failure = rollback_failure
                    self._connection._sql_unusable = True
                    try:
                        sqlite3.Connection.close(self._connection)
                    except BaseException as close_failure:
                        if isinstance(cleanup_failure, Exception):
                            cleanup_failure = close_failure
                if (isinstance(original, Exception) and cleanup_failure is not None
                        and not isinstance(cleanup_failure, Exception)):
                    raise cleanup_failure
                raise

    def open_host_run(
        self,
        project_id: str,
        *,
        assignment: dict[str, Any],
        task: dict[str, Any],
        route: dict[str, Any],
        execution_configuration: dict[str, Any],
        client_version: str,
        orchestration_handle: str,
        fallback_receipt: str | None = None,
        host_profile: dict[str, Any] | None = None,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Persist a trusted assigned-run start and return a single-use opaque handle.

        Admission is always evaluated here, from ledger-held evidence and this
        process's environment; a denial is stored and raised before any binding.
        """

        # Refuse an outer unit before admission preparation, not only at the
        # final BEGIN. Preparation must not do crypto inside a caller's writer.
        with self._held():
            if self._connection.in_transaction:
                raise LedgerError("account write transaction is already active")
        checked_assignment = validate_assignment_shape(assignment)
        validate_assignment_execution_limits(checked_assignment, route)
        checked_task = validate_task(task)
        checked_configuration = validate_execution_configuration(
            execution_configuration
        )
        capability = self._client_capabilities.get(client_version)
        if capability is None or "host" not in capability.get("producers", []):
            raise LedgerError("host lifecycle client is not authorized")
        if any(
            checked_assignment[field] != checked_configuration[field]
            for field in ("model", "effort", "role")
        ):
            raise LedgerError("host assignment does not match its route configuration")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        observation_seconds = route.get(
            "observation_deadline_seconds",
            checked_assignment["bounds"]["timeout_seconds"],
        )
        if (
            not isinstance(observation_seconds, int)
            or isinstance(observation_seconds, bool)
            or observation_seconds < 1
        ):
            raise LedgerError("route observation deadline is invalid")
        observation_deadline_at_ms = timestamp + observation_seconds * 1000
        # A verifier bound to a worker outcome is opened only for that outcome,
        # in this orchestration, and its assignment names exactly that outcome,
        # so the result it is given and the outcome QA binds it to agree.
        worker_outcome_digest = checked_task.get("verification_for_outcome")
        if worker_outcome_digest is not None:
            self.verification_worker_result(
                project_id, checked_task,
                orchestration_handle=orchestration_handle, with_result=False,
            )
            if checked_assignment["context"] != [worker_outcome_digest]:
                raise LedgerError(
                    "a bound verifier's assignment context must be exactly its "
                    "verification_for_outcome"
                )
        from .providers import AdmissionDenied

        provider = route.get("provider", "codex")
        # Admission runs on the ledger's clock, so a caller-chosen time cannot
        # make evidence look reset or stale.
        prepared_attestations = self._prepare_attestations(project_id, provider)
        admitted_at = self._clock_ms()
        admission = self.evaluate_admission(
            project_id, provider=provider, environ=os.environ, now_ms=admitted_at,
            _prepared_attestations=prepared_attestations,
        )
        run_handle = f"hrn_{secrets.token_hex(24)}"
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        run_id = external_id(self.state.digest_key(), "run", run_handle)
        assignment_digest = keyed_digest(
            self.state.digest_key(), canonical_json(checked_assignment)
        )
        task_digest = keyed_digest(
            self.state.digest_key(), canonical_json(checked_task)
        )
        route_digest = keyed_digest(self.state.digest_key(), canonical_json(route_identity(route)))
        configuration_digest = content_digest(checked_configuration)
        task_slice = routing_task_slice(checked_task)
        event = validate_event(
            {
                "schema_version": 1,
                "record_type": "event",
                "record_id": external_id(
                    self.state.digest_key(),
                    "evt",
                    f"{run_id}\x00{checked_assignment['assignment_id']}\x00started",
                ),
                "run_id": run_id,
                "turn_id": None,
                "assignment_id": checked_assignment["assignment_id"],
                "parent_run_id": None,
                "observed_at_ms": timestamp,
                "event_code": "subagent_started",
                "model": checked_assignment["model"],
                "effort": checked_assignment["effort"],
                "role": checked_assignment["role"],
                "task_family": checked_task["family"],
                "task_slice": task_slice,
                "topology": checked_configuration["topology"],
                "configuration_digest": configuration_digest,
                "status": "started",
                "stop_reason": None,
                "tool_digest": None,
                "item_digest": None,
                "coverage": "lifecycle_partial",
                "usage": empty_usage(),
            }
        )
        try:
            with self._account_transaction():
                project = self._connection.execute(
                    "SELECT status FROM projects WHERE project_id=?", (project_id,)
                ).fetchone()
                if not project or project["status"] != "active":
                    raise LedgerError("project binding is not active")
                orchestration = self._orchestration_for_handle_locked(
                    project_id, orchestration_handle
                )
                if orchestration["status"] != "active":
                    raise LedgerError("orchestration is not active")
                orchestration_id = str(orchestration["orchestration_id"])
                fallback = route.get("fallback")
                if (fallback_receipt is None) != (fallback is None):
                    raise LedgerError("fallback route and receipt must appear together")
                if fallback_receipt is not None:
                    if (
                        not isinstance(fallback, dict)
                        or fallback.get("receipt_id") != fallback_receipt
                        or not isinstance(fallback.get("authorization_digest"), str)
                    ):
                        raise LedgerError("fallback route receipt binding is invalid")
                    receipt = self._connection.execute(
                        "SELECT assignment_digest,reason_code,expires_at_ms,"
                        "consumed_at_ms,run_id FROM repair_receipts "
                        "WHERE project_id=? AND receipt_id=?",
                        (project_id, fallback_receipt),
                    ).fetchone()
                    if (
                        receipt is None
                        or receipt["reason_code"] != "model_unavailable_fallback"
                        or receipt["assignment_digest"]
                        != fallback["authorization_digest"]
                        or int(receipt["expires_at_ms"]) <= timestamp
                        or receipt["consumed_at_ms"] is not None
                        or receipt["run_id"] != orchestration_id
                    ):
                        raise LedgerError("fallback receipt is unavailable for this run")
                # O0b RS-A round 2 G4: the cap counts as the status and the signature open do, only live
                # bindings (pending, not past expiry, and not released by the register), so a released claimed
                # binding kept pending for its settlement never fills it, even after a clock rollback (G12: from
                # held register rows).
                pending = int(
                    self._connection.execute(
                        "SELECT COUNT(*) " + LIVE_BINDINGS, (project_id, timestamp),
                    ).fetchone()[0]
                )
                if pending >= MAX_PENDING_HOST_RUNS:
                    raise LedgerError("pending host run capacity is exhausted")
                # Re-check under the write lock before anything is written, so two
                # opens cannot both use the same Claude bootstrap, take the last
                # place under the run cap, or race past newer evidence. The
                # clock is read again here, so an opener that waited for the
                # lock is judged, and its decision stamped, at the time it holds it.
                admitted_at = self._clock_ms()
                admission = self._evaluate_admission_locked(
                    project_id, provider=provider, environ=os.environ, timestamp=admitted_at,
                    _prepared_attestations=prepared_attestations,
                )
                if admission["decision"] != "pass":
                    raise _RecheckDenied(admission)
                self._connection.execute(
                    "INSERT INTO host_run_bindings("
                    "project_id,handle_digest,run_id,assignment_digest,task_digest,"
                    "task_id_digest,"
                    "route_digest,configuration_digest,client_version,created_at_ms,"
                    "expires_at_ms,consumed_at_ms,orchestration_id,native_assignment_id,"
                    "agent_type,usage_complete,binding_state,abandoned_reason,"
                    "observation_started_at_ms,observation_deadline_at_ms,"
                    "last_progress_at_ms,deadline_observed) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?,?,NULL,?,NULL,?,NULL,'pending',NULL,"
                    "?,?,?,0)",
                    (
                        project_id, handle_digest, run_id, assignment_digest,
                        task_digest,
                        keyed_digest(self.state.digest_key(), checked_task["id"]),
                        route_digest, configuration_digest, client_version,
                        timestamp, timestamp + HOST_RUN_TTL_MS, orchestration_id,
                        route.get("agent_type", checked_assignment["role"]),
                        timestamp, observation_deadline_at_ms, timestamp,
                    ),
                )
                if fallback_receipt is not None:
                    changed = self._connection.execute(
                        "UPDATE repair_receipts SET consumed_at_ms=?,run_id=? "
                        "WHERE project_id=? AND receipt_id=? "
                        "AND consumed_at_ms IS NULL AND expires_at_ms>?",
                        (
                            timestamp,
                            run_id,
                            project_id,
                            fallback_receipt,
                            timestamp,
                        ),
                    ).rowcount
                    if changed != 1:
                        raise LedgerError("fallback receipt was already consumed")
                self._connection.execute(
                    "INSERT OR IGNORE INTO sessions VALUES(?,?,?,?)",
                    (project_id, handle_digest, "host", timestamp),
                )
                if route.get("dispatch") == "bridge":
                    self._connection.execute(
                        "INSERT INTO launch_inputs VALUES(?,?,?,?,?,?,?,?)",
                        (project_id, handle_digest, run_id, COLLECTOR_RUNTIME_DIGEST,
                         provider, checked_assignment["model"], checked_assignment["effort"],
                         min(route["bounds"]["timeout_seconds"], checked_assignment["bounds"]["timeout_seconds"])),
                    )
                self._connection.execute(
                    "INSERT INTO run_provenance VALUES(?,?,?,?,?,?)",
                    (
                        project_id, run_id, "host", client_version,
                        handle_digest, timestamp,
                    ),
                )
                self._append_checked_locked(
                    project_id, event, producer="host", timestamp=timestamp
                )
                self._store_admission_locked(
                    project_id, admission, run_id=run_id, timestamp=admitted_at
                )
                self._store_route_availability_locked(project_id, run_id, route, admitted_at)
                if worker_outcome_digest is not None:
                    material = {
                        "schema_version": 1,
                        "record_type": "verification_binding",
                        "run_id": run_id,
                        "worker_outcome_digest": worker_outcome_digest,
                        "observed_at_ms": timestamp,
                    }
                    try:
                        binding_record = validate_learning_record({
                            **material,
                            "record_id": f"verification_binding:{content_digest(material)}",
                        })
                    except ContractError as exc:
                        raise LedgerError("verification binding is invalid") from exc
                    self._append_checked_locked(
                        project_id, binding_record, producer="lifecycle",
                        timestamp=timestamp,
                    )
                if host_profile is not None:
                    if host_profile.get("host_client") != orchestration["client_version"]:
                        raise LedgerError("host run profile differs from the orchestration host")
                    material = {
                        "schema_version": 1,
                        "record_type": "host_run_profile",
                        "run_id": run_id,
                        **host_profile,
                        "observed_at_ms": admitted_at,
                    }
                    try:
                        profile = validate_learning_record(
                            {**material, "record_id": f"host_run_profile:{content_digest(material)}"}
                        )
                    except ContractError as exc:
                        raise LedgerError("host run profile is invalid") from exc
                    self._append_checked_locked(
                        project_id, profile, producer="lifecycle", timestamp=admitted_at
                    )
        except _RecheckDenied as denied:
            # The denial is stored like any other, after the open is abandoned.
            with self._account_transaction():
                record = self._store_admission_locked(
                    project_id, denied.decision, run_id=None,
                    timestamp=denied.decision["observed_at_ms"],
                )
            denial = AdmissionDenied(denied.decision["reason_code"])
            denial.open_reference = {"project_id": project_id, "admission_record_id": record["record_id"],
                                     "admission_content_digest": content_digest(record)}
            raise denial from None
        return {
            "run_handle": run_handle,
            "admission": admission["reason_code"],
            "status": "started",
            "coverage": "lifecycle_partial",
            "usage": empty_usage(),
            "observation_started_at_ms": timestamp,
            "observation_deadline_at_ms": observation_deadline_at_ms,
        }

    def _clock_ms(self) -> int:
        """The ledger's own time for evidence it stamps; callers never supply it."""

        return time.time_ns() // 1_000_000

    def _store_provider_observations(
        self,
        project_id: str,
        records: list[dict[str, Any]],
        *,
        timestamp: int,
    ) -> list[dict[str, Any]]:
        try:
            checked = [validate_learning_record(record) for record in records]
        except ContractError as exc:
            raise LedgerError("record admission rejected") from exc
        if any(record["record_type"] not in PROVIDER_OBSERVATION_TYPES for record in checked):
            raise LedgerError("provider observation type is unsupported")
        with self._write_unit():
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            results = [
                self._append_checked_locked(
                    project_id, record, producer="provider", timestamp=timestamp
                )
                for record in checked
            ]
        self.state.harden_database_files()
        return results

    def observe_provider(
        self,
        project_id: str,
        provider: str,
        *,
        project_root: Path,
        environ: Any = None,
        run_handle: str | None = None,
        phase: str | None = None,
    ) -> list[dict[str, Any]]:
        """Run one non-spending observation and store it under a keyed fingerprint.

        The ledger runs the provider client itself and derives the fingerprint
        with its own key, so no caller can supply observation records. With a
        run handle, the headroom and billing it reads are bound to that open
        run and to a phase, before or after its launch.
        """

        from .host_paths import HostPathError, private_directory, remove_private_directory
        from .providers import observe_claude, observe_codex

        run_id = None
        if (run_handle is None) != (phase is None) or phase not in {None, "before", "after"}:
            raise LedgerError("a run observation needs its run and its phase")
        if provider not in {"claude", "codex"}:
            raise LedgerError("provider is unsupported")
        if run_handle is not None:
            with self._account_transaction():
                run_id = self._open_run_for_provider_locked(project_id, run_handle, provider)
                if phase == "before":
                    self._connection.execute(
                        "DELETE FROM launch_observations WHERE project_id=? AND handle_digest=?",
                        (project_id, keyed_digest(self.state.digest_key(), run_handle)),
                    )
        timestamp = self._clock_ms()
        untrusted = self._registered_roots(project_id)
        # The client's TMPDIR is a fresh owner-only directory under the learning
        # state, never the system temp directory a sandboxed primary can write.
        try:
            tmpdir = private_directory(self.state.root, "scratch", "client-")
        except HostPathError as exc:
            raise LedgerError("a private client directory is unavailable") from exc
        try:
            if provider == "claude":
                records = observe_claude(
                    digest_key=self.state.digest_key(),
                    observed_at_ms=timestamp,
                    tmpdir=tmpdir,
                    environ=environ,
                    untrusted=untrusted,
                )
            else:
                records = observe_codex(
                    project_root,
                    digest_key=self.state.digest_key(),
                    observed_at_ms=timestamp,
                    tmpdir=tmpdir,
                    environ=environ,
                    run_id=run_id,
                    phase=phase,
                    untrusted=untrusted,
                )
        finally:
            remove_private_directory(tmpdir)
        self._store_provider_observations(project_id, records, timestamp=timestamp)
        if run_handle is not None and phase == "before":
            with self._account_transaction():
                self._open_run_for_provider_locked(project_id, run_handle, provider)
                identities = [record for record in records if record["record_type"] == "provider_identity"]
                if len(identities) != 1:
                    raise LedgerError("launch observation has no single identity")
                self._connection.execute(
                    "INSERT INTO launch_observations VALUES(?,?,?,?) "
                    "ON CONFLICT(project_id,handle_digest) DO UPDATE SET "
                    "identity_digest=excluded.identity_digest,observed_at_ms=excluded.observed_at_ms",
                    (project_id, keyed_digest(self.state.digest_key(), run_handle), content_digest(identities[0]), timestamp),
                )
        return records

    def _registered_roots(self, project_id: str) -> tuple[Path, ...]:
        """The registered project's root, which no provider client may live in."""

        with self._held():
            row = self._connection.execute(
                "SELECT canonical_root FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
        if row is None or row["canonical_root"] is None:
            return ()
        return (Path(str(row["canonical_root"])),)

    def _open_run_for_provider_locked(
        self, project_id: str, run_handle: str, provider: str
    ) -> str:
        """The run ID of an open run whose stored admission passed for `provider`."""

        if not isinstance(run_handle, str):
            raise LedgerError("host run handle is invalid")
        binding = self._connection.execute(
            "SELECT run_id,binding_state,consumed_at_ms FROM host_run_bindings "
            "WHERE project_id=? AND handle_digest=?",
            (project_id, keyed_digest(self.state.digest_key(), run_handle)),
        ).fetchone()
        if binding is None:
            raise LedgerError("host run is unavailable")
        if binding["binding_state"] != "pending" or binding["consumed_at_ms"] is not None:
            raise LedgerError("host run is no longer open for observations")
        run_id = str(binding["run_id"])
        if self._run_admission_locked(project_id, run_id)["provider"] != provider:
            raise LedgerError("observation provider differs from the run's admission")
        return run_id

    def record_observation_unavailable(
        self,
        project_id: str,
        *,
        run_handle: str,
        provider: str,
        phase: str,
        reason_code: str,
    ) -> dict[str, Any]:
        """Persist that a run's provider reading could not be taken, and why.

        The record is never evidence for admission; it keeps a failed reading
        visible in the ledger instead of dropping it.
        """

        timestamp = self._clock_ms()
        with self._held(), self._connection:
            run_id = self._open_run_for_provider_locked(project_id, run_handle, provider)
            material = {
                "schema_version": 1,
                "record_type": "observation_unavailable",
                "provider": provider,
                "run_id": run_id,
                "phase": phase,
                "reason_code": reason_code,
                "observed_at_ms": timestamp,
            }
            try:
                record = validate_learning_record({
                    **material,
                    "record_id": f"observation_unavailable:{content_digest(material)}",
                })
            except ContractError as exc:
                raise LedgerError("unavailable observation is invalid") from exc
            self._append_checked_locked(
                project_id, record, producer="provider", timestamp=timestamp
            )
        self.state.harden_database_files()
        return record

    def record_provider_usage(
        self,
        project_id: str,
        *,
        run_handle: str,
        provider: str,
        usage: dict[str, Any],
    ) -> dict[str, Any]:
        """Persist a dispatched run's client-observed usage, once, linked to the run."""

        timestamp = self._clock_ms()
        with self._held(), self._connection:
            run_id = self._open_run_for_provider_locked(project_id, run_handle, provider)
            if self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND record_type='dispatch_intent' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, run_id),
            ).fetchone() is None:
                raise LedgerError("only a dispatched run records its usage")
            _refuse_malformed_rows(self._connection, project_id, "provider_usage")
            if self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND record_type='provider_usage' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, run_id),
            ).fetchone() is not None:
                raise LedgerError("host run already recorded its usage")
            if not isinstance(usage, dict):
                raise LedgerError("provider usage is invalid")
            material = {
                **usage,
                "schema_version": 1,
                "record_type": "provider_usage",
                "provider": provider,
                "run_id": run_id,
                "phase": "after",
                "observed_at_ms": timestamp,
            }
            material.pop("record_id", None)
            try:
                record = validate_learning_record({
                    **material, "record_id": f"provider_usage:{content_digest(material)}",
                })
            except ContractError as exc:
                raise LedgerError("provider usage is invalid") from exc
            self._append_checked_locked(
                project_id, record, producer="provider", timestamp=timestamp
            )
        self.state.harden_database_files()
        return record

    def _launch_identity_locked(
        self, project_id: str, run_handle: str, identity: dict[str, Any],
    ) -> tuple[dict[str, Any], str]:
        """Re-read the actual open run and its exact stored launch observation."""

        if type(identity) is not dict:
            raise LedgerError("launch identity is invalid")
        run_id = self._open_run_for_provider_locked(
            project_id, run_handle, identity.get("provider")
        )
        admission = self._run_admission_locked(project_id, run_id)
        digest = content_digest(identity)
        if (
            identity.get("record_type") != "provider_identity"
            or identity.get("account_fingerprint") != admission["account_fingerprint"]
            or self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND content_digest=? "
                "AND record_type='provider_identity' AND source='provider'",
                (project_id, digest),
            ).fetchone() is None
        ):
            raise LedgerError("launch identity is not this run's stored observation")
        return admission, digest

    def launch_recheck(
        self, project_id: str, *, run_handle: str, identity: dict[str, Any]
    ) -> str | None:
        """Re-check the actual admitted run against current launch restrictions.

        Verify immutable owner-signature inputs outside the ledger lock, then
        reject any change to their owner generation, signer or complete rows.
        Re-read the run, stored identity, shared billing/headroom and clock in
        the final locked phase. Preparation never caches launch eligibility.
        Denial records and links commit in one explicit unit. None is not a
        durable launch claim. Call without already holding the private mutex.
        This legacy primitive still reads JSON/filesystem under the final lock;
        bounded service jobs and native caller enrollment remain separate gates.
        """

        from .providers import evaluate_launch

        # Reject an invalid/foreign run before spending verification work. Never
        # borrow or commit an outer write transaction while releasing this lock.
        with self._held():
            if self._connection.in_transaction:
                raise LedgerError("account write transaction is already active")
            admission, _ = self._launch_identity_locked(project_id, run_handle, identity)
        prepared = self._prepare_attestations(project_id, admission["provider"])
        denied = None
        with self._held():
            admission, digest = self._launch_identity_locked(project_id, run_handle, identity)
            provider = admission["provider"]
            attestations = self._prepared_attestations_locked(prepared, project_id, provider)
            billing, _ = self._account_records_locked(project_id, "provider_billing", provider)
            headroom, _ = self._account_records_locked(
                project_id, "provider_headroom", provider
            )
            timestamp = self._clock_ms()
            reason = evaluate_launch(
                provider=provider, identity=identity, billing=billing,
                headroom=headroom, now_ms=timestamp, attestations=attestations,
                bootstrap=admission["admission_basis"] == "bootstrap",
            )
            if reason is not None:
                denied = {
                    "provider": provider, "decision": "deny", "reason_code": reason,
                    "admission_basis": None,
                    "account_fingerprint": admission["account_fingerprint"],
                    "evidence_digests": [digest], "observed_at_ms": timestamp,
                }
                # Denial metadata and derived links are one explicit write
                # unit, including mode checks before commit and full rollback.
                with self._account_transaction():
                    self._store_admission_locked(
                        project_id, denied, run_id=None, timestamp=timestamp
                    )
        self.state.harden_database_files()
        return None if denied is None else denied["reason_code"]

    def admitted_client(self, project_id: str, run_handle: str) -> dict[str, Any]:
        """The identity a run was admitted on: its account and the client it saw.

        Read from the stored admission's own evidence, so the launch re-check
        compares against what was admitted, never against current facts.
        """

        with self._held():
            binding = self._connection.execute(
                "SELECT run_id FROM host_run_bindings WHERE project_id=? AND handle_digest=?",
                (project_id, keyed_digest(self.state.digest_key(), run_handle)),
            ).fetchone()
            if binding is None:
                raise LedgerError("host run is unavailable")
            run_id = str(binding["run_id"])
            admission = self._run_admission_locked(project_id, run_id)
            identities = []
            for digest in admission["evidence_digests"]:
                row = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? AND content_digest=? "
                    "AND record_type='provider_identity' AND source='provider'",
                    (project_id, digest),
                ).fetchone()
                if row is not None:
                    identities.append(json.loads(bytes(row["content"])))
        if len(identities) != 1:
            raise LedgerError("host run admission has no single admitted identity")
        try:
            identity = validate_learning_record(identities[0])
        except ContractError as exc:
            raise LedgerError("admitted identity is invalid") from exc
        if (
            identity["provider"] != admission["provider"]
            or identity["account_fingerprint"] != admission["account_fingerprint"]
        ):
            raise LedgerError("admitted identity differs from the admission")
        return {
            "provider": identity["provider"],
            "account_fingerprint": identity["account_fingerprint"],
            "client_version": identity["client_version"],
        }

    def observe_claude_billing(
        self,
        project_id: str,
        *,
        project_root: Path,
        environ: Any = None,
    ) -> dict[str, Any]:
        """Observe the Claude identity, then probe billing and headroom once.

        Native Claude children emit no rate-limit event, so this probe is the
        billing evidence for a Claude primary. It is a real, small request, so
        it passes the same admission rules as a run first (except that stale
        billing may be refreshed), shares the single per-account bootstrap
        allowance, and reuses account evidence younger than five minutes.
        Otherwise a probe for the same account in the last five minutes, in any
        project and whatever its outcome, refuses with `probe_cooldown`, so a
        probe that records nothing cannot be repeated. Every rate-limit event
        it reports is kept as one conservative merge.
        """

        from . import admission_metadata
        from .bridge import BridgeRefused, claude_billing_probe
        from .claude_host import ClaudeHostDenied, check_backend
        from .providers import AdmissionDenied, _headroom_state, claude_rate_limit_records, probe_records

        environ = os.environ if environ is None else environ
        # Decision 50 (BR-21): a provider API key in the caller's environment or in the process's own refuses,
        # whichever the caller passed; the passed one still decides what a launched probe runs with.
        checked_environ = {**dict(os.environ), **dict(environ)}
        started = self._clock_ms()

        def deny(reason: str, timestamp: int, decision: dict[str, Any] | None = None):
            record = decision or {
                "provider": "claude", "decision": "deny", "reason_code": reason,
                "admission_basis": None, "account_fingerprint": None,
                "evidence_digests": [], "observed_at_ms": timestamp,
            }
            with self._held(), self._connection:
                # Decision 50 (BR-22): one denial record per reason and account per window.
                self._store_probe_denial_locked(project_id, record, timestamp=timestamp)
            self.state.harden_database_files()

        try:
            check_backend(environ, project_root)
        except ClaudeHostDenied as exc:
            deny(exc.reason_code, self._clock_ms())
            raise
        identity = self.observe_provider(
            project_id, "claude", project_root=project_root, environ=environ
        )[0]
        fingerprint = identity["account_fingerprint"]
        with self._held(), self._connection:
            # Read under the lock that orders admission decisions.
            timestamp = self._clock_ms()
            account_billing, _ = self._account_records_locked(project_id, "provider_billing", "claude")
            account_headroom, _ = self._account_records_locked(project_id, "provider_headroom", "claude")
            billing = [(record, digest) for record, digest in account_billing
                       if record["account_fingerprint"] == fingerprint]
            # Decision 50 (BR-21): the reading a reuse stands on is the probe's own (a finished child's
            # records neither stand in for it nor refresh its age), and a newer run record that is more
            # restrictive stops the reuse, as it does on the account path (R2, BR-2).
            latest = admission_metadata.probe_latest(billing, fingerprint)
            order = {
                str(row[0]): int(row[1]) for row in self._connection.execute(
                    "SELECT record_id,rowid FROM records WHERE source='provider' "
                    "AND record_type IN ('provider_billing','provider_headroom')"
                ).fetchall()
            }
            reuse = (
                latest is not None
                and 0 <= timestamp - latest["observed_at_ms"] < (
                    PROBE_REUSE_SECONDS * 1000
                )
                and not admission_metadata.newer_run_restricts(
                    latest, billing, account_headroom, fingerprint, timestamp, order)
            )
            decision = self._evaluate_admission_locked(
                project_id, provider="claude", environ=checked_environ, timestamp=timestamp,
                probe=True,
            )
            if reuse and decision["decision"] == "pass":
                # B1: fresh evidence bounds the spend when children open back to back,
                # but never without a judgment: paid usage, a client version or an
                # attestation problem is refused below with its own reason.
                head = admission_metadata.probe_head(account_headroom, fingerprint, latest)
                # Decision 50 (BR-21): the yes is built here and nowhere else, by the shared gate, after the
                # last read and with nothing external after it.
                refusal = admission_metadata.reuse_gate(
                    environ=environ, process_environ=os.environ, identity_at=identity["observed_at_ms"],
                    reuse_at=latest["observed_at_ms"], now_ms=self._clock_ms(), since_ms=started,
                    reuse_ms=PROBE_REUSE_SECONDS * 1000,
                )
                if refusal is None:
                    return {
                        "probe": "reused",
                        "records": [identity, *([] if head is None else [head]), latest],
                    }
                if refusal == "provider_api_key_present":
                    decision = {
                        "provider": "claude", "decision": "deny", "reason_code": refusal,
                        "admission_basis": None, "account_fingerprint": fingerprint,
                        "evidence_digests": [], "observed_at_ms": timestamp,
                    }
                reuse = False
            # Owner decision 40 (a): the real problem is reported first; the cooldown
            # names itself only when nothing else refuses. billing_unverified is the
            # gap the cooling probe itself fills, so it does not count as a real problem.
            cooldown = self._connection.execute(
                "SELECT MAX(observed_at_ms) FROM records WHERE record_type='probe_admission' "
                "AND source='lifecycle' "
                "AND json_extract(CAST(content AS TEXT),'$.decision')='pass' "
                "AND json_extract(CAST(content AS TEXT),'$.account_fingerprint')=? "
                "AND observed_at_ms>?",
                (fingerprint, timestamp - PROBE_COOLDOWN_SECONDS * 1000),
            ).fetchone()[0]
            retry_at = None
            if not reuse and (
                decision["decision"] == "pass"
                or decision["reason_code"] == "billing_unverified"
            ) and cooldown is not None:
                retry_at = admission_metadata.probe_retry_at(cooldown)
                # The reservation is durable and account-wide; a probe stamped
                # after now also counts, so a clock step never reopens it.
                decision = {
                    "provider": "claude", "decision": "deny",
                    "reason_code": "probe_cooldown", "admission_basis": None,
                    "account_fingerprint": fingerprint, "evidence_digests": [],
                    "observed_at_ms": timestamp,
                }
            if decision["decision"] == "pass":
                # Stored before launch, in the same transaction as the decision,
                # so a crash or a repeat cannot take the bootstrap twice.
                self._store_probe_admission_locked(
                    project_id, decision, timestamp=timestamp
                )
        if decision["decision"] != "pass":
            deny(decision["reason_code"], timestamp, decision)
            raise AdmissionDenied(decision["reason_code"], retry_at=retry_at)
        self.state.harden_database_files()
        import secrets
        probe_id = secrets.token_hex(32)
        infos, failure = claude_billing_probe(
            environ, project_root=project_root,
            untrusted=self._registered_roots(project_id),
        )
        observed = self._clock_ms()
        headroom: list[dict[str, Any]] = []
        billing_records: list[dict[str, Any]] = []
        invalid = 0
        for info in infos:
            # Each event is parsed on its own, so one bad event never discards
            # the restrictions the others carry.
            try:
                event_headroom, event_billing = claude_rate_limit_records(
                    info, account_fingerprint=fingerprint, observed_at_ms=observed
                )
            except ContractError:
                invalid += 1
                continue
            headroom.append(event_headroom)
            billing_records.append(event_billing)
        records: list[dict[str, Any]] = []
        if headroom:
            # One conservative merge of every valid event: the highest status,
            # per window the highest use and latest effective reset, and
            # billing at its highest rank. Stored even when the probe failed.
            records = [
                _merged_restriction(headroom, observed_at_ms=observed),
                max(
                    reversed(billing_records),
                    key=lambda record: BILLING_RANK[record["paid_usage_usable"]],
                ),
            ]
            if failure is not None or invalid:
                # An incomplete probe never refreshes clean evidence: only its
                # restrictive parts are stored. Clean billing would look fresh
                # and admit runs, so it is dropped and the older reading ages
                # out; a clean headroom reading is dropped with it.
                merged_headroom, merged_billing = records
                records = [
                    *([merged_headroom] if merged_headroom["status"] != "allowed"
                      or _headroom_state("claude", merged_headroom, observed) not in {"ample", None}
                      else []),
                    *([merged_billing] if merged_billing["paid_usage_usable"] is not False
                      else []),
                ]
            records = probe_records(records, probe_id)
            if records:
                self._store_provider_observations(project_id, records, timestamp=observed)
        if failure is not None:
            raise BridgeRefused(f"billing probe failed: {failure}")
        if not infos:
            raise BridgeRefused("billing probe reported no rate-limit event")
        if not headroom:
            raise BridgeRefused("billing probe reported no valid rate-limit event")
        if invalid:
            raise BridgeRefused("billing probe reported an invalid rate-limit event")
        return {"probe": "launched", "records": [identity, *records]}

    def _store_probe_admission_locked(
        self, project_id: str, decision: dict[str, Any], *, timestamp: int
    ) -> dict[str, Any]:
        material = {"schema_version": 1, "record_type": "probe_admission", **decision}
        try:
            record = validate_learning_record(
                {**material, "record_id": f"probe_admission:{content_digest(material)}"}
            )
        except ContractError as exc:
            raise LedgerError("probe admission decision is invalid") from exc
        self._append_checked_locked(
            project_id, record, producer="lifecycle", timestamp=timestamp
        )
        return record

    def _store_probe_denial_locked(
        self, project_id: str, decision: dict[str, Any], *, timestamp: int
    ) -> tuple[dict[str, Any], bool]:
        """Decision 50 (BR-22): one denial record per reason per account per window.

        A refusal whose (reason, account) already has a denial record inside PROBE_DENIAL_WINDOW_MS of this
        time (before or after it, so a clock step does not reopen it) is answered from that record and stores
        nothing, so a client asking again and again cannot grow the ledger. The window is the probe cooldown;
        a stored record keeps the ordinary retention. Returns (the record that stands for it, whether it is new).
        A pass admission is never bounded: it is stored by _store_probe_admission_locked."""

        window = PROBE_DENIAL_WINDOW_MS
        row = self._connection.execute(
            "SELECT content FROM records WHERE record_type='probe_admission' AND source='lifecycle' "
            "AND json_extract(CAST(content AS TEXT),'$.decision')='deny' "
            "AND json_extract(CAST(content AS TEXT),'$.reason_code')=? "
            "AND json_extract(CAST(content AS TEXT),'$.account_fingerprint') IS ? "
            "AND observed_at_ms>? AND observed_at_ms<? ORDER BY observed_at_ms DESC LIMIT 1",
            (decision["reason_code"], decision["account_fingerprint"], timestamp - window, timestamp + window),
        ).fetchone()
        if row is not None:
            return validate_learning_record(json.loads(bytes(row[0]))), False
        return self._store_probe_admission_locked(project_id, decision, timestamp=timestamp), True

    def record_claude_rate_limit_event(
        self,
        project_id: str,
        *,
        run_handle: str,
        rate_limit_info: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Record a rate-limit event of an open, admitted Claude run.

        The fingerprint comes from the run's stored admission and the time from
        the ledger's clock, and events are accepted only before the run's result
        is committed. Every event that is more restrictive than what the run
        already recorded is kept, so a rejection late in a run blocks the next
        admission. A less restrictive event is dropped, so a caller cannot use a
        later favourable event to replace the run's evidence. Returns the
        records kept.
        """

        from .providers import claude_rate_limit_records

        timestamp = self._clock_ms()
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._write_unit():
            binding = self._connection.execute(
                "SELECT run_id,binding_state,consumed_at_ms FROM host_run_bindings "
                "WHERE project_id=? AND handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if binding is None:
                raise LedgerError("host run is unavailable")
            if binding["binding_state"] != "pending" or binding["consumed_at_ms"] is not None:
                raise LedgerError("host run is no longer open for observations")
            run_id = str(binding["run_id"])
            decision = self._run_admission_locked(project_id, run_id)
            if decision["provider"] != "claude":
                raise ContractError("rate-limit event does not belong to a Claude run")
            prior = [
                json.loads(bytes(row["content"]))
                for row in self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? AND source='provider' "
                    "AND record_type IN ('provider_headroom','provider_billing') "
                    "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=? "
                    "AND json_extract(CAST(content AS TEXT),'$.phase')='during' "
                    "ORDER BY source_sequence",
                    (project_id, run_id),
                ).fetchall()
            ]
            if len(prior) >= MAX_RUN_RATE_LIMIT_RECORDS:
                # The run is fenced: its restriction was merged when it reached
                # the cap, and the bridge stopped it.
                raise ContractError("host run recorded too many rate-limit events")
            records = claude_rate_limit_records(
                rate_limit_info,
                account_fingerprint=decision["account_fingerprint"],
                observed_at_ms=timestamp,
                run_id=run_id,
                phase="during",
            )
            try:
                checked = [validate_learning_record(record) for record in records]
            except ContractError as exc:
                raise LedgerError("record admission rejected") from exc
            kept = [
                record for record in checked
                if _more_restrictive(record, [
                    item for item in prior if item["record_type"] == record["record_type"]
                ])
            ]
            overflow = bool(kept) and len(prior) + len(kept) >= MAX_RUN_RATE_LIMIT_RECORDS
            if overflow:
                # At the cap the run's whole restriction is merged into one
                # record, the highest status with the latest reset, and the run
                # is fenced: the bridge stops it and later events are refused.
                headroom = [item for item in prior if item["record_type"] == "provider_headroom"]
                new = [item for item in checked if item["record_type"] == "provider_headroom"]
                try:
                    merged = validate_learning_record(
                        _merged_restriction([*headroom, *new], observed_at_ms=timestamp)
                    )
                except ContractError as exc:
                    raise LedgerError("record admission rejected") from exc
                kept = [
                    merged,
                    *(item for item in kept if item["record_type"] == "provider_billing"),
                ]
            for record in kept:
                self._append_checked_locked(
                    project_id, record, producer="provider", timestamp=timestamp
                )
        self.state.harden_database_files()
        if overflow:
            raise ContractError("host run recorded too many rate-limit events")
        return kept

    def _record_project_rate_limit_event(self, project_id, *, runtime_digest, event, storage_binding, storage_evidence):
        """A rate-limit event of a registered, unfinished Claude run of one project.

        The run's lease and sealed storage evidence name the run; the event is
        accepted only while its execution is registered and has no terminal.
        A failure to keep it is recorded as a lost `during` reading before the
        refusal, so the account never silently drops a restriction.
        """
        from .claim_storage import capture_storage_evidence, verify_bound_storage_evidence
        from .rate_limit_contracts import RateLimitEventInput

        if type(event) is not RateLimitEventInput:
            raise ClaimError("claim_execution_invalid")
        event = RateLimitEventInput(**event.payload())
        expected, evidence = capture_storage_evidence(storage_binding, storage_evidence)
        lease = verify_bound_storage_evidence(self.state.digest_key(), expected, evidence)
        if (expected.project_id != project_id or expected.runtime_digest != runtime_digest
                or expected.run_handle != event.run_handle or lease.claim_id is None):
            raise ClaimError("claim_execution_invalid")
        handle_digest = keyed_digest(self.state.digest_key(), event.run_handle)
        with self._held():
            row = self._connection.execute(
                "SELECT e.run_id FROM capacity_executions e JOIN active_run_capacity a "
                "ON a.project_id=e.project_id AND a.handle_digest=e.handle_digest AND a.run_id=e.run_id "
                "AND a.bridge_run_id=e.bridge_run_id "
                "LEFT JOIN capacity_completions c ON c.project_id=e.project_id AND c.handle_digest=e.handle_digest "
                "WHERE e.project_id=? AND e.handle_digest=? AND e.bridge_run_id=? AND e.run_id=? "
                "AND a.provider='claude' AND a.released_at_ms IS NULL AND c.handle_digest IS NULL",
                (project_id, handle_digest, lease.claim_id, expected.run_id),
            ).fetchone()
        if row is None:
            raise ClaimError("claim_execution_unavailable")
        try:
            return self.record_claude_rate_limit_event(project_id, run_handle=event.run_handle,
                                                       rate_limit_info=event.rate_limit_info)
        except (ContractError, LedgerError):
            with contextlib.suppress(ContractError, LedgerError):
                self.record_observation_unavailable(project_id, run_handle=event.run_handle, provider="claude",
                                                    phase="during", reason_code="observation_failed")
            raise

    def _owner_generation_locked(self) -> tuple[int, bytes, str, int] | None:
        row = self._connection.execute(
            "SELECT sequence,signer_line,reason,recorded_at_ms FROM owner_key_history "
            "ORDER BY sequence DESC LIMIT 1"
        ).fetchone()
        if row is None:
            return None
        if (
            type(row[0]) is not int or row[0] < 1 or type(row[1]) is not bytes
            or not 0 < len(row[1]) <= OWNER_SIGNERS_MAX_BYTES
            or row[2] not in {"enrolled", "replaced"} or type(row[3]) is not int or row[3] < 0
        ):
            raise LedgerError("owner generation is incompatible")
        return tuple(row)

    def _attestation_rows_locked(
        self, project_id: str, provider: str,
    ) -> tuple[tuple[str, int, bytes, str, str, bytes | None], ...]:
        rows = self._connection.execute(
            "SELECT r.record_id,r.source_sequence,r.content,r.content_digest,r.source,a.signature "
            "FROM temp.capture_candidates c CROSS JOIN records r LEFT JOIN owner_attestations a "
            "ON a.project_id=r.project_id AND a.subject_record_id=r.record_id "
            "WHERE c.consumer=? AND c.project_id=? AND c.record_type='billing_attestation' "
            "AND r.rowid=c.record_rowid AND json_extract(CAST(r.content AS TEXT),'$.provider')=? "
            "ORDER BY c.source_sequence",
            (provider, project_id, provider),
        ).fetchall()
        result = []
        for row in rows:
            if (
                type(row[0]) is not str or type(row[1]) is not int or row[1] < 1
                or type(row[2]) is not bytes or not 0 < len(row[2]) <= MAX_RECORD_BYTES
                or type(row[3]) is not str or re.fullmatch(r"[0-9a-f]{64}", row[3]) is None
                or hashlib.sha256(row[2]).hexdigest() != row[3] or type(row[4]) is not str
                or (row[5] is not None and (type(row[5]) is not bytes or len(row[5]) > 16_384))
            ):
                raise LedgerError("admission attestation is incompatible")
            result.append(tuple(row))
        return tuple(result)

    def _current_signer_bytes(self) -> bytes | None:
        try:
            return self.state._owner_signer_bytes()
        except (StateError, OSError):
            return None

    def _prepare_attestations(self, project_id: str, provider: str) -> _PreparedAttestations:
        """Verify immutable signature inputs outside the account lock/transaction.

        This owner-only value never crosses a request API. It authenticates no
        caller, cannot substitute a daemon's environment for launch facts, and
        does not implement bounded service job scheduling or native enrollment.
        """

        from .learning_engine import OwnerGrantAuthority

        with self._held():
            if self._connection.in_transaction:
                raise LedgerError("account write transaction is already active")
            owner = self._owner_generation_locked()
            rows = self._attestation_rows_locked(project_id, provider)
        signer = self._current_signer_bytes()
        authority = None
        if signer is not None and (owner is None or owner[1] == signer):
            try:
                authority = OwnerGrantAuthority(self.state.allowed_signers_path, signer_line=signer)
            except (ContractError, OSError):
                pass
        verified = set()
        if authority is not None:
            for identifier, _, content, _, source, signature in rows:
                if source != "owner" or not signature:
                    continue
                try:
                    if authority.verify_owner_record(project_id, parse_bounded_json(content), signature):
                        verified.add(identifier)
                except (ContractError, TypeError, ValueError, OSError):
                    pass
        return _PreparedAttestations(self._attestation_origin, project_id, provider, owner, signer, rows, frozenset(verified))

    def _prepared_attestations_locked(
        self, prepared: _PreparedAttestations, project_id: str, provider: str,
    ) -> list[tuple[dict[str, Any], str]]:
        if (
            type(prepared) is not _PreparedAttestations or prepared.origin is not self._attestation_origin
            or prepared.project_id != project_id or prepared.provider != provider
            or prepared.owner != self._owner_generation_locked()
            or prepared.signer != self._current_signer_bytes()
            or prepared.rows != self._attestation_rows_locked(project_id, provider)
        ):
            raise LedgerError("admission preparation is stale")
        return [(parse_bounded_json(content), digest) for identifier, _, content, digest, source, _ in prepared.rows
                if source == "owner" and identifier in prepared.verified]

    def _provider_records_locked(
        self, project_id: str, record_type: str, provider: str
    ) -> list[tuple[dict[str, Any], str]]:
        try:
            rows = self._connection.execute(
                # LOCKHOLD-2/3: an ORDER BY must not make SQLite walk every event in
                # the project's sequence index. Sort only this type's evidence rows.
                "SELECT content,content_digest,source FROM records INDEXED BY records_type_project "
                "WHERE project_id=? AND record_type=? "
                "AND json_extract(CAST(content AS TEXT),'$.provider')=? "
                "ORDER BY source_sequence",
                (project_id, record_type, provider),
            ).fetchall()
        except sqlite3.OperationalError as error:
            # Match the pinned evidence lookups: other SQLite errors keep their answers.
            if "no such index" not in str(error) and "no query solution" not in str(error):
                raise
            raise LedgerError("provider evidence lookup is unavailable; reopen the ledger") from None
        result = []
        for row in rows:
            record = json.loads(bytes(row["content"]))
            # Attestations count only while the current owner key verifies their signature,
            # so replacing or swapping the key cancels what the earlier key signed.
            if record_type == "billing_attestation" and (
                row["source"] != "owner"
                or not self._attestation_signed_by_owner_locked(project_id, record)
            ):
                continue
            result.append((record, str(row["content_digest"])))
        return result

    def _attestation_signed_by_owner_locked(
        self, project_id: str, record: dict[str, Any]
    ) -> bool:
        from .learning_engine import OwnerGrantAuthority

        receipt = self._connection.execute(
            "SELECT signature FROM owner_attestations "
            "WHERE project_id=? AND subject_record_id=?",
            (project_id, record["record_id"]),
        ).fetchone()
        if receipt is None:
            return False
        try:
            authority = OwnerGrantAuthority.for_state(self.state)
            return authority.verify_owner_record(
                project_id, record, bytes(receipt["signature"])
            )
        except (StateError, ContractError, OSError):
            return False

    def _admission_settings(self, provider: str) -> dict[str, Any] | None:
        """The provider's committed admission settings; None if they cannot be read."""

        from .routing import admission_settings, load_policy

        try:
            policy = (
                self._admission_policy
                if self._admission_policy is not None
                else load_policy(INSTALLED_ROUTING_POLICY)
            )
            return admission_settings(policy, provider)
        except (ValueError, TypeError, KeyError, AttributeError, OSError):
            return None

    def client_version_reviewed(self, provider: str, version: Any) -> bool:
        """Whether a client version is inside the provider's committed reviewed range."""

        from .learning_contracts import parse_semver

        settings = self._admission_settings(provider)
        parsed = parse_semver(version)
        if settings is None or parsed is None:
            return False
        versions = settings["client_versions"]
        minimum = parse_semver(versions["minimum"])
        maximum = parse_semver(versions["maximum_exclusive"])
        return minimum is not None and maximum is not None and minimum <= parsed < maximum

    def _prior_run_admissions_locked(
        self, provider: str, timestamp: int
    ) -> list[tuple[str, int]]:
        """Passing run admissions for a provider since one window before `timestamp`.

        The cap belongs to the account, so admissions in every project of this
        ledger count; fingerprints use the ledger-wide key and compare across
        projects. Read under the writer lock with the decision that uses them,
        so two opens cannot both take the last place under the cap. Probe
        admissions are a separate record type and never count.
        """

        from .providers import FIVE_HOURS_MS

        rows = self._connection.execute(
            "SELECT json_extract(CAST(content AS TEXT),'$.account_fingerprint'),"
            "observed_at_ms FROM records WHERE "
            "record_type='admission_decision' AND source='lifecycle' "
            "AND json_extract(CAST(content AS TEXT),'$.provider')=? "
            "AND json_extract(CAST(content AS TEXT),'$.decision')='pass' "
            "AND json_extract(CAST(content AS TEXT),'$.run_id') IS NOT NULL "
            "AND observed_at_ms>=?",
            (provider, timestamp - FIVE_HOURS_MS),
        ).fetchall()
        return [(str(row[0]), int(row[1])) for row in rows if row[0] is not None]

    def _account_records_locked(
        self, project_id: str, record_type: str, provider: str
    ) -> tuple[list[tuple[dict[str, Any], str]], set[str]]:
        """A provider's observations of one type from every project, and this
        project's digests among them.

        Billing, headroom and the run cap belong to the account, which several
        projects can share, so they are read ledger-wide. Fingerprints use the
        ledger-wide key and compare across projects. A decision cites only the
        records its own project holds.
        """

        rows = self._connection.execute(
            "SELECT project_id,content,content_digest FROM records WHERE "
            "record_type=? AND source='provider' "
            "AND json_extract(CAST(content AS TEXT),'$.provider')=? "
            "ORDER BY observed_at_ms,ingested_at_ms,project_id,source_sequence",
            (record_type, provider),
        ).fetchall()
        records = [
            (json.loads(bytes(row["content"])), str(row["content_digest"])) for row in rows
        ]
        local = {str(row["content_digest"]) for row in rows if row["project_id"] == project_id}
        return records, local

    def _prior_claude_admissions_locked(self) -> set[str]:
        """Accounts that already had a passing Claude run or probe, in any project.

        The single Claude bootstrap is per account, not per project.
        """

        return {
            str(row[0])
            for row in self._connection.execute(
                "SELECT json_extract(CAST(content AS TEXT),'$.account_fingerprint') "
                "FROM records WHERE source='lifecycle' "
                "AND record_type IN ('admission_decision','probe_admission') "
                "AND json_extract(CAST(content AS TEXT),'$.provider')='claude' "
                "AND json_extract(CAST(content AS TEXT),'$.decision')='pass'",
            ).fetchall()
            if row[0] is not None
        }

    def _recheck_attempts_locked(self, provider, fingerprint):
        """USAGE-RECHECK-5: when this account's admitted billing probes began, in any project.

        An admitted probe is committed before it launches, so it reserves the account's re-check interval whether
        or not its run produced a reading. Codex re-checks do not spend; the route reserves them (cli.py)."""
        if provider != "claude" or fingerprint is None:
            return ()
        return tuple(int(row[0]) for row in self._connection.execute(
            "SELECT observed_at_ms FROM records WHERE source='lifecycle' AND record_type='probe_admission' "
            "AND json_extract(CAST(content AS TEXT),'$.provider')='claude' "
            "AND json_extract(CAST(content AS TEXT),'$.decision')='pass' "
            "AND json_extract(CAST(content AS TEXT),'$.account_fingerprint')=?", (fingerprint,)).fetchall())

    def _store_route_availability_locked(self, project_id, run_id, route, timestamp):
        """Bind the logical open's bounded attempt history to its admitted run."""
        availability = route.get("availability", {})
        if not availability.get("open_attempts"):
            return  # Earlier callers without logical route/open recovery.
        material = {"schema_version": 1, "record_type": "route_availability", "run_id": run_id,
                    "availability": availability, "observed_at_ms": timestamp}
        record = validate_learning_record({**material, "record_id": "route_availability:" + content_digest(material)})
        self._append_checked_locked(project_id, record, producer="lifecycle", timestamp=timestamp)

    def provider_state_snapshot(self, project_id: str, *, now_ms: int | None = None):
        """Build advisory routing state from the service's trusted account evidence."""
        from .admission_metadata import ProviderStateSnapshot, classify_provider_state, select_provider_identity
        timestamp = self._clock_ms() if now_ms is None else now_ms
        states = {}
        with self._write_unit():
            project = self._connection.execute("SELECT status FROM projects WHERE project_id=?", (project_id,)).fetchone()
            if project is None or project["status"] != "active":
                raise LedgerError("project binding is not active")
            for provider in ("codex", "claude"):
                identities = self._provider_records_locked(project_id, "provider_identity", provider)
                identity = select_provider_identity(provider, identities, timestamp)
                fingerprint = identity[0]["account_fingerprint"] if identity is not None else None
                headroom, _ = self._account_records_locked(project_id, "provider_headroom", provider)
                billing, _ = self._account_records_locked(project_id, "provider_billing", provider)
                state = classify_provider_state(provider, fingerprint, headroom, billing, timestamp,
                    recheck_attempts_ms=self._recheck_attempts_locked(provider, fingerprint))
                digests = state["evidence_digests"]
                refs = []
                if digests:
                    rows = self._connection.execute(
                        "SELECT DISTINCT project_id,content_digest FROM records WHERE source='provider' AND content_digest IN ("
                        + ",".join("?" for _ in digests) + ") ORDER BY project_id,content_digest", digests).fetchall()
                    refs = [{"project_id": str(row[0]), "digest": str(row[1])} for row in rows]
                states[provider] = {**state, "account_fingerprint": fingerprint,
                    "identity_evidence": identity[1] if identity is not None else None,
                    "identity_available": identity is not None, "evidence_refs": refs}
        return ProviderStateSnapshot(project_id, timestamp, states)

    def _evaluate_admission_locked(
        self,
        project_id: str,
        *,
        provider: str,
        environ: Any,
        timestamp: int,
        probe: bool = False,
        _prepared_attestations: _PreparedAttestations | None = None,
    ) -> dict[str, Any]:
        from .providers import evaluate_admission

        project = self._connection.execute(
            "SELECT status FROM projects WHERE project_id=?", (project_id,)
        ).fetchone()
        if not project or project["status"] != "active":
            raise LedgerError("project binding is not active")
        identities = self._provider_records_locked(project_id, "provider_identity", provider)
        attestations = (
            self._provider_records_locked(project_id, "billing_attestation", provider)
            if _prepared_attestations is None
            else self._prepared_attestations_locked(_prepared_attestations, project_id, provider)
        )
        billing, local_billing = self._account_records_locked(
            project_id, "provider_billing", provider
        )
        headroom, local_headroom = self._account_records_locked(
            project_id, "provider_headroom", provider
        )
        if probe:
            from .admission_metadata import select_provider_identity
            identity = select_provider_identity(provider, identities, timestamp)
            attempts = self._recheck_attempts_locked(
                provider, identity[0]["account_fingerprint"] if identity is not None else None)
        else:
            attempts = ()
        return evaluate_admission(
            admission_policy=self._admission_settings(provider),
            prior_run_admissions=self._prior_run_admissions_locked(provider, timestamp),
            provider=provider,
            identities=identities,
            attestations=attestations,
            billing=billing,
            headroom=headroom,
            window_headroom=headroom,
            prior_claude_admissions=self._prior_claude_admissions_locked(),
            cited_digests={
                *(digest for _, digest in identities),
                *(digest for _, digest in attestations),
                *local_billing,
                *local_headroom,
            },
            environ=environ,
            now_ms=timestamp,
            probe=probe,
            recheck_attempts_ms=attempts,
        )

    def evaluate_admission(
        self,
        project_id: str,
        *,
        provider: str,
        environ: Any,
        now_ms: int | None = None,
        _prepared_attestations: _PreparedAttestations | None = None,
    ) -> dict[str, Any]:
        """Evaluate admission from stored evidence; a denial is stored and raised.

        The returned decision is informational: only the ledger binds a decision
        to a run, inside open_host_run or a session binding.
        """

        from .providers import AdmissionDenied

        prepared = (
            self._prepare_attestations(project_id, provider)
            if _prepared_attestations is None else _prepared_attestations
        )
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held():
            decision = self._evaluate_admission_locked(
                project_id, provider=provider, environ=environ, timestamp=timestamp,
                _prepared_attestations=prepared,
            )
            if decision["decision"] == "deny":
                # Denials are durable metadata too. Begin explicitly only for
                # their write; a successful informational evaluation stays read-only.
                with self._account_transaction():
                    record = self._store_admission_locked(
                        project_id, decision, run_id=None, timestamp=timestamp
                    )
        if decision["decision"] == "deny":
            denial = AdmissionDenied(decision["reason_code"])
            denial.open_reference = {"project_id": project_id, "admission_record_id": record["record_id"],
                                     "admission_content_digest": content_digest(record)}
            raise denial
        self.state.harden_database_files()
        return decision

    def _store_admission_locked(
        self,
        project_id: str,
        decision: dict[str, Any],
        *,
        run_id: str | None,
        timestamp: int,
    ) -> dict[str, Any]:
        from .providers import admission_record

        try:
            record = admission_record(decision, run_id)
        except ContractError as exc:
            raise LedgerError("admission decision is invalid") from exc
        for digest in record["evidence_digests"]:
            if self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND content_digest=?",
                (project_id, digest),
            ).fetchone() is None:
                raise LedgerError("admission evidence is unavailable")
        self._append_checked_locked(
            project_id, record, producer="lifecycle", timestamp=timestamp
        )
        return record

    def _run_admission_locked(self, project_id: str, run_id: str) -> dict[str, Any]:
        rows = self._connection.execute(
            "SELECT content,source FROM records WHERE project_id=? "
            "AND record_type='admission_decision' "
            "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
            (project_id, run_id),
        ).fetchall()
        if len(rows) != 1 or rows[0]["source"] != "lifecycle":
            raise LedgerError("host run has no stored admission decision")
        try:
            decision = validate_learning_record(json.loads(bytes(rows[0]["content"])))
        except (ContractError, TypeError, ValueError) as exc:
            raise LedgerError("host run admission is invalid") from exc
        if decision["record_type"] != "admission_decision" or decision["decision"] != "pass":
            raise LedgerError("host run admission is not a pass")
        return decision

    def _claim_context_locked(self, project_id, handle_digest, launch, timestamp):
        from .providers import BILLING_MAX_AGE_MS

        binding = self._connection.execute(
            "SELECT * FROM host_run_bindings WHERE project_id=? AND handle_digest=?", (project_id, handle_digest),
        ).fetchone()
        if binding is None:
            return "claim_not_open", None, None, None
        if (binding["binding_state"] != "pending" or binding["consumed_at_ms"] is not None
                or binding["client_version"] != "bridge-v1" or binding["expires_at_ms"] <= timestamp):
            return "claim_not_open", binding, None, None
        if _claim_exists(self._connection, project_id, handle_digest, binding["run_id"]):
            return "claim_already_consumed", binding, None, None
        started, until = self._claim_observation_window(binding)
        if not started <= timestamp < until:
            return 'claim_not_open', binding, None, None
        inputs = self._connection.execute(
            "SELECT * FROM launch_inputs WHERE project_id=? AND handle_digest=?", (project_id, handle_digest),
        ).fetchone()
        if inputs is None or inputs["run_id"] != binding["run_id"]:
            return "claim_context_missing", binding, None, None
        if inputs["runtime_digest"] != COLLECTOR_RUNTIME_DIGEST:
            return "claim_runtime_mismatch", binding, inputs, None
        observed = self._connection.execute(
            "SELECT identity_digest,observed_at_ms FROM launch_observations WHERE project_id=? AND handle_digest=?",
            (project_id, handle_digest),
        ).fetchone()
        if (observed is None or observed["identity_digest"] != launch.identity_digest
                or not binding["created_at_ms"] <= observed["observed_at_ms"] <= timestamp
                or timestamp - observed["observed_at_ms"] > BILLING_MAX_AGE_MS):
            return "claim_observation_missing", binding, inputs, None
        row = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? AND content_digest=? "
            "AND record_type='provider_identity' AND source='provider'", (project_id, launch.identity_digest),
        ).fetchone()
        if row is None:
            return "claim_observation_missing", binding, inputs, None
        identity = validate_learning_record(json.loads(bytes(row[0])))
        admission, digest = self._launch_identity_locked(project_id, launch.run_handle, identity)
        admitted = self.admitted_client(project_id, launch.run_handle)
        if (digest != launch.identity_digest or identity["observed_at_ms"] != observed["observed_at_ms"]
                or admission["provider"] != inputs["provider"]
                or identity["client_version"] is None or identity["client_version"] != admitted["client_version"]):
            return "claim_client_changed", binding, inputs, identity
        if not self.client_version_reviewed(inputs["provider"], identity["client_version"]):
            return "client_version_unreviewed", binding, inputs, identity
        return None, binding, inputs, identity

    def _claim_receipt_material(self, project_id, scope, request, parameters, handle, body):
        return {"project_id": project_id, "scope": scope, "request": request,
                "parameters": parameters, "handle": handle, **body}

    def _known_claim_receipt_locked(self, project_id, scope, request, parameters):
        row = self._connection.execute(
            "SELECT * FROM launch_receipts WHERE project_id=? AND scope_digest=? AND request_digest=?",
            (project_id, scope, request),
        ).fetchone()
        if row is None:
            return None
        if row["parameters_digest"] != parameters:
            raise ClaimError("claim_conflict")
        body = {name: row[name] for name in
                ("state", "run_id", "reason_code", "bridge_run_id", "deadline_at_ms", "recorded_at_ms")}
        expected = keyed_digest(self.state.digest_key(), canonical_json(self._claim_receipt_material(
            project_id, scope, request, parameters, row["handle_digest"], body,
        )))
        if expected != row["receipt_digest"]:
            raise ClaimError("claim_unavailable")
        return checked_claim_receipt({**body, "receipt_digest": expected, "known": True})

    def _store_claim_receipt_locked(self, project_id, scope, request, parameters, handle, body):
        digest = keyed_digest(self.state.digest_key(), canonical_json(self._claim_receipt_material(
            project_id, scope, request, parameters, handle, body,
        )))
        result = checked_claim_receipt({**body, "receipt_digest": digest, "known": False})
        self._connection.execute(
            "INSERT INTO launch_receipts VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (project_id, scope, request, parameters, handle, digest, body["run_id"], body["state"],
             body["reason_code"], body["bridge_run_id"], body["deadline_at_ms"], body["recorded_at_ms"]),
        )
        return result

    def _claim_preflight(
        self, project_id: str, *, runtime_digest: str, caller_scope: str,
        request_id: str, launch: LaunchClaimInput, work_limits=None,
        storage_required=False, storage_binding=None, storage_evidence=None, earlier_runtime=False,
    ):
        """Capture a request and current state; perform no signature work.

        `earlier_runtime`: only for fencing an earlier version's claim request (0.3.3, C3f), whose
        runtime is not this account's; nothing can be admitted for such a request.
        """
        if (not claim_matches(project_id, _CLAIM_PROJECT) or not claim_matches(runtime_digest, _CLAIM_DIGEST)
                or (runtime_digest != COLLECTOR_RUNTIME_DIGEST) != (earlier_runtime is True)
                or not claim_matches(caller_scope, _CLAIM_DIGEST)
                or not claim_matches(request_id, _CLAIM_REQUEST_ID) or type(launch) is not LaunchClaimInput):
            raise ClaimError("claim_invalid_request")
        launch = LaunchClaimInput(launch.run_handle, launch.identity_digest)
        from .claim_storage import MAX_STORAGE_EVIDENCE_BYTES
        from .result_contracts import ResultLeaseBinding

        if (type(storage_required) is not bool
                or (storage_binding is not None and type(storage_binding) is not ResultLeaseBinding)
                or (storage_evidence is not None and
                    (type(storage_evidence) is not bytes or not 0 < len(storage_evidence) <= MAX_STORAGE_EVIDENCE_BYTES))):
            raise ClaimError("claim_storage_invalid")
        if storage_binding is not None:
            storage_binding = ResultLeaseBinding(**storage_binding.as_data())
        key = self.state.digest_key()
        handle = keyed_digest(key, launch.run_handle)
        scope = keyed_digest(key, canonical_json({"project": project_id, "runtime": runtime_digest, "caller": caller_scope}))
        request = keyed_digest(key, request_id)
        parameters = keyed_digest(key, canonical_json(launch.payload()))
        context = _ClaimRequest(self._attestation_origin, project_id, runtime_digest, caller_scope,
                                request_id, launch, handle, scope, request, parameters,
                                storage_required=storage_required or storage_binding is not None or storage_evidence is not None,
                                storage_binding=storage_binding, storage_evidence=storage_evidence)
        with self._held():
            if self._connection.in_transaction:
                raise LedgerError("account write transaction is already active")
            self.state.harden_database_files()
            def read():
                known, timestamp = self._claim_commit_header(context)
                if known is not None:
                    return known, None, None, None
                check = self._claim_context_locked if work_limits is None else self._claim_scalar_context_locked
                early, binding, inputs, observed = check(project_id, handle, launch, timestamp)
                columns = None
                if early is None:
                    rows = ((binding, inputs, observed) if work_limits is not None
                            else self._claim_run_rows_locked(project_id, handle))
                    columns = self._claim_run_columns(*rows)
                return None, early, None if inputs is None else inputs["provider"], columns

            known, early_reason, provider, columns = (read() if work_limits is None else
                                                     self._connection.read_call(work_limits, read))
            if known is not None:
                return context, known, None, None
        return replace(context, run_context=columns), None, early_reason, provider

    def _check_active_capacity_locked(self, provider, account):
        """Bounded fresh counts inside the same transaction as consumption."""
        from .active_run_capacity import ActiveRunLimits

        policy = INSTALLED_ACTIVE_RUN_LIMITS
        if (type(policy) is not ActiveRunLimits or provider not in {"codex", "claude"}
                or (account is not None and not claim_matches(account, _CLAIM_DIGEST))):
            raise ClaimError("claim_unavailable")
        policy.__post_init__()
        # A claimed run whose project host crashed never settles. Its hard
        # deadline is enforced by the detached watchdog, so well past that
        # deadline on both the wall and the monotonic clock the child cannot
        # still be running: it stops counting against the limits, while its row
        # stays unreleased (explicitly unconfirmed) and a late terminal still
        # settles it normally.
        now = self._clock_ms()
        if type(now) is not int:
            raise ClaimError("claim_unavailable")
        crashed, crashed_parameters = crashed_claim("", now, self._capacity_clock_reference())
        active = self._connection.execute(
            "SELECT 1 FROM active_run_capacity INDEXED BY active_capacity_machine "
            f"WHERE released_at_ms IS NULL AND NOT {crashed} LIMIT ?",
            (*crashed_parameters, policy.machine),
        ).fetchall()
        probe_active = self._connection.execute(
            "SELECT 1 FROM account_billing_probe_requests INDEXED BY billing_probe_active_machine "
            "WHERE state='admitted' LIMIT ?", (policy.machine,),
        ).fetchall()
        if len(active)+len(probe_active) >= policy.machine:
            raise ClaimError("claim_busy")
        # A legacy unknown account consumes a slot for every candidate. A
        # provider-known but account-unknown reservation counts for that whole
        # provider. Machine counting first bounds this read to fewer than 64
        # active rows even after a large conservative historical backfill.
        account_active = self._connection.execute(
            "SELECT 1 FROM active_run_capacity INDEXED BY active_capacity_account "
            f"WHERE released_at_ms IS NULL AND NOT {crashed} "
            "AND (provider IS NULL OR (provider=? "
            "AND (? IS NULL OR account_fingerprint IS NULL OR account_fingerprint=?))) LIMIT ?",
            (*crashed_parameters, provider, account, account, policy.account),
        ).fetchall()
        account_probes = ([] if provider != 'claude' else self._connection.execute(
            "SELECT 1 FROM account_billing_probe_requests INDEXED BY billing_probe_active_account "
            "WHERE state='admitted' AND (? IS NULL OR account_fingerprint=?) LIMIT ?",
            (account, account, policy.account),
        ).fetchall())
        if len(account_active)+len(account_probes) >= policy.account:
            raise ClaimError("claim_busy")
        return policy

    def _capacity_clock_reference(self):
        try:
            reference = time.monotonic_ns()
        except Exception:
            raise ClaimError("claim_unavailable") from None
        if type(reference) is not int or not 0 <= reference <= (1 << 63) - 1:
            raise ClaimError("claim_unavailable")
        return reference

    def _capacity_clock_owner(self, key, reference, deadline, claimed_at, wall_deadline):
        return keyed_digest(self.state.digest_key(), canonical_json({
            "domain": "capacity-claim-clock-v1", "project_id": key.project_id, "handle_digest": key.handle_digest,
            "run_id": key.run_id, "bridge_run_id": key.bridge_run_id, "owner": self._capacity_execution_origin,
            "runtime_digest": COLLECTOR_RUNTIME_DIGEST, "clock_reference_ns": reference,
            "execution_deadline_ns": deadline, "claimed_at_ms": claimed_at, "deadline_at_ms": wall_deadline,
        }))

    def _reserve_active_capacity_locked(self, project, handle, run, bridge, provider, account, policy, timestamp, deadline, reference):
        if not self._connection.in_transaction:
            raise ClaimError("claim_unavailable")
        deadline_ns = reference + (deadline - timestamp) * 1_000_000
        now = self._capacity_clock_reference()
        if not reference <= now < deadline_ns <= (1 << 63) - 1:
            raise ClaimError("claim_unavailable")
        clock_owner = self._capacity_clock_owner(
            OwnedExecutionKey(project, handle, run, bridge), reference, deadline_ns, timestamp, deadline,
        )
        self._connection.execute(
            "INSERT INTO active_run_capacity(project_id,handle_digest,run_id,bridge_run_id,kind,provider,"
            "account_fingerprint,runtime_digest,policy_digest,claimed_at_ms,deadline_at_ms,"
            "clock_reference_ns,execution_deadline_ns,clock_owner_digest) VALUES(?,?,?,?,'claimed',?,?,?,?,?,?,?,?,?)",
            (project, handle, run, bridge, provider, account, COLLECTOR_RUNTIME_DIGEST, policy.digest, timestamp, deadline,
             reference, deadline_ns, clock_owner),
        )

    def _close_denied_attempt(self, project_id, *, runtime_digest, caller_scope, closure, storage_binding, storage_evidence):
        """Commit a permanent exact no-launch fence before freeing body storage.

        Native peer/actor/epoch proof and old-capability drain remain activation
        gates. Claimed, ambiguous, native-bound or foreign attempts cannot close.
        """
        from .claim_denial import CloseDeniedInput, decode_close_denied

        if type(closure) is not CloseDeniedInput:
            raise ClaimError('claim_denial_invalid')
        return self._settle_unlaunched(project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
                                       closure=decode_close_denied(closure.payload()), storage_binding=storage_binding,
                                       storage_evidence=storage_evidence, fence=False)

    def _fence_claim(self, project_id, *, runtime_digest, caller_scope, fence, storage_binding, storage_evidence):
        """Close the run's own claim request for good, unless this account already admitted it.

        In one account transaction: a receipt already held for the request is
        returned unchanged, and a claimed one closes nothing. Otherwise a denied
        receipt (`claim_not_open`: the run is closed to claims) is stored for
        the request, so every later claim
        with it gets that receipt back before any admission or capacity work
        (an admission still in flight finds it at its commit), and the run is
        settled exactly as a denied claim. A launch or capacity row for the run
        without a receipt for this request is contradictory and refused, and a
        refusal anywhere commits nothing.
        """
        from .claim_denial import FenceClaimInput, decode_fence_claim

        if type(fence) is not FenceClaimInput:
            raise ClaimError('claim_denial_invalid')
        return self._settle_unlaunched(project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
                                       closure=decode_fence_claim(fence.payload()), storage_binding=storage_binding,
                                       storage_evidence=storage_evidence, fence=True)

    def _settle_unlaunched(self, project_id, *, runtime_digest, caller_scope, closure, storage_binding, storage_evidence,
                           fence):
        from .account_api import ACCOUNT_PROTOCOL_VERSION, AccountRequest, account_request_digest
        from .claim_denial import DENIAL_LEGACY_READ_LIMITS, binding_digest, denial_closure, denial_record_id
        from .claim_storage import capture_storage_evidence, verify_pending_storage_evidence
        from .sql_read_budget import SQLReadError, SQLReadLimits

        expected, raw = capture_storage_evidence(storage_binding, storage_evidence)
        if expected is None:
            raise ClaimError('claim_storage_required')
        # The sweep of a lease an earlier service left armed (0.3.3, C3) names no identity. Such a
        # lease is usually an earlier version's, under that version's runtime (C3f): the request
        # comes under this account's runtime, and the claim request it closes is checked whole
        # under the lease's own runtime, so the denial is stored for exactly that request.
        sweep = closure.identity_digest is None
        original_runtime = expected.runtime_digest if sweep and runtime_digest == COLLECTOR_RUNTIME_DIGEST else runtime_digest
        if closure.identity_digest is None:
            # The identity this run was observed with before launch, checked below against the
            # whole claim request.
            if not fence:
                raise ClaimError('claim_denial_invalid')
            with self._held():
                observed = self._connection.execute(
                    'SELECT identity_digest FROM launch_observations WHERE project_id=? AND handle_digest=?',
                    (project_id, keyed_digest(self.state.digest_key(), closure.run_handle))).fetchone()
            if observed is None:
                raise ClaimError('claim_denial_unavailable')
            closure = replace(closure, identity_digest=observed[0])
        launch = LaunchClaimInput(closure.run_handle, closure.identity_digest)
        original = AccountRequest(ACCOUNT_PROTOCOL_VERSION, 'account.claim_launch', closure.claim_request_id,
                                  project_id, original_runtime, launch.payload())
        if (expected.project_id != project_id or expected.runtime_digest != original_runtime
                or expected.run_handle != closure.run_handle or expected.claim_request_id != closure.claim_request_id
                or expected.claim_request_digest != account_request_digest(original)):
            raise ClaimError('claim_denial_invalid')
        context, known, _, _ = self._claim_preflight(project_id, runtime_digest=original_runtime, caller_scope=caller_scope,
                                                    request_id=closure.claim_request_id, launch=launch, storage_binding=expected,
                                                    earlier_runtime=original_runtime != COLLECTOR_RUNTIME_DIGEST)
        if fence and known is not None and known['state'] == 'claimed':
            return {'receipt': known, 'closure': None}  # Admitted: nothing here is closed.
        if not fence and (known is None or known['state'] != 'denied'
                          or known['receipt_digest'] != closure.denial_receipt_digest):
            raise ClaimError('claim_denial_unavailable')
        if known is not None and known['run_id'] != expected.run_id:
            raise ClaimError('claim_denial_unavailable')
        key = self.state.digest_key()
        identity = denial_record_id(key, project_id, closure.lease_digest)
        with self._held():
            prior_hint = self._connection.execute('SELECT 1 FROM records WHERE project_id=? AND record_id=?',
                                                  (project_id, identity)).fetchone() is not None
        lease = None if prior_hint else verify_pending_storage_evidence(key, expected, raw)
        with self._account_transaction():
            current = self._known_claim_receipt_locked(project_id, context.scope, context.request, context.parameters)
            if fence:
                if current is not None and current['state'] == 'claimed':
                    return {'receipt': current, 'closure': None}
                if current is None:
                    self._fence_claim_request_locked(project_id, context, expected)
                    current = self._known_claim_receipt_locked(project_id, context.scope, context.request,
                                                               context.parameters)
                known = current
            if current != known or known['state'] != 'denied' or known['run_id'] != expected.run_id:
                raise ClaimError('claim_denial_unavailable')
            facts = {'run_id': expected.run_id, 'handle_digest': context.handle, 'scope_digest': context.scope,
                     'request_digest': context.request, 'parameters_digest': context.parameters,
                     'binding_digest': binding_digest(key, expected), 'lease_digest': closure.lease_digest, 'denial': known}
            binding = self._connection.execute(
                'SELECT h.*,l.provider FROM host_run_bindings h '
                'LEFT JOIN launch_inputs l ON l.project_id=h.project_id AND l.handle_digest=h.handle_digest '
                'WHERE h.project_id=? AND h.handle_digest=?', (project_id, context.handle),
            ).fetchone()
            orchestration_digest = self._claim_original_orchestration_digest(expected, 'claim_denial_unavailable')
            # Any durable consumed/unknown launch or capacity is contradictory.
            if (_claim_exists(self._connection, project_id, context.handle, expected.run_id)
                    or _capacity_exists(self._connection, project_id, context.handle, expected.run_id)):
                raise ClaimError('claim_denial_unavailable')
            def legacy_intent():
                return self._connection.execute(
                    "SELECT 1 FROM records WHERE project_id=? AND record_type IN ('dispatch_intent','dispatch_result') "
                    "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=? LIMIT 1", (project_id, expected.run_id)).fetchone()
            limited = False
            try:
                legacy = self._connection.transaction_read_call(SQLReadLimits(*DENIAL_LEGACY_READ_LIMITS), legacy_intent)
            except SQLReadError:
                limited = True
            if limited:
                raise ClaimError('claim_busy')
            if legacy is not None:
                raise ClaimError('claim_denial_unavailable')
            prior = self._connection.execute('SELECT record_type,source,content_digest,length(content) AS content_size '
                                             'FROM records WHERE project_id=? AND record_id=?', (project_id, identity)).fetchone()
            if prior is not None:
                if (prior['record_type'] != 'claim_denial_settlement' or prior['source'] != 'lifecycle'
                        or type(prior['content_size']) is not int or not 0 < prior['content_size'] <= 16_384):
                    raise ClaimError('claim_denial_conflict')
                invalid = False
                try:
                    encoded = bytes(self._connection.execute('SELECT content FROM records WHERE project_id=? AND record_id=?',
                                                             (project_id, identity)).fetchone()[0])
                    record = validate_learning_record(parse_bounded_json(encoded, max_bytes=16_384))
                    invalid = (prior['record_type'] != 'claim_denial_settlement' or prior['source'] != 'lifecycle'
                               or record['record_id'] != identity or encoded != canonical_json(record)
                               or prior['content_digest'] != content_digest(record)
                               or any(record[n] != value for n, value in facts.items())
                               or (binding is not None and (binding['run_id'] != expected.run_id
                                   or binding['binding_state'] != 'abandoned'
                                   or binding['abandoned_reason'] not in {'claim_denied', 'withdrawn'}
                                   or binding['assignment_digest'] != record['assignment_digest']
                                   or binding['native_assignment_id'] is not None or binding['consumed_at_ms'] is not None)))
                except Exception:
                    invalid = True
                if invalid:
                    raise ClaimError('claim_denial_conflict')
                result = denial_closure(key, expected, record, known=True)
                return {'receipt': known, 'closure': result} if fence else result
            if lease is None:
                raise ClaimError('claim_denial_unavailable')  # Never reconstruct a vanished known settlement.
            now = self._clock_ms()
            if (binding is None or binding['run_id'] != expected.run_id or binding['client_version'] != 'bridge-v1'
                    or binding['provider'] not in {'codex', 'claude'}
                    # B3: a claim refused because its open was withdrawn is closed like any refused claim (the
                    # binding is already ended; the update below leaves it as it is).
                    or (binding['binding_state'], binding['abandoned_reason']) not in {('pending', None),
                                                                                       ('abandoned', 'withdrawn')}
                    or binding['consumed_at_ms'] is not None or binding['native_assignment_id'] is not None
                    or binding['usage_complete'] is not None
                    or binding['assignment_digest'] != lease.assignment_digest or lease.lease_digest != closure.lease_digest
                    or orchestration_digest != keyed_digest(key, expected.orchestration_handle)
                    or not lease.created_at_ms <= known['recorded_at_ms']
                    or type(now) is not int or not known['recorded_at_ms'] <= now <= MAX_CLAIM_INTEGER):
                raise ClaimError('claim_denial_unavailable')
            record = validate_learning_record({**facts, 'schema_version': 1, 'record_type': 'claim_denial_settlement',
                                               'record_id': identity, 'assignment_digest': lease.assignment_digest,
                                               'observed_at_ms': now})
            self._append_checked_locked(project_id, record, producer='lifecycle', timestamp=now)
            self._connection.execute("UPDATE host_run_bindings SET binding_state='abandoned',abandoned_reason='claim_denied' "
                                     "WHERE project_id=? AND handle_digest=? AND binding_state='pending'",
                                     (project_id, context.handle))
        result = denial_closure(key, expected, record, known=False)
        return {'receipt': known, 'closure': result} if fence else result

    def _fence_claim_request_locked(self, project_id, context, expected):
        """Inside the fence's transaction: a denied receipt for a request this account never answered."""
        binding = self._connection.execute('SELECT run_id FROM host_run_bindings WHERE project_id=? AND handle_digest=?',
                                           (project_id, context.handle)).fetchone()
        if (binding is None or binding['run_id'] != expected.run_id
                or _claim_exists(self._connection, project_id, context.handle, expected.run_id)
                or _capacity_exists(self._connection, project_id, context.handle, expected.run_id)):
            raise ClaimError('claim_denial_unavailable')
        now = self._clock_ms()
        if type(now) is not int or not 0 <= now <= MAX_CLAIM_INTEGER:
            raise ClaimError('claim_unavailable')
        self._store_claim_receipt_locked(project_id, context.scope, context.request, context.parameters, context.handle, {
            'state': 'denied', 'run_id': expected.run_id, 'reason_code': 'claim_not_open', 'bridge_run_id': None,
            'deadline_at_ms': None, 'recorded_at_ms': now,
        })

    def _attest_run_provenance(self, project_id, *, runtime_digest, caller_scope, request,
                              storage_binding, storage_evidence, work_limits):
        from .account_run_provenance import attest_run_provenance
        return attest_run_provenance(self, project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
                                     request=request, storage_binding=storage_binding,
                                     storage_evidence=storage_evidence, work_limits=work_limits)

    def _attest_open_provenance(self, project_id, *, runtime_digest, caller_scope, request,
                               storage_binding, storage_evidence, work_limits):
        from .account_host_open import attest_open_provenance
        return attest_open_provenance(self, project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
                                      request=request, storage_binding=storage_binding,
                                      storage_evidence=storage_evidence, work_limits=work_limits)

    def _register_project_execution(self, project_id, *, runtime_digest, caller_scope, registration,
                                    storage_binding, storage_evidence):
        """Durable one-use registration for an independently enrolled project.

        This creates no account-local process ticket. Native service identity,
        supervisor epoch and account/project transport are separate activation
        gates; JSON/source labels and these data do not establish them.
        """
        from .account_api import ACCOUNT_PROTOCOL_VERSION, AccountRequest, account_request_digest
        from .claim_storage import capture_storage_evidence, verify_bound_storage_evidence
        from .execution_grant import ExecutionRegistrationInput, sign_execution_grant
        from .history_contracts import AttemptBinding
        from .result_contracts import LEASE_SCOPE_FIELDS

        if type(registration) is not ExecutionRegistrationInput:
            raise ClaimError("claim_execution_invalid")
        registration = ExecutionRegistrationInput(**registration.payload())
        expected, evidence = capture_storage_evidence(storage_binding, storage_evidence)
        key = self.state.digest_key()
        lease = verify_bound_storage_evidence(key, expected, evidence)
        if (expected.project_id != project_id or expected.runtime_digest != runtime_digest
                or expected.run_handle != registration.run_handle or expected.claim_request_id != registration.claim_request_id
                or lease.claim_id != registration.bridge_run_id or lease.claim_digest != registration.claim_digest):
            raise ClaimError("claim_execution_invalid")
        launch = LaunchClaimInput(registration.run_handle, registration.identity_digest)
        original = AccountRequest(ACCOUNT_PROTOCOL_VERSION, "account.claim_launch", registration.claim_request_id,
                                  project_id, runtime_digest, launch.payload())
        if expected.claim_request_digest != account_request_digest(original):
            raise ClaimError("claim_execution_invalid")
        context, known, _, _ = self._claim_preflight(project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
                                                    request_id=registration.claim_request_id, launch=launch, storage_binding=expected)
        if (known is None or known["state"] != "claimed" or known["bridge_run_id"] != registration.bridge_run_id
                or known["receipt_digest"] != registration.claim_digest):
            raise ClaimError("claim_execution_unavailable")
        binding = AttemptBinding(**{name: getattr(expected, name) for name in LEASE_SCOPE_FIELDS},
                                 claim_id=registration.bridge_run_id, claim_digest=registration.claim_digest)
        claim_binding = keyed_digest(key, canonical_json({
            "domain": "project-result-claim-binding-v1", "lease_digest": lease.lease_digest,
            "binding": binding.as_data(), "hard_deadline_at_ms": lease.hard_deadline_at_ms,
        }))
        if not secrets.compare_digest(claim_binding, lease.claim_binding_digest):
            raise ClaimError("claim_execution_invalid")
        with self._account_transaction():
            current = self._known_claim_receipt_locked(project_id, context.scope, context.request, context.parameters)
            if current is None or current["receipt_digest"] != known["receipt_digest"]:
                raise ClaimError("claim_execution_unavailable")
            row = self._connection.execute(
                "SELECT a.*,h.assignment_digest,h.task_digest,h.route_digest,h.configuration_digest,"
                "h.native_assignment_id,h.binding_state,h.consumed_at_ms,h.client_version,"
                "e.owner_digest AS registered_digest "
                "FROM active_run_capacity a JOIN host_run_bindings h "
                "ON h.project_id=a.project_id AND h.handle_digest=a.handle_digest AND h.run_id=a.run_id "
                "LEFT JOIN capacity_executions e ON e.project_id=a.project_id AND e.handle_digest=a.handle_digest "
                "WHERE a.project_id=? AND a.handle_digest=? AND a.bridge_run_id=?",
                (project_id, context.handle, registration.bridge_run_id),
            ).fetchone()
            orchestration_digest = self._claim_original_orchestration_digest(expected, 'claim_execution_unavailable')
            if (row is None or row["kind"] != "claimed" or row["runtime_digest"] != runtime_digest
                    or row["provider"] not in {"codex", "claude"} or row["run_id"] != expected.run_id
                    or row["assignment_digest"] != lease.assignment_digest
                    or orchestration_digest != keyed_digest(key, expected.orchestration_handle)
                    or row["deadline_at_ms"] != lease.hard_deadline_at_ms):
                raise ClaimError("claim_execution_invalid")
            grant = sign_execution_grant(
                key, binding=binding, handle_digest=context.handle, assignment_digest=row["assignment_digest"],
                task_digest=row["task_digest"], route_digest=row["route_digest"], configuration_digest=row["configuration_digest"],
                lease_digest=lease.lease_digest, clock_owner_digest=row["clock_owner_digest"],
                clock_reference_ns=row["clock_reference_ns"], deadline_ns=row["execution_deadline_ns"],
                claimed_at_ms=row["claimed_at_ms"], deadline_at_ms=row["deadline_at_ms"],
            )
            if row["registered_digest"] is not None:
                if not secrets.compare_digest(row["registered_digest"], grant.registration_digest):
                    raise ClaimError("claim_execution_conflict")
                registered = self._connection.execute('SELECT cleanup_reservation_digest FROM capacity_executions '
                    'WHERE project_id=? AND handle_digest=?', (project_id, context.handle)).fetchone()
                if registered is not None and registered['cleanup_reservation_digest'] is not None:
                    from .account_cleanup import original_journal
                    original_journal(self, expected, grant)
                return {"grant": grant.as_data(), "known": True}
            clock = self._capacity_clock_reference()
            now = self._clock_ms()
            owned_key = OwnedExecutionKey(project_id, context.handle, expected.run_id, registration.bridge_run_id)
            native_id = external_id(key, "asg", registration.bridge_run_id)
            if (row["released_at_ms"] is not None or row["binding_state"] != "pending"
                    or row["consumed_at_ms"] is not None or row["client_version"] != "bridge-v1"
                    or row["native_assignment_id"] not in {None, native_id}
                    or type(now) is not int or not row["claimed_at_ms"] <= now < row["deadline_at_ms"]
                    or not row["clock_reference_ns"] <= clock < row["execution_deadline_ns"]
                    or not secrets.compare_digest(row["clock_owner_digest"], self._capacity_clock_owner(
                        owned_key, row["clock_reference_ns"], row["execution_deadline_ns"],
                        row["claimed_at_ms"], row["deadline_at_ms"]))):
                raise ClaimError("claim_execution_unavailable")
            from .account_cleanup import reserve_cleanup
            cleanup = reserve_cleanup(self, expected, grant) if lease.cleanup_reservation_digest is not None else None
            self._connection.execute("INSERT INTO capacity_executions VALUES(?,?,?,?,?,?)",
                                     (project_id, context.handle, expected.run_id, registration.bridge_run_id,
                                      grant.registration_digest, cleanup))
            self._connection.execute("UPDATE host_run_bindings SET native_assignment_id=? WHERE project_id=? AND handle_digest=?",
                                     (native_id, project_id, context.handle))
        return {"grant": grant.as_data(), "known": False}

    def _accept_project_terminal(self, project_id, *, runtime_digest, caller_scope, submission,
                                 storage_binding, storage_evidence, terminal_evidence, require_known=False):
        """Accept exact safe terminal metadata; never infer cleanup or release.

        Native project enrollment/current authority and protected evidence
        publication remain activation gates. Account SQL records the original
        registered claim's completion digest without opening a project store,
        receiving a result body or reconstructing process custody.
        """
        from .account_api import ACCOUNT_PROTOCOL_VERSION, AccountRequest, account_request_digest
        from .claim_storage import capture_storage_evidence, verify_bound_storage_evidence
        from .terminal_delivery import TerminalSubmissionInput, decode_terminal_submission, terminal_receipt, verify_terminal_evidence

        if type(submission) is not TerminalSubmissionInput:
            raise ClaimError('claim_terminal_invalid')
        submission = decode_terminal_submission(submission.payload())
        expected, bound_raw = capture_storage_evidence(storage_binding, storage_evidence)
        key = self.state.digest_key()
        lease = verify_bound_storage_evidence(key, expected, bound_raw)
        evidence = verify_terminal_evidence(key, expected, terminal_evidence)
        grant, delivery = evidence.grant, evidence.delivery
        terminal_record = parse_bounded_json(evidence.record)
        observed = terminal_record['observed_at_ms']
        registration = submission.registration
        launch = LaunchClaimInput(registration.run_handle, registration.identity_digest)
        original = AccountRequest(ACCOUNT_PROTOCOL_VERSION, 'account.claim_launch', registration.claim_request_id,
                                  project_id, runtime_digest, launch.payload())
        if (expected.project_id != project_id or expected.runtime_digest != runtime_digest
                or expected.claim_request_id != registration.claim_request_id
                or expected.claim_request_digest != account_request_digest(original)
                or grant.binding.run_handle != registration.run_handle or grant.binding.claim_id != registration.bridge_run_id
                or grant.binding.claim_digest != registration.claim_digest
                or lease.claim_id != grant.binding.claim_id or lease.claim_digest != grant.binding.claim_digest
                or lease.lease_digest != grant.lease_digest or lease.assignment_digest != grant.assignment_digest
                or lease.hard_deadline_at_ms != grant.deadline_at_ms
                or grant.registration_digest != submission.registration_digest
                or delivery.record_id != submission.terminal_record_id
                or delivery.record_content_digest != submission.terminal_content_digest
                or delivery.result_digest != submission.result_digest):
            raise ClaimError('claim_terminal_invalid')
        claim_binding = keyed_digest(key, canonical_json({
            'domain': 'project-result-claim-binding-v1', 'lease_digest': lease.lease_digest,
            'binding': grant.binding.as_data(), 'hard_deadline_at_ms': grant.deadline_at_ms,
        }))
        if not secrets.compare_digest(claim_binding, lease.claim_binding_digest):
            raise ClaimError('claim_terminal_invalid')
        context, known, _, _ = self._claim_preflight(project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
                                                    request_id=registration.claim_request_id, launch=launch, storage_binding=expected)
        if (known is None or known['state'] != 'claimed' or known['bridge_run_id'] != registration.bridge_run_id
                or known['receipt_digest'] != registration.claim_digest):
            raise ClaimError('claim_terminal_unavailable')
        with self._account_transaction():
            current = self._known_claim_receipt_locked(project_id, context.scope, context.request, context.parameters)
            if current is None or current['receipt_digest'] != registration.claim_digest:
                raise ClaimError('claim_terminal_unavailable')
            row = self._connection.execute(
                'SELECT a.*,h.assignment_digest,h.task_digest,h.route_digest,h.configuration_digest,'
                'h.native_assignment_id,h.binding_state,h.abandoned_reason,h.consumed_at_ms,h.client_version,'
                'e.owner_digest FROM active_run_capacity a '
                'JOIN host_run_bindings h ON h.project_id=a.project_id AND h.handle_digest=a.handle_digest AND h.run_id=a.run_id '
                'JOIN capacity_executions e ON e.project_id=a.project_id AND e.handle_digest=a.handle_digest '
                'AND e.run_id=a.run_id AND e.bridge_run_id=a.bridge_run_id '
                'WHERE a.project_id=? AND a.handle_digest=? AND a.bridge_run_id=?',
                (project_id, context.handle, registration.bridge_run_id),
            ).fetchone()
            orchestration_digest = self._claim_original_orchestration_digest(expected, 'claim_terminal_unavailable')
            if (row is None or row['kind'] != 'claimed' or row['provider'] not in {'codex', 'claude'}
                    # Only the Claude client reports diagnostics; the record validator closed their values.
                    or (terminal_record['client_diagnostics'] is not None and row['provider'] != 'claude')
                    or row['runtime_digest'] != runtime_digest or row['run_id'] != grant.binding.run_id
                    or row['client_version'] != 'bridge-v1' or row['owner_digest'] != grant.registration_digest
                    or orchestration_digest != keyed_digest(key, grant.binding.orchestration_handle)
                    or row['native_assignment_id'] != external_id(key, 'asg', registration.bridge_run_id)
                    or row['execution_deadline_ns'] != grant.deadline_ns
                    or any(row[n] != getattr(grant, n) for n in (
                        'handle_digest', 'assignment_digest', 'task_digest', 'route_digest', 'configuration_digest',
                        'clock_owner_digest', 'clock_reference_ns', 'claimed_at_ms', 'deadline_at_ms'))):
                raise ClaimError('claim_terminal_unavailable')
            prior = self._connection.execute('SELECT * FROM capacity_completions WHERE project_id=? AND handle_digest=?',
                                             (project_id, context.handle)).fetchone()
            if prior is not None:
                if (prior['run_id'] != grant.binding.run_id or prior['bridge_run_id'] != grant.binding.claim_id
                        or prior['terminal_record_id'] != delivery.record_id
                        or prior['terminal_content_digest'] != delivery.record_content_digest):
                    raise ClaimError('claim_terminal_conflict')
                from .account_cleanup import record_terminal
                record_terminal(self, expected, grant, delivery, known=True)
                # A terminal ACK must not hide corrupt release metadata (a completion's own time when a written
                # decision released the slot: round 1 F9).
                completed = self._capacity_completion_locked(OwnedExecutionKey(
                    project_id, context.handle, grant.binding.run_id, grant.binding.claim_id))
                at = (completed['completion_released_at_ms']
                      if self._slot_decision_locked(project_id, context.handle, completed['release_digest'])
                      else completed['released_at_ms'])
                if at is not None and not secrets.compare_digest(
                        self._capacity_completion_digest(completed, at), completed['receipt_digest']):
                    raise ClaimError('claim_terminal_unavailable')
                return terminal_receipt(key, grant, delivery, known=True)
            if require_known:
                raise ClaimError('claim_terminal_unavailable')
            now = self._clock_ms()
            # O0b RS-A round 1 F9: a terminal after a written decision is the run's own fact and is kept; the
            # decision stays as written. A lost decision's binding was settled service_lost.
            from .active_run_capacity import LOST_RUN_REASON
            decided = self._slot_decision_locked(project_id, context.handle, row['release_digest'])
            open_binding = row['binding_state'] == 'pending' or (
                decided == 'lost' and row['binding_state'] == 'abandoned' and row['abandoned_reason'] == LOST_RUN_REASON)
            if ((row['released_at_ms'] is not None and decided is None) or not open_binding
                    or row['consumed_at_ms'] is not None
                    or type(now) is not int or not grant.claimed_at_ms <= observed <= now <= MAX_CLAIM_INTEGER):
                raise ClaimError('claim_terminal_unavailable')
            from .account_cleanup import record_terminal
            record_terminal(self, expected, grant, delivery, known=False, recorded_at_ms=now)
            self._connection.execute(
                'INSERT INTO capacity_completions(project_id,handle_digest,run_id,bridge_run_id,'
                'terminal_record_id,terminal_content_digest) VALUES(?,?,?,?,?,?)',
                (project_id, context.handle, grant.binding.run_id, grant.binding.claim_id,
                 delivery.record_id, delivery.record_content_digest),
            )
        return terminal_receipt(key, grant, delivery, known=False)

    def _new_owned_execution(self, project_id, run_handle, bridge_run_id):
        """Internal fixed-bridge registration, not a caller-selected PID API."""
        handle = keyed_digest(self.state.digest_key(), run_handle)
        with self._account_transaction():
            row = self._connection.execute(
                "SELECT a.run_id,a.bridge_run_id,a.kind,a.runtime_digest,a.released_at_ms,a.claimed_at_ms,a.deadline_at_ms,"
                "a.clock_reference_ns,a.execution_deadline_ns,a.clock_owner_digest,"
                "EXISTS(SELECT 1 FROM capacity_executions e WHERE e.project_id=a.project_id "
                "AND e.handle_digest=a.handle_digest) AS execution_registered "
                "FROM active_run_capacity a "
                "JOIN host_run_bindings h ON h.project_id=a.project_id AND h.handle_digest=a.handle_digest AND h.run_id=a.run_id "
                "WHERE a.project_id=? AND a.handle_digest=? AND h.binding_state='pending' AND h.consumed_at_ms IS NULL "
                "AND h.client_version='bridge-v1' AND h.native_assignment_id=? "
                "AND NOT EXISTS(SELECT 1 FROM capacity_completions c "
                "WHERE c.project_id=a.project_id AND c.handle_digest=a.handle_digest)",
                (project_id, handle, external_id(self.state.digest_key(), "asg", bridge_run_id)),
            ).fetchone()
            if (row is None or row["kind"] != "claimed" or row["released_at_ms"] is not None
                    or row["bridge_run_id"] != bridge_run_id or row["runtime_digest"] != COLLECTOR_RUNTIME_DIGEST):
                raise LedgerError("owned execution is unavailable")
            if row["execution_registered"]:
                raise LedgerError("owned execution was already registered")
            key = OwnedExecutionKey(project_id, handle, row["run_id"], bridge_run_id)
            monotonic_reference = time.monotonic_ns()
            now = self._clock_ms()
            if (type(now) is not int or not row["claimed_at_ms"] <= now < row["deadline_at_ms"]
                    or type(monotonic_reference) is not int
                    or not row["clock_reference_ns"] <= monotonic_reference < row["execution_deadline_ns"]
                    or not secrets.compare_digest(row["clock_owner_digest"], self._capacity_clock_owner(
                        key, row["clock_reference_ns"], row["execution_deadline_ns"],
                        row["claimed_at_ms"], row["deadline_at_ms"]))):
                raise LedgerError("owned execution deadline is unavailable")
            # Only the claiming owner retains this clock-domain association.
            # A later wall sample or reopened owner cannot recreate its budget.
            deadline_ns = row["execution_deadline_ns"]
            owner = self._capacity_execution_owner(key)
            try:
                self._connection.execute("INSERT INTO capacity_executions(project_id,handle_digest,run_id,bridge_run_id,owner_digest) VALUES(?,?,?,?,?)",
                                         (project_id, handle, row["run_id"], bridge_run_id, owner))
            except sqlite3.IntegrityError:
                raise LedgerError("owned execution was already registered") from None
        # Issue usable process custody only after the registration is durable.
        # A rolled-back commit must not burn an unreturned registry key/slot.
        try:
            return self._capacity_executions.issue(key, deadline_ns=deadline_ns, run_handle=run_handle)
        except ExecutionCustodyError:
            raise LedgerError("owned execution deadline is unavailable") from None

    def _capacity_execution_owner(self, key):
        return keyed_digest(self.state.digest_key(), canonical_json({
            "domain": "capacity-execution-owner-v1", "project_id": key.project_id, "handle_digest": key.handle_digest,
            "run_id": key.run_id, "bridge_run_id": key.bridge_run_id, "owner": self._capacity_execution_origin,
        }))

    def _slot_decision_locked(self, project_id, handle_digest, release_digest):
        """O0b RS-A: the written `lost` or `crashed` decision that released this slot, if that is how it was
        released (its register receipt equals the capacity row's release digest), else None."""
        if release_digest is None:
            return None
        row = self._connection.execute(
            "SELECT release_kind FROM run_holds WHERE project_id=? AND kind='run_slot' AND identity=? "
            "AND release_kind IN ('lost','crashed','unsent','process_gone','owner_confirmed') AND receipt=?", (project_id, handle_digest, release_digest)).fetchone()
        return None if row is None else row[0]

    def _capacity_completion_locked(self, key):
        row = self._connection.execute(
            "SELECT a.*,c.terminal_record_id,c.terminal_content_digest,c.released_at_ms AS completion_released_at_ms,"
            "c.receipt_digest,e.owner_digest AS execution_owner_digest,e.cleanup_reservation_digest "
            "FROM active_run_capacity a LEFT JOIN capacity_completions c "
            "ON c.project_id=a.project_id AND c.handle_digest=a.handle_digest "
            "AND c.run_id=a.run_id AND c.bridge_run_id=a.bridge_run_id "
            "LEFT JOIN capacity_executions e ON e.project_id=a.project_id AND e.handle_digest=a.handle_digest "
            "AND e.run_id=a.run_id AND e.bridge_run_id=a.bridge_run_id "
            "WHERE a.project_id=? AND a.handle_digest=? AND a.run_id=? AND a.bridge_run_id=?",
            (key.project_id, key.handle_digest, key.run_id, key.bridge_run_id),
        ).fetchone()
        if row is None or row["kind"] != "claimed":
            raise LedgerError("capacity completion is unavailable")
        # O0b RS-A: a slot released by a written lost or crashed decision keeps its completion separately, and
        # may have none yet (round 1 F10); any other slot needs its completion row.
        decided = self._slot_decision_locked(key.project_id, key.handle_digest, row["release_digest"])
        if decided is None and (row["terminal_record_id"] is None
                                or row["released_at_ms"] != row["completion_released_at_ms"]
                                or row["release_digest"] != row["receipt_digest"]):
            raise LedgerError("capacity completion is unavailable")
        return row

    def _capacity_completion_digest(self, row, timestamp):
        if row['cleanup_reservation_digest'] is not None:
            from .account_cleanup import checked_completion_digest
            try:
                return checked_completion_digest(self, row, timestamp)
            except ClaimError:
                raise LedgerError('capacity completion is unavailable') from None
        material = {"domain": "active-capacity-release-v1", **{name: row[name] for name in (
            "project_id", "handle_digest", "run_id", "bridge_run_id", "provider", "account_fingerprint",
            "runtime_digest", "policy_digest", "claimed_at_ms", "deadline_at_ms", "terminal_record_id", "terminal_content_digest",
            "clock_reference_ns", "execution_deadline_ns", "clock_owner_digest", "execution_owner_digest",
        )}, "released_at_ms": timestamp}
        return keyed_digest(self.state.digest_key(), canonical_json(material))

    def _release_active_capacity(self, ticket):
        key = self._capacity_executions.key(ticket)
        with self._account_transaction():
            row = self._capacity_completion_locked(key)
            decided = self._slot_decision_locked(key.project_id, key.handle_digest, row["release_digest"])
            if row["terminal_record_id"] is None:  # a completion needs its stored terminal first
                raise LedgerError("capacity completion is unavailable")
            # O0b RS-A-2: after a written lost or crashed decision the slot is already free; a late release
            # stores only the completion (or answers the one stored), and the decision stays as written.
            known = (row["completion_released_at_ms"] if decided else row["released_at_ms"]) is not None
            if known and decided:
                timestamp = row["completion_released_at_ms"]
                digest = self._capacity_completion_digest(row, timestamp)
                if not secrets.compare_digest(digest, row["receipt_digest"]):
                    raise LedgerError("capacity completion is unavailable")
            elif known:
                timestamp = row["released_at_ms"]
                digest = self._capacity_completion_digest(row, timestamp)
                if not secrets.compare_digest(digest, row["receipt_digest"]):
                    raise LedgerError("capacity completion is unavailable")
            else:
                # Actual retained fixed-runner custody must establish cleanup.
                # A constructed ticket or a durable terminal row is insufficient.
                self._capacity_executions.key(ticket, cleaned=True)
                registered = self._connection.execute(
                    "SELECT owner_digest FROM capacity_executions WHERE project_id=? AND handle_digest=? "
                    "AND run_id=? AND bridge_run_id=?", (key.project_id, key.handle_digest, key.run_id, key.bridge_run_id),
                ).fetchone()
                if registered is None or not secrets.compare_digest(registered[0], self._capacity_execution_owner(key)):
                    raise LedgerError("owned execution is unavailable")
                timestamp = self._clock_ms()
                if type(timestamp) is not int or not row["claimed_at_ms"] <= timestamp <= MAX_CLAIM_INTEGER:
                    raise LedgerError("capacity completion is unavailable")
                digest = self._capacity_completion_digest(row, timestamp)
                self._connection.execute(
                    "UPDATE capacity_completions SET released_at_ms=?,receipt_digest=? "
                    "WHERE project_id=? AND handle_digest=?", (timestamp, digest, key.project_id, key.handle_digest),
                )
                if not decided:
                    self._connection.execute(
                        "UPDATE active_run_capacity SET released_at_ms=?,release_digest=? "
                        "WHERE project_id=? AND handle_digest=?", (timestamp, digest, key.project_id, key.handle_digest),
                    )
        # Commit precedes registry acknowledgement. A lost acknowledgement
        # retrieves the exact existing receipt, including after clock rollback.
        self._capacity_executions.acknowledge_release(ticket)
        return {"state": "released", "receipt_digest": digest, "released_at_ms": timestamp, "known": known}

    def _finish_owned_execution(self, ticket):
        try:
            return self._release_active_capacity(ticket)
        except (ExecutionCustodyError, LedgerError, StateError, sqlite3.Error):
            # A completed result remains its own fact. Missing cleanup or failed
            # completion delivery retains capacity and never replays model work.
            return {"state": "held", "receipt_digest": None, "released_at_ms": None, "known": False}

    def _known_capacity_release(self, project_id, run_handle, bridge_run_id):
        """Owner metadata reconciliation; never launches or releases anything."""
        handle = keyed_digest(self.state.digest_key(), run_handle)
        with self._held():
            cap = self._connection.execute(
                "SELECT run_id,released_at_ms FROM active_run_capacity "
                "WHERE project_id=? AND handle_digest=? AND bridge_run_id=?", (project_id, handle, bridge_run_id),
            ).fetchone()
            if cap is None or cap["released_at_ms"] is None:
                return None
            row = self._capacity_completion_locked(OwnedExecutionKey(project_id, handle, cap["run_id"], bridge_run_id))
            if self._slot_decision_locked(project_id, handle, row["release_digest"]) is not None:
                # O0b RS-A: released by a written decision; its completion, if any, is answered as stored.
                if row["completion_released_at_ms"] is None:
                    return {"state": "released", "receipt_digest": row["release_digest"],
                            "released_at_ms": row["released_at_ms"], "known": True}
                timestamp = row["completion_released_at_ms"]
            else:
                timestamp = row["released_at_ms"]
            digest = self._capacity_completion_digest(row, timestamp)
            if not secrets.compare_digest(digest, row["receipt_digest"]):
                raise LedgerError("capacity completion is unavailable")
            return {"state": "released", "receipt_digest": digest, "released_at_ms": timestamp, "known": True}

    def _capacity_status(self, project_id, status):
        """Current bounded owner view; never releases, registers or launches.

        Expired, terminal or unreconciled reservations stay held. Missing
        scoped metadata is unknown, not proof of a free slot or absent process.
        Released observations require the original keyed completion receipt.
        """
        if not claim_matches(project_id, _CLAIM_PROJECT) or type(status) is not CapacityStatusInput:
            raise LedgerError("capacity status is unavailable")
        status.__post_init__()
        with self._held():
            if self._connection.in_transaction:
                raise LedgerError("capacity status is unavailable")
            self.state.harden_database_files()
            handle = keyed_digest(self.state.digest_key(), status.run_handle)
            cap = self._connection.execute(
                "SELECT run_id,released_at_ms FROM active_run_capacity "
                "WHERE project_id=? AND handle_digest=? AND bridge_run_id=?",
                (project_id, handle, status.bridge_run_id),
            ).fetchone()
            result = {"state": "unknown", "receipt_digest": None, "released_at_ms": None}
            if cap is not None:
                result["state"] = "held"
                if cap["released_at_ms"] is not None:
                    key = OwnedExecutionKey(project_id, handle, cap["run_id"], status.bridge_run_id)
                    row = self._capacity_completion_locked(key)
                    if self._slot_decision_locked(project_id, handle, row["release_digest"]) is not None:
                        # Round 1 F10: released by a written decision; the slot's own receipt and time.
                        return checked_capacity_status({"state": "released", "receipt_digest": row["release_digest"],
                                                        "released_at_ms": row["released_at_ms"]})
                    digest = self._capacity_completion_digest(row, row["released_at_ms"])
                    if not secrets.compare_digest(digest, row["receipt_digest"]):
                        raise LedgerError("capacity status is unavailable")
                    result = {"state": "released", "receipt_digest": digest, "released_at_ms": row["released_at_ms"]}
            return checked_capacity_status(result)

    def claim_launch(
        self, project_id: str, *, runtime_digest: str, caller_scope: str,
        request_id: str, launch: LaunchClaimInput, storage_required=False, storage_binding=None, storage_evidence=None,
    ) -> dict[str, Any]:
        """Legacy synchronous owner reference; replies are metadata, never grants.

        The asynchronous service path uses the same preflight and commit with an
        actually returned fixed signature job. Native caller/environment custody,
        bounded final admission work and normal-client migration remain required.
        AccountService requires storage evidence by default; this direct library
        reference does not grant a normal client a database or fallback path.
        """
        context, known, early_reason, provider = self._claim_preflight(
            project_id, runtime_digest=runtime_digest, caller_scope=caller_scope,
            request_id=request_id, launch=launch,
            storage_required=storage_required, storage_binding=storage_binding, storage_evidence=storage_evidence,
        )
        if known is not None:
            return known
        prepared = None if early_reason else self._prepare_attestations(project_id, provider)
        return self._claim_commit(context, prepared, early_reason)

    def _claim_from_signature_job(self, context, pool, handle):
        """Consume only an actually returned job from this owner's fixed pool.

        No caller-selected indices, snapshot, callback or verification flag is
        accepted. A pool/dataclass alone is not proof: the registered pool's
        private completion registry and original retained inputs must agree.
        The coordinator retains the reservation through commit/publication.
        """
        from .signature_worker_pool import SignatureWorkerPool

        self._check_claim_context(context)
        intake = getattr(self, "_signature_job_intake", None)
        if (type(pool) is not SignatureWorkerPool or intake is None or pool._intake is not intake
                or getattr(intake, "_signature_worker_pool", None) is not pool
                or intake._views._ledger is not self):
            raise ClaimError("claim_unavailable")
        pool._owner()
        result = pool.result(handle)
        inputs = intake.returned_inputs(handle)
        if (inputs.origin is not self._attestation_origin or inputs.project_id != context.project_id):
            raise ClaimError("claim_unavailable")
        admission, work_limits = intake.returned_admission(handle)
        # Even a failed verification job may retrieve a durable receipt produced
        # independently while it waited. This never releases an active worker.
        with self._held():
            known = self._connection.read_call(work_limits, lambda: self._known_claim_for_request_locked(context))
        if known is not None:
            return known
        if result.reason != "signature_execution_completed":
            raise ClaimError("claim_preparation_failed")
        from .claim_admission import PreparedClaimAdmission, admission_signature_rows

        if (type(result.prepared) is not PreparedClaimAdmission or result.prepared.snapshot is not admission
                or admission.origin is not intake._views._admission_capture_origin
                or admission.project_id != context.project_id or admission.provider != inputs.provider
                or admission.owner != inputs.owner or admission.signer != inputs.signer
                or inputs.rows != admission_signature_rows(admission)):
            raise ClaimError("claim_unavailable")
        prepared = _PreparedAttestations(
            self._attestation_origin, inputs.project_id, inputs.provider, inputs.owner, inputs.signer,
            inputs.rows, frozenset(inputs.rows[index][0] for index in result.indices),
        )
        return self._claim_commit(context, prepared, None, admission=result.prepared, work_limits=work_limits)

    def _check_claim_context(self, context):
        if type(context) is not _ClaimRequest or context.origin is not self._attestation_origin:
            raise ClaimError("claim_invalid_request")

    def _known_claim_for_request_locked(self, context):
        """Original managed integrity also applies to clock-free known replies."""
        known = self._known_claim_receipt_locked(context.project_id, context.scope, context.request, context.parameters)
        if known is None:
            return None
        origin = self._connection.execute('SELECT history_owner FROM host_run_bindings WHERE project_id=? AND handle_digest=?',
                                          (context.project_id, context.handle)).fetchone()
        managed = any(self._connection.execute('SELECT 1 FROM '+table+' WHERE project_id=? AND handle_digest=?',
                                              (context.project_id, context.handle)).fetchone() is not None
                      for table in ('account_open_receipts', 'account_open_requests'))
        if not managed and ((origin is not None and origin[0] == 'legacy')
                            or (origin is None and known['state'] != 'claimed')):
            return known
        from .account_api import ACCOUNT_PROTOCOL_VERSION, AccountRequest, account_request_digest

        expected = context.storage_binding
        original = AccountRequest(ACCOUNT_PROTOCOL_VERSION, 'account.claim_launch', context.request_id,
                                  context.project_id, context.runtime_digest, context.launch.payload())
        if (expected is None or expected.project_id != context.project_id or expected.runtime_digest != context.runtime_digest
                or expected.run_handle != context.launch.run_handle or expected.run_id != known['run_id']
                or expected.claim_request_id != context.request_id or expected.claim_request_digest != account_request_digest(original)):
            raise ClaimError('claim_storage_invalid')
        self._claim_original_orchestration_digest(expected, 'claim_storage_invalid')
        return known

    def _claim_commit_header(self, context, *, capture_clock=False):
        project = self._connection.execute("SELECT status FROM projects WHERE project_id=?", (context.project_id,)).fetchone()
        if project is None or project[0] != "active":
            raise ClaimError("claim_unavailable")
        known = self._known_claim_for_request_locked(context)
        if known is not None:
            return (known, None, None) if capture_clock else (known, None)
        reference = self._capacity_clock_reference() if capture_clock else None
        timestamp = self._clock_ms()
        if type(timestamp) is not int or not 0 <= timestamp <= MAX_CLAIM_INTEGER:
            raise ClaimError("claim_unavailable")
        return (known, timestamp, reference) if capture_clock else (known, timestamp)

    def _claim_run_rows_locked(self, project_id, handle):
        """Read all fixed scalar inputs before any eligibility short circuit."""
        binding = self._connection.execute(
            "SELECT run_id,binding_state,consumed_at_ms,client_version,expires_at_ms,created_at_ms,assignment_digest,orchestration_id,"
            "observation_started_at_ms,observation_deadline_at_ms,history_owner "
            "FROM host_run_bindings WHERE project_id=? AND handle_digest=?", (project_id, handle),
        ).fetchone()
        inputs = self._connection.execute(
            "SELECT run_id,provider,runtime_digest,model,effort,hard_timeout_seconds "
            "FROM launch_inputs WHERE project_id=? AND handle_digest=?", (project_id, handle),
        ).fetchone()
        observed = self._connection.execute(
            "SELECT identity_digest,observed_at_ms FROM launch_observations WHERE project_id=? AND handle_digest=?",
            (project_id, handle),
        ).fetchone()
        return binding, inputs, observed

    def _claim_scalar_context_locked(self, project_id, handle, launch, timestamp, *, rows=None):
        """Fresh fixed run/observation columns; never parse stored JSON here."""
        from .providers import BILLING_MAX_AGE_MS

        binding, inputs, observed = self._claim_run_rows_locked(project_id, handle) if rows is None else rows
        if binding is None:
            return "claim_not_open", None, None, None
        if (binding["binding_state"] != "pending" or binding["consumed_at_ms"] is not None
                or binding["client_version"] != "bridge-v1" or binding["expires_at_ms"] <= timestamp):
            return "claim_not_open", binding, None, None
        if not claim_matches(binding["run_id"], _CLAIM_RUN):
            raise ClaimError("claim_unavailable")
        if _claim_exists(self._connection, project_id, handle, binding["run_id"]):
            return "claim_already_consumed", binding, None, None
        started, until = self._claim_observation_window(binding)
        if not started <= timestamp < until:
            return 'claim_not_open', binding, None, None
        if inputs is None or inputs["run_id"] != binding["run_id"] or inputs["provider"] not in {"codex", "claude"}:
            return "claim_context_missing", binding, None, None
        if inputs["runtime_digest"] != COLLECTOR_RUNTIME_DIGEST:
            return "claim_runtime_mismatch", binding, inputs, None
        if (observed is None or observed["identity_digest"] != launch.identity_digest
                or not binding["created_at_ms"] <= observed["observed_at_ms"] <= timestamp
                or timestamp - observed["observed_at_ms"] > BILLING_MAX_AGE_MS):
            return "claim_observation_missing", binding, inputs, None
        return None, binding, inputs, observed

    @staticmethod
    def _claim_observation_window(binding):
        started, until = binding['observation_started_at_ms'], binding['observation_deadline_at_ms']
        if (type(started) is not int or type(until) is not int or type(binding['created_at_ms']) is not int
                or not 0 <= binding['created_at_ms'] <= started < until <= MAX_CLAIM_INTEGER):
            raise ClaimError('claim_unavailable')
        return started, until

    @staticmethod
    def _claim_run_columns(binding, inputs, observed):
        # A bounded metadata tuple retained with the already reserved ticket.
        # No unbounded database string is retained as preparation context.
        if (type(inputs["model"]) is not str or not 0 < len(inputs["model"].encode()) <= 160
                or type(inputs["effort"]) is not str or not 0 < len(inputs["effort"].encode()) <= 32
                or type(inputs["hard_timeout_seconds"]) is not int or inputs["hard_timeout_seconds"] < 1
                or type(binding["created_at_ms"]) is not int or binding["created_at_ms"] < 0
                or type(binding["expires_at_ms"]) is not int or binding["expires_at_ms"] < binding["created_at_ms"]):
            raise ClaimError("claim_unavailable")
        return (tuple(binding), tuple(inputs), tuple(observed))

    def _claim_admission_context(self, context, prepared, work_limits):
        from .admission_inputs import AdmissionCaptureLimits
        from .claim_admission import claim_identity, same_admission_inputs

        intake = self._signature_job_intake
        view, limits = intake._views, intake._limits
        snapshot = prepared.snapshot
        signer = self._current_signer_bytes()
        policy = view._claim_policy(snapshot.provider)

        def read():
            current = view._capture_admission_rows_locked(
                context.project_id, snapshot.provider, policy,
                AdmissionCaptureLimits(limits.rows_per_job, limits.bytes_per_job), signer, snapshot.anchor_ms,
            )
            if not same_admission_inputs(snapshot, current):
                raise ClaimError("claim_preparation_stale")
            rows = self._claim_run_rows_locked(context.project_id, context.handle)
            if context.run_context != tuple(None if row is None else tuple(row) for row in rows):
                raise _run_changed()
            # The capture kept history from the run's open on; only that anchor is sound.
            if rows[0] is None or snapshot.anchor_ms != rows[0]["created_at_ms"]:
                raise _run_changed()
            state = self._claim_scalar_context_locked(
                context.project_id, context.handle, context.launch, current.captured_at_ms, rows=rows,
            )
            return (*state, current.captured_at_ms)

        reason, binding, inputs, observed, timestamp = self._connection.transaction_read_call(work_limits, read)
        identity = admission = None
        if reason is None:
            if inputs["provider"] != snapshot.provider:
                raise ClaimError("claim_preparation_stale")
            reason, admission, identity = claim_identity(prepared, binding["run_id"], context.launch.identity_digest)
            if reason is None and identity["observed_at_ms"] != observed["observed_at_ms"]:
                reason = "claim_client_changed"
            if reason is None and identity["client_version"] not in prepared.reviewed_versions:
                reason = "client_version_unreviewed"
        return reason, binding, inputs, identity, admission, timestamp

    def _claim_original_orchestration_digest(self, expected, error_code):
        from .account_open_contracts import OpenError
        from .account_original_open import original_orchestration_digest

        try:
            return original_orchestration_digest(self, expected)
        except OpenError:
            raise ClaimError(error_code) from None

    def _check_claim_storage(self, context, run_id, timestamp, deadline, work_limits):
        from .account_api import ACCOUNT_PROTOCOL_VERSION, AccountRequest, account_request_digest
        from .claim_storage import verify_storage_evidence

        if context.storage_binding is None or context.storage_evidence is None:
            raise ClaimError("claim_storage_required")
        def metadata():
            row = self._connection.execute(
                "SELECT h.assignment_digest FROM host_run_bindings h "
                "WHERE h.project_id=? AND h.handle_digest=? AND h.run_id=?", (context.project_id, context.handle, run_id),
            ).fetchone()
            if row is None:
                raise ClaimError("claim_storage_invalid")
            return row[0], self._claim_original_orchestration_digest(context.storage_binding, 'claim_storage_invalid')
        assignment, orchestration = (metadata() if work_limits is None else
                                     self._connection.transaction_read_call(work_limits, metadata))
        request = AccountRequest(ACCOUNT_PROTOCOL_VERSION, "account.claim_launch", context.request_id,
                                 context.project_id, context.runtime_digest, context.launch.payload())
        verify_storage_evidence(
            self.state.digest_key(), context.storage_binding, context.storage_evidence,
            project_id=context.project_id, runtime_digest=context.runtime_digest, run_handle=context.launch.run_handle,
            run_id=run_id, request_id=context.request_id, request_digest=account_request_digest(request),
            assignment_digest=assignment, orchestration_digest=orchestration, now_ms=timestamp, deadline_ms=deadline,
        )

    def _claim_commit(self, context, prepared, early_reason, *, admission=None, work_limits=None):
        self._check_claim_context(context)
        project_id, launch = context.project_id, context.launch
        scope, request, parameters, handle = context.scope, context.request, context.parameters, context.handle
        with self._account_transaction():
            def header():
                return self._claim_commit_header(context, capture_clock=True)
            known, timestamp, monotonic_reference = (header() if work_limits is None else
                                                     self._connection.transaction_read_call(work_limits, header))
            if known is not None:
                return known
            if admission is None and work_limits is None and early_reason is None:
                rows = self._claim_run_rows_locked(project_id, handle)
                if context.run_context != tuple(None if row is None else tuple(row) for row in rows):
                    raise _run_changed()
            if admission is not None:
                reason, binding, inputs, identity, admitted, fresh_timestamp = self._claim_admission_context(
                    context, admission, work_limits,
                )
                if fresh_timestamp < timestamp:
                    raise ClaimError("claim_unavailable")
                timestamp = fresh_timestamp
            elif work_limits is not None:
                if early_reason is None:
                    raise ClaimError("claim_unavailable")
                reason, binding, inputs, identity = self._connection.transaction_read_call(
                    work_limits, lambda: self._claim_scalar_context_locked(project_id, handle, launch, timestamp),
                )
            else:
                reason, binding, inputs, identity = self._claim_context_locked(project_id, handle, launch, timestamp)
            reason = early_reason or reason
            run_id = None if binding is None else binding["run_id"]
            if not claim_matches(run_id, _CLAIM_RUN):
                # Older fenced bindings can retain historical identifiers
                # outside this wire contract. Do not reinterpret or export one.
                run_id = None
            if reason is None:
                from .providers import evaluate_launch

                if admission is None:
                    admitted, identity_digest = self._launch_identity_locked(project_id, launch.run_handle, identity)
                    attestations = self._prepared_attestations_locked(prepared, project_id, inputs["provider"])
                    billing, _ = self._account_records_locked(project_id, "provider_billing", inputs["provider"])
                    headroom, _ = self._account_records_locked(project_id, "provider_headroom", inputs["provider"])
                else:
                    identity_digest = launch.identity_digest
                    billing, headroom = admission.billing, admission.headroom
                    attestations = [(record, digest) for identifier, record, digest in admission.attestations
                                    if identifier in prepared.verified]
                reason = evaluate_launch(
                    provider=inputs["provider"], identity=identity, billing=billing, headroom=headroom,
                    now_ms=timestamp, attestations=attestations, bootstrap=admitted["admission_basis"] == "bootstrap",
                )
                if reason is not None:
                    self._store_admission_locked(project_id, {
                        "provider": inputs["provider"], "decision": "deny", "reason_code": reason,
                        "admission_basis": None, "account_fingerprint": admitted["account_fingerprint"],
                        "evidence_digests": [identity_digest], "observed_at_ms": timestamp,
                    }, run_id=None, timestamp=timestamp)
            bridge = deadline = None
            if reason is None:
                # Waiting for signatures/export cannot restart the original
                # host-open budget. Both wall and monotonic capacity deadlines
                # are derived below from this same remaining window.
                deadline = min(timestamp + inputs["hard_timeout_seconds"] * 1000,
                               self._claim_observation_window(binding)[1])
                if not timestamp < deadline <= MAX_CLAIM_INTEGER:
                    raise ClaimError("claim_unavailable")
                if context.storage_required:
                    self._check_claim_storage(context, run_id, timestamp, deadline, work_limits)
                def capacity():
                    return self._check_active_capacity_locked(inputs["provider"], admitted["account_fingerprint"])
                policy = (capacity() if work_limits is None else
                          self._connection.transaction_read_call(work_limits, capacity))
                bridge = "brg_" + secrets.token_hex(16)
                material = {"schema_version": 1, "record_type": "dispatch_intent", "run_id": run_id,
                            "bridge_run_id": bridge, "provider": inputs["provider"], "model": inputs["model"],
                            "effort": inputs["effort"], "deadline_at_ms": deadline, "observed_at_ms": timestamp}
                record = validate_learning_record({**material, "record_id": "dispatch_intent:" + content_digest(material)})
                self._connection.execute("INSERT INTO launch_claims VALUES(?,?,?,'claimed',?,?)",
                                         (project_id, handle, run_id, timestamp, bridge))
                self._reserve_active_capacity_locked(project_id, handle, run_id, bridge, inputs["provider"],
                                                     admitted["account_fingerprint"], policy, timestamp, deadline,
                                                     monotonic_reference)
                self._append_checked_locked(project_id, record, producer="lifecycle", timestamp=timestamp)
            return self._store_claim_receipt_locked(project_id, scope, request, parameters, handle, {
                "state": "claimed" if reason is None else "denied", "run_id": run_id, "reason_code": reason,
                "bridge_run_id": bridge, "deadline_at_ms": deadline, "recorded_at_ms": timestamp,
            })

    def record_dispatch_intent(
        self,
        project_id: str,
        *,
        run_handle: str,
        assignment: dict[str, Any],
        task: dict[str, Any],
        route: dict[str, Any],
        deadline_seconds: int,
        claim: bool = True,
    ) -> dict[str, Any]:
        """Durably claim the single bridged launch for an open, admitted run.

        The run must still be pending and bound to exactly this assignment, task
        and route, with a passing admission for the route's provider. A second
        claim for the same run is refused, even after history expiry or clock
        rollback. Consumption is owner metadata, not an expiring event. With
        `claim` false the same checks run and nothing is written, so a refusal
        can happen before anything is exported or launched.
        """

        if type(claim) is not bool:
            raise LedgerError("dispatch claim flag is invalid")
        try:
            monotonic_reference = self._capacity_clock_reference() if claim else None
        except ClaimError:
            raise LedgerError("dispatch deadline is unavailable") from None
        timestamp = self._clock_ms()
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        bridge_run_id = f"brg_{secrets.token_hex(16)}"
        # Preflight reads do not acquire SQLite's write reservation.
        with self._account_transaction() if claim else self._held():
            binding = self._connection.execute(
                "SELECT run_id,binding_state,consumed_at_ms,assignment_digest,"
                "task_digest,route_digest,expires_at_ms FROM host_run_bindings "
                "WHERE project_id=? AND handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if binding is None:
                raise LedgerError("host run is unavailable")
            if (
                binding["binding_state"] != "pending"
                or binding["consumed_at_ms"] is not None
                or int(binding["expires_at_ms"]) <= timestamp
            ):
                raise LedgerError("host run is no longer open for dispatch")
            key = self.state.digest_key()
            if (
                str(binding["route_digest"]) != keyed_digest(key, canonical_json(route_identity(route)))
                or str(binding["assignment_digest"]) != keyed_digest(
                    key, canonical_json(validate_assignment_shape(assignment))
                )
                or str(binding["task_digest"]) != keyed_digest(
                    key, canonical_json(validate_task(task))
                )
            ):
                raise LedgerError("dispatch does not match the opened host run")
            run_id = str(binding["run_id"])
            admission = self._run_admission_locked(project_id, run_id)
            if admission["provider"] != route.get("provider"):
                raise LedgerError("host run admission differs from the dispatched provider")
            if _claim_exists(self._connection, project_id, handle_digest, run_id):
                raise LedgerError("host run was already dispatched")
            _refuse_malformed_rows(self._connection, project_id, "dispatch_intent")
            if self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND record_type='dispatch_intent' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, run_id),
            ).fetchone() is not None:
                raise LedgerError("host run was already dispatched")
            try:
                policy = self._check_active_capacity_locked(route["provider"], admission["account_fingerprint"])
            except ClaimError as error:
                raise LedgerError("active launch capacity is unavailable") from error
            if not claim:
                return {"run_id": run_id}
            material = {
                "schema_version": 1,
                "record_type": "dispatch_intent",
                "run_id": run_id,
                "bridge_run_id": bridge_run_id,
                "provider": route["provider"],
                "model": route["model"],
                "effort": route["effort"],
                "deadline_at_ms": timestamp + deadline_seconds * 1000,
                "observed_at_ms": timestamp,
            }
            try:
                record = validate_learning_record(
                    {**material, "record_id": f"dispatch_intent:{content_digest(material)}"}
                )
            except ContractError as exc:
                raise LedgerError("dispatch intent is invalid") from exc
            self._connection.execute(
                "INSERT INTO launch_claims(project_id,handle_digest,run_id,kind,claimed_at_ms,bridge_run_id) "
                "VALUES(?,?,?,'claimed',?,?)",
                (project_id, handle_digest, run_id, timestamp, bridge_run_id),
            )
            try:
                self._reserve_active_capacity_locked(project_id, handle_digest, run_id, bridge_run_id,
                                                     route["provider"], admission["account_fingerprint"], policy, timestamp,
                                                     record["deadline_at_ms"], monotonic_reference)
            except ClaimError:
                raise LedgerError("dispatch deadline is unavailable") from None
            self._append_checked_locked(
                project_id, record, producer="lifecycle", timestamp=timestamp
            )
        return {
            "bridge_run_id": bridge_run_id,
            "run_id": run_id,
            "account_fingerprint": admission["account_fingerprint"],
            "deadline_at_ms": record["deadline_at_ms"],
        }

    def record_dispatch_result(
        self,
        project_id: str,
        *,
        run_handle: str,
        bridge_run_id: str,
        result: dict[str, Any],
        fenced: bool,
        reviewed: bool,
        terminal_state: str | None,
        result_validation_reason_code: str | None = None,
        client_diagnostics: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Bind what a dispatched child returned to its run, once.

        The ledger keeps a keyed digest of the result, never its text, with the
        bridge's fence, review and terminal-state facts. Recording the run's
        result later requires exactly this result and terminal state, so a
        primary can neither substitute a result nor drop a fence.
        """

        timestamp = self._clock_ms()
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._account_transaction():
            binding = self._connection.execute(
                "SELECT run_id,binding_state,consumed_at_ms FROM host_run_bindings "
                "WHERE project_id=? AND handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if (
                binding is None
                or binding["binding_state"] != "pending"
                or binding["consumed_at_ms"] is not None
            ):
                raise LedgerError("host run is not pending")
            run_id = str(binding["run_id"])
            intents = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='dispatch_intent' AND source='lifecycle' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, run_id),
            ).fetchall()
            if len(intents) != 1:
                raise LedgerError("only the dispatched run records its child's result")
            intent = json.loads(bytes(intents[0]["content"]))
            if intent["bridge_run_id"] != bridge_run_id:
                raise LedgerError("only the dispatched run records its child's result")
            if client_diagnostics is not None and intent["provider"] != "claude":
                raise LedgerError("client observations require a Claude dispatch")
            _refuse_malformed_rows(self._connection, project_id, "dispatch_result")
            if self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? AND record_type='dispatch_result' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, run_id),
            ).fetchone() is not None:
                raise LedgerError("the dispatched child's result is already recorded")
            material = {
                "schema_version": DISPATCH_RESULT_SCHEMA_VERSION,
                "record_type": "dispatch_result",
                "run_id": run_id,
                "bridge_run_id": bridge_run_id,
                "result_digest": keyed_digest(self.state.digest_key(), canonical_json(result)),
                "fenced": fenced,
                "reviewed": reviewed,
                "terminal_state": terminal_state,
                "result_validation_reason_code": result_validation_reason_code,
                "client_diagnostics": client_diagnostics,
                "observed_at_ms": timestamp,
            }
            try:
                record = validate_learning_record(
                    {**material, "record_id": f"dispatch_result:{content_digest(material)}"}
                )
            except ContractError as exc:
                raise LedgerError("dispatch result is invalid") from exc
            self._append_checked_locked(
                project_id, record, producer="lifecycle", timestamp=timestamp
            )
            self._connection.execute(
                "INSERT INTO capacity_completions(project_id,handle_digest,run_id,bridge_run_id,"
                "terminal_record_id,terminal_content_digest) VALUES(?,?,?,?,?,?)",
                (project_id, handle_digest, run_id, bridge_run_id, record["record_id"], content_digest(record)),
            )
        return {"run_id": run_id, "bridge_run_id": bridge_run_id}

    def host_owner(
        self,
        project_id: str,
        *,
        orchestration_handle: str | None = None,
        run_handle: str | None = None,
    ) -> str:
        """The host client that opened the orchestration owning this handle.

        A run bound before orchestrations existed has no owner record; those were
        only ever opened by the Codex host.
        """

        with self._held():
            if orchestration_handle is not None:
                row = self._orchestration_for_handle_locked(project_id, orchestration_handle)
                return str(row["client_version"])
            if not isinstance(run_handle, str):
                raise LedgerError("host run handle is invalid")
            binding = self._connection.execute(
                "SELECT orchestration_id FROM host_run_bindings "
                "WHERE project_id=? AND handle_digest=?",
                (project_id, keyed_digest(self.state.digest_key(), run_handle)),
            ).fetchone()
            if binding is None:
                raise LedgerError("host run is unavailable")
            if binding["orchestration_id"] is None:
                return "codex-host-v1"
            row = self._connection.execute(
                "SELECT client_version FROM orchestrations "
                "WHERE project_id=? AND orchestration_id=?",
                (project_id, str(binding["orchestration_id"])),
            ).fetchone()
        if row is None:
            raise LedgerError("host run orchestration is unavailable")
        return str(row["client_version"])

    def record_host_denial(
        self, project_id: str, *, provider: str, reason_code: str
    ) -> None:
        """Store a host-side open denial, as admission denials are stored."""

        timestamp = self._clock_ms()
        decision = {
            "provider": provider, "decision": "deny", "reason_code": reason_code,
            "admission_basis": None, "account_fingerprint": None,
            "evidence_digests": [], "observed_at_ms": timestamp,
        }
        with self._held(), self._connection:
            self._store_admission_locked(
                project_id, decision, run_id=None, timestamp=timestamp
            )
        self.state.harden_database_files()

    def host_run_admission(self, project_id: str, run_handle: str) -> dict[str, Any]:
        """Return the stored admission for a run; time-varying facts are not re-read."""

        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._held():
            binding = self._connection.execute(
                "SELECT run_id FROM host_run_bindings "
                "WHERE project_id=? AND handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if binding is None:
                raise LedgerError("host run is unavailable")
            return self._run_admission_locked(project_id, str(binding["run_id"]))

    def observe_host_run(
        self,
        project_id: str,
        *,
        run_handle: str,
        event: str,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Persist progress or observation-deadline state without inventing termination."""

        if event not in {"progress", "deadline"}:
            raise LedgerError("host observation event is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        handle_digest = keyed_digest(self.state.digest_key(), run_handle)
        with self._held(), self._connection:
            binding = self._connection.execute(
                "SELECT binding_state,observation_started_at_ms,"
                "observation_deadline_at_ms,last_progress_at_ms,deadline_observed "
                "FROM host_run_bindings WHERE project_id=? AND handle_digest=?",
                (project_id, handle_digest),
            ).fetchone()
            if binding is None or binding["binding_state"] != "pending":
                raise LedgerError("host run is not pending")
            if binding["observation_deadline_at_ms"] is None:
                raise LedgerError("legacy host run requires manual deadline reconciliation")
            deadline = int(binding["observation_deadline_at_ms"])
            if event == "deadline" and timestamp < deadline:
                raise LedgerError("host observation deadline has not elapsed")
            if event == "progress":
                self._connection.execute(
                    "UPDATE host_run_bindings SET last_progress_at_ms=MAX("
                    "last_progress_at_ms,?) WHERE project_id=? AND handle_digest=?",
                    (timestamp, project_id, handle_digest),
                )
            else:
                self._connection.execute(
                    "UPDATE host_run_bindings SET deadline_observed=1 "
                    "WHERE project_id=? AND handle_digest=?",
                    (project_id, handle_digest),
                )
        return {
            "state": "stale" if timestamp >= deadline else "active",
            "observation_started_at_ms": int(binding["observation_started_at_ms"]),
            "observation_deadline_at_ms": deadline,
            "last_progress_at_ms": (
                max(int(binding["last_progress_at_ms"]), timestamp)
                if event == "progress" else int(binding["last_progress_at_ms"])
            ),
            "deadline_observed": bool(binding["deadline_observed"]) or event == "deadline",
        }

    def commit_host_result(
        self,
        project_id: str,
        *,
        assignment: dict[str, Any],
        task: dict[str, Any],
        route: dict[str, Any],
        result: dict[str, Any],
        observation: dict[str, Any],
        execution_configuration: dict[str, Any],
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Derive and atomically admit one result through the trusted host adapter."""

        from .learning_contracts import validate_host_observation

        try:
            checked_observation = validate_host_observation(observation)
        except ContractError as exc:
            # validate_host_observation uses only fixed rule text and internal field names.
            raise LedgerError(f"host observation admission rejected: {exc}") from exc
        try:
            checked_result = validate_result(result, assignment=assignment)
        except ContractError as exc:
            raise LedgerError("host result admission rejected") from exc
        if (
            validate_execution_configuration(execution_configuration)[
                "verification_required"
            ] is True
            and len(canonical_json(checked_result)) > MAX_WORKER_RESULT_BYTES
        ):
            # A result that will be verified must be kept for its verifier, and
            # it is kept as canonical JSON, which escapes non-ASCII text. Refuse
            # before anything is consumed, so the run stays open for a result
            # that fits.
            raise LedgerError(
                "host result is too large to keep for its verifier as canonical JSON"
            )
        axes = result_axes(checked_result, attempt=assignment.get("attempt", 1))
        if axes["admission_state"] != "unverified":
            raise LedgerError("host result cannot self-assign admission")
        terminal_state = checked_observation.get("terminal_state")
        if terminal_state is not None and terminal_state != axes["execution_state"]:
            raise LedgerError("host terminal state conflicts with the result")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        trusted_handle = checked_observation.get("run_handle")
        if trusted_handle is not None:
            if axes["execution_state"] == "timed_out" and terminal_state != "timed_out":
                raise LedgerError("timed-out result requires an authoritative host fact")
            handle_digest = keyed_digest(self.state.digest_key(), trusted_handle)
            with self._held():
                binding = self._connection.execute(
                    "SELECT * FROM host_run_bindings WHERE project_id=? "
                    "AND handle_digest=?",
                    (project_id, handle_digest),
                ).fetchone()
            if (
                binding is None
                or binding["consumed_at_ms"] is not None
                or int(binding["expires_at_ms"]) <= timestamp
                or str(binding["assignment_digest"]) != keyed_digest(
                    self.state.digest_key(),
                    canonical_json(validate_assignment_shape(assignment)),
                )
                or str(binding["task_digest"]) != keyed_digest(
                    self.state.digest_key(), canonical_json(validate_task(task))
                )
                or str(binding["route_digest"]) != keyed_digest(
                    self.state.digest_key(), canonical_json(route_identity(route))
                )
                or str(binding["configuration_digest"])
                != content_digest(validate_execution_configuration(execution_configuration))
            ):
                raise LedgerError("host run handle does not match this assigned route")
            client_version = str(binding["client_version"])
            checked_observation = {
                "run_id": str(binding["run_id"]),
                "client_version": client_version,
                "result_attempts": checked_observation["result_attempts"],
                **(
                    {"terminal_state": terminal_state}
                    if terminal_state is not None else {}
                ),
            }
            host_evidence = {
                "run_id": checked_observation["run_id"],
                "coverage": "lifecycle_partial",
                "usage": empty_usage(),
                "observed_at_ms": timestamp,
                "no_progress_events": 0,
                "usage_source": "host_observed",
            }
            reconciled = None
        else:
            client_version = checked_observation["client_version"]
        capability = self._client_capabilities.get(client_version)
        if capability is None:
            raise LedgerError("host result client is not in the accepted matrix")
        if trusted_handle is None:
            with self._held():
                provenance = self._connection.execute(
                    "SELECT 1 FROM run_provenance WHERE project_id=? AND run_id=? "
                    "AND client_version=?",
                    (project_id, checked_observation["run_id"], client_version),
                ).fetchone()
                rows = self._connection.execute(
                    "SELECT source,content FROM records WHERE project_id=? "
                    "AND record_type='event' AND source IN ('hook','app_server')",
                    (project_id,),
                ).fetchall()
            if provenance is None:
                raise LedgerError("host result run has no trusted client binding")
            envelopes = [
                {"source": str(row["source"]), "record": record}
                for row in rows
                if (
                    (record := json.loads(bytes(row["content"]))) ["run_id"]
                    == checked_observation["run_id"]
                )
            ]
            if not envelopes:
                raise LedgerError("host result has no admitted host events")
            reconciled = reconcile_run(envelopes, capability=capability)
            observed_at_ms = max(item["record"]["observed_at_ms"] for item in envelopes)
            host_evidence = {
                "run_id": checked_observation["run_id"],
                "coverage": reconciled["coverage"],
                "usage": reconciled["usage"] or empty_usage(),
                "observed_at_ms": observed_at_ms,
                "no_progress_events": sum(
                    item["record"]["stop_reason"] == "no_progress" for item in envelopes
                ),
                "usage_source": "client_observed",
            }
        # Every result path needs the run's stored passing admission, including
        # collector-bound sessions, whose admission is decided when they bind.
        dispatch_diagnostics = {}
        with self._held():
            self._run_admission_locked(project_id, checked_observation["run_id"])
            if client_version == BRIDGE_CLIENT_VERSION and self._connection.execute(
                "SELECT 1 FROM records WHERE project_id=? "
                "AND record_type='dispatch_intent' AND source='lifecycle' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, checked_observation["run_id"]),
            ).fetchone() is None:
                # A bridged run's result can only come from its dispatched child.
                raise LedgerError("a bridged run must be dispatched before its result")
            if client_version == BRIDGE_CLIENT_VERSION:
                # ... and it must be exactly what that child returned, with the
                # bridge's terminal state: neither may be made up or dropped.
                dispatched = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='dispatch_result' AND source='lifecycle' "
                    "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                    (project_id, checked_observation["run_id"]),
                ).fetchall()
                if len(dispatched) != 1:
                    raise LedgerError("a bridged run has no recorded child result")
                recorded = json.loads(bytes(dispatched[0]["content"]))
                # Diagnostics come only from the bridge's durable record, never
                # the primary's observation or its (already fenced) result.
                reason = recorded.get("result_validation_reason_code")
                if reason is not None:
                    dispatch_diagnostics["result_validation_reason_code"] = reason
                client_diagnostics = recorded.get("client_diagnostics")
                if client_diagnostics is not None:
                    dispatch_diagnostics["client_diagnostics"] = client_diagnostics
                if not secrets.compare_digest(
                    keyed_digest(self.state.digest_key(), canonical_json(result)),
                    recorded["result_digest"],
                ):
                    raise LedgerError("host result differs from the bridged child's result")
                if terminal_state != recorded["terminal_state"]:
                    raise LedgerError(
                        "host terminal state differs from the bridged child's outcome"
                    )
            if trusted_handle is not None and client_version == BRIDGE_CLIENT_VERSION:
                # A bridged run's usage is what the bridge itself recorded for
                # it in the ledger; the primary never supplies it.
                usage = self._bridge_usage_locked(project_id, checked_observation["run_id"])
                if usage is not None:
                    host_evidence["usage"] = usage
                    host_evidence["usage_source"] = "client_observed"
        from .learning_engine import build_host_result_records

        evaluation_candidate_digest = None
        evaluation_case_digest = None
        with self._held():
            assignment_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_assignment'",
                (project_id,),
            ).fetchall()
            bindings: list[tuple[dict[str, Any], dict[str, Any]]] = []
            for row in assignment_rows:
                evaluation_assignment = json.loads(bytes(row["content"]))
                plans = [
                    item for item in evaluation_assignment["trial_plan"]
                    if item["trial_id"] == assignment["assignment_id"]
                ]
                if len(plans) == 1:
                    bindings.append((evaluation_assignment, plans[0]))
            if len(bindings) > 1:
                raise LedgerError("host result matches multiple evaluation assignments")
            if bindings:
                evaluation_assignment, plan = bindings[0]
                candidate_rows = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='candidate'",
                    (project_id,),
                ).fetchall()
                candidates = [
                    value for row in candidate_rows
                    if (value := json.loads(bytes(row["content"]))) ["candidate_digest"]
                    == evaluation_assignment["candidate_digest"]
                ]
                if len(candidates) != 1:
                    raise LedgerError("host result evaluation candidate is unavailable")
                candidate = candidates[0]
                expected_configuration = (
                    candidate["candidate_configuration"]
                    if plan["cohort"] == "candidate"
                    else candidate["champion_configuration"]
                )
                expected_reference = (
                    candidate["candidate_digest"]
                    if plan["cohort"] == "candidate"
                    else candidate["base_digest"]
                )
                case_row = self._connection.execute(
                    "SELECT content,content_digest FROM records WHERE project_id=? "
                    "AND record_id=? AND record_type='evaluation_case'",
                    (project_id, plan["case_id"]),
                ).fetchone()
                if (
                    case_row is None
                    or evaluation_assignment["client_digest"]
                    != execution_configuration["client_digest"]
                    or plan["configuration_digest"]
                    != expected_reference
                    or execution_configuration != expected_configuration
                ):
                    raise LedgerError("host result does not match its evaluation assignment")
                evaluation_candidate_digest = plan["configuration_digest"]
                evaluation_case_digest = str(case_row["content_digest"])

        event, outcome, producer = build_host_result_records(
            assignment=assignment,
            task=task,
            result=checked_result,
            observation=checked_observation,
            host_evidence=host_evidence,
            execution_configuration=execution_configuration,
            digest_key=self.state.digest_key(),
            client_capability=capability,
            evaluation_candidate_digest=evaluation_candidate_digest,
            evaluation_case_digest=evaluation_case_digest,
        )
        if reconciled is not None and reconciled["conflicting"]:
            raise LedgerError("host result events conflict")
        if (
            reconciled is not None
            and axes["execution_state"] == "timed_out"
            and reconciled.get("terminal_stop_reason") != "timeout"
        ):
            raise LedgerError("timed-out result lacks an authoritative host timeout fact")
        if reconciled is not None and reconciled["terminal_status"] != event["status"]:
            raise LedgerError("host result conflicts with the trusted terminal event")
        host_outcome_digest = content_digest(outcome)
        # A result that will be verified is kept, outside the database, so a
        # bound verifier can be given exactly this result later.
        stored_result = (
            self._write_worker_result(project_id, host_outcome_digest, checked_result)
            if execution_configuration["verification_required"] is True
            else None
        )

        def discard_new_result():
            # Refused before the transaction: only the file this attempt made goes, so a retry succeeds.
            if stored_result is not None and stored_result["created"]:
                with contextlib.suppress(OSError):
                    (self.state.root / stored_result["relative_path"]).unlink()
        with self._held(on_refused=discard_new_result):
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                project = self._connection.execute(
                    "SELECT status FROM projects WHERE project_id=?", (project_id,)
                ).fetchone()
                if not project or project["status"] != "active":
                    raise LedgerError("project binding is not active")
                if trusted_handle is not None:
                    binding = self._connection.execute(
                        "SELECT native_assignment_id FROM host_run_bindings "
                        "WHERE project_id=? AND handle_digest=? "
                        "AND binding_state='pending' AND consumed_at_ms IS NULL "
                        "AND expires_at_ms>?",
                        (project_id, handle_digest, timestamp),
                    ).fetchone()
                    if binding is None:
                        raise LedgerError("host run handle is expired or already consumed")
                    if binding["native_assignment_id"] is None:
                        raise LedgerError("host run is not bound to a native agent")
                    usage_complete = int(token_usage_known(outcome["usage"]))
                    consumed = self._connection.execute(
                        "UPDATE host_run_bindings SET consumed_at_ms=?,expires_at_ms=?,"
                        "usage_complete=?,binding_state='terminal' "
                        "WHERE project_id=? "
                        "AND handle_digest=? AND binding_state='pending' "
                        "AND consumed_at_ms IS NULL AND expires_at_ms>?",
                        (
                            timestamp,
                            timestamp + DEFAULT_RETENTION_MS,
                            usage_complete,
                            project_id,
                            handle_digest,
                            timestamp,
                        ),
                    )
                    if consumed.rowcount != 1:
                        raise LedgerError("host run handle is expired or already consumed")
                assignment_digest = keyed_digest(
                    self.state.digest_key(),
                    canonical_json(validate_assignment_shape(assignment)),
                )
                for attempt in checked_observation["result_attempts"]:
                    if attempt["status"] != "rejected":
                        continue
                    receipt = self._connection.execute(
                        "SELECT assignment_digest,reason_code,expires_at_ms,consumed_at_ms "
                        "FROM repair_receipts WHERE project_id=? AND receipt_id=?",
                        (project_id, attempt["receipt_id"]),
                    ).fetchone()
                    if (
                        receipt is None
                        or receipt["assignment_digest"] != assignment_digest
                        or receipt["reason_code"] != attempt["reason_code"]
                        or int(receipt["expires_at_ms"]) <= timestamp
                        or receipt["consumed_at_ms"] is not None
                    ):
                        raise LedgerError("result repair receipt is invalid")
                    receipt_consumed = self._connection.execute(
                        "UPDATE repair_receipts SET consumed_at_ms=?,run_id=? "
                        "WHERE project_id=? AND receipt_id=? AND consumed_at_ms IS NULL",
                        (
                            timestamp,
                            checked_observation["run_id"],
                            project_id,
                            attempt["receipt_id"],
                        ),
                    )
                    if receipt_consumed.rowcount != 1:
                        raise LedgerError("result repair receipt is invalid")
                event_result = self._append_checked_locked(
                    project_id, event, producer="host", timestamp=timestamp
                )
                self._validate_evidence_links_locked(project_id, outcome)
                outcome_result = self._append_checked_locked(
                    project_id, outcome, producer="host", timestamp=timestamp
                )
                if stored_result is not None and stored_result["created"]:
                    self._connection.execute(
                        "INSERT INTO stored_files VALUES(?,?,?,?,?,?,?)",
                        (
                            project_id,
                            stored_result["file_id"],
                            "artifact",
                            stored_result["relative_path"],
                            stored_result["result_digest"],
                            outcome["record_id"],
                            timestamp + WORKER_RESULT_RETENTION_MS,
                        ),
                    )
                self._connection.execute("COMMIT")
            except Exception:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                if stored_result is not None and stored_result["created"]:
                    with contextlib.suppress(OSError):
                        (self.state.root / stored_result["relative_path"]).unlink()
                raise
        self.state.harden_database_files()
        return {
            "event": event,
            "outcome": outcome,
            # The one identifier for this outcome: operational QA, routing
            # evidence and verification_for_outcome all take it.
            "host_outcome_digest": host_outcome_digest,
            "worker_result_stored": stored_result is not None,
            "event_commit": event_result,
            "outcome_commit": outcome_result,
            **({"dispatch_diagnostics": dispatch_diagnostics} if dispatch_diagnostics else {}),
        }

    def _write_worker_result(
        self, project_id: str, outcome_digest: str, result: dict[str, Any]
    ) -> dict[str, Any]:
        """Write a run's validated result to an owner-only artifact file.

        The database never holds result text: it registers the file under the
        keyed result digest the outcome already cites, and the file expires and
        is deleted with the outcome and with the project. Any failure refuses
        the commit before the run is consumed; a verification-required result
        is never recorded without its file.
        """

        payload = canonical_json(result)
        if len(payload) > MAX_WORKER_RESULT_BYTES:
            raise LedgerError(
                "host result is too large to keep for its verifier as canonical JSON"
            )
        file_id = f"host_result_{outcome_digest}"
        try:
            path = self._write_owner_file("artifact", project_id, file_id, payload)
        except FileExistsError as exc:
            # The existing file is never replaced. When it is already registered
            # for this exact outcome, the outcome is a replay: its kept result is
            # already there, and the commit refuses or stands on its own checks.
            # An unregistered file is an interrupted commit, removed at the next
            # ledger start, and refuses this one.
            with self._held():
                registered = self._connection.execute(
                    "SELECT relative_path,content_digest FROM stored_files "
                    "WHERE project_id=? AND file_id=? AND kind='artifact'",
                    (project_id, file_id),
                ).fetchone()
            digest = keyed_digest(self.state.digest_key(), payload)
            if registered is None or str(registered["content_digest"]) != digest:
                raise LedgerError(
                    "host result file for this outcome already exists"
                ) from exc
            return {
                "file_id": file_id,
                "relative_path": str(registered["relative_path"]),
                "result_digest": digest,
                "created": False,
            }
        except OSError as exc:
            raise LedgerError("host result file could not be written") from exc
        return {
            "file_id": file_id,
            "relative_path": path.relative_to(self.state.root).as_posix(),
            "result_digest": keyed_digest(self.state.digest_key(), payload),
            "created": True,
        }

    def _read_worker_result_locked(
        self, project_id: str, outcome: dict[str, Any], outcome_digest: str
    ) -> dict[str, Any]:
        row = self._connection.execute(
            "SELECT relative_path,content_digest,source_record_id,expires_at_ms "
            "FROM stored_files WHERE project_id=? AND file_id=? AND kind='artifact'",
            (project_id, f"host_result_{outcome_digest}"),
        ).fetchone()
        if row is None or row["source_record_id"] != outcome["record_id"]:
            raise LedgerError("the worker result for verification_for_outcome is unavailable")
        if row["expires_at_ms"] is None or int(row["expires_at_ms"]) <= self._clock_ms():
            # Past its retention it is never handed on, swept or not.
            raise LedgerError(
                "the worker result for verification_for_outcome is unavailable: it expired"
            )
        path = self.state.root / str(row["relative_path"])
        try:
            _assert_no_symlink_components(path)
            descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
            with os.fdopen(descriptor, "rb") as handle:
                if not stat.S_ISREG(os.fstat(handle.fileno()).st_mode):
                    raise OSError("not a regular file")
                payload = handle.read(MAX_WORKER_RESULT_BYTES + 1)
        except (OSError, StateError) as exc:
            raise LedgerError(
                "the worker result for verification_for_outcome is unavailable"
            ) from exc
        digest = keyed_digest(self.state.digest_key(), payload)
        if (
            len(payload) > MAX_WORKER_RESULT_BYTES
            or not secrets.compare_digest(digest, str(row["content_digest"]))
            or digest not in outcome["evidence_digests"]
        ):
            raise LedgerError("the worker result for verification_for_outcome is invalid")
        result = json.loads(payload)
        if canonical_json(result) != payload:
            raise LedgerError("the worker result for verification_for_outcome is invalid")
        return result

    def _bridge_usage_locked(self, project_id: str, run_id: str) -> dict[str, Any] | None:
        """Map a bridged run's recorded provider usage onto the outcome usage fields.

        Claude reports cache reads and writes apart from input, so they are
        added back to make the input total; a count that cannot be known, or
        a pair the outcome contract rejects, stays unknown.
        """

        rows = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? AND record_type='provider_usage' "
            "AND source='provider' AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
            (project_id, run_id),
        ).fetchall()
        if len(rows) != 1:
            return None
        recorded = json.loads(bytes(rows[0]["content"]))
        inputs = recorded["input_tokens"]
        cached = recorded["cached_input_tokens"]
        if recorded["provider"] == "claude":
            parts = (inputs, cached, recorded["cache_creation_input_tokens"])
            inputs = None if any(part is None for part in parts) else sum(parts)
        outputs = recorded["output_tokens"]
        reasoning = recorded["reasoning_output_tokens"]
        if cached is not None and inputs is not None and cached > inputs:
            cached = None
        if reasoning is not None and outputs is not None and reasoning > outputs:
            reasoning = None
        return {
            **empty_usage(),
            "input_tokens": inputs,
            "cached_tokens": cached,
            "output_tokens": outputs,
            "reasoning_tokens": reasoning,
        }

    def _operational_qa_scope_locked(
        self,
        project_id: str,
        host_outcome_digest: str,
        verifier_host_outcome_digest: str,
    ) -> tuple[dict[str, Any], dict[str, Any], str]:
        for digest in (host_outcome_digest, verifier_host_outcome_digest):
            if not isinstance(digest, str) or not HOST_OUTCOME_DIGEST.fullmatch(digest):
                # Record identifiers (`out:...`) are not accepted: QA takes the
                # host_outcome_digest that learning-record-host-result prints.
                raise LedgerError(
                    "operational QA takes the host_outcome_digest printed by "
                    "learning-record-host-result"
                )
        host_row = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? AND content_digest=? "
            "AND record_type='outcome' AND source='host'",
            (project_id, host_outcome_digest),
        ).fetchone()
        verifier_row = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? AND content_digest=? "
            "AND record_type='outcome' AND source='host'",
            (project_id, verifier_host_outcome_digest),
        ).fetchone()
        if host_row is None or verifier_row is None:
            raise LedgerError("operational QA requires two durable host outcomes")
        host_outcome = json.loads(bytes(host_row["content"]))
        verifier_host_outcome = json.loads(bytes(verifier_row["content"]))
        binding_rows = self._connection.execute(
            "SELECT run_id,orchestration_id,native_assignment_id "
            "FROM host_run_bindings WHERE project_id=? AND run_id IN (?,?)",
            (
                project_id,
                host_outcome["run_id"],
                verifier_host_outcome["run_id"],
            ),
        ).fetchall()
        if (
            len(binding_rows) != 2
            or any(row["orchestration_id"] is None for row in binding_rows)
            or len({str(row["orchestration_id"]) for row in binding_rows}) != 1
            or any(row["native_assignment_id"] is None for row in binding_rows)
            or len({str(row["native_assignment_id"]) for row in binding_rows}) != 2
        ):
            raise LedgerError(
                "operational QA requires two distinct native agents in one orchestration"
            )
        orchestration_id = str(binding_rows[0]["orchestration_id"])
        orchestration = self._connection.execute(
            "SELECT status FROM orchestrations WHERE project_id=? AND orchestration_id=?",
            (project_id, orchestration_id),
        ).fetchone()
        if orchestration is None or orchestration["status"] != "active":
            raise LedgerError("operational QA requires an active orchestration")
        self._operational_verifier_provider_locked(
            project_id, host_outcome, verifier_host_outcome
        )
        bindings = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? "
            "AND record_type='verification_binding' AND source='lifecycle' "
            "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
            (project_id, verifier_host_outcome["run_id"]),
        ).fetchall()
        if len(bindings) != 1:
            raise LedgerError(
                "operational QA requires a verifier opened with verification_for_outcome"
            )
        if json.loads(bytes(bindings[0]["content"]))["worker_outcome_digest"] != (
            host_outcome_digest
        ):
            raise LedgerError(
                "operational QA verifier was opened for another worker outcome"
            )
        return host_outcome, verifier_host_outcome, orchestration_id

    def _operational_verifier_provider_locked(
        self,
        project_id: str,
        host_outcome: dict[str, Any],
        verifier_host_outcome: dict[str, Any],
    ) -> None:
        """Bind the verifier's role to its admitted provider and to the worker's.

        The verifier outcome's role and model are those of the route its run was
        opened with (the ledger bound that configuration at open and commit), so
        they must be the verification role and a model of the provider the run
        was admitted for. A Claude verifier must be the other provider than the
        worker. A Codex verifier of a Codex worker stays valid, because a
        Codex-only project has no other provider to verify with.
        """

        roles = {
            "codex": "codex_agents_verification_worker",
            "claude": "claude_agents_verification_worker",
        }
        worker_provider = self._run_admission_locked(
            project_id, host_outcome["run_id"]
        )["provider"]
        verifier_provider = self._run_admission_locked(
            project_id, verifier_host_outcome["run_id"]
        )["provider"]
        try:
            model_provider = provider_for_model(verifier_host_outcome["model"])
        except ContractError as exc:
            raise LedgerError("operational verifier model is not a provider model") from exc
        if (
            verifier_host_outcome["role"] != roles.get(verifier_provider)
            or model_provider != verifier_provider
        ):
            raise LedgerError(
                "operational verifier role is not the route role of its admitted provider"
            )
        if verifier_provider == worker_provider and verifier_provider != "codex":
            raise LedgerError(
                "operational verifier must be the other provider than the worker"
            )

    def validate_operational_qa_scope(
        self,
        project_id: str,
        *,
        host_outcome_digest: str,
        verifier_host_outcome_digest: str,
    ) -> dict[str, Any]:
        """Validate the two exact runs before executing project-approved checks."""

        with self._held():
            _, _, orchestration_id = self._operational_qa_scope_locked(
                project_id, host_outcome_digest, verifier_host_outcome_digest
            )
        return {"ready": True, "orchestration_id": orchestration_id}

    def verification_worker_result(
        self,
        project_id: str,
        task: dict[str, Any],
        *,
        orchestration_handle: str | None = None,
        run_handle: str | None = None,
        with_result: bool = True,
    ) -> dict[str, Any] | None:
        """Resolve a verification task's bound worker outcome and its recorded result.

        Returns None for a task without `verification_for_outcome`. Otherwise the
        outcome must be a host outcome of this project, from a non-verification
        run of the task's `verification_for_family`, admitted for the provider
        named in `verification_for_provider`, in an active orchestration; with
        an orchestration or run handle, that orchestration must be the handle's.
        The result is read from the ledger and checked against the digest the
        outcome cites, so a primary can never substitute it. `with_result=False`
        checks the binding only, so a verifier that already ran can be recorded.
        """

        checked = validate_task(task)
        digest = checked.get("verification_for_outcome")
        if digest is None:
            return None
        with self._held():
            rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type='outcome' "
                "AND source='host' AND content_digest=?",
                (project_id, digest),
            ).fetchall()
            if len(rows) != 1:
                raise LedgerError("verification_for_outcome is not a recorded host outcome")
            outcome = json.loads(bytes(rows[0]["content"]))
            if outcome["task_slice"].startswith("verification-") or (
                outcome["task_slice"].split("-")[0] != checked["verification_for_family"]
            ):
                raise LedgerError(
                    "verification_for_outcome is not a worker outcome of "
                    "verification_for_family"
                )
            binding = self._connection.execute(
                "SELECT orchestration_id FROM host_run_bindings "
                "WHERE project_id=? AND run_id=?",
                (project_id, outcome["run_id"]),
            ).fetchone()
            if binding is None or binding["orchestration_id"] is None:
                raise LedgerError("verification_for_outcome has no orchestration")
            orchestration_id = str(binding["orchestration_id"])
            orchestration = self._connection.execute(
                "SELECT status FROM orchestrations WHERE project_id=? "
                "AND orchestration_id=?",
                (project_id, orchestration_id),
            ).fetchone()
            if orchestration is None or orchestration["status"] != "active":
                raise LedgerError("verification_for_outcome orchestration is not active")
            try:
                admission = self._run_admission_locked(project_id, outcome["run_id"])
            except LedgerError as exc:
                raise LedgerError(
                    "verification_for_outcome has no admitted provider"
                ) from exc
            if admission["provider"] != checked["verification_for_provider"]:
                raise LedgerError(
                    "verification_for_outcome comes from another provider than "
                    "verification_for_provider"
                )
            if orchestration_handle is not None:
                current = self._orchestration_for_handle_locked(
                    project_id, orchestration_handle
                )
                if str(current["orchestration_id"]) != orchestration_id:
                    raise LedgerError(
                        "verification_for_outcome belongs to another orchestration"
                    )
            if run_handle is not None:
                verifier = self._connection.execute(
                    "SELECT orchestration_id FROM host_run_bindings "
                    "WHERE project_id=? AND handle_digest=?",
                    (project_id, keyed_digest(self.state.digest_key(), run_handle)),
                ).fetchone()
                if verifier is None or verifier["orchestration_id"] != orchestration_id:
                    raise LedgerError(
                        "verification_for_outcome belongs to another orchestration"
                    )
            worker_result = (
                self._read_worker_result_locked(project_id, outcome, digest)
                if with_result else None
            )
        return {
            "host_outcome_digest": digest,
            "provider": admission["provider"],
            "orchestration_id": orchestration_id,
            "worker_result": worker_result,
        }

    def provider_attestation_status(self, project_id: str) -> dict[str, Any]:
        """Display only, using admission's owner-verified project/account lookup."""

        from .providers import _latest

        report = {}
        with self._held():
            for provider in ("codex", "claude"):
                identity = _latest(self._provider_records_locked(
                    project_id, "provider_identity", provider
                ))
                attestations = self._provider_records_locked(
                    project_id, "billing_attestation", provider
                )
                if identity is None:
                    status = "identity_missing"
                else:
                    fingerprint = identity[0]["account_fingerprint"]
                    attestation = _latest([
                        item for item in attestations
                        if item[0]["account_fingerprint"] == fingerprint
                    ])
                    status = "present" if attestation is not None else "missing"
                report[provider] = {"state": status}
        return report

    def billing_waived_by_attestation(
        self, project_id: str, record: dict[str, Any]
    ) -> bool:
        """Whether admission would read this billing record's credits as not usable.

        The same rule and the same attestation admission uses: the project's
        latest owner-verified attestation for the record's account.
        """

        from .providers import _latest, credits_waived

        provider = record.get("provider")
        if provider != "codex":
            # The original rule never waives Claude overage. No owner-signature
            # lookup or second connection is needed to display that fixed fact.
            return credits_waived(provider, record, None)
        with self._held():
            attestations = self._provider_records_locked(
                project_id, "billing_attestation", provider
            )
        attestation = _latest([
            item for item in attestations
            if item[0]["account_fingerprint"] == record.get("account_fingerprint")
        ])
        return credits_waived(
            provider, record, None if attestation is None else attestation[0]
        )

    def issue_operational_check_receipt(
        self,
        project_id: str,
        *,
        host_outcome_digest: str,
        verifier_host_outcome_digest: str,
        check_report: dict[str, Any],
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Bind a trusted runner's closed report to two runs with a single-use receipt."""

        from .learning_engine import _check_report_digests

        if not isinstance(check_report, dict) or set(check_report) != {
            "deterministic_checks", "security_checks", "observed_at_ms"
        }:
            raise LedgerError("operational check report is invalid")
        try:
            _, deterministic_pass = _check_report_digests(
                check_report["deterministic_checks"], "deterministic_checks"
            )
            _, security_pass = _check_report_digests(
                check_report["security_checks"], "security_checks"
            )
        except ContractError as exc:
            raise LedgerError("operational check report is invalid") from exc
        observed_at_ms = check_report["observed_at_ms"]
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        if (
            not isinstance(observed_at_ms, int)
            or isinstance(observed_at_ms, bool)
            or observed_at_ms > timestamp + 1_000
        ):
            raise LedgerError("operational check report time is invalid")
        receipt_id = f"oqc_{secrets.token_hex(24)}"
        with self._held(), self._connection:
            host, verifier, orchestration_id = self._operational_qa_scope_locked(
                project_id, host_outcome_digest, verifier_host_outcome_digest
            )
            if observed_at_ms < max(
                int(host["observed_at_ms"]), int(verifier["observed_at_ms"])
            ):
                raise LedgerError("operational check report predates its runs")
            self._connection.execute(
                "DELETE FROM operational_check_receipts "
                "WHERE project_id=? AND expires_at_ms<=?",
                (project_id, timestamp),
            )
            pending = int(
                self._connection.execute(
                    "SELECT COUNT(*) FROM operational_check_receipts "
                    "WHERE project_id=? AND consumed_at_ms IS NULL",
                    (project_id,),
                ).fetchone()[0]
            )
            if pending >= MAX_PENDING_OPERATIONAL_CHECKS:
                raise LedgerError("pending operational check capacity is exhausted")
            report_digest = content_digest(check_report)
            self._connection.execute(
                "INSERT INTO operational_check_receipts VALUES(?,?,?,?,?,?,?,?,NULL,?)",
                (
                    project_id,
                    receipt_id,
                    report_digest,
                    host_outcome_digest,
                    verifier_host_outcome_digest,
                    orchestration_id,
                    timestamp,
                    timestamp + OPERATIONAL_CHECK_TTL_MS,
                    canonical_json(check_report),
                ),
            )
        self.state.harden_database_files()
        return {
            "check_receipt": receipt_id,
            "check_report_digest": report_digest,
            "checks_passed": deterministic_pass and security_pass,
            "expires_at_ms": timestamp + OPERATIONAL_CHECK_TTL_MS,
        }

    def commit_operational_qa(
        self,
        project_id: str,
        *,
        host_outcome_digest: str,
        verifier_host_outcome_digest: str,
        evaluator_assignment: dict[str, Any],
        evaluator_result: dict[str, Any],
        check_receipt: str,
        verifier_assignment: dict[str, Any],
        verifier_result: dict[str, Any],
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Atomically admit routine independent QA and its superseding outcome."""

        if not isinstance(check_receipt, str) or not re.fullmatch(
            r"oqc_[0-9a-f]{48}", check_receipt
        ):
            raise LedgerError("operational check receipt is invalid")
        current_time = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held():
            host_outcome, verifier_host_outcome, orchestration_id = (
                self._operational_qa_scope_locked(
                    project_id, host_outcome_digest, verifier_host_outcome_digest
                )
            )
            receipt = self._connection.execute(
                "SELECT report_digest,host_outcome_digest,"
                "verifier_host_outcome_digest,orchestration_id,expires_at_ms,"
                "consumed_at_ms,report FROM operational_check_receipts "
                "WHERE project_id=? AND receipt_id=?",
                (
                    project_id,
                    check_receipt,
                ),
            ).fetchone()
        if (
            receipt is None
            or receipt["host_outcome_digest"] != host_outcome_digest
            or receipt["verifier_host_outcome_digest"] != verifier_host_outcome_digest
            or receipt["orchestration_id"] != orchestration_id
            or int(receipt["expires_at_ms"]) <= current_time
            or receipt["consumed_at_ms"] is not None
        ):
            raise LedgerError("operational check receipt is unavailable")
        check_report = json.loads(bytes(receipt["report"]))
        if content_digest(check_report) != receipt["report_digest"]:
            raise LedgerError("operational check receipt report is invalid")
        from .learning_engine import build_operational_qa_records

        try:
            qa, outcome = build_operational_qa_records(
                digest_key=self.state.digest_key(),
                host_outcome=host_outcome,
                verifier_host_outcome=verifier_host_outcome,
                evaluator_assignment=evaluator_assignment,
                evaluator_result=evaluator_result,
                check_report=check_report,
                verifier_assignment=verifier_assignment,
                verifier_result=verifier_result,
            )
        except ContractError as exc:
            raise LedgerError("operational QA admission rejected") from exc
        qa_digest = content_digest(qa)
        timestamp = int(qa["observed_at_ms"])
        with self._held():
            self._connection.execute("BEGIN IMMEDIATE")
            try:
                consumed = self._connection.execute(
                    "UPDATE operational_check_receipts SET consumed_at_ms=? "
                    "WHERE project_id=? AND receipt_id=? AND consumed_at_ms IS NULL "
                    "AND expires_at_ms>?",
                    (current_time, project_id, check_receipt, current_time),
                )
                if consumed.rowcount != 1:
                    raise LedgerError("operational check receipt is unavailable")
                existing = self._connection.execute(
                    "SELECT qa_digest FROM operational_qa WHERE project_id=? "
                    "AND host_outcome_digest=?",
                    (project_id, host_outcome_digest),
                ).fetchone()
                if existing is not None:
                    raise LedgerError("host outcome already has operational QA")
                self._connection.execute(
                    "INSERT INTO operational_qa VALUES(?,?,?,?,?,?,?,?)",
                    (
                        project_id,
                        qa["record_id"],
                        qa_digest,
                        host_outcome_digest,
                        verifier_host_outcome_digest,
                        int(qa["accepted"]),
                        timestamp,
                        canonical_json(qa),
                    ),
                )
                self._validate_evidence_links_locked(project_id, outcome)
                outcome_commit = self._append_checked_locked(
                    project_id, outcome, producer="verifier", timestamp=timestamp
                )
                self._connection.execute("COMMIT")
            except Exception:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
        self.state.harden_database_files()
        return {
            "qa": qa,
            "outcome": outcome,
            "stored": True,
            "duplicate": False,
            "outcome_commit": outcome_commit,
            "attention_required": not qa["accepted"],
        }

    def prepare_verified_evaluation_outcome(
        self,
        project_id: str,
        *,
        evaluation_assignment_digest: str,
        host_outcome_digest: str,
        verifier_host_outcome_digest: str,
        evaluator_assignment: dict[str, Any],
        evaluator_result: dict[str, Any],
        check_report: dict[str, Any],
        verifier_assignment: dict[str, Any],
        verifier_result: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Prepare exact QA bytes from two durable host-bound executions."""

        with self._held():
            assignment_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND content_digest=? "
                "AND record_type='evaluation_assignment'",
                (project_id, evaluation_assignment_digest),
            ).fetchone()
            host_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND content_digest=? "
                "AND record_type='outcome' AND source='host'",
                (project_id, host_outcome_digest),
            ).fetchone()
            verifier_host_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND content_digest=? "
                "AND record_type='outcome' AND source='host'",
                (project_id, verifier_host_outcome_digest),
            ).fetchone()
            if (
                assignment_row is None
                or host_row is None
                or verifier_host_row is None
            ):
                raise LedgerError(
                    "verified QA requires durable assignment, evaluator, and verifier runs"
                )
            assignment_record = json.loads(bytes(assignment_row["content"]))
            planned = [
                item for item in assignment_record["trial_plan"]
                if item["trial_id"] == evaluator_assignment.get("assignment_id")
            ]
            if len(planned) != 1:
                raise LedgerError("verified QA trial is not in the durable assignment")
            case_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_id=? "
                "AND record_type='evaluation_case'",
                (project_id, planned[0]["case_id"]),
            ).fetchone()
            if case_row is None:
                raise LedgerError("verified QA evaluation case is unavailable")
            case_record = json.loads(bytes(case_row["content"]))
            host_record = json.loads(bytes(host_row["content"]))
            verifier_host_record = json.loads(bytes(verifier_host_row["content"]))
        from .learning_engine import build_verified_qa_records

        try:
            qa, outcome = build_verified_qa_records(
                digest_key=self.state.digest_key(),
                host_outcome=host_record,
                verifier_host_outcome=verifier_host_record,
                evaluation_assignment=assignment_record,
                evaluation_case=case_record,
                evaluator_assignment=evaluator_assignment,
                evaluator_result=evaluator_result,
                check_report=check_report,
                verifier_assignment=verifier_assignment,
                verifier_result=verifier_result,
            )
        except ContractError as exc:
            raise LedgerError("verified QA evidence admission rejected") from exc
        return qa, outcome

    def commit_verified_evaluation_outcome(
        self,
        project_id: str,
        *,
        evaluation_assignment_digest: str,
        host_outcome_digest: str,
        verifier_host_outcome_digest: str,
        evaluator_assignment: dict[str, Any],
        evaluator_result: dict[str, Any],
        check_report: dict[str, Any],
        verifier_assignment: dict[str, Any],
        verifier_result: dict[str, Any],
        signature: bytes,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Commit exact owner-attested QA backed by evaluator and verifier runs."""

        qa, outcome = self.prepare_verified_evaluation_outcome(
            project_id,
            evaluation_assignment_digest=evaluation_assignment_digest,
            host_outcome_digest=host_outcome_digest,
            verifier_host_outcome_digest=verifier_host_outcome_digest,
            evaluator_assignment=evaluator_assignment,
            evaluator_result=evaluator_result,
            check_report=check_report,
            verifier_assignment=verifier_assignment,
            verifier_result=verifier_result,
        )
        from .learning_engine import OwnerGrantAuthority

        authority = OwnerGrantAuthority.for_state(self.state)
        if not authority.verify_qa_attestation(project_id, qa, signature):
            raise LedgerError("verified QA attestation is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            qa_result = self._append_checked_locked(
                project_id, qa, producer="verifier", timestamp=timestamp
            )
            self._validate_evidence_links_locked(project_id, outcome)
            outcome_result = self._append_checked_locked(
                project_id, outcome, producer="evaluator", timestamp=timestamp
            )
            receipt = self._connection.execute(
                "SELECT signature FROM owner_attestations "
                "WHERE project_id=? AND subject_record_id=?",
                (project_id, qa["record_id"]),
            ).fetchone()
            if receipt and bytes(receipt["signature"]) != signature:
                raise LedgerError("verified QA attestation conflicts")
            self._connection.execute(
                "INSERT OR IGNORE INTO owner_attestations VALUES(?,?,?,?)",
                (project_id, qa["record_id"], signature, timestamp),
            )
        self.state.harden_database_files()
        return {
            "qa_evidence": qa,
            "outcome": outcome,
            "qa_commit": qa_result,
            "outcome_commit": outcome_result,
        }

    def commit_evidence_review(
        self,
        project_id: str,
        *,
        subject_digests: list[str],
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Record a deterministic post-population review of verified subjects."""

        subjects = sorted(subject_digests)
        if not subjects or len(subjects) != len(set(subjects)):
            raise LedgerError("evidence review subjects are invalid")
        with self._held():
            rows = self._connection.execute(
                "SELECT record_type,content,content_digest FROM records "
                "WHERE project_id=?",
                (project_id,),
            ).fetchall()
            by_digest = {
                str(row["content_digest"]): (
                    str(row["record_type"]), json.loads(bytes(row["content"]))
                )
                for row in rows
            }
            qa_rows = {
                str(row["content_digest"]): json.loads(bytes(row["content"]))
                for row in rows
                if row["record_type"] == "qa_evidence"
            }
            attestations = {
                str(row[0]) for row in self._connection.execute(
                    "SELECT subject_record_id FROM owner_attestations WHERE project_id=?",
                    (project_id,),
                ).fetchall()
            }
            for digest in subjects:
                stored = by_digest.get(digest)
                if stored is None or stored[0] not in {"evaluation_trial", "outcome"}:
                    raise LedgerError("evidence review subject is unavailable")
                record = stored[1]
                outcome = record
                if stored[0] == "evaluation_trial":
                    linked = by_digest.get(record["outcome_digest"])
                    if linked is None or linked[0] != "outcome":
                        raise LedgerError("evidence review trial outcome is unavailable")
                    outcome = linked[1]
                linked_qa = [
                    qa for qa_digest, qa in qa_rows.items()
                    if qa_digest in outcome["evidence_digests"]
                ]
                if (
                    len(linked_qa) != 1
                    or linked_qa[0]["record_id"] not in attestations
                ):
                    raise LedgerError("evidence review subject lacks attested QA")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        material = {
            "schema_version": 1,
            "record_type": "evidence_review",
            "subject_digests": subjects,
            "accepted": True,
            "observed_at_ms": timestamp,
        }
        checked = validate_learning_record(
            {
                **material,
                "record_id": f"evidence_review:{content_digest(material)}",
            }
        )
        with self._held(), self._connection:
            result = self._append_checked_locked(
                project_id, checked, producer="verifier", timestamp=timestamp
            )
        self.state.harden_database_files()
        return {"record": checked, **result}

    def commit_owner_record(
        self,
        project_id: str,
        *,
        record: dict[str, Any],
        signature: bytes,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Verify and atomically store signed owner feedback or calibration."""

        try:
            checked = validate_learning_record(record)
        except ContractError as exc:
            raise LedgerError("record admission rejected") from exc
        if checked["record_type"] not in {
            "feedback", "grader_calibration", "billing_attestation", "run_slot_confirmation"
        }:
            raise LedgerError("authenticated owner record type is unsupported")
        from .learning_engine import OwnerGrantAuthority

        with self._held():
            # A key added while this ledger was already open (a new machine: register, then
            # attest) is recorded before its first signature counts, as opening would have.
            if not self._connection.in_transaction and self._owner_generation_locked() is None:
                self._record_first_owner_key()
        authority = OwnerGrantAuthority.for_state(self.state)
        if not authority.verify_owner_record(project_id, checked, signature):
            raise LedgerError("owner record signature is invalid")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._write_unit():
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            if checked["record_type"] == "run_slot_confirmation":
                slots = self._connection.execute(
                    "SELECT * FROM active_run_capacity WHERE project_id=? AND run_id=? AND kind='legacy_unknown'"
                    + (" AND handle_digest=?" if "handle_digest" in checked else ""),
                    (project_id, checked["run_id"], *((checked["handle_digest"],) if "handle_digest" in checked else ()))
                ).fetchall()
                # A record naming only a run id is honoured only when it names exactly one slot.
                slot = slots[0] if len(slots) == 1 else None
                if slot is None:
                    raise LedgerError("slot confirmation is unavailable")
                if slot["released_at_ms"] is None:
                    self._release_slot_locked(project_id, slot["handle_digest"], "owner_confirmed",
                                              self._clock_ms(), self._capacity_clock_reference(),
                                              proof={"record_digest": content_digest(checked)})
                else:
                    release = self._connection.execute(
                        "SELECT release_kind FROM run_holds WHERE project_id=? AND kind='run_slot' AND identity=?",
                        (project_id, slot["handle_digest"])).fetchone()
                    if release is None or release["release_kind"] != "owner_confirmed":
                        raise LedgerError("slot confirmation is unavailable")
            self._validate_evidence_links_locked(project_id, checked)
            result = self._append_checked_locked(
                project_id, checked, producer="owner", timestamp=timestamp
            )
            receipt = self._connection.execute(
                "SELECT signature FROM owner_attestations "
                "WHERE project_id=? AND subject_record_id=?",
                (project_id, checked["record_id"]),
            ).fetchone()
            if receipt and bytes(receipt["signature"]) != signature:
                raise LedgerError("owner record attestation conflicts")
            self._connection.execute(
                "INSERT OR IGNORE INTO owner_attestations VALUES(?,?,?,?)",
                (project_id, checked["record_id"], signature, timestamp),
            )
        self.state.harden_database_files()
        return result

    def _validate_evidence_links_locked(
        self, project_id: str, checked: dict[str, Any]
    ) -> None:
        if checked["record_type"] == "candidate":
            linked = checked["evidence_digests"]
            placeholders = ",".join("?" for _ in linked)
            try:
                evidence_rows = self._connection.execute(
                    "SELECT record_type,content,content_digest FROM records INDEXED BY records_project_digest "
                    f"WHERE project_id=? AND content_digest IN ({placeholders})",
                    (project_id, *linked),
                ).fetchall()
            except sqlite3.OperationalError as error:
                # Only a missing/unusable index is "reopen"; busy, locked and I/O errors keep their own answers.
                if "no such index" not in str(error) and "no query solution" not in str(error):
                    raise
                raise LedgerError("candidate evidence lookup is unavailable; reopen the ledger") from None
            evidence = {
                str(row["content_digest"]): (
                    str(row["record_type"]), json.loads(bytes(row["content"]))
                )
                for row in evidence_rows
            }
            if not checked["evidence_digests"] or any(
                digest not in evidence for digest in checked["evidence_digests"]
            ):
                raise LedgerError("candidate evidence is not durable project evidence")
            configuration_fields = set(checked["champion_configuration"])
            if not any(
                kind == "outcome"
                and record["task_slice"] == checked["task_slice"]
                and {
                    field: record[field] for field in configuration_fields
                } == checked["champion_configuration"]
                for digest in checked["evidence_digests"]
                for kind, record in [evidence[digest]]
            ):
                raise LedgerError(
                    "candidate champion lacks matching durable outcome evidence"
                )
            if self._candidate_evidence_invalidated_locked(project_id, checked):
                raise LedgerError("candidate evidence was invalidated by owner feedback")
            return
        if checked["record_type"] == "feedback":
            outcomes = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type='outcome'",
                (project_id,),
            ).fetchall()
            if not any(
                json.loads(bytes(row["content"]))["run_id"] == checked["run_id"]
                for row in outcomes
            ):
                raise LedgerError("owner feedback run is not admitted")
            return
        if checked["record_type"] == "outcome":
            event_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type='event' "
                "AND source='host'",
                (project_id,),
            ).fetchall()
            linked_events = [
                event
                for row in event_rows
                if (
                    (event := json.loads(bytes(row["content"]))) ["run_id"]
                    == checked["run_id"]
                    and event["assignment_id"] == checked["assignment_id"]
                    and event["model"] == checked["model"]
                    and event["effort"] == checked["effort"]
                    and event["role"] == checked["role"]
                    and event["task_slice"] == checked["task_slice"]
                    and event["topology"] == checked["topology"]
                    and event["configuration_digest"]
                    == checked["configuration_digest"]
                    and event["coverage"] == checked["coverage"]
                )
            ]
            terminal_event = {
                "accepted": ({"item_completed", "turn_completed"}, {"completed"}),
                "rejected": ({"item_completed", "turn_completed"}, {"completed"}),
                "unverified": ({"item_completed", "turn_completed"}, {"completed"}),
                "failed": ({"turn_failed"}, {"failed"}),
                "interrupted": ({"turn_interrupted"}, {"interrupted"}),
                "cancelled": ({"turn_interrupted"}, {"cancelled"}),
            }[checked["status"]]
            qa_rows = self._connection.execute(
                "SELECT content,content_digest FROM records WHERE project_id=? "
                "AND record_type='qa_evidence' AND source='verifier'",
                (project_id,),
            ).fetchall()
            verified_host_digest = None
            for row in qa_rows:
                qa_digest = str(row["content_digest"])
                qa_record = json.loads(bytes(row["content"]))
                if qa_digest in checked["evidence_digests"]:
                    verified_host_digest = qa_record["host_outcome_digest"]
                    break
            verified_host = None
            if verified_host_digest is not None:
                verified_host = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND content_digest=? AND record_type='outcome' AND source='host'",
                    (project_id, verified_host_digest),
                ).fetchone()
            linked = any(
                (
                    event["event_code"] in terminal_event[0]
                    and event["status"] in terminal_event[1]
                    and event["item_digest"] is not None
                    and event["item_digest"] in checked["evidence_digests"]
                    and (
                        event["usage"] == checked["usage"]
                        or verified_host is not None
                    )
                )
                for event in linked_events
            )
            if not linked:
                raise LedgerError("outcome lacks completed host result provenance")
            if checked["evaluation_candidate_digest"] is not None:
                case_row = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='evaluation_case' AND content_digest=?",
                    (project_id, checked["evaluation_case_digest"]),
                ).fetchone()
                if case_row:
                    evaluation_case = json.loads(bytes(case_row["content"]))
                    if evaluation_case["corpus_state"] == "promotion_holdout":
                        assignment_rows = self._connection.execute(
                            "SELECT content FROM records WHERE project_id=? "
                            "AND record_type='evaluation_assignment'",
                            (project_id,),
                        ).fetchall()
                        matching_assignments = []
                        for row in assignment_rows:
                            assignment = json.loads(bytes(row["content"]))
                            plans = [
                                item for item in assignment["trial_plan"]
                                if item["trial_id"] == checked["assignment_id"]
                                and item["case_id"] == evaluation_case["record_id"]
                                and item["configuration_digest"]
                                == checked["evaluation_candidate_digest"]
                            ]
                            if assignment["client_digest"] == checked["client_digest"] and len(plans) == 1:
                                matching_assignments.append((assignment, plans[0]))
                        if len(matching_assignments) != 1:
                            raise LedgerError(
                                "evaluation outcome is not in a durable assignment"
                            )
                        assigned, planned = matching_assignments[0]
                        candidate_rows = self._connection.execute(
                            "SELECT content FROM records WHERE project_id=? "
                            "AND record_type='candidate'",
                            (project_id,),
                        ).fetchall()
                        candidates = [
                            json.loads(bytes(row["content"])) for row in candidate_rows
                        ]
                        candidates = [
                            candidate for candidate in candidates
                            if candidate["candidate_digest"]
                            == assigned["candidate_digest"]
                        ]
                        from .learning_engine import candidate_matches_outcome
                        if len(candidates) != 1 or not candidate_matches_outcome(
                            candidates[0], planned["cohort"], checked
                        ):
                            raise LedgerError(
                                "evaluation outcome does not match its candidate configuration"
                            )
                        existing_outcomes = self._connection.execute(
                            "SELECT content FROM records WHERE project_id=? "
                            "AND record_type='outcome' AND source='evaluator'",
                            (project_id,),
                        ).fetchall()
                        if any(
                            json.loads(bytes(row["content"]))["assignment_id"]
                            == checked["assignment_id"]
                            and json.loads(bytes(row["content"]))["record_id"]
                            != checked["record_id"]
                            for row in existing_outcomes
                        ):
                            raise LedgerError("evaluation assignment already has an outcome")
            return
        if checked["record_type"] == "evaluation_case":
            source = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_id=? "
                "AND record_type='outcome'",
                (project_id, checked["source_outcome_id"]),
            ).fetchone()
            previous_id = checked["supersedes_case_id"]
            previous = None if previous_id is None else self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_id=? "
                "AND record_type='evaluation_case'",
                (project_id, previous_id),
            ).fetchone()
            related_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_case' AND record_id<>?",
                (project_id, previous_id or checked["record_id"]),
            ).fetchall()
            try:
                check_evaluation_case(
                    checked,
                    source_outcome=json.loads(bytes(source["content"])) if source else None,
                    previous_case=json.loads(bytes(previous["content"])) if previous else None,
                    related_cases=(json.loads(bytes(row["content"])) for row in related_rows),
                    invalidated_run_ids=self._owner_invalidated_run_ids_locked(project_id),
                )
            except EligibilityError as error:
                raise LedgerError(str(error)) from None
            return
        if checked["record_type"] == "evaluation_assignment":
            candidate_rows = self._connection.execute(
                "SELECT content,source_sequence FROM records WHERE project_id=? "
                "AND record_type='candidate'",
                (project_id,),
            ).fetchall()
            matching_candidates = [
                row for row in candidate_rows
                if json.loads(bytes(row["content"]))["candidate_digest"]
                == checked["candidate_digest"]
            ]
            if len(matching_candidates) != 1:
                raise LedgerError("evaluation assignment candidate is missing")
            candidate_row = matching_candidates[0]
            candidate = json.loads(bytes(candidate_row["content"]))
            if self._candidate_evidence_invalidated_locked(project_id, candidate):
                raise LedgerError("evaluation candidate was invalidated by owner feedback")
            if candidate["task_slice"] != checked["task_slice"]:
                raise LedgerError("evaluation assignment task slice does not match")
            supported_paths = {"routing.model_effort"}
            if any(
                change["path_code"] not in supported_paths
                for change in candidate["change_manifest"]
            ):
                raise LedgerError(
                    "candidate target lacks exact evaluation configuration binding"
                )
            capability = self._client_capabilities.get(checked["client_version"])
            if (
                capability is None
                or content_digest(capability) != checked["client_digest"]
                or capability.get("app_server_coverage") != "end_to_end_complete"
                or capability.get("child_usage") is not True
                or capability.get("ordering_proven") is not True
            ):
                raise LedgerError("evaluation assignment client is not accepted")
            case_rows = self._connection.execute(
                "SELECT record_id,content,content_digest,source_sequence FROM records "
                "WHERE project_id=? AND record_type='evaluation_case'",
                (project_id,),
            ).fetchall()
            by_id = {str(row["record_id"]): row for row in case_rows}
            selected = [by_id.get(case_id) for case_id in checked["case_ids"]]
            if any(row is None for row in selected):
                raise LedgerError("evaluation assignment case is missing")
            selected_rows = [row for row in selected if row is not None]
            selected_cases = [json.loads(bytes(row["content"])) for row in selected_rows]
            source_run_ids = {
                str(row["record_id"]): json.loads(bytes(row["content"]))["run_id"]
                for row in self._connection.execute(
                    "SELECT record_id,content FROM records WHERE project_id=? "
                    "AND record_type='outcome'",
                    (project_id,),
                ).fetchall()
            }
            invalidated = self._owner_invalidated_run_ids_locked(project_id)
            if (
                [str(row["content_digest"]) for row in selected_rows]
                != checked["case_digests"]
                or any(
                    case["corpus_state"] not in {"promotion_holdout", "canary"}
                    or not case["reviewed"] or not case["frozen"]
                    or case["task_slice"] != checked["task_slice"]
                    for case in selected_cases
                )
                or len({case["corpus_state"] for case in selected_cases}) != 1
                or any(
                    source_run_ids.get(case["source_outcome_id"]) in invalidated
                    for case in selected_cases
                )
                or any(
                    int(row["source_sequence"]) >= int(candidate_row["source_sequence"])
                    for row in selected_rows
                )
            ):
                raise LedgerError(
                    "evaluation cases must be frozen before candidate generation"
                )
            from .learning_engine import deduplicate_cases
            duplicates = deduplicate_cases(selected_cases)
            if any(duplicates.values()):
                raise LedgerError("evaluation assignment contains corpus leakage")
            expected_configurations = {
                "candidate": candidate["candidate_digest"],
                "champion": candidate["base_digest"],
            }
            if any(
                item["configuration_digest"] != expected_configurations[item["cohort"]]
                for item in checked["trial_plan"]
            ):
                raise LedgerError("evaluation assignment configuration is invalid")
            return
        if checked["record_type"] == "evaluation_trial":
            case_row = self._connection.execute(
                "SELECT content,content_digest FROM records WHERE project_id=? "
                "AND record_id=? AND record_type='evaluation_case'",
                (project_id, checked["case_id"]),
            ).fetchone()
            outcome_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND content_digest=? "
                "AND record_type='outcome' AND source='evaluator'",
                (project_id, checked["outcome_digest"]),
            ).fetchone()
            capability = self._client_capabilities.get(checked["client_version"])
            assignment_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_assignment' AND content_digest=?",
                (project_id, checked["evaluation_assignment_digest"]),
            ).fetchone()
            if not case_row or not outcome_row or capability is None or not assignment_row:
                raise LedgerError("evaluation trial provenance is missing")
            case = json.loads(bytes(case_row["content"]))
            outcome = json.loads(bytes(outcome_row["content"]))
            if outcome["run_id"] in self._owner_invalidated_run_ids_locked(project_id):
                raise LedgerError("evaluation outcome was invalidated by owner feedback")
            assignment = json.loads(bytes(assignment_row["content"]))
            plan = [
                item for item in assignment["trial_plan"]
                if item["trial_id"] == checked["trial_id"]
            ]
            if len(plan) != 1:
                raise LedgerError("evaluation trial is not in its assignment")
            expected = {
                "case_id": plan[0]["case_id"],
                "cohort": plan[0]["cohort"],
                "task_slice": case["task_slice"],
                "configuration_digest": plan[0]["configuration_digest"],
                "coverage": outcome["coverage"],
                "deterministic_pass": outcome["deterministic_pass"],
                "security_pass": outcome["security_pass"],
                "required_criteria_pass": outcome["required_criteria_passed"]
                == outcome["required_criteria_total"],
                "quality_micros": outcome["quality_micros"],
                "terminal_failure": outcome["terminal_failure"],
                "repairs": outcome["repairs"],
                "input_tokens": outcome["usage"]["input_tokens"],
                "output_tokens": outcome["usage"]["output_tokens"],
                "model_calls": outcome["usage"]["model_calls"],
                "client_digest": content_digest(capability),
                "host_configuration_digest": outcome["configuration_digest"],
            }
            if (
                outcome["evaluation_case_digest"] != str(case_row["content_digest"])
                or outcome["assignment_id"] != checked["trial_id"]
                or any(checked[field] != value for field, value in expected.items())
            ):
                raise LedgerError("evaluation trial differs from persisted evidence")
            existing_trials = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_trial'",
                (project_id,),
            ).fetchall()
            if any(
                json.loads(bytes(row["content"]))["evaluation_assignment_digest"]
                == checked["evaluation_assignment_digest"]
                and json.loads(bytes(row["content"]))["trial_id"] == checked["trial_id"]
                and json.loads(bytes(row["content"]))["record_id"] != checked["record_id"]
                for row in existing_trials
            ):
                raise LedgerError("evaluation assignment trial already exists")
            return

        if checked["record_type"] == "promotion":
            self._validate_promotion_evidence_locked(project_id, checked)
            return
        if checked["record_type"] not in {"comparison", "canary_report"}:
            return
        candidate_rows = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? AND record_type='candidate'",
            (project_id,),
        ).fetchall()
        candidates = [json.loads(bytes(row["content"])) for row in candidate_rows]
        matching_candidates = [
            record for record in candidates
            if record["candidate_digest"] == checked["candidate_digest"]
        ]
        if len(matching_candidates) != 1:
            raise LedgerError("evaluation evidence candidate is not in this project")
        persisted_candidate = matching_candidates[0]
        if self._candidate_evidence_invalidated_locked(
            project_id, persisted_candidate
        ):
            raise LedgerError("candidate was invalidated by owner feedback")
        review_rows = self._connection.execute(
            "SELECT content,source_sequence FROM records WHERE project_id=? AND content_digest=? "
            "AND record_type='evidence_review' AND source='verifier'",
            (project_id, checked["independent_review_digest"]),
        ).fetchall()
        valid_reviews: list[dict[str, Any]] = []
        for row in review_rows:
            review = json.loads(bytes(row["content"]))
            review["_source_sequence"] = int(row["source_sequence"])
            if review.get("accepted") is True:
                valid_reviews.append(review)
        if not valid_reviews:
            raise LedgerError("independent verification evidence is missing")
        if checked["record_type"] == "comparison":
            assignment_row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_assignment' AND content_digest=?",
                (project_id, checked["evaluation_assignment_digest"]),
            ).fetchone()
            if not assignment_row:
                raise LedgerError("comparison evaluation assignment is missing")
            assignment = json.loads(bytes(assignment_row["content"]))
            if (
                assignment["candidate_digest"] != checked["candidate_digest"]
                or assignment["case_ids"] != checked["case_ids"]
                or assignment["case_digests"] != checked["case_digests"]
                or assignment["client_version"] != checked["client_version"]
                or assignment["client_digest"] != checked["client_digest"]
            ):
                raise LedgerError("comparison differs from its evaluation assignment")
            capability = self._client_capabilities.get(checked["client_version"])
            if (
                capability is None
                or content_digest(capability) != checked["client_digest"]
            ):
                raise LedgerError("comparison client is not in the accepted matrix")
            trial_rows = self._connection.execute(
                "SELECT content,content_digest,source_sequence FROM records WHERE project_id=? "
                "AND record_type='evaluation_trial'",
                (project_id,),
            ).fetchall()
            persisted_trials = {
                str(row["content_digest"]): json.loads(bytes(row["content"]))
                for row in trial_rows
            }
            trial_sequences = {
                str(row["content_digest"]): int(row["source_sequence"])
                for row in trial_rows
            }
            if any(digest not in persisted_trials for digest in checked["trial_digests"]):
                raise LedgerError("comparison trials are not durable project evidence")
            assigned_trials = [
                record for record in persisted_trials.values()
                if record["evaluation_assignment_digest"]
                == checked["evaluation_assignment_digest"]
            ]
            expected_trial_ids = sorted(
                item["trial_id"] for item in assignment["trial_plan"]
            )
            if (
                sorted(record["trial_id"] for record in assigned_trials)
                != expected_trial_ids
                or sorted(content_digest(record) for record in assigned_trials)
                != checked["trial_digests"]
            ):
                raise LedgerError("comparison does not contain the complete assigned population")
            if not any(
                review["subject_digests"] == sorted(checked["trial_digests"])
                and review["_source_sequence"]
                > max(trial_sequences[digest] for digest in checked["trial_digests"])
                for review in valid_reviews
            ):
                raise LedgerError(
                    "independent review predates or omits comparison trials"
                )
            if checked["grader_digest"] is not None:
                calibration = self._connection.execute(
                    "SELECT records.content FROM records JOIN owner_attestations "
                    "ON owner_attestations.project_id=records.project_id "
                    "AND owner_attestations.subject_record_id=records.record_id "
                    "WHERE records.project_id=? "
                    "AND records.record_type='grader_calibration' "
                    "AND records.content_digest=? AND records.source='owner'",
                    (project_id, checked["grader_digest"]),
                ).fetchone()
                if (
                    not calibration
                    or json.loads(bytes(calibration["content"]))["ready"] is not True
                ):
                    raise LedgerError(
                        "comparison grader calibration is missing or not ready"
                    )
            rows = self._connection.execute(
                "SELECT record_id,content_digest FROM records WHERE project_id=? "
                "AND record_type='evaluation_case'",
                (project_id,),
            ).fetchall()
            present = {
                str(row["record_id"]): str(row["content_digest"]) for row in rows
            }
            expected_cases = dict(zip(checked["case_ids"], checked["case_digests"]))
            if any(present.get(case_id) != digest for case_id, digest in expected_cases.items()):
                raise LedgerError("comparison cases are not in this project")
            selected_trials = [
                persisted_trials[digest] for digest in checked["trial_digests"]
            ]
            selected_outcomes = []
            for trial in selected_trials:
                row = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='outcome' AND content_digest=?",
                    (project_id, trial["outcome_digest"]),
                ).fetchone()
                if not row:
                    raise LedgerError("comparison outcome evidence is missing")
                selected_outcomes.append(
                    (trial["cohort"], json.loads(bytes(row["content"])))
                )
            from .learning_engine import candidate_matches_outcome
            if any(
                not candidate_matches_outcome(persisted_candidate, cohort, outcome)
                for cohort, outcome in selected_outcomes
            ):
                raise LedgerError("comparison cohort does not match candidate configuration")
            configuration_fields = {
                "model", "effort", "role", "topology", "max_parallel",
                "verification_required", "verifier_digest", "bounds_digest", "package_digest",
                "policy_digest", "agent_digest", "skill_digests", "prompt_digest",
                "client_digest",
            }
            changed_fields: set[str] = set()
            for change in persisted_candidate["change_manifest"]:
                changed_fields.update(
                    {
                        "routing.model_effort": {"model", "effort"},
                    }.get(change["path_code"], set())
                )
            unchanged = configuration_fields - changed_fields
            normalized = {
                content_digest({field: outcome[field] for field in sorted(unchanged)})
                for _, outcome in selected_outcomes
            }
            cohort_vectors = {
                cohort: {
                    outcome["configuration_digest"]
                    for item_cohort, outcome in selected_outcomes
                    if item_cohort == cohort
                }
                for cohort in ("champion", "candidate")
            }
            if len(normalized) != 1 or any(
                len(vectors) != 1 for vectors in cohort_vectors.values()
            ):
                raise LedgerError("comparison cohorts contain configuration confounding")
            selected_cases = []
            for case_id, digest in expected_cases.items():
                row = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? AND record_id=? "
                    "AND record_type='evaluation_case' AND content_digest=?",
                    (project_id, case_id, digest),
                ).fetchone()
                if not row:
                    raise LedgerError("comparison case evidence is missing")
                selected_cases.append(json.loads(bytes(row["content"])))
            calibration_record = None
            if checked["grader_digest"] is not None:
                row = self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='grader_calibration' AND content_digest=?",
                    (project_id, checked["grader_digest"]),
                ).fetchone()
                assert row is not None
                calibration_record = json.loads(bytes(row["content"]))
            from .learning_engine import compare_candidate

            derived = compare_candidate(
                candidate=persisted_candidate,
                trials=selected_trials,
                cases=selected_cases,
                client_version=checked["client_version"],
                client_capability=capability,
                independent_review_digest=checked["independent_review_digest"],
                evaluation_assignment_digest=checked[
                    "evaluation_assignment_digest"
                ],
                grader_calibration=calibration_record,
                subjective_grading_required=calibration_record is not None,
            )
            if derived != checked:
                raise LedgerError("comparison differs from durable evaluation evidence")
        else:
            comparison = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type='comparison' "
                "AND content_digest=?",
                (project_id, checked["comparison_digest"]),
            ).fetchone()
            if not comparison:
                raise LedgerError("canary report lacks its promoting comparison")
            comparison_record = json.loads(bytes(comparison["content"]))
            if (
                comparison_record["decision"] != "promote"
                or comparison_record["candidate_digest"] != checked["candidate_digest"]
                or comparison_record["champion_digest"] != checked["champion_digest"]
            ):
                raise LedgerError("canary comparison does not match its candidate")
            case_rows = self._connection.execute(
                "SELECT content,content_digest FROM records WHERE project_id=? "
                "AND record_type='evaluation_case'",
                (project_id,),
            ).fetchall()
            canary_cases = {
                str(row["content_digest"]): json.loads(bytes(row["content"]))
                for row in case_rows
            }
            if any(
                digest not in canary_cases
                or canary_cases[digest]["corpus_state"] != "canary"
                or canary_cases[digest]["reviewed"] is not True
                or canary_cases[digest]["frozen"] is not True
                or canary_cases[digest]["task_slice"] != persisted_candidate["task_slice"]
                for digest in checked["case_digests"]
            ):
                raise LedgerError("canary cases are not frozen canary evidence")
            started_rows = self._connection.execute(
                "SELECT content,source_sequence FROM records WHERE project_id=? "
                "AND record_type='promotion'",
                (project_id,),
            ).fetchall()
            started = [
                {
                    **json.loads(bytes(row["content"])),
                    "_source_sequence": int(row["source_sequence"]),
                }
                for row in started_rows
                if json.loads(bytes(row["content"]))["action"] == "canary_started"
                and json.loads(bytes(row["content"]))["candidate_digest"]
                == checked["candidate_digest"]
                and json.loads(bytes(row["content"]))["canary_case_digests"]
                == checked["case_digests"]
            ]
            if not started:
                raise LedgerError("canary report has no durable canary start")
            started_sequence = max(record["_source_sequence"] for record in started)
            outcome_rows = self._connection.execute(
                "SELECT content,content_digest,source_sequence FROM records WHERE project_id=? "
                "AND record_type='outcome' AND source='evaluator'",
                (project_id,),
            ).fetchall()
            outcomes = {
                str(row["content_digest"]): {
                    **json.loads(bytes(row["content"])),
                    "_source_sequence": int(row["source_sequence"]),
                }
                for row in outcome_rows
            }
            candidate_digests: list[str] = []
            derived_deterministic = True
            derived_security = True
            derived_criteria = True
            derived_regressions = 0
            from .learning_engine import candidate_matches_outcome
            for pair in checked["case_outcomes"]:
                case_digest = pair["case_digest"]
                champion_digest = pair["champion_outcome_digest"]
                candidate_digest_value = pair["candidate_outcome_digest"]
                if champion_digest not in outcomes or candidate_digest_value not in outcomes:
                    raise LedgerError("canary outcome evidence is missing")
                champion = outcomes[champion_digest]
                outcome = outcomes[candidate_digest_value]
                candidate_digests.append(candidate_digest_value)
                if (
                    champion["_source_sequence"] >= started_sequence
                    or outcome["_source_sequence"] <= started_sequence
                    or champion["evaluation_candidate_digest"] != checked["champion_digest"]
                    or outcome["evaluation_candidate_digest"] != checked["candidate_digest"]
                    or champion["evaluation_case_digest"] != case_digest
                    or outcome["evaluation_case_digest"] != case_digest
                    or champion["task_slice"] != persisted_candidate["task_slice"]
                    or outcome["task_slice"] != persisted_candidate["task_slice"]
                    or not candidate_matches_outcome(
                        persisted_candidate, "champion", champion
                    )
                    or not candidate_matches_outcome(
                        persisted_candidate, "candidate", outcome
                    )
                ):
                    raise LedgerError("canary outcome does not prove its case")
                derived_deterministic &= outcome["deterministic_pass"]
                derived_security &= outcome["security_pass"]
                derived_criteria &= (
                    outcome["required_criteria_passed"]
                    == outcome["required_criteria_total"]
                )
                derived_regressions += (
                    outcome["quality_micros"] < champion["quality_micros"]
                )
            if (
                checked["deterministic_pass"] is not derived_deterministic
                or checked["security_pass"] is not derived_security
                or checked["required_criteria_pass"] is not derived_criteria
                or checked["quality_regressions"] != derived_regressions
            ):
                raise LedgerError("canary report hard gates do not match outcomes")
            latest_outcome_sequence = max(
                outcomes[digest]["_source_sequence"] for digest in candidate_digests
            )
            if not any(
                review["_source_sequence"] > latest_outcome_sequence
                and review["subject_digests"] == sorted(candidate_digests)
                for review in valid_reviews
            ):
                raise LedgerError("canary independent review predates or omits canary evidence")

    def _owner_invalidated_run_ids_locked(self, project_id: str) -> set[str]:
        invalidated: set[str] = set()
        with self._held():
            rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='feedback'",
                (project_id,),
            ).fetchall()
        for row in rows:
            feedback = json.loads(bytes(row["content"]))
            if feedback["label"] in {"rejected", "corrected"}:
                invalidated.add(feedback["run_id"])
        return invalidated

    def _candidate_evidence_invalidated_locked(
        self, project_id: str, candidate: dict[str, Any]
    ) -> bool:
        invalidated = self._owner_invalidated_run_ids_locked(project_id)
        linked = candidate["evidence_digests"]
        placeholders = ",".join("?" for _ in linked)
        # Pin the identity seek: the type index otherwise lets SQLite scan all project outcomes.
        with self._held():
            try:
                rows = self._connection.execute(
                    "SELECT content,content_digest FROM records INDEXED BY records_project_digest WHERE project_id=? "
                    f"AND content_digest IN ({placeholders}) AND record_type='outcome'",
                    (project_id, *linked),
                ).fetchall()
            except sqlite3.OperationalError as error:
                # Only a missing/unusable index is "reopen"; busy, locked and I/O errors keep their own answers.
                if "no such index" not in str(error) and "no query solution" not in str(error):
                    raise
                raise LedgerError("candidate evidence lookup is unavailable; reopen the ledger") from None
        invalidated_outcomes = {
            str(row["content_digest"])
            for row in rows
            if json.loads(bytes(row["content"]))["run_id"] in invalidated
        }
        return any(
            digest in invalidated_outcomes
            for digest in candidate["evidence_digests"]
        )

    def _validate_promotion_evidence_locked(
        self, project_id: str, promotion: dict[str, Any]
    ) -> None:
        candidate_rows = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? "
            "AND record_type='candidate'",
            (project_id,),
        ).fetchall()
        candidates = [
            json.loads(bytes(row["content"])) for row in candidate_rows
            if json.loads(bytes(row["content"]))["candidate_digest"]
            == promotion["candidate_digest"]
        ]
        if len(candidates) != 1 or self._candidate_evidence_invalidated_locked(
            project_id, candidates[0]
        ):
            raise LedgerError("lifecycle candidate was invalidated by owner feedback")
        action = promotion["action"]
        if action in {"canary_started", "promoted"}:
            raise LedgerError("authorized transition requires atomic grant consumption")
        evidence_type = None
        required_decision = None
        required_pass = None
        if action in {"evaluated", "rejected", "drift_detected"}:
            evidence_type = "comparison"
            required_decision = "promote" if action == "evaluated" else "reject"
        elif action in {"canary_passed", "canary_failed"}:
            evidence_type = "canary_report"
            required_pass = action == "canary_passed"
        evidence = None
        if evidence_type is not None:
            row = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type=? "
                "AND content_digest=?",
                (project_id, evidence_type, promotion["evidence_digest"]),
            ).fetchone()
            if not row:
                raise LedgerError("lifecycle transition evidence is missing")
            evidence = json.loads(bytes(row["content"]))
            if (
                evidence["candidate_digest"] != promotion["candidate_digest"]
                or evidence["champion_digest"] != promotion["champion_digest"]
                or (required_decision is not None and evidence["decision"] != required_decision)
                or (required_pass is not None and evidence["passed"] is not required_pass)
            ):
                raise LedgerError("lifecycle transition evidence does not match")
            if action.startswith("canary_") and (
                evidence["case_digests"] != promotion["canary_case_digests"]
            ):
                raise LedgerError("canary transition cases do not match evidence")
        prior_rows = self._connection.execute(
            "SELECT content FROM records WHERE project_id=? AND record_type='promotion'",
            (project_id,),
        ).fetchall()
        prior = [json.loads(bytes(row["content"])) for row in prior_rows]
        related = [
            record for record in prior
            if record["candidate_digest"] == promotion["candidate_digest"]
            and record["champion_digest"] == promotion["champion_digest"]
        ]
        prerequisites = {
            "canary_passed": {"canary_started"},
            "canary_failed": {"canary_started"},
            "drift_detected": {"promoted"},
            "reverted": {"promoted"},
        }.get(action, set())
        if not prerequisites.issubset({record["action"] for record in related}):
            raise LedgerError("lifecycle transition prerequisite is missing")

    def _append_checked_locked(
        self,
        project_id: str,
        checked: dict[str, Any],
        *,
        producer: str,
        timestamp: int,
    ) -> dict[str, Any]:
        if checked["record_type"] != "event_summary" and str(checked["record_id"]).startswith("evsum-"):
            raise LedgerError("the evsum- identifier prefix is kept for event summaries")
        if checked["record_type"] in LEARNING_MOVED_TYPES and self._learning_moved_locked(
            project_id
        ):
            raise LedgerError(LEARNING_MOVED_ERROR)
        if checked["record_type"] == "candidate":
            self._validate_candidate_eligibility_locked(project_id, checked)
        if checked.get("record_type") == "outcome":
            validate_outcome(checked)  # a new row never takes the stored-read leniency, whoever built it
        source = SOURCE_BY_PRODUCER[producer]
        content = canonical_json(checked)
        digest = content_digest(checked)
        expires = (
            None
            if checked["record_type"]
            in {
                "evaluation_case", "qa_evidence", "evidence_review", "evaluation_trial", "candidate", "comparison", "canary_report",
                "grader_calibration", "owner_grant", "promotion", "learning_export",
                "billing_attestation", "run_slot_confirmation",
                "claim_denial_settlement",
            }
            # A raw hook or app-server event is kept as long as its code's weight says;
            # a host lifecycle event as long as its run's outcome (the default).
            else timestamp + _retention_policy().event_keep_ms[checked["event_code"]]
            if checked["record_type"] == "event" and source in {"hook", "app_server"}
            else timestamp + _retention_policy().summary_keep_ms
            if checked["record_type"] == "event_summary"
            else timestamp + DEFAULT_RETENTION_MS
        )
        existing = self._connection.execute(
            "SELECT content_digest, source_sequence FROM records "
            "WHERE project_id=? AND record_id=?",
            (project_id, checked["record_id"]),
        ).fetchone()
        if existing:
            if existing["content_digest"] != digest:
                raise LedgerError("record identifier conflicts with existing content")
            return {
                "stored": False,
                "duplicate": True,
                "source_sequence": int(existing["source_sequence"]),
            }
        row = self._connection.execute(
            # O10 AP: two lookups, each answered from one end of an index (the combined form reads
            # every one of the project's records); the results are the same.
            "SELECT COALESCE((SELECT MAX(source_sequence) FROM records WHERE project_id=?),0), "
            "COALESCE((SELECT MAX(observed_at_ms) FROM records WHERE project_id=?),0)",
            (project_id, project_id),
        ).fetchone()
        sequence = int(row[0]) + 1
        late = int(checked.get("observed_at_ms", timestamp) < int(row[1]))
        self._connection.execute(
            "INSERT INTO records(project_id,record_id,record_type,source,source_sequence,observed_at_ms,ingested_at_ms,expires_at_ms,content,content_digest,late,probe_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                project_id,
                checked["record_id"],
                checked["record_type"],
                source,
                sequence,
                int(checked.get("observed_at_ms", timestamp)),
                timestamp,
                expires,
                content,
                digest,
                late,
                checked.get("probe_id"),
            ),
        )
        self._auto_link_locked(project_id, checked)
        return {
            "stored": True,
            "duplicate": False,
            "source_sequence": sequence,
            "late": bool(late),
        }

    def _auto_link_locked(self, project_id: str, record: dict[str, Any]) -> None:
        """Record complete derivation lineage in the same append transaction."""

        target = record["record_id"]

        def ids_for_digest(digest: str | None) -> list[str]:
            if digest is None:
                return []
            return [
                str(row[0])
                for row in self._connection.execute(
                    "SELECT record_id FROM records WHERE project_id=? AND content_digest=?",
                    (project_id, digest),
                ).fetchall()
            ]

        def ids_for_candidate(digest: str | None) -> list[str]:
            if digest is None:
                return []
            rows = self._connection.execute(
                "SELECT record_id,content FROM records WHERE project_id=? "
                "AND record_type='candidate' AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN "
                "json_extract(CAST(content AS TEXT),'$.candidate_digest') END=?",
                (project_id, digest),
            ).fetchall()
            return [str(row["record_id"]) for row in rows]

        def link(source_ids: Iterator[str] | list[str] | set[str], relation: str) -> None:
            for source in set(source_ids):
                if source == target:
                    continue
                self._connection.execute(
                    "INSERT OR IGNORE INTO record_links VALUES(?,?,?,?)",
                    (project_id, source, target, relation),
                )

        kind = record["record_type"]
        if kind == "outcome":
            rows = self._connection.execute(
                "SELECT record_id,content FROM records WHERE project_id=? "
                "AND record_type='event' AND source='host' "
                "AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, record["run_id"]),
            ).fetchall()
            link(
                [
                    str(row["record_id"])
                    for row in rows
                    if (
                        (event := json.loads(bytes(row["content"]))) ["run_id"]
                        == record["run_id"]
                        and event["assignment_id"] == record["assignment_id"]
                        and event["item_digest"] in record["evidence_digests"]
                    )
                ],
                "derived_from",
            )
        elif kind == "feedback":
            rows = self._connection.execute(
                "SELECT record_id,content FROM records WHERE project_id=? "
                "AND record_type='outcome' AND CASE WHEN json_valid(CAST(content AS TEXT)) THEN json_extract(CAST(content AS TEXT),'$.run_id') END=?",
                (project_id, record["run_id"]),
            ).fetchall()
            link(
                [
                    str(row["record_id"])
                    for row in rows
                    if json.loads(bytes(row["content"]))["run_id"] == record["run_id"]
                ],
                "corrects",
            )
        elif kind == "evaluation_case":
            link([record["source_outcome_id"]], "derived_from")
            if record["supersedes_case_id"] is not None:
                link([record["supersedes_case_id"]], "derived_from")
        elif kind == "candidate":
            link(
                [
                    item
                    for digest in record["evidence_digests"]
                    for item in ids_for_digest(digest)
                ],
                "evidence",
            )
        elif kind == "evaluation_assignment":
            link(ids_for_candidate(record["candidate_digest"]), "evaluates")
            link(record["case_ids"], "evidence")
        elif kind == "qa_evidence":
            link(ids_for_digest(record["evaluation_assignment_digest"]), "derived_from")
            link(ids_for_digest(record["case_digest"]), "evidence")
            link(ids_for_digest(record["host_outcome_digest"]), "evidence")
            link(ids_for_digest(record["verifier_host_outcome_digest"]), "evidence")
        elif kind == "evidence_review":
            link(
                [
                    item
                    for digest in record["subject_digests"]
                    for item in ids_for_digest(digest)
                ],
                "evidence",
            )
        elif kind == "evaluation_trial":
            link(ids_for_digest(record["evaluation_assignment_digest"]), "derived_from")
            link([record["case_id"]], "evidence")
            link(ids_for_digest(record["outcome_digest"]), "evidence")
        elif kind == "comparison":
            link(ids_for_candidate(record["candidate_digest"]), "evaluates")
            link(ids_for_digest(record["evaluation_assignment_digest"]), "derived_from")
            link(record["case_ids"], "evidence")
            link(
                [item for digest in record["trial_digests"] for item in ids_for_digest(digest)],
                "evidence",
            )
            link(ids_for_digest(record["independent_review_digest"]), "evidence")
            link(ids_for_digest(record["grader_digest"]), "evidence")
        elif kind == "canary_report":
            link(ids_for_candidate(record["candidate_digest"]), "evaluates")
            link(ids_for_digest(record["comparison_digest"]), "evidence")
            link(ids_for_digest(record["independent_review_digest"]), "evidence")
            for case_outcome in record["case_outcomes"]:
                link(ids_for_digest(case_outcome["case_digest"]), "evidence")
                link(ids_for_digest(case_outcome["champion_outcome_digest"]), "evidence")
                link(ids_for_digest(case_outcome["candidate_outcome_digest"]), "evidence")
        elif kind == "owner_grant":
            link(ids_for_candidate(record["candidate_digest"]), "promotes")
            link(ids_for_digest(record["review_digest"]), "evidence")
        elif kind == "promotion":
            link(ids_for_candidate(record["candidate_digest"]), "promotes")
            link(ids_for_digest(record["evidence_digest"]), "evidence")
            if record["grant_id"] is not None:
                link([record["grant_id"]], "promotes")
            for digest in record["canary_case_digests"]:
                link(ids_for_digest(digest), "evidence")
        elif kind == "learning_export":
            link(ids_for_candidate(record["candidate_digest"]), "derived_from")

    def commit_granted_promotion(
        self,
        project_id: str,
        *,
        grant: dict[str, Any],
        promotion: dict[str, Any],
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Atomically persist a grant, its transition, and durable single-use receipt."""

        try:
            checked_grant = validate_learning_record(grant)
            checked_promotion = validate_learning_record(promotion)
        except ContractError as exc:
            raise LedgerError("record admission rejected") from exc
        if checked_grant["record_type"] != "owner_grant" or checked_promotion["record_type"] != "promotion":
            raise LedgerError("granted transition record types are invalid")
        expected_action = {"canary": "canary_started", "promotion": "promoted"}[
            checked_grant["grant_kind"]
        ]
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        authorization_timestamp = time.time_ns() // 1_000_000
        from .learning_engine import OwnerGrantAuthority

        authority = OwnerGrantAuthority.for_state(self.state)
        if (
            not authority.verify(checked_grant)
            or not checked_grant["issued_at_ms"]
            <= authorization_timestamp
            < checked_grant["expires_at_ms"]
            or checked_grant["project_id"] != project_id
            or checked_promotion["grant_id"] != checked_grant["record_id"]
            or checked_promotion["candidate_digest"] != checked_grant["candidate_digest"]
            or checked_promotion["champion_digest"] != checked_grant["champion_digest"]
            or checked_promotion["action"] != expected_action
            or checked_promotion["evidence_digest"] != checked_grant["review_digest"]
            or content_digest(checked_promotion["canary_case_digests"])
            != checked_grant["bounds_digest"]
        ):
            raise LedgerError("grant and transition do not match")
        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            self._validate_granted_transition_locked(
                project_id, checked_grant, checked_promotion
            )
            used = self._connection.execute(
                "SELECT promotion_record_id FROM consumed_grants "
                "WHERE grant_id=?",
                (checked_grant["record_id"],),
            ).fetchone()
            if used:
                if used["promotion_record_id"] == checked_promotion["record_id"]:
                    return {"stored": False, "duplicate": True}
                raise LedgerError("owner grant was already consumed")
            self._append_checked_locked(
                project_id, checked_grant, producer="owner", timestamp=timestamp
            )
            self._append_checked_locked(
                project_id, checked_promotion, producer="lifecycle", timestamp=timestamp
            )
            self._connection.execute(
                "INSERT INTO consumed_grants VALUES(?,?,?,?,?,?)",
                (
                    project_id,
                    checked_grant["record_id"],
                    checked_promotion["record_id"],
                    checked_grant["candidate_digest"],
                    checked_promotion["action"],
                    timestamp,
                ),
            )
        self.state.harden_database_files()
        return {"stored": True, "duplicate": False}

    def _validate_granted_transition_locked(
        self,
        project_id: str,
        grant: dict[str, Any],
        promotion: dict[str, Any],
    ) -> None:
        prerequisite = self._connection.execute(
            "SELECT ingested_at_ms FROM records WHERE project_id=? AND content_digest=? "
            "AND record_type=?",
            (
                project_id,
                grant["review_digest"],
                "comparison" if grant["grant_kind"] == "canary" else "canary_report",
            ),
        ).fetchone()
        if (
            not prerequisite
            or grant["issued_at_ms"] < int(prerequisite["ingested_at_ms"])
        ):
            raise LedgerError("owner grant predates its prerequisite evidence")
        rows = self._connection.execute(
            # O10 AP5-2: only the five kinds read below, not every record of the project.
            "SELECT record_type,content,content_digest FROM records WHERE project_id=? AND record_type IN "
            "('candidate','promotion','evaluation_case','comparison','canary_report')",
            (project_id,),
        ).fetchall()
        records = [
            (str(row["record_type"]), json.loads(bytes(row["content"])), str(row["content_digest"]))
            for row in rows
        ]
        candidates = [
            record for kind, record, _ in records
            if kind == "candidate" and record["candidate_digest"] == grant["candidate_digest"]
        ]
        if not candidates or any(
            record["base_digest"] != grant["champion_digest"] for record in candidates
        ):
            raise LedgerError("granted transition has no matching persisted candidate")
        if self._candidate_evidence_invalidated_locked(project_id, candidates[0]):
            raise LedgerError("granted candidate was invalidated by owner feedback")
        prior_promotions = [record for kind, record, _ in records if kind == "promotion"]
        if grant["grant_kind"] == "canary":
            persisted_canary_cases = {
                digest
                for kind, record, digest in records
                if kind == "evaluation_case"
                and record["corpus_state"] == "canary"
                and record["reviewed"] is True
                and record["frozen"] is True
                and record["task_slice"] == candidates[0]["task_slice"]
            }
            if not set(promotion["canary_case_digests"]).issubset(
                persisted_canary_cases
            ):
                raise LedgerError("canary grant bounds are not frozen canary cases")
            comparison = [
                record for kind, record, digest in records
                if kind == "comparison" and digest == grant["review_digest"]
            ]
            if not comparison or any(
                record["decision"] != "promote"
                or record["candidate_digest"] != grant["candidate_digest"]
                or record["champion_digest"] != grant["champion_digest"]
                for record in comparison
            ):
                raise LedgerError("canary grant lacks a promoting comparison")
            if not any(
                record["action"] == "evaluated"
                and record["candidate_digest"] == grant["candidate_digest"]
                and record["champion_digest"] == grant["champion_digest"]
                and record["evidence_digest"] == grant["review_digest"]
                for record in prior_promotions
            ):
                raise LedgerError("canary grant lacks a durable evaluated transition")
            return
        canary_reports = [
            record for kind, record, digest in records
            if kind == "canary_report" and digest == grant["review_digest"]
        ]
        if not canary_reports or any(
            record["passed"] is not True
            or record["candidate_digest"] != grant["candidate_digest"]
            or record["champion_digest"] != grant["champion_digest"]
            or content_digest(record["case_digests"]) != grant["bounds_digest"]
            for record in canary_reports
        ):
            raise LedgerError("promotion grant lacks a successful canary report")
        matching_actions = [
            record for record in prior_promotions
            if record["candidate_digest"] == grant["candidate_digest"]
            and record["champion_digest"] == grant["champion_digest"]
            and record["canary_case_digests"] == promotion["canary_case_digests"]
        ]
        canary_started = any(record["action"] == "canary_started" for record in matching_actions)
        canary_passed = any(
            record["action"] == "canary_passed"
            and record["evidence_digest"] == grant["review_digest"]
            for record in matching_actions
        )
        if not canary_started or not canary_passed:
            raise LedgerError("promotion grant lacks durable canary transitions")

    def link(self, project_id: str, from_id: str, to_id: str, relation: str) -> None:
        if relation not in {"evidence", "derived_from", "corrects", "evaluates", "promotes"}:
            raise LedgerError("record relation is unsupported")
        with self._held(), self._connection:
            try:
                self._connection.execute(
                    "INSERT OR IGNORE INTO record_links VALUES(?,?,?,?)",
                    (project_id, from_id, to_id, relation),
                )
            except sqlite3.IntegrityError as exc:
                raise LedgerError("record link is invalid") from exc

    def write_sanitized_record_file(
        self,
        project_id: str,
        *,
        file_id: str,
        kind: str,
        record: dict[str, Any],
        expires_at_ms: int | None = None,
    ) -> Path:
        """Write a validated metadata-only record; callers cannot register arbitrary bytes."""

        if kind not in {"artifact", "export"}:
            raise LedgerError("sanitized record file kind is unsupported")
        try:
            checked = validate_learning_record(record)
        except ContractError as exc:
            raise LedgerError("stored record admission rejected") from exc
        with self._held():
            persisted = self._connection.execute(
                "SELECT content_digest FROM records WHERE project_id=? AND record_id=?",
                (project_id, checked["record_id"]),
            ).fetchone()
            if not persisted or persisted["content_digest"] != content_digest(checked):
                raise LedgerError("stored record must already exist in its project partition")
            path = self._write_owner_file(kind, project_id, file_id, canonical_json(checked))
            try:
                self._register_stored_file(
                    project_id,
                    file_id=file_id,
                    kind=kind,
                    path=path,
                    digest=hashlib.sha256(canonical_json(checked)).hexdigest(),
                    source_record_id=checked["record_id"],
                    expires_at_ms=expires_at_ms,
                )
            except Exception:
                with contextlib.suppress(OSError):
                    path.unlink()
                raise
            return path

    def create_sanitized_backup(
        self,
        project_id: str,
        *,
        file_id: str,
        expires_at_ms: int,
    ) -> Path:
        """Create a recoverable project-partition backup: a streamed, checked, registered copy."""

        if expires_at_ms <= time.time_ns() // 1_000_000:
            raise LedgerError("sanitized backup expiry must be in the future")
        with self._held():
            self._plan_project_backups([project_id], LEDGER_SCHEMA_VERSION)
            return self._write_streamed_backup(project_id, LEDGER_SCHEMA_VERSION, file_id,
                                               expires_at_ms=expires_at_ms)

    def _capture_learning_source_image(
        self, project_id: str, file_id: str, *, expected_domain_digest: str, work_limits,
    ) -> dict[str, Any]:
        """Explicit offline-owner source rows; no native or activation authority.

        Normal clients have no endpoint for this operation. The checker reuses
        this existing owner/key and requires its explicit offline intent and
        recorded drain checks; it never opens or takes over another live store.
        Complete provenance, retained files and durable writer retirement still
        precede use of the staged corpus.
        """
        from .learning_source_image import capture_source_image
        return capture_source_image(self, project_id, file_id,
                                    expected_domain_digest=expected_domain_digest, work_limits=work_limits)

    def verify_sanitized_backup(
        self, project_id: str, *, file_id: str
    ) -> dict[str, Any]:
        """Restore one registered backup into an isolated in-memory verifier."""

        row = self._connection.execute(
            "SELECT relative_path,content_digest FROM stored_files "
            "WHERE project_id=? AND file_id=? AND kind='backup'",
            (project_id, file_id),
        ).fetchone()
        if row is None:
            raise LedgerError("project backup is unavailable")
        path = self.state.root / str(row["relative_path"])
        _assert_no_symlink_components(path)
        if path.suffix == ".sqlite3":
            result = self._verify_streamed_backup(path, project_id, str(row["content_digest"]), compare=False)
            return {"verified": True, "backup_sha256": result["backup_sha256"],
                    "manifest_sha256": result["manifest_sha256"],
                    "ledger_schema_version": result["ledger_schema_version"], "counts": result["counts"],
                    "isolated_restore_integrity": "ok", "isolated_restore_foreign_keys": "ok"}
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != str(row["content_digest"]):
            raise LedgerError("project backup file digest disagrees with its registry")
        body, counts, manifest_digest = _verify_backup_envelope(
            raw, expected_project_id=project_id
        )
        return {
            "verified": True,
            "backup_sha256": hashlib.sha256(raw).hexdigest(),
            "manifest_sha256": manifest_digest,
            "ledger_schema_version": body["ledger_schema_version"],
            "counts": counts,
            "isolated_restore_integrity": "ok",
            "isolated_restore_foreign_keys": "ok",
        }

    def _write_owner_file(
        self, kind: str, project_id: str, file_id: str, payload: bytes
    ) -> Path:
        self._fence.check(self._connection)
        if not file_id or len(file_id) > 160 or not file_id.replace("_", "").isalnum():
            raise LedgerError("stored file identifier is invalid")
        root = {
            "artifact": self.state.artifacts,
            "export": self.state.exports,
            "backup": self.state.backups,
        }[kind]
        partition = root / project_id
        partition.mkdir(mode=0o700, exist_ok=True)
        _assert_no_symlink_components(partition)
        _check_owner_mode(partition, directory=True)
        path = partition / f"{file_id}.json"
        descriptor = os.open(
            path,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
        except Exception:
            with contextlib.suppress(OSError):
                path.unlink()
            raise
        return path

    def _register_stored_file(
        self,
        project_id: str,
        *,
        file_id: str,
        kind: str,
        path: Path,
        digest: str,
        source_record_id: str | None = None,
        expires_at_ms: int | None = None,
    ) -> None:
        """Register a file created by a typed writer in this ledger."""

        if kind not in {"artifact", "export", "backup"}:
            raise LedgerError("stored file kind is unsupported")
        if not file_id or len(file_id) > 160 or not file_id.replace("_", "").isalnum():
            raise LedgerError("stored file identifier is invalid")
        if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
            raise LedgerError("stored file digest is invalid")
        if expires_at_ms is not None and (
            not isinstance(expires_at_ms, int)
            or isinstance(expires_at_ms, bool)
            or expires_at_ms < 0
        ):
            raise LedgerError("stored file expiry is invalid")
        root_by_kind = {
            "artifact": self.state.artifacts,
            "export": self.state.exports,
            "backup": self.state.backups,
        }
        partition = root_by_kind[kind] / project_id
        _assert_no_symlink_components(path)
        try:
            resolved = path.resolve(strict=True)
            resolved.relative_to(partition.resolve(strict=True))
        except (OSError, ValueError) as exc:
            raise LedgerError("stored file is outside its project partition") from exc
        if resolved.is_symlink() or not resolved.is_file():
            raise LedgerError("stored file must be a regular file")
        try:
            _check_owner_mode(resolved, directory=False)
        except StateError as exc:
            raise LedgerError("stored file permissions are unsafe") from exc
        hasher = hashlib.sha256()
        try:
            with resolved.open("rb") as handle:
                for chunk in iter(lambda: handle.read(65_536), b""):
                    hasher.update(chunk)
        except OSError as exc:
            raise LedgerError("stored file cannot be read") from exc
        if not secrets.compare_digest(hasher.hexdigest(), digest):
            raise LedgerError("stored file digest does not match")
        relative = resolved.relative_to(self.state.root).as_posix()
        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            try:
                self._connection.execute(
                    "INSERT INTO stored_files VALUES(?,?,?,?,?,?,?)",
                    (
                        project_id,
                        file_id,
                        kind,
                        relative,
                        digest,
                        source_record_id,
                        expires_at_ms,
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise LedgerError("stored file registration is invalid") from exc

    @contextlib.contextmanager
    def repository(self, project_id: str) -> Iterator["ProjectRepository"]:
        with self._held():  # validation and registration in one hold, so no deletion comes between
            row = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not row or row["status"] != "active":
                raise LedgerError("project binding is not active")
            with self._readers_lock:
                self._active_readers += 1
        try:
            yield ProjectRepository(self, project_id)
        finally:
            with self._readers_lock:  # E1a: the exit never waits for the ledger
                self._active_readers -= 1

    def lifecycle_records(
        self, project_id: str, candidate_digest_value: str
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        """Return one candidate and its ordered transitions for the lifecycle controller."""

        with self._held():
            candidate_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type='candidate'",
                (project_id,),
            ).fetchall()
            candidates = [
                json.loads(bytes(row["content"]))
                for row in candidate_rows
                if json.loads(bytes(row["content"]))["candidate_digest"]
                == candidate_digest_value
            ]
            if len(candidates) != 1:
                raise LedgerError("candidate lifecycle record was not found")
            promotion_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type='promotion' "
                "ORDER BY source_sequence",
                (project_id,),
            ).fetchall()
        promotions = [
            json.loads(bytes(row["content"]))
            for row in promotion_rows
            if json.loads(bytes(row["content"]))["candidate_digest"]
            == candidate_digest_value
        ]
        return candidates[0], promotions

    def routing_candidates(
        self,
        project_id: str,
        selection_slice: str,
        *,
        released_candidate_digests: frozenset[str],
    ) -> list[dict[str, Any]]:
        """Return promoted candidates activated by the versioned release registry."""

        from .learning_engine import CandidateLifecycle, OwnerGrantAuthority

        if not released_candidate_digests:
            return []

        with self._held():
            candidate_rows = self._connection.execute(
                "SELECT content,source_sequence FROM records WHERE project_id=? "
                "AND record_type='candidate' ORDER BY source_sequence",
                (project_id,),
            ).fetchall()
            promotion_rows = self._connection.execute(
                "SELECT content,source_sequence FROM records WHERE project_id=? "
                "AND record_type='promotion' ORDER BY source_sequence",
                (project_id,),
            ).fetchall()
        promotions = [
            json.loads(bytes(row["content"])) for row in promotion_rows
        ]
        active: list[tuple[int, dict[str, Any]]] = []
        authority = OwnerGrantAuthority.for_state(self.state)
        for row in candidate_rows:
            candidate = json.loads(bytes(row["content"]))
            parts = candidate["task_slice"].split("-")
            candidate_selection_slice = (
                "-".join((parts[0], parts[1], *parts[3:]))
                if len(parts) == 7
                else None
            )
            if (
                candidate_selection_slice != selection_slice
                or candidate["scope"] != "general"
            ):
                continue
            if self._candidate_evidence_invalidated_locked(project_id, candidate):
                continue
            related = [
                record
                for record in promotions
                if record["candidate_digest"] == candidate["candidate_digest"]
            ]
            lifecycle = CandidateLifecycle.restore(
                candidate=candidate,
                champion_digest=candidate["base_digest"],
                project_id=project_id,
                authority=authority,
                digest_key=self.state.digest_key(),
                promotions=related,
            )
            selected = lifecycle.resolve_digest("")
            if (
                lifecycle.status == "promoted"
                and selected == candidate["candidate_digest"]
                and selected in released_candidate_digests
            ):
                activation = next(
                    int(promotion_rows[index]["source_sequence"])
                    for index, record in enumerate(promotions)
                    if record["candidate_digest"] == selected
                    and record["action"] in {"canary_started", "promoted"}
                )
                active.append((activation, candidate))
        if len(active) > 1:
            raise LedgerError(
                "model selection candidate is ambiguous across risk variants"
            )
        return [candidate for _, candidate in sorted(active, key=lambda item: item[0])]

    def canary_routing_candidate(
        self, project_id: str, case_id: str
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Resolve one reviewed canary case without accepting caller-supplied digests."""

        from .learning_engine import CandidateLifecycle, OwnerGrantAuthority

        with self._held():
            case_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_case' AND record_id=?",
                (project_id, case_id),
            ).fetchall()
            candidate_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='candidate' ORDER BY source_sequence",
                (project_id,),
            ).fetchall()
            promotion_rows = self._connection.execute(
                "SELECT content,source_sequence FROM records WHERE project_id=? "
                "AND record_type='promotion' ORDER BY source_sequence",
                (project_id,),
            ).fetchall()
            outcome_rows = self._connection.execute(
                "SELECT content,source_sequence FROM records WHERE project_id=? "
                "AND record_type='outcome' ORDER BY source_sequence",
                (project_id,),
            ).fetchall()
            attested_qa_digests = {
                str(row[0])
                for row in self._connection.execute(
                    "SELECT r.content_digest FROM records r "
                    "JOIN owner_attestations a ON a.project_id=r.project_id "
                    "AND a.subject_record_id=r.record_id "
                    "WHERE r.project_id=? AND r.record_type='qa_evidence'",
                    (project_id,),
                ).fetchall()
            }
        if len(case_rows) != 1:
            raise LedgerError("canary case was not found")
        case = json.loads(bytes(case_rows[0]["content"]))
        if (
            case["corpus_state"] != "canary"
            or not case["reviewed"]
            or not case["frozen"]
        ):
            raise LedgerError("canary case is not reviewed and frozen")
        case_digest = content_digest(case)
        promotions = [json.loads(bytes(row["content"])) for row in promotion_rows]
        outcomes = [
            (json.loads(bytes(row["content"])), int(row["source_sequence"]))
            for row in outcome_rows
        ]
        authority = OwnerGrantAuthority.for_state(self.state)
        active: list[dict[str, Any]] = []
        for row in candidate_rows:
            candidate = json.loads(bytes(row["content"]))
            if (
                candidate["scope"] != "general"
                or candidate["task_slice"] != case["task_slice"]
            ):
                continue
            if self._candidate_evidence_invalidated_locked(project_id, candidate):
                continue
            lifecycle = CandidateLifecycle.restore(
                candidate=candidate,
                champion_digest=candidate["base_digest"],
                project_id=project_id,
                authority=authority,
                digest_key=self.state.digest_key(),
                promotions=[
                    record for record in promotions
                    if record["candidate_digest"] == candidate["candidate_digest"]
                ],
            )
            canary_started_sequences = [
                int(promotion_rows[index]["source_sequence"])
                for index, record in enumerate(promotions)
                if record["candidate_digest"] == candidate["candidate_digest"]
                and record["action"] == "canary_started"
                and case_digest in record["canary_case_digests"]
            ]
            champion = candidate["champion_configuration"]
            configuration_fields = set(champion)
            champion_replayed = bool(canary_started_sequences) and any(
                sequence < min(canary_started_sequences)
                and outcome["status"] == "accepted"
                and outcome["evaluation_candidate_digest"] == candidate["base_digest"]
                and outcome["evaluation_case_digest"] == case_digest
                and {
                    field: outcome[field] for field in configuration_fields
                } == champion
                and bool(
                    set(outcome["evidence_digests"]) & attested_qa_digests
                )
                for outcome, sequence in outcomes
            )
            if (
                lifecycle.status == "canary_approved"
                and lifecycle.resolve_digest(case_digest)
                == candidate["candidate_digest"]
                and champion_replayed
            ):
                active.append(candidate)
        if len(active) != 1:
            raise LedgerError("canary case does not resolve to exactly one candidate")
        return case, active[0]

    def record_by_digest(
        self, project_id: str, digest: str, record_type: str
    ) -> dict[str, Any]:
        """Return one typed controller record by its canonical content digest."""

        if record_type not in {
            "comparison", "canary_report", "outcome", "grader_calibration",
            "evaluation_assignment", "evaluation_trial",
        }:
            raise LedgerError("controller record type is unsupported")
        with self._held():
            rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_type=? "
                "AND content_digest=?",
                (project_id, record_type, digest),
            ).fetchall()
        if len(rows) != 1:
            raise LedgerError("controller evidence record was not found")
        return json.loads(bytes(rows[0]["content"]))

    def trusted_routing_evidence_refs(
        self, project_id: str, task: dict[str, Any]
    ) -> frozenset[str]:
        """Resolve task-bound, QA-accepted reconnaissance outcomes."""

        checked = validate_task(task)
        references = checked["routing_evidence_refs"]
        if not references:
            return frozenset()
        if self.learning_moved(project_id):
            # The owner may have rejected a run in the project store since the move;
            # this frozen copy cannot vouch for any.
            raise LedgerError(LEARNING_MOVED_ERROR)
        expected_task_id = keyed_digest(self.state.digest_key(), checked["id"])
        accepted: set[str] = set()
        with self._held():
            invalidated_run_ids = self._owner_invalidated_run_ids_locked(project_id)
            for reference in references:
                match = re.fullmatch(r"outcome:([0-9a-f]{64})", reference)
                if match is None:
                    raise LedgerError(
                        "routing evidence must be a typed host outcome digest"
                    )
                digest = match.group(1)
                rows = self._connection.execute(
                    "SELECT r.content,q.accepted FROM records AS r "
                    "JOIN operational_qa AS q ON q.project_id=r.project_id "
                    "AND q.host_outcome_digest=r.content_digest "
                    "WHERE r.project_id=? AND r.record_type='outcome' "
                    "AND r.source='host' AND r.content_digest=?",
                    (project_id, digest),
                ).fetchall()
                if len(rows) != 1 or int(rows[0]["accepted"]) != 1:
                    raise LedgerError("routing evidence is not QA accepted")
                outcome = json.loads(bytes(rows[0]["content"]))
                if (
                    outcome.get("execution_state", "completed") != "completed"
                    or outcome.get("semantic_verdict", "pass")
                    not in {"pass", "ready", "ready-with-corrections"}
                ):
                    raise LedgerError(
                        "routing evidence is not positive completed reconnaissance"
                    )
                if outcome["run_id"] in invalidated_run_ids:
                    raise LedgerError(
                        "routing evidence was invalidated by owner feedback"
                    )
                parts = outcome["task_slice"].split("-")
                binding = self._connection.execute(
                    "SELECT task_id_digest FROM host_run_bindings "
                    "WHERE project_id=? AND run_id=?",
                    (project_id, outcome["run_id"]),
                ).fetchall()
                if (
                    len(parts) != 7
                    or parts[0] != checked["family"]
                    or not (parts[4] == "unknown" or parts[5] == "unknown")
                    or len(binding) != 1
                    or binding[0]["task_id_digest"] != expected_task_id
                ):
                    raise LedgerError(
                        "routing evidence is not task-bound reconnaissance"
                    )
                accepted.add(reference)
        return frozenset(accepted)

    def run_learning_cycle(
        self, project_id: str, *, as_of_ms: int, max_age_ms: int = DEFAULT_RETENTION_MS
    ) -> dict[str, Any]:
        """Run bounded deterministic aggregation, case mining, and inert proposal generation."""

        from .learning_contracts import candidate_base_digest
        from .learning_engine import analyze_outcomes, generate_candidate, mine_evaluation_case

        with self._held(), self._connection:
            project = self._connection.execute(
                "SELECT status FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
            if not project or project["status"] != "active":
                raise LedgerError("project binding is not active")
            if self._learning_moved_locked(project_id):
                raise LedgerError(LEARNING_MOVED_ERROR)
            # The window (O0c P8): outcomes of the retention, and the cases and candidates of it and the
            # ones kept for a reason, never all time; the collector sweep removes the rest.
            horizon = as_of_ms - LEARNING_RETENTION_MS
            windowed = f" AND (ingested_at_ms>? OR {_kept_learning_sql('records')})"
            outcome_rows = self._connection.execute(
                "SELECT content,content_digest FROM records WHERE project_id=? "
                "AND record_type='outcome' AND ingested_at_ms>? ORDER BY source_sequence LIMIT ?",
                (project_id, horizon, CYCLE_MAX_OUTCOMES + 1),
            ).fetchall()
            if len(outcome_rows) > CYCLE_MAX_OUTCOMES:
                raise LedgerError("learning cycle evidence exceeds its bounded window")
            outcome_pairs = [
                (json.loads(bytes(row["content"])), row) for row in outcome_rows
            ]
            verified_run_ids = {
                outcome["run_id"]
                for outcome, _ in outcome_pairs
                if outcome["status"] != "unverified"
            }
            outcome_pairs = [
                (outcome, row) for outcome, row in outcome_pairs
                if not (
                    outcome["status"] == "unverified"
                    and outcome["run_id"] in verified_run_ids
                )
            ]
            outcomes = [outcome for outcome, _ in outcome_pairs]
            owner_invalidated_run_ids = self._owner_invalidated_run_ids_locked(
                project_id
            )
            existing_case_sources = {
                json.loads(bytes(row[0]))["source_outcome_id"]
                for row in self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='evaluation_case'" + windowed,
                    (project_id, horizon),
                ).fetchall()
            }
            mined = []
            for outcome in outcomes:
                if (
                    outcome["record_id"] in existing_case_sources
                    or outcome["evaluation_candidate_digest"] is not None
                    or outcome["run_id"] in owner_invalidated_run_ids
                    or outcome["status"] == "unverified"
                ):
                    continue
                criteria = {
                    "deterministic_pass": outcome["deterministic_pass"],
                    "security_pass": outcome["security_pass"],
                    "required_criteria_total": outcome["required_criteria_total"],
                    "required_criteria_passed": outcome["required_criteria_passed"],
                }
                record = mine_evaluation_case(
                    digest_key=self.state.digest_key(),
                    outcome=outcome,
                    fixture_digest=outcome["fixture_digest"],
                    criteria_digest=content_digest(criteria),
                    lineage_digest=keyed_digest(
                        self.state.digest_key(), outcome["run_id"]
                    ),
                )
                self._validate_evidence_links_locked(project_id, record)
                self._append_checked_locked(
                    project_id, record, producer="evaluator", timestamp=as_of_ms
                )
                mined.append(record["record_id"])

            analysis = analyze_outcomes(
                outcomes,
                as_of_ms=as_of_ms,
                max_age_ms=max_age_ms,
                owner_invalidated_run_ids=owner_invalidated_run_ids,
            )
            controlled_rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? "
                "AND record_type='evaluation_case'" + windowed + " LIMIT ?",
                (project_id, horizon, CYCLE_MAX_CASES + 1),
            ).fetchall()
            if len(controlled_rows) > CYCLE_MAX_CASES:
                raise LedgerError("learning case corpus exceeds its bounded window")
            all_cases = [json.loads(bytes(row["content"])) for row in controlled_rows]
            protected_lineages = {
                case["lineage_digest"]
                for case in all_cases
                if case["corpus_state"] != "development"
            }
            protected_similarities = {
                case["similarity_group_digest"]
                for case in all_cases
                if case["corpus_state"] != "development"
                and case["similarity_group_digest"] is not None
            }
            protected_case_ids = {
                identifier
                for case in all_cases
                if case["corpus_state"] != "development"
                for identifier in (case["record_id"], case["supersedes_case_id"])
                if identifier is not None
            }
            changed = True
            while changed:
                changed = False
                for case in all_cases:
                    if (
                        case["lineage_digest"] in protected_lineages
                        or case["similarity_group_digest"] in protected_similarities
                        or case["record_id"] in protected_case_ids
                        or case["supersedes_case_id"] in protected_case_ids
                    ):
                        before = len(protected_case_ids)
                        protected_lineages.add(case["lineage_digest"])
                        if case["similarity_group_digest"] is not None:
                            protected_similarities.add(case["similarity_group_digest"])
                        protected_case_ids.add(case["record_id"])
                        if case["supersedes_case_id"] is not None:
                            protected_case_ids.add(case["supersedes_case_id"])
                        changed = changed or len(protected_case_ids) != before
            controlled_source_ids = {
                case["source_outcome_id"]
                for case in all_cases
                if (
                    case["lineage_digest"] in protected_lineages
                    or case["similarity_group_digest"] in protected_similarities
                    or case["record_id"] in protected_case_ids
                )
            }
            holdout_counts: dict[str, int] = {}
            for case in all_cases:
                if (
                    case["corpus_state"] == "promotion_holdout"
                    and case["reviewed"] is True
                    and case["frozen"] is True
                ):
                    holdout_counts[case["task_slice"]] = (
                        holdout_counts.get(case["task_slice"], 0) + 1
                    )
            existing_candidates = {
                json.loads(bytes(row[0]))["candidate_digest"]
                for row in self._connection.execute(
                    "SELECT content FROM records WHERE project_id=? "
                    "AND record_type='candidate'" + windowed,
                    (project_id, horizon),
                ).fetchall()
            }
            groups: dict[tuple[str, str], list[tuple[dict[str, Any], str]]] = {}
            retry_parent = {
                str(outcome["assignment_id"]): outcome.get("retry_of_assignment_id")
                for outcome, _ in outcome_pairs
            }

            def retry_root(outcome: dict[str, Any]) -> str:
                current = str(outcome["assignment_id"])
                seen: set[str] = set()
                while retry_parent.get(current) is not None and current not in seen:
                    seen.add(current)
                    current = str(retry_parent[current])
                return current

            grouped_lineages: dict[tuple[str, str], set[str]] = {}
            for outcome, row in outcome_pairs:
                if (
                    outcome["evaluation_candidate_digest"] is not None
                    or outcome["record_id"] in controlled_source_ids
                    or outcome["accepted"] is not True
                    or outcome.get("semantic_verdict", "pass")
                    not in {"pass", "ready", "ready-with-corrections"}
                    or outcome["run_id"] in owner_invalidated_run_ids
                ):
                    continue
                execution = {
                    key: outcome[key]
                    for key in (
                        "model", "effort", "role", "topology", "max_parallel",
                        "verification_required", "verifier_digest", "bounds_digest", "package_digest",
                        "policy_digest", "agent_digest", "skill_digests", "prompt_digest",
                        "client_digest",
                    )
                }
                group_key = (outcome["task_slice"], content_digest(execution))
                lineage = retry_root(outcome)
                if lineage in grouped_lineages.setdefault(group_key, set()):
                    continue
                grouped_lineages[group_key].add(lineage)
                groups.setdefault(group_key, []).append(
                    (outcome, str(row["content_digest"]))
                )
            proposed = []
            proposal_status = "configuration_limit" if len(groups) > 64 else "complete"
            groups_to_compare = {} if len(groups) > 64 else groups
            for (task_slice, _), champion_records in sorted(groups_to_compare.items()):
                if (
                    holdout_counts.get(task_slice, 0) < 20
                    or len(champion_records) < 20
                ):
                    continue
                champion = champion_records[0][0]
                champion_config = {
                    key: champion[key]
                    for key in (
                        "model", "effort", "role", "topology", "max_parallel",
                        "verification_required", "verifier_digest", "bounds_digest", "package_digest",
                        "policy_digest", "agent_digest", "skill_digests", "prompt_digest",
                        "client_digest",
                    )
                }
                for (other_slice, _), candidate_records in sorted(groups_to_compare.items()):
                    if other_slice != task_slice or candidate_records is champion_records:
                        continue
                    if len(candidate_records) < 20:
                        continue
                    champion_by_fixture = {
                        item[0]["fixture_digest"]: item for item in champion_records
                    }
                    candidate_by_fixture = {
                        item[0]["fixture_digest"]: item for item in candidate_records
                    }
                    matched_fixtures = sorted(
                        champion_by_fixture.keys() & candidate_by_fixture.keys()
                    )
                    if len(matched_fixtures) < 20:
                        continue
                    # Candidate records carry at most 64 evidence digests. Retain
                    # one deterministic observation per configuration for each of
                    # the most recent 32 matched fixtures.
                    matched_fixtures = matched_fixtures[-32:]
                    selected_champion_records = [
                        champion_by_fixture[fixture] for fixture in matched_fixtures
                    ]
                    selected_candidate_records = [
                        candidate_by_fixture[fixture] for fixture in matched_fixtures
                    ]
                    challenger = selected_candidate_records[0][0]
                    challenger_config = {
                        key: challenger[key] for key in champion_config
                    }
                    unchanged = set(champion_config) - {"model", "effort"}
                    if any(champion_config[key] != challenger_config[key] for key in unchanged):
                        continue
                    champion_outcomes = [item[0] for item in selected_champion_records]
                    challenger_outcomes = [item[0] for item in selected_candidate_records]
                    both = champion_outcomes + challenger_outcomes
                    if not all(
                        item["coverage"] == "end_to_end_complete"
                        and item["deterministic_pass"]
                        and item["security_pass"]
                        and item["required_criteria_passed"]
                        == item["required_criteria_total"]
                        and item["usage"]["input_tokens"] is not None
                        and item["usage"]["output_tokens"] is not None
                        and item["usage"]["model_calls"] is not None
                        for item in both
                    ):
                        continue

                    def mean(records: list[dict[str, Any]], field: str) -> float:
                        if field == "tokens":
                            return sum(
                                item["usage"]["input_tokens"]
                                + item["usage"]["output_tokens"]
                                for item in records
                            ) / len(records)
                        if field == "model_calls":
                            return sum(item["usage"][field] for item in records) / len(records)
                        return sum(item[field] for item in records) / len(records)

                    champion_tokens = mean(champion_outcomes, "tokens")
                    challenger_tokens = mean(challenger_outcomes, "tokens")
                    champion_calls = mean(champion_outcomes, "model_calls")
                    challenger_calls = mean(challenger_outcomes, "model_calls")
                    if (
                        mean(challenger_outcomes, "quality_micros")
                        < mean(champion_outcomes, "quality_micros")
                        or challenger_tokens > champion_tokens
                        or challenger_calls > champion_calls
                        or not (
                            challenger_tokens <= champion_tokens * 0.9
                            or challenger_calls <= champion_calls * 0.9
                        )
                    ):
                        continue
                    before = {
                        "model": champion_config["model"],
                        "effort": champion_config["effort"],
                    }
                    after = {
                        "model": challenger_config["model"],
                        "effort": challenger_config["effort"],
                    }
                    if before == after:
                        continue
                    record = generate_candidate(
                        digest_key=self.state.digest_key(),
                        scope="project",
                        task_slice=task_slice,
                        target="model_effort",
                        effect="optimize",
                        base_digest=candidate_base_digest(champion_config),
                        champion_configuration=champion_config,
                        change_manifest=[
                            {
                                "path_code": "routing.model_effort",
                                "before_digest": content_digest(before),
                                "after_digest": content_digest(after),
                                "before_value": before,
                                "after_value": after,
                            }
                        ],
                        evidence_digests=sorted(
                            item[1]
                            for item in selected_champion_records
                            + selected_candidate_records
                        ),
                        eligibility_receipt={
                            "task_slice": task_slice,
                            "evidence_set_digest": content_digest(
                                sorted(
                                    item[1]
                                    for item in selected_champion_records
                                    + selected_candidate_records
                                )
                            ),
                            "independent_case_count": len(matched_fixtures),
                            "usage_complete": True,
                            "version_unconfounded": True,
                            "task_mix_matched": True,
                            "retry_deduplicated": True,
                            "verifier_evidence_complete": True,
                        },
                    )
                    if record["candidate_digest"] in existing_candidates:
                        continue
                    try:
                        self._validate_evidence_links_locked(project_id, record)
                        self._append_checked_locked(
                            project_id, record, producer="evaluator", timestamp=as_of_ms
                        )
                    except LedgerError:
                        # Automatic proposal generation is opportunistic. Invalid or
                        # incomplete observations remain durable learning evidence but
                        # cannot make the whole maintenance cycle fail.
                        continue
                    existing_candidates.add(record["candidate_digest"])
                    proposed.append(record["candidate_digest"])
        self.state.harden_database_files()
        return {
            "mined_case_ids": mined,
            "proposed_candidate_digests": proposed,
            "analysis": analysis,
            "proposal_status": proposal_status,
        }

    def evaluation_case(self, project_id: str, record_id: str) -> dict[str, Any]:
        """Return one exact controlled case for the evaluation controller only."""

        with self._held():
            rows = self._connection.execute(
                "SELECT content FROM records WHERE project_id=? AND record_id=? "
                "AND record_type='evaluation_case'",
                (project_id, record_id),
            ).fetchall()
        if len(rows) != 1:
            raise LedgerError("evaluation case was not found")
        record = json.loads(bytes(rows[0]["content"]))
        if record["corpus_state"] == "development":
            raise LedgerError("evaluation case is not in a controlled corpus")
        return record

    def _records_for_project(self, project_id: str, record_type: str | None) -> list[dict[str, Any]]:
        query = "SELECT content, source_sequence, late FROM records WHERE project_id=?"
        params: tuple[Any, ...] = (project_id,)
        if record_type is not None:
            query += " AND record_type=?"
            params += (record_type,)
        query += " ORDER BY source_sequence"
        with self._held():
            rows = self._connection.execute(query, params).fetchall()
        return [
            {
                **json.loads(bytes(row["content"])),
                "_source_sequence": int(row["source_sequence"]),
                "_late": bool(row["late"]),
            }
            for row in rows
        ]

    def health_increment(self, project_id: str, code: str, *, now_ms: int | None = None) -> None:
        if code not in {"admission_rejected", "queue_full", "collector_error", "conflict"}:
            raise LedgerError("health code is unsupported")
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        with self._held(), self._connection:
            self._connection.execute(
                "INSERT INTO collector_health VALUES(?,?,1,?) "
                "ON CONFLICT(project_id,code) DO UPDATE SET count=count+1, updated_at_ms=excluded.updated_at_ms",
                (project_id, code, timestamp),
            )

    def machine_idle(self) -> dict[str, list[str]]:
        """S1-H1c: the projects that still have an unreleased run slot from the last day or an admitted
        probe, read only; this errs on the side of "still running"."""
        now_ms = time.time_ns() // 1_000_000
        with self._held():
            # C1 (review 040-s1-h1c): any unreleased slot claimed in the last day, counted or not, since
            # its child may outlive its counted life.
            # D1 (review 040-s1-h1c-2): or still counted by the two-clock rule, whatever its age.
            mono = time.monotonic_ns()
            runs = self._connection.execute(
                # O0b RS-A: a slot released lost or crashed still counts here exactly as before its release
                # (C1 and D1 unchanged), since its child may still be alive; only the other readers honour it.
                "SELECT DISTINCT a.project_id FROM active_run_capacity a WHERE (a.released_at_ms IS NULL "
                "OR EXISTS(SELECT 1 FROM run_holds r WHERE r.project_id=a.project_id AND r.kind='run_slot' "
                "AND r.identity=a.handle_digest AND r.release_kind IN ('lost','crashed'))) "
                "AND (a.kind='legacy_unknown' OR claimed_at_ms>=:legacy OR (deadline_at_ms IS NOT NULL AND NOT (deadline_at_ms+:grace<:now "
                "AND (execution_deadline_ns+:grace_ns<=:mono OR clock_reference_ns>:mono)))) ORDER BY a.project_id",
                {"legacy": now_ms - LEGACY_RUN_MAX_MS, "now": now_ms, "mono": mono, "grace": CRASHED_CLAIM_GRACE_MS,
                 "grace_ns": CRASHED_CLAIM_GRACE_MS * 1_000_000}).fetchall()
            probes = self._connection.execute(
                "SELECT DISTINCT project_id FROM account_billing_probe_requests WHERE state='admitted' "
                "ORDER BY project_id").fetchall()
        return {"run_slots": [row[0] for row in runs], "probes": [row[0] for row in probes]}

    def account_slot_health(self, project_id: str) -> dict[str, Any]:
        """S1-H1a: this project's account slots still held, read only. Never waits on the ledger lock
        (`ledger_busy`), and stops at SLOT_HEALTH_STEPS SQLite steps (`budget_spent`, never a partial
        count). A run slot is past its deadline when both clocks are (or the machine rebooted since
        its claim), and still counted, i.e. not yet past crashed_claim's grace on both; probe
        deadlines are wall-clock only (stated in the reply). This frees nothing."""
        if not self._lock.acquire(blocking=False):
            self._lock_waits.refused("slot_health")  # E1a-3
            return {"available": False, "reason": "ledger_busy"}
        try:
            # C8: another reader's progress handler or budgeted read scope is left alone.
            if getattr(self._connection, "_sql_foreign_progress", False) or getattr(
                    self._connection, "_sql_scope", None) is not None:
                return {"available": False, "reason": "ledger_busy"}
            interval = max(1, min(100, SLOT_HEALTH_STEPS))
            steps = [0]

            def budget():
                steps[0] += interval
                return 1 if steps[0] >= SLOT_HEALTH_STEPS else 0

            from .legacy_slots import deadline_sql
            now_ms, mono = time.time_ns() // 1_000_000, time.monotonic_ns()
            grace_ns = CRASHED_CLAIM_GRACE_MS * 1_000_000
            self._connection.set_progress_handler(budget, interval)
            try:
                runs = self._connection.execute(
                    "SELECT COALESCE(SUM(effective_deadline IS NOT NULL AND effective_deadline<:now "
                    "AND ((kind='legacy_unknown' AND effective_deadline+:grace>=:now) OR "
                    "(kind='claimed' AND (execution_deadline_ns<:mono OR clock_reference_ns>:mono) "
                    "AND NOT (effective_deadline+:grace<:now AND (execution_deadline_ns+:grace_ns<=:mono "
                    "OR clock_reference_ns>:mono))))),0),"
                    "COALESCE(SUM(effective_deadline IS NULL),0) FROM (SELECT a.*,"
                    f"CASE WHEN kind='legacy_unknown' THEN {deadline_sql('a')} ELSE deadline_at_ms END AS effective_deadline "
                    "FROM active_run_capacity a WHERE project_id=:project AND released_at_ms IS NULL)",
                    {"now": now_ms, "mono": mono, "grace": CRASHED_CLAIM_GRACE_MS, "grace_ns": grace_ns,
                     "project": project_id}).fetchone()
                probes = self._connection.execute(
                    "SELECT COUNT(*),COALESCE(SUM(deadline_at_ms<?),0) FROM account_billing_probe_requests "
                    "WHERE project_id=? AND state='admitted'", (now_ms, project_id)).fetchone()
            except sqlite3.OperationalError:
                return {"available": False, "reason": "budget_spent"}
            finally:
                self._connection.set_progress_handler(None, 0)
            return {"available": True, "runs_past_deadline": int(runs[0]), "runs_held_without_deadline": int(runs[1]),
                    "probes_held": int(probes[0]), "probes_past_deadline": int(probes[1]),
                    "probe_deadlines": "wall_clock"}
        finally:
            self._lock.release()

    def account_capacity(self, project_id: str) -> dict[str, dict[str, Any]]:
        """How near this project is to each account limit (0.3.4 R9): counts by the rule each limit enforces,
        and (O0b RS-A round 1 F14) the account holds by kind, as account_holds_status reads them."""
        from .account_cleanup import MAX_RELEASE_RESERVATIONS, live_cleanup_receipts
        from .account_observation import MAX_OBSERVATION_REQUESTS

        from .account_billing_admission import MAX_PROBE_REQUESTS
        from .account_open_contracts import OPEN_REQUESTS_IN_FLIGHT
        from .account_original_open import IN_FLIGHT_OPENS

        with self._held():
            observations = self._connection.execute(
                "SELECT COUNT(*) FROM account_observation_origins WHERE project_id=?", (project_id,)).fetchone()[0]
            # OP-3: the open requests in flight, by the open-time cap's own rule (OP-1).
            opens = self._connection.execute(IN_FLIGHT_OPENS + ")", (project_id, self._clock_ms(),
                                                                     OPEN_REQUESTS_IN_FLIGHT + 1)).fetchone()[0]
            receipts = live_cleanup_receipts(self, project_id)
            # O0b B0 (narrowed): the holds the open and probe caps count, by the rule each cap uses.
            bindings = self._connection.execute(  # G12: from held register rows
                "SELECT COUNT(*) " + LIVE_BINDINGS, (project_id, self._clock_ms())).fetchone()[0]
            probes = self._connection.execute(
                "SELECT COUNT(*) FROM account_billing_probe_requests WHERE project_id=? AND state<>'committed'",
                (project_id,)).fetchone()[0]
            holds = self.account_holds_status(project_id)  # F14: read in the same hold (it re-enters)
        return {"observations": {"live": int(observations), "limit": MAX_OBSERVATION_REQUESTS},
                "cleanup_receipts": {"live": int(receipts), "limit": MAX_RELEASE_RESERVATIONS},
                "pending_bindings": {"live": int(bindings), "limit": MAX_PENDING_HOST_RUNS},
                "billing_probes": {"live": int(probes), "limit": MAX_PROBE_REQUESTS},
                "open_requests": {"live": int(opens), "limit": OPEN_REQUESTS_IN_FLIGHT},
                "holds": holds}

    def _release_slot_locked(self, project_id, handle_digest, kind, now, monotonic, *, proof=None) -> bool:
        """O0b RS-A: release one unreleased run slot as `lost` or `crashed`, for good, inside the caller's
        account transaction. The decision, with the clocks it was made on, is the release's own evidence: its
        digest is both the capacity row's release digest and the register row's receipt, so the coverage
        checks can match them. Its time is max(now, the claim's), so a wall clock set back never blocks it."""
        if kind not in {"lost", "crashed", "unsent", "process_gone", "owner_confirmed"} or not self._connection.in_transaction:
            raise LedgerError("invalid slot release")
        row = self._connection.execute(
            "SELECT claimed_at_ms FROM active_run_capacity WHERE project_id=? AND handle_digest=? "
            "AND released_at_ms IS NULL", (project_id, handle_digest)).fetchone()
        if row is None:
            return False
        at = max(now, int(row["claimed_at_ms"]))
        evidence = {"decision": "run-slot-release-v1", "kind": kind, "project_id": project_id,
                    "handle_digest": handle_digest, "released_at_ms": at, "observed_wall_ms": now,
                    "observed_monotonic_ns": monotonic}
        if proof is not None:
            evidence["proof"] = proof
        decision = content_digest(evidence)
        # F5: the evidence is kept next to its digest, so the decision can be checked again later.
        self._connection.execute(
            "UPDATE run_holds SET release_kind=?,receipt=?,evidence=? WHERE kind='run_slot' AND project_id=? "
            "AND identity=? AND state='held'",
            (kind, decision, canonical_json(evidence).decode(), project_id, handle_digest))
        self._connection.execute(
            "UPDATE active_run_capacity SET released_at_ms=?,release_digest=? WHERE project_id=? AND handle_digest=? "
            "AND released_at_ms IS NULL", (at, decision, project_id, handle_digest))
        return True

    def account_holds_status(self, project_id: str) -> dict[str, dict[str, Any]]:
        """O0b RS-A-6: this project's account holds by kind: how many are held, how many are past due (their
        own predicate says release, the sweep has not run yet), and when the next can be released by time
        (`next_eligible`, wall ms; None when none is held or only evidence can release it)."""
        from .active_run_capacity import crashed_claim
        from .account_billing_admission import PROBE_ORPHAN_GRACE_MS
        from .billing_probe_contracts import PROBE_NO_LAUNCH_EVIDENCE_REASON, PROBE_NO_LAUNCH_EVIDENCE_STATE

        with self._held():
            now = self._clock_ms()
            monotonic = self._capacity_clock_reference()
            crashed, parameters = crashed_claim("a", now, monotonic)
            # O0b RS-A round 2 G12: each kind is read from its held register rows (run_holds_due), so the status
            # costs what is held, never the project's released history.
            from .legacy_slots import deadline_sql
            held = self._connection.execute(
                "SELECT a.kind,a.run_id,a.handle_digest,a.claimed_at_ms,"
                f"CASE WHEN a.kind='legacy_unknown' THEN {deadline_sql('a')} ELSE a.deadline_at_ms END AS deadline_at_ms,"
                "a.execution_deadline_ns,a.clock_reference_ns,"
                "(SELECT h.client_version FROM host_run_bindings h WHERE h.project_id=a.project_id "
                "AND h.handle_digest=a.handle_digest) AS client_version,"
                "CASE WHEN " + crashed + " THEN 1 ELSE 0 END AS due "
                "FROM run_holds r INDEXED BY run_holds_due CROSS JOIN active_run_capacity a "
                "ON a.project_id=r.project_id AND a.handle_digest=r.identity WHERE r.state<>'released' "
                "AND r.state='held' AND r.kind='run_slot' AND r.project_id=?",
                (*parameters, project_id)).fetchall()
            binding = self._connection.execute(
                "SELECT COUNT(*),COALESCE(SUM(CASE WHEN h.expires_at_ms<=? THEN 1 ELSE 0 END),0),"
                "MIN(h.expires_at_ms),MIN(h.expires_at_ms) FROM run_holds r INDEXED BY run_holds_due "
                "CROSS JOIN host_run_bindings h ON h.project_id=r.project_id AND h.handle_digest=r.identity "
                "WHERE r.state<>'released' AND r.state='held' AND r.kind='binding' AND r.project_id=?",
                (now, project_id)).fetchone()
            probes = self._connection.execute(
                "SELECT p.request_key,p.state,p.deadline_at_ms FROM run_holds r INDEXED BY run_holds_due "
                "CROSS JOIN account_billing_probe_requests p ON p.project_id=r.project_id AND p.request_key=r.identity "
                "WHERE r.state<>'released' AND r.state='held' AND r.kind='probe' AND r.project_id=?", (project_id,)).fetchall()
            # Decision 188 keeps P6: only current originals require evidence; an earlier
            # collector's admission is time-bound. Read the same custody map as the sweep.
            owner = getattr(self, "_billing_admission_owner", None)
            originals = set(getattr(owner, "_pending", ())) if owner is not None else set()
            probe_times, no_launch_evidence = [], []
            evidence_only = 0
            for row in probes:
                if row["state"] == "reserved":
                    probe_times.append(row["deadline_at_ms"] + 1)
                elif (project_id, row["request_key"]) in originals:
                    evidence_only += 1
                else:
                    cutoff = row["deadline_at_ms"] + PROBE_ORPHAN_GRACE_MS
                    probe_times.append(cutoff + 1)  # P6: held at the exact cutoff.
                    no_launch_evidence.append({"state": PROBE_NO_LAUNCH_EVIDENCE_STATE,
                                              "reason": PROBE_NO_LAUNCH_EVIDENCE_REASON,
                                              "release_after_ms": cutoff})
            probe = (len(probes), sum(at <= now for at in probe_times), min(probe_times, default=None),
                     min((row["deadline_at_ms"] for row in probes), default=None), evidence_only)
        eligible = [t for t in (self._slot_eligible(row, now, monotonic) for row in held if not row["due"])
                    if t is not None]
        deadlines = [row["deadline_at_ms"] for row in held if row["deadline_at_ms"] is not None]
        slot = (len(held), sum(row["due"] for row in held), min(eligible, default=None), min(deadlines, default=None))
        status = {name: {"held": int(row[0]), "past_due": int(row[1]),
                         "next_eligible": None if row[2] is None else int(row[2]),
                         "deadline": None if row[3] is None else int(row[3])}
                  for name, row in (("run_slot", slot), ("binding", binding), ("probe", probe))}
        from .legacy_slots import DEADLINE_REASON, OWNER_REASON, MISSING_REASON
        import shlex
        reasons, confirmations = set(), []
        for row in held:
            if row["due"]:
                continue
            if row["deadline_at_ms"] is not None:
                reasons.add(DEADLINE_REASON)
            else:
                # Every held slot with no recorded deadline can be released by the owner's signed confirmation:
                # a native slot waits on process evidence, any other (pruned intent, no binding row) lacks evidence.
                reason = OWNER_REASON if row["client_version"] == "claude-host-v1" else MISSING_REASON
                reasons.add(reason)
                roots = self._registered_roots(project_id)
                if not roots:
                    continue
                # The owner screen (decision 36) shows the project and state paths and the run id. The first command
                # prints the payload to sign; the second repeats it with the signature file. A child of the slot may
                # still run: confirming is the owner's call.
                step = ("python3 " + shlex.quote(str(roots[0] / '.codex/orchestration/cli.py'))
                        + " learning-confirm-run-slot --project-root " + shlex.quote(str(roots[0]))
                        + " --state-root " + shlex.quote(str(self.state.root))
                        + " --run-id " + shlex.quote(row["run_id"])
                        + " --handle-digest " + shlex.quote(row["handle_digest"]))
                confirmations.append({
                    "reason": reason, "command": step,
                    "signing_instruction": "Sign the payload printed above and save the signature as owner-signature.bin, then run:",
                    "signed_command": step + " --signature owner-signature.bin"})
        if any(not row["due"] and row["deadline_at_ms"] is None for row in held):
            status["run_slot"]["next_eligible"] = None
        if any(row["kind"] == "legacy_unknown" for row in held):
            status["run_slot"]["reasons"] = sorted(reasons)
            status["run_slot"]["owner_confirmations"] = confirmations
        status["probe"]["release_by_evidence"] = int(probe[4])  # admitted: no timer frees it in RS-A
        if no_launch_evidence:
            status["probe"]["admitted_no_launch_evidence"] = sorted(
                no_launch_evidence, key=lambda detail: detail["release_after_ms"])
        return status

    @staticmethod
    def _slot_eligible(row, now, monotonic):
        """Round 1 F8 (design draft 4 item 4): the earliest wall time the crash rule can hold on both clocks;
        None while the wall clock is behind the claim or a legacy slot needs evidence."""
        from .active_run_capacity import CRASHED_CLAIM_GRACE_MS

        if now < row["claimed_at_ms"]:
            return None
        if row["kind"] == "legacy_unknown":
            return (row["deadline_at_ms"] + CRASHED_CLAIM_GRACE_MS + 1
                    if row["deadline_at_ms"] is not None else None)
        if row["deadline_at_ms"] is None or row["execution_deadline_ns"] is None:
            return None
        wall = row["deadline_at_ms"] + CRASHED_CLAIM_GRACE_MS + 1
        if monotonic < row["clock_reference_ns"]:  # rebooted since the claim: the monotonic side holds already
            return wall
        remaining_ns = row["execution_deadline_ns"] + CRASHED_CLAIM_GRACE_MS * 1_000_000 - monotonic
        return max(wall, now - (-remaining_ns // 1_000_000)) if remaining_ns > 0 else wall

    def withdraw_open(self, project_id: str, *, run_handle: str, request_digest: str,
                      generation: int | None, owner: dict | None = None) -> dict[str, Any]:
        """O0b RS-A-2: withdraw a run opened but never claimed, so its binding ends now, not at its expiry.

        In one account transaction, serialized with claim admission (both take the ledger's write lock): the
        binding must be this project's and still pending, and no claim may exist for it. It is then
        abandoned with reason `withdrawn` (its register row is released `withdrawn` by the trigger), and every
        later claim refuses it as not pending. The caller's authority (the project's service, or the host
        session that opened it) is checked by the account.

        O0b RS-A round 1 F13 (design draft 4 item 2, draft 4b item 2): the receipt is stored with the request's
        digest and the generation it named. A request whose digest and supplied generation match gets it back,
        `known`, whatever the row's generation is now (through restart and pruning: the tombstone answers). A
        new transition must name the row's current generation (else `stale`); one naming none (an older
        client) is refused `generation_required`.

        B3 (RS-B draft 3 §4): `owner` is the account route's authenticated caller, `{caller_scope, run_id,
        inputs_digest, attempt, reason}` (the project is the enrolled root's). An exact replay is answered only to the
        caller scope that made it; the same digest from any other is `not authorized`, revealing no receipt. A new
        transition must name the open's own run id and inputs digest and come from the caller scope of the host class
        that opened it (all from the open's sealed receipt); and its receipt evidence keeps those facts for good. With
        no `owner` this is the ledger-level primitive RS-A defined (no account caller)."""
        if owner is not None and (type(owner) is not dict
                                  or set(owner) != {'caller_scope', 'run_id', 'inputs_digest', 'attempt', 'reason'}
                                  or any(type(owner[n]) is not str for n in ('caller_scope', 'run_id', 'inputs_digest',
                                                                             'reason'))
                                  or type(owner['attempt']) is not int):
            raise LedgerError("withdrawal is unavailable")
        if (type(run_handle) is not str or not re.fullmatch(r"hrn_[0-9a-f]{48}", run_handle)
                or type(request_digest) is not str or not re.fullmatch(r"[0-9a-f]{64}", request_digest)
                or (generation is not None and (type(generation) is not int or generation < 1))):
            raise LedgerError("withdrawal is unavailable")
        handle = keyed_digest(self.state.digest_key(), run_handle)
        with self._account_transaction():
            hold = self._connection.execute(
                "SELECT state,release_kind,generation,receipt,evidence FROM run_holds "
                "WHERE project_id=? AND kind='binding' AND identity=?", (project_id, handle)).fetchone()
            if hold is None:
                raise LedgerError("withdrawal is not authorized" if owner is not None else "withdrawal is unavailable")
            if hold["release_kind"] == "withdrawn" and hold["evidence"] is not None:
                stored = self._stored_withdrawal(hold["evidence"])
                if owner is not None and any(stored.get(name) != owner[name]
                                             for name in ('caller_scope', 'run_id', 'inputs_digest')):
                    # W4c: another caller scope, or a request for another run, learns nothing about this handle's
                    # receipt, whether its request is the stored one or an altered one.
                    raise LedgerError("withdrawal is not authorized")
                if stored.get("request_digest") == request_digest:
                    # RS-13: a matching digest cannot authorize a substituted generation.
                    # Legacy digest-only retries still name no generation (F13).
                    if generation is not None and generation != stored.get("generation"):
                        raise LedgerError("withdrawal is stale")
                    if owner is not None and any(stored.get(name) != owner[name] for name in ('attempt', 'reason')):
                        raise LedgerError("withdrawal is not authorized")
                    return {**stored["answer"], "run_handle": run_handle, "receipt": hold["receipt"], "known": True}
            if owner is not None:
                # A new transition: the open's own sealed receipt must name this caller scope, run id and inputs
                # digest. A binding with no such receipt (pruned, or opened by an earlier version) never matches.
                from .account_original_open import opened_by
                if not opened_by(self, project_id, handle, caller_scope=owner["caller_scope"],
                                 run_id=owner["run_id"], inputs_digest=owner["inputs_digest"]):
                    raise LedgerError("withdrawal is not authorized")
            if generation is None:
                raise LedgerError("generation_required")
            if generation != hold["generation"]:
                raise LedgerError("withdrawal is stale")
            row = self._connection.execute(
                "SELECT binding_state FROM host_run_bindings WHERE project_id=? AND handle_digest=?",
                (project_id, handle)).fetchone()
            claimed = self._connection.execute(
                "SELECT 1 FROM launch_claims WHERE project_id=? AND handle_digest=? UNION ALL "
                "SELECT 1 FROM active_run_capacity WHERE project_id=? AND handle_digest=? LIMIT 1",
                (project_id, handle, project_id, handle)).fetchone()
            if row is None or row["binding_state"] != "pending" or claimed is not None or hold["state"] != "held":
                raise LedgerError("withdrawal is unavailable")
            self._connection.execute(
                "UPDATE host_run_bindings SET binding_state='abandoned',abandoned_reason='withdrawn' "
                "WHERE project_id=? AND handle_digest=? AND binding_state='pending'", (project_id, handle))
            released = self._connection.execute(
                "SELECT released_at_ms FROM run_holds WHERE project_id=? AND kind='binding' AND identity=?",
                (project_id, handle)).fetchone()["released_at_ms"]
            answer = {"state": "withdrawn"}
            evidence = {"decision": "binding-withdrawal-v1", "project_id": project_id, "handle_digest": handle,
                        "request_digest": request_digest, "generation": generation, "release_kind": "withdrawn",
                        "released_at_ms": released, "answer": answer}
            if owner is not None:
                # B3: the ownership an exact replay is answered against, kept with the receipt for the row's life.
                # The row already is the project, the handle, the release kind and its time, and the answer is
                # fixed, so only what the row does not say is kept, under short names (under 512 bytes at most;
                # `_stored_withdrawal` reads it, and the earlier v1/v2 records, back).
                evidence = {"d": "w3", "q": request_digest, "g": generation, "c": owner["caller_scope"],
                            "r": owner["run_id"], "i": owner["inputs_digest"], "a": owner["attempt"],
                            "w": owner["reason"]}
            receipt = content_digest(evidence)
            # F13: written with the release, so a lost reply's retry finds it.
            self._connection.execute(
                "UPDATE run_holds SET receipt=?,evidence=? WHERE project_id=? AND kind='binding' AND identity=? "
                "AND state='released' AND release_kind='withdrawn'",
                (receipt, canonical_json(evidence).decode(), project_id, handle))
        return {**answer, "run_handle": run_handle, "receipt": receipt, "known": False}

    @staticmethod
    def _stored_withdrawal(raw) -> dict:
        """A withdrawn row's stored evidence under the names `withdraw_open` reads: the compact B3 record (`d: w3`),
        or an earlier v1/v2 record as it was written."""
        stored = json.loads(raw)
        if stored.get("d") != "w3":
            return stored
        return {"decision": "binding-withdrawal-v3", "request_digest": stored["q"], "generation": stored["g"],
                "caller_scope": stored["c"], "run_id": stored["r"], "inputs_digest": stored["i"],
                "attempt": stored["a"], "reason": stored["w"], "answer": {"state": "withdrawn"}}

    def account_holds_due(self) -> bool:
        """O0b RS-A round 2 G6: whether any held register row's hold is due now (what the next release batch
        would release), by one read: no transaction and no write, the rows found from the held register rows
        by index, so its cost follows the live holds, never history. The collector's idle check calls it
        under the ledger lock it took without waiting; re-entry is immediate."""
        with self._held():
            now, monotonic = self._clock_ms(), self._capacity_clock_reference()
            crashed, parameters = crashed_claim("a", now, monotonic)
            row = self._connection.execute(
                "SELECT EXISTS(SELECT 1 FROM run_holds r JOIN active_run_capacity a ON a.project_id=r.project_id "
                "AND a.handle_digest=r.identity WHERE r.state<>'released' AND r.state='held' AND r.kind='run_slot' "
                f"AND a.released_at_ms IS NULL AND {crashed}) "
                "OR EXISTS(SELECT 1 FROM run_holds r JOIN account_billing_probe_requests p "
                "ON p.project_id=r.project_id AND p.request_key=r.identity WHERE r.state<>'released' "
                "AND r.state='held' AND r.kind='probe' AND p.state='reserved' AND p.deadline_at_ms<?) "
                "OR EXISTS(SELECT 1 FROM run_holds r JOIN host_run_bindings h ON h.project_id=r.project_id "
                "AND h.handle_digest=r.identity WHERE r.state<>'released' AND r.state='held' AND r.kind='binding' "
                "AND h.binding_state='pending' AND h.expires_at_ms<=?)",
                (*parameters, now, now)).fetchone()
            if row[0]:
                return True
            # O0c P6: an admitted probe past deadline + grace that no original of this process holds.
            from .account_billing_admission import PROBE_ORPHAN_GRACE_MS
            owner = getattr(self, "_billing_admission_owner", None)
            held = set(getattr(owner, "_pending", ())) if owner is not None else set()
            overdue = self._connection.execute(
                "SELECT project_id,request_key FROM account_billing_probe_requests INDEXED BY "
                "billing_probe_active_machine WHERE state='admitted' AND deadline_at_ms<? LIMIT ?",
                (now - PROBE_ORPHAN_GRACE_MS, len(held) + 1)).fetchall()
        return any((item[0], item[1]) not in held for item in overdue)

    def release_due_account_holds(self, *, limit: int = 64) -> int:
        """O0b RS-A: release the account holds whose own predicate now says so, writing each decision once.

        A run slot the crash rule says cannot still be running is released for good, `lost` when its
        service settled it so, else `crashed`, at max(now, its claim time), so no later clock or uptime can
        make it count again (CR-1). A pending binding past its expiry is released `expired`. Each is one
        register transition (the triggers keep the kind written here). Returns how many were released.
        """
        if type(limit) is not int or not 1 <= limit <= 1024:
            raise LedgerError("invalid release batch")
        probes: list[int] = []
        with self._account_transaction():
            released = self._release_due_locked(self._clock_ms(), self._capacity_clock_reference(), limit,
                                                probes=probes)
        # O0b RS-A round 2 G3: only after the commit (a rollback raised above) is the probe owner told, so it
        # forgets the closed originals on its own thread without waiting for another reservation.
        owner = getattr(self, "_billing_admission_owner", None)
        if owner is not None and sum(probes):
            # The releases are committed whatever happens here; a failed forget is retried at the owner's step.
            with contextlib.suppress(Exception):
                owner.probes_closed()
        return released

    def _release_due_locked(self, now: int, monotonic: int, limit: int, *, probes: list | None = None) -> int:
        """The sweep's releases inside the caller's account transaction (the sweep's batches and the 14 -> 15
        upgrade, before activation): at most `limit`. `probes`, when given, receives how many reserved probes
        were closed (round 2 G3)."""
        from .active_run_capacity import LOST_RUN_REASON, crashed_claim

        released = 0
        crashed, parameters = crashed_claim("a", now, monotonic)
        slots = self._connection.execute(
            "SELECT a.project_id,a.handle_digest,a.run_id,a.bridge_run_id,a.kind,a.claimed_at_ms,EXISTS(SELECT 1 FROM host_run_bindings h "
            "WHERE h.project_id=a.project_id AND h.handle_digest=a.handle_digest "
            f"AND h.binding_state='abandoned' AND h.abandoned_reason='{LOST_RUN_REASON}') AS lost "
            f"FROM active_run_capacity a WHERE a.released_at_ms IS NULL AND {crashed} LIMIT ?",
            (*parameters, limit)).fetchall()
        # Process proof is read here and nowhere in a count: an earlier-version slot that is not yet past its
        # deadline is examined too, and only a durable release changes what counts.
        seen = {(row["project_id"], row["handle_digest"]) for row in slots}
        slots = [*slots, *(row for row in self._connection.execute(
            "SELECT a.project_id,a.handle_digest,a.run_id,a.bridge_run_id,a.kind,a.claimed_at_ms,0 AS lost "
            "FROM active_run_capacity a WHERE a.released_at_ms IS NULL AND a.kind='legacy_unknown'").fetchall()
            if (row["project_id"], row["handle_digest"]) not in seen)]
        for slot in slots:
            from .legacy_slots import process_proof
            proof = (process_proof(self.state, slot["project_id"], slot["handle_digest"], slot["run_id"],
                                   slot["bridge_run_id"]) if slot["kind"] == "legacy_unknown" else None)
            if slot["kind"] == "legacy_unknown" and not slot["lost"] and proof is None:
                from .legacy_slots import dispatch_deadline, intents_sql
                intents = self._connection.execute(
                    intents_sql(), (slot["project_id"], slot["run_id"])).fetchall()
                deadline = (dispatch_deadline(intents[0]["content"], intents[0]["content_digest"],
                                             slot["run_id"], slot["bridge_run_id"]) if len(intents) == 1 else None)
                if deadline is None or now <= deadline + CRASHED_CLAIM_GRACE_MS:
                    continue
                proof = {"kind": "crashed", "dispatch_intent": json.loads(bytes(intents[0]["content"]))}
            self._release_slot_locked(slot["project_id"], slot["handle_digest"],
                                      "lost" if slot["lost"] else proof["kind"] if proof else "crashed",
                                      now, monotonic, proof=proof)
            released += 1
            if released >= limit:
                break
        if released < limit:
            # O0b RS-A-2: reserved probes past their deadline, closed as unlaunched denials.
            from .account_billing_admission import close_expired_reserved
            closed = close_expired_reserved(self, now, limit - released)
            released += closed
            if probes is not None:
                probes.append(closed)
        if released < limit:
            # O0c P6: admitted probes of an earlier collector (no original in memory) past deadline + grace.
            from .account_billing_admission import close_orphaned_admitted
            released += close_orphaned_admitted(self, now, limit - released)
        if released < limit:
            # F7: an unclaimed binding is ended in its own row too (the trigger then releases its register
            # row `expired`), so a claim checking the binding refuses it whatever the wall clock later says.
            # Round 2 G5: candidates come from held register rows (run_holds_due), never from pending source
            # rows, so released claimed bindings, pending for their settlement, are never examined again.
            cursor = self._connection.execute(
                "UPDATE host_run_bindings SET binding_state='abandoned',abandoned_reason='expired' WHERE rowid IN "
                "(SELECT h.rowid FROM run_holds r INDEXED BY run_holds_due CROSS JOIN host_run_bindings h "
                "ON h.project_id=r.project_id AND h.handle_digest=r.identity WHERE r.state<>'released' "
                "AND r.kind='binding' AND h.binding_state='pending' AND h.expires_at_ms<=? "
                "AND NOT EXISTS(SELECT 1 FROM launch_claims c WHERE c.project_id=h.project_id "
                "AND c.handle_digest=h.handle_digest) AND NOT EXISTS(SELECT 1 FROM active_run_capacity a "
                "WHERE a.project_id=h.project_id AND a.handle_digest=h.handle_digest) LIMIT ?)",
                (now, limit - released))
            released += cursor.rowcount
        if released < limit:
            # A claimed binding stays pending for its settlement; only its register row is released (G5: found
            # from held register rows, as above).
            cursor = self._connection.execute(
                "UPDATE run_holds SET state='released',generation=generation+1,released_at_ms=?,"
                "release_kind='expired' WHERE rowid IN (SELECT r.rowid FROM run_holds r INDEXED BY run_holds_due "
                "CROSS JOIN host_run_bindings h ON h.project_id=r.project_id AND h.handle_digest=r.identity "
                "WHERE r.state<>'released' AND r.kind='binding' AND r.state='held' AND h.binding_state='pending' AND h.expires_at_ms<=? LIMIT ?)",
                (now, now, limit - released))
            released += cursor.rowcount
        return released

    def health_snapshot(self, project_id: str) -> dict[str, dict[str, int]]:
        with self._held():
            rows = self._connection.execute(
                "SELECT code,count,updated_at_ms FROM collector_health "
                "WHERE project_id=? ORDER BY code",
                (project_id,),
            ).fetchall()
        return {
            str(row["code"]): {
                "count": int(row["count"]),
                "updated_at_ms": int(row["updated_at_ms"]),
            }
            for row in rows
        }

    def ingestion_snapshot(
        self,
        project_id: str,
        *,
        client_failures: dict[str, Any] | None = None,
        now_ms: int | None = None,
    ) -> dict[str, Any]:
        """Return exact-project hook ingestion counts without record content or IDs."""

        with self._held():
            rows = self._connection.execute(
                "SELECT event_code,accepted_count,last_accepted_at_ms "
                "FROM hook_ingestion WHERE project_id=? ORDER BY event_code",
                (project_id,),
            ).fetchall()
            # A run the project's own service drove settles through its capacity
            # row; its binding here is never consumed by the ledger.
            host_row = self._connection.execute(
                "SELECT COUNT(*) AS opened,"
                # O0b RS-A: a run is terminal from completion evidence, never from a written lost or crashed release.
                "SUM(h.consumed_at_ms IS NOT NULL OR (c.released_at_ms IS NOT NULL AND NOT EXISTS(SELECT 1 "
                "FROM run_holds r WHERE r.project_id=c.project_id AND r.kind='run_slot' AND r.identity=c.handle_digest "
                "AND r.release_kind IN ('lost','crashed','unsent','process_gone','owner_confirmed') AND r.receipt IS c.release_digest)) "
                # round 1 F11: a late completion after a decision counts the run as terminal
                "OR EXISTS(SELECT 1 FROM capacity_completions cc WHERE cc.project_id=h.project_id "
                "AND cc.handle_digest=h.handle_digest AND cc.released_at_ms IS NOT NULL)) AS terminal,"
                "SUM(h.binding_state='pending' AND c.released_at_ms IS NULL) AS pending,"
                "SUM(h.native_assignment_id IS NOT NULL) AS native_bound,"
                "SUM(h.usage_complete=1) AS usage_complete,"
                "SUM(h.usage_complete=0) AS usage_unknown,"
                "SUM(h.binding_state='abandoned') AS abandoned "
                "FROM host_run_bindings AS h LEFT JOIN active_run_capacity AS c "
                "ON c.project_id=h.project_id AND c.handle_digest=h.handle_digest "
                "WHERE h.project_id=?",
                (project_id,),
            ).fetchone()
            orchestration_rows = self._connection.execute(
                "SELECT status,COUNT(*) AS count FROM orchestrations "
                "WHERE project_id=? GROUP BY status",
                (project_id,),
            ).fetchall()
            qa_rows = self._connection.execute(
                "SELECT accepted,COUNT(*) AS count FROM operational_qa "
                "WHERE project_id=? GROUP BY accepted",
                (project_id,),
            ).fetchall()
        counts = {code: 0 for code in HOOK_EVENT_CODES}
        last_accepted: int | None = None
        for row in rows:
            event_code = str(row["event_code"])
            if event_code in counts:
                counts[event_code] = int(row["accepted_count"])
            accepted_at = int(row["last_accepted_at_ms"])
            last_accepted = (
                accepted_at if last_accepted is None else max(last_accepted, accepted_at)
            )
        failures = client_failures or {}
        rejected_count = 0
        last_rejected: int | None = None
        for code in HOOK_REJECTION_CODES:
            counter = failures.get(code)
            if not isinstance(counter, dict):
                continue
            rejected_count += int(counter.get("count", 0))
            updated = counter.get("updated_at_ms")
            if isinstance(updated, int) and not isinstance(updated, bool):
                last_rejected = updated if last_rejected is None else max(last_rejected, updated)
        snapshot = empty_ingestion_snapshot(registered=True)
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        age = None if last_accepted is None else max(0, timestamp - last_accepted)
        freshness = (
            "awaiting_hook_review_or_first_event"
            if age is None
            else "fresh" if age <= INGESTION_FRESH_MS else "idle"
        )
        snapshot.update(
            accepted_hook_event_count=sum(counts.values()),
            last_accepted_hook_event_at_ms=last_accepted,
            rejected_hook_event_count=rejected_count,
            last_rejected_hook_event_at_ms=last_rejected,
            freshness={
                "state": freshness, "age_ms": age,
                "message": (
                    "No events since the hooks were installed; open /hooks on the main checkout."
                    if age is None else "Hooks have delivered events; no recent activity."
                    if freshness == "idle" else "Hooks are delivering events."
                ),
            },
            hook_event_counts=counts,
            managed_lifecycle={
                "orchestrations_active": sum(
                    int(row["count"])
                    for row in orchestration_rows if row["status"] == "active"
                ),
                "orchestrations_closed": sum(
                    int(row["count"])
                    for row in orchestration_rows
                    if row["status"] not in {"active", "paused"}
                ),
                "orchestrations_paused": sum(
                    int(row["count"])
                    for row in orchestration_rows if row["status"] == "paused"
                ),
                "host_runs_opened": int(host_row["opened"] or 0),
                "host_runs_terminal": int(host_row["terminal"] or 0),
                "host_runs_pending": int(host_row["pending"] or 0),
                "host_runs_abandoned": int(host_row["abandoned"] or 0),
                "native_agent_bindings": int(host_row["native_bound"] or 0),
                "operational_qa_passed": sum(
                    int(row["count"]) for row in qa_rows if bool(row["accepted"])
                ),
                "operational_qa_failed": sum(
                    int(row["count"]) for row in qa_rows if not bool(row["accepted"])
                ),
                "host_usage_complete": int(host_row["usage_complete"] or 0),
                "host_usage_unknown": int(host_row["usage_unknown"] or 0),
            },
        )
        return snapshot

    def expire(self, project_id: str, *, now_ms: int) -> int:
        """Apply retention and lineage deletion until nothing due is left: bounded batches, each its own
        lock hold and transaction (the lock is released between them); returns how many records went."""
        removed = 0
        while True:
            report = self.expire_report(project_id, now_ms=now_ms)
            removed += report["removed"]
            if not report["more"] or not report["removed"]:
                return removed

    def expire_report(self, project_id: str, *, now_ms: int) -> dict[str, Any]:
        """Apply retention and lineage deletion; {'removed': count, 'more': True} when a bounded batch of
        event summaries left expired raw events for a next call."""
        with self._held():
            if self._readers():
                raise LedgerError("expiry requires closed scoped readers")
            links = self._connection.execute(
                "SELECT from_record_id,to_record_id FROM record_links WHERE project_id=?",
                (project_id,),
            ).fetchall()
            undirected: dict[str, set[str]] = {}
            for row in links:
                left, right = str(row[0]), str(row[1])
                undirected.setdefault(left, set()).add(right)
                undirected.setdefault(right, set()).add(left)
            promoted_rows = self._connection.execute(
                "SELECT record_id,content FROM records WHERE project_id=? "
                "AND record_type='promotion'",
                (project_id,),
            ).fetchall()
            protected = {
                str(row["record_id"])
                for row in promoted_rows
                if json.loads(bytes(row["content"]))["action"] == "promoted"
            }
            protected_frontier = list(protected)
            while protected_frontier:
                current = protected_frontier.pop()
                for linked in undirected.get(current, set()):
                    if linked not in protected:
                        protected.add(linked)
                        protected_frontier.append(linked)
            # One bounded page of due records (EXPIRE_SUMMARY_BATCH, in sequence order), never all of them.
            identifiers: set[str] = set()
            last_sequence, after, more = 0, 0, False
            while len(identifiers) < EXPIRE_SUMMARY_BATCH:
                page = self._connection.execute(
                    "SELECT record_id,source_sequence FROM records WHERE project_id=? "
                    "AND expires_at_ms IS NOT NULL AND expires_at_ms<=? AND source_sequence>? "
                    "ORDER BY source_sequence LIMIT ?",
                    (project_id, now_ms, after, EXPIRE_SUMMARY_BATCH)).fetchall()
                if not page:
                    break
                for row in page:
                    after = int(row[1])
                    if str(row[0]) not in protected:
                        identifiers.add(str(row[0]))
                        last_sequence = after
                    if len(identifiers) == EXPIRE_SUMMARY_BATCH:
                        more = self._connection.execute(
                            "SELECT 1 FROM records WHERE project_id=? AND expires_at_ms IS NOT NULL "
                            "AND expires_at_ms<=? AND source_sequence>? LIMIT 1",
                            (project_id, now_ms, after)).fetchone() is not None
                        break
            event_rows = self._expire_event_targets(project_id, now_ms, last_sequence)
            frontier = list(identifiers)
            adjacency: dict[str, set[str]] = {}
            for row in links:
                left, right = str(row[0]), str(row[1])
                adjacency.setdefault(left, set()).add(right)
            while frontier:
                current = frontier.pop()
                for linked in adjacency.get(current, set()):
                    if linked not in identifiers and linked not in protected:
                        identifiers.add(linked)
                        frontier.append(linked)
            stored = self._connection.execute(
                "SELECT relative_path,kind,source_record_id,expires_at_ms "
                "FROM stored_files WHERE project_id=?",
                (project_id,),
            ).fetchall()
            file_rows = [
                row
                for row in stored
                if (
                    (row["expires_at_ms"] is not None and int(row["expires_at_ms"]) <= now_ms)
                    or (row["source_record_id"] in identifiers)
                    or (bool(identifiers) and row["kind"] == "backup")
                )
            ]
            if not identifiers and not file_rows:
                with self._connection:
                    self._connection.execute(
                        "DELETE FROM repair_receipts WHERE project_id=? AND expires_at_ms<=?",
                        (project_id, now_ms),
                    )
                    self._connection.execute(
                        "DELETE FROM operational_check_receipts "
                        "WHERE project_id=? AND expires_at_ms<=?",
                        (project_id, now_ms),
                    )
                return {"removed": 0, "more": more}
            self._begin_exclusive_maintenance()
            try:
                self._summarise_expiring_events(project_id, event_rows, identifiers, now_ms)
                self._connection.execute(
                    "DELETE FROM repair_receipts WHERE project_id=? AND expires_at_ms<=?",
                    (project_id, now_ms),
                )
                self._connection.execute(
                    "DELETE FROM operational_check_receipts "
                    "WHERE project_id=? AND expires_at_ms<=?",
                    (project_id, now_ms),
                )
                for row in file_rows:
                    self._connection.execute(
                        "DELETE FROM stored_files WHERE project_id=? AND relative_path=?",
                        (project_id, str(row["relative_path"])),
                    )
                for record_id in identifiers:
                    self._connection.execute(
                        "DELETE FROM records WHERE project_id=? AND record_id=?",
                        (project_id, record_id),
                    )
                self._connection.execute("COMMIT")
            except Exception:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
            finally:
                self._finish_exclusive_maintenance()
            for row in file_rows:
                self._remove_registered_path(project_id, str(row["relative_path"]))
            for root in (self.state.artifacts, self.state.exports, self.state.backups):
                with contextlib.suppress(OSError):
                    (root / project_id).rmdir()
        return {"removed": len(identifiers), "more": more}

    def _holds_account_restrictions_locked(self, project_id: str, now_ms: int) -> bool:
        """Whether a project holds a record that still restricts its account.

        That is paid usage or overage in the last day, an exhausted or rejected
        headroom window that has not reset, ordinary Codex usage disallowed in
        the last 30 minutes, a probe cooldown, or a passing run admission
        that may still count under a run cap, or a Codex reading in the last day that
        reports spend control reached. Records stamped after now count.
        """

        from .providers import (
            BILLING_MAX_AGE_MS,
            EVIDENCE_HORIZON_MS,
            FIVE_HOURS_MS,
            _headroom_state,
        )

        rows = self._connection.execute(
            "SELECT record_type,source,observed_at_ms,content FROM records "
            "WHERE project_id=? AND record_type IN "
            "('provider_billing','provider_headroom','probe_admission','admission_decision')",
            (project_id,),
        ).fetchall()
        for row in rows:
            record = json.loads(bytes(row["content"]))
            age = now_ms - int(row["observed_at_ms"])
            kind = str(row["record_type"])
            if kind == "provider_billing" and row["source"] == "provider":
                if age <= EVIDENCE_HORIZON_MS and (
                    record["paid_usage_usable"] is True or record["is_using_overage"] is True
                ):
                    return True
                if (
                    age <= EVIDENCE_HORIZON_MS
                    and record["provider"] == "codex"
                    and record.get("spend_control_reached") is True
                ):
                    return True
                if age <= BILLING_MAX_AGE_MS and record["ordinary_usage_allowed"] is False:
                    return True
            elif kind == "provider_headroom" and row["source"] == "provider":
                if _headroom_state(record["provider"], record, now_ms) == "exhausted":
                    return True
            elif kind == "probe_admission" and row["source"] == "lifecycle":
                if record["decision"] == "pass" and age < PROBE_COOLDOWN_SECONDS * 1000:
                    return True
            elif kind == "admission_decision" and row["source"] == "lifecycle":
                if (
                    record["decision"] == "pass"
                    and record["run_id"] is not None
                    and age < FIVE_HOURS_MS
                ):
                    return True
        return False

    def delete_project(self, project_id: str, *, now_ms: int | None = None) -> str:
        timestamp = now_ms if now_ms is not None else time.time_ns() // 1_000_000
        deletion_id = f"del_{secrets.token_hex(16)}"
        with self._held():
            if self._readers():
                raise LedgerError("project deletion requires closed scoped readers")
            if self._connection.execute(
                "SELECT 1 FROM account_billing_probe_requests "
                "WHERE project_id=? AND state='admitted' LIMIT 1",
                (project_id,),
            ).fetchone() is not None:
                raise LedgerError("project_has_active_billing_probe")
            if self._connection.execute(
                # O0b RS-A (draft 4b): a slot released lost or crashed inside machine_idle's day still blocks
                # deletion, as its unreleased row did before, since its child may still be running.
                "SELECT 1 FROM active_run_capacity a WHERE a.project_id=? AND (a.released_at_ms IS NULL OR "
                "(a.claimed_at_ms>=? AND EXISTS(SELECT 1 FROM run_holds r WHERE r.project_id=a.project_id "
                "AND r.kind='run_slot' AND r.identity=a.handle_digest AND r.release_kind IN ('lost','crashed')))) LIMIT 1",
                (project_id, self._clock_ms() - LEGACY_RUN_MAX_MS),  # F4: the ledger's clock, never the caller's
            ).fetchone() is not None:
                raise LedgerError("project_has_active_launch_capacity")
            # Account restrictions are read from every project, so deleting the
            # project that holds one would lift it. The ledger's own clock
            # decides, never the caller's time.
            if self._holds_account_restrictions_locked(project_id, self._clock_ms()):
                raise LedgerError("project_holds_account_restrictions")
            rows = self._connection.execute(
                "SELECT relative_path FROM stored_files WHERE project_id=?", (project_id,)
            ).fetchall()
            self._begin_exclusive_maintenance()
            try:
                self._connection.execute("DELETE FROM hook_ingestion WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM account_billing_probe_requests WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM account_billing_probe_origins WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM records WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM sessions WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM run_provenance WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM stored_files WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM collector_health WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM repair_receipts WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM host_run_bindings WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM launch_receipts WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM launch_observations WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM launch_inputs WHERE project_id=?", (project_id,))
                self._connection.execute("DELETE FROM active_run_capacity WHERE project_id=? AND released_at_ms IS NOT NULL", (project_id,))
                self._connection.execute("DELETE FROM launch_claims WHERE project_id=?", (project_id,))
                # O0b RS-A (F4): the register rows and tombstones go with the holds they record.
                self._connection.execute("DELETE FROM run_holds WHERE project_id=?", (project_id,))
                updated = self._connection.execute(
                    "UPDATE projects SET canonical_root=NULL,root_digest=NULL,status='deleted',deleted_at_ms=? "
                    "WHERE project_id=? AND status='active'",
                    (timestamp, project_id),
                ).rowcount
                if not updated:
                    raise LedgerError("project binding is not active")
                self._connection.execute(
                    "INSERT INTO tombstones VALUES(?,?,?)",
                    (project_id, deletion_id, timestamp),
                )
                self._connection.execute("COMMIT")
            except Exception:
                if self._connection.in_transaction:
                    self._connection.execute("ROLLBACK")
                raise
            finally:
                self._finish_exclusive_maintenance()
            for row in rows:
                self._remove_registered_path(project_id, str(row[0]))
            for root in (self.state.artifacts, self.state.exports, self.state.backups):
                with contextlib.suppress(OSError):
                    (root / project_id).rmdir()
        return deletion_id

    def _begin_exclusive_maintenance(self) -> None:
        """Acquire a rollback-journal exclusive transaction or fail before deletion."""

        self._connection.execute("PRAGMA busy_timeout = 50")
        try:
            checkpoint = self._connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            if checkpoint is None or int(checkpoint[0]) != 0:
                raise LedgerError("maintenance requires all external readers to close")
            mode = str(self._connection.execute("PRAGMA journal_mode = DELETE").fetchone()[0])
            if mode.lower() != "delete":
                raise LedgerError("maintenance could not acquire rollback journal mode")
            self._connection.execute("BEGIN EXCLUSIVE")
        except (sqlite3.Error, LedgerError) as exc:
            with contextlib.suppress(sqlite3.Error):
                self._connection.execute("PRAGMA journal_mode = WAL")
            self._connection.execute("PRAGMA busy_timeout = 5000")
            if isinstance(exc, LedgerError):
                raise
            raise LedgerError("maintenance requires all external readers to close") from exc

    def _finish_exclusive_maintenance(self) -> None:
        try:
            self._connection.execute("VACUUM")
            mode_cursor = self._connection.execute("PRAGMA journal_mode = WAL")
            mode_row = mode_cursor.fetchone()
            mode_cursor.close()
            mode = str(mode_row[0])
            if mode.lower() != "wal":
                raise LedgerError("ledger journal mode could not be restored")
            # VACUUM has already committed a complete rollback-journal image.
            # Re-entering WAL is sufficient here; a same-connection checkpoint can
            # report SQLITE_LOCKED while schema statements remain cached even though
            # no external reader exists.
        except sqlite3.Error as exc:
            raise LedgerError("ledger maintenance could not be finalized") from exc
        finally:
            self._connection.execute("PRAGMA busy_timeout = 5000")
            self.state.harden_database_files()

    def _remove_registered_path(self, project_id: str, relative: str) -> None:
        self._fence.check(self._connection)
        path = Path(relative)
        if (
            path.is_absolute()
            or ".." in path.parts
            or len(path.parts) < 3
            or path.parts[0] not in {"artifacts", "exports", "backups"}
            or path.parts[1] != project_id
        ):
            raise LedgerError("registered file path is unsafe")
        descriptor = os.open(
            self.state.root,
            os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0),
        )
        try:
            for part in path.parent.parts:
                next_descriptor = os.open(
                    part,
                    os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0),
                    dir_fd=descriptor,
                )
                os.close(descriptor)
                descriptor = next_descriptor
            try:
                os.unlink(path.name, dir_fd=descriptor)
            except FileNotFoundError:
                pass
        except OSError as exc:
            raise LedgerError("registered file path is unsafe") from exc
        finally:
            os.close(descriptor)

    def storage_residuals(self) -> list[str]:
        residuals = []
        for suffix in ("-wal", "-journal"):
            path = Path(str(self.state.database) + suffix)
            if path.exists() and path.stat().st_size:
                residuals.append(path.name)
        return residuals


class ProjectRepository:
    """Fixed project-scoped read surface."""

    def __init__(self, ledger: LearningLedger, project_id: str) -> None:
        self.__ledger = ledger
        self.project_id = project_id

    def records(self, record_type: str | None = None) -> list[dict[str, Any]]:
        if record_type is not None and record_type not in RECORD_TYPES:
            raise LedgerError("record type is unsupported")
        records = self.__ledger._records_for_project(self.project_id, record_type)
        all_cases = self.__ledger._records_for_project(
            self.project_id, "evaluation_case"
        )
        hidden_development = {
            case["supersedes_case_id"]
            for case in all_cases
            if case["corpus_state"] != "development"
        }
        return [
            record
            for record in records
            if record.get("record_type") != "evaluation_case"
            or (
                record.get("corpus_state") == "development"
                and record.get("record_id") not in hidden_development
            )
        ]

    def record(self, record_id: str, record_type: str | None = None) -> dict[str, Any]:
        """Return one immutable record from this project partition."""

        records = self.records(record_type)
        matches = [record for record in records if record["record_id"] == record_id]
        if len(matches) != 1:
            raise LedgerError("project record was not found")
        return {key: value for key, value in matches[0].items() if not key.startswith("_")}


_PASSING_READ_REFUSALS = frozenset({
    "sql_read_busy", "sql_read_deadline", "sql_read_work_limit", "sql_read_value_limit",
})


def _passing_refusal(error: BaseException) -> bool:
    """A refusal that leaves the connection healthy: the busy database or a read's own limit."""
    if isinstance(error, SQLReadError):
        return error.reason_code in _PASSING_READ_REFUSALS
    code = getattr(error, "sqlite_errorcode", None)
    return (isinstance(error, sqlite3.OperationalError) and type(code) is int
            and code & 255 in {sqlite3.SQLITE_BUSY, sqlite3.SQLITE_LOCKED})


def _wake_marked(folder: Path) -> bool:
    """E2a-9 (decision 179): whether any service instance left its unpublished-write marker (one file per instance
    in the project's marker folder; a dot name is one being created)."""
    try:
        with os.scandir(folder) as entries:
            return any(not entry.name.startswith(".") for entry in entries)
    except OSError:
        return os.path.lexists(folder)


class CollectorServer:
    """Sequential AF_UNIX collector. Only this loop calls the ledger writer."""

    def __init__(
        self,
        ledger: LearningLedger,
        *,
        client_capabilities: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        self.ledger = ledger
        self.state = ledger.state
        self._bindings: dict[str, SessionBinding] = {}
        self._stop = threading.Event()
        self._ready = threading.Event()
        self._thread: threading.Thread | None = None
        self._socket: socket.socket | None = None
        self._startup_error: OSError | None = None
        self._started_at_ms: int | None = None
        # How the previous collector stopped, and an error that ended this one's thread (0.3.3, C10).
        self.previous_exit: dict | None = None
        self.startup_phases: dict | None = None  # S1-U9a, set by collector_host once started
        # O10 ST1, set by collector_host: 'starting', 'running' or 'unavailable'; None otherwise.
        self.account_services: str | None = None
        # S1-H1a, set by collector_host: the account lanes' published notes (a no-lock view).
        self.account_lanes = None
        self.account_restart = None  # S1-H1c, set by collector_host: its latest restart decision
        self.account_restart_last = None  # S1-H1c D5: the last self-restart kept (time, lane, cause)
        self.thread_error: BaseException | None = None
        self.sweep_error: str | None = None  # S1-H1a-6: the type of the last unexpected sweep error
        self._sweeps: threading.Thread | None = None
        self._sweeps_stop = threading.Event()
        # HM-0: the health monitor's checks, run once per full sweep interval after the cycle (no ledger lock).
        self.health_monitor = HealthMonitor.with_builtin_checks(sweep_interval_seconds=WORKER_RESULT_SWEEP_SECONDS)
        # HM-1: every COCOLO run container belongs to a live run, over the journals under this state root.
        self.health_monitor.register(ContainerCheck(self.state.root))
        self._clients = client_capabilities or load_client_capabilities(
            Path(__file__).resolve().parent.parent / "config" / "learning-clients.json"
        )

    def start(self) -> None:
        if not hasattr(socket, "AF_UNIX") or fcntl is None:
            raise CollectorError("local Unix sockets are unavailable")
        if (self._thread and self._thread.is_alive()) or (self._sweeps and self._sweeps.is_alive()):
            # G4: refused before anything changes, so a sweep left from a stop stays cancelled.
            raise CollectorError("collector is already running")
        self._stop.clear()
        self._sweeps_stop.clear()  # before the thread starts, so a stop right after start is kept (G1)
        self._ready.clear()
        self._startup_error = None
        with self.ledger._lock:
            if self.ledger._collector_active:
                raise CollectorError("another collector owns this state root")
            self.ledger._collector_active = True
        self._thread = threading.Thread(target=self.serve, name="codex-agents-collector")
        self._thread.start()
        if not self._ready.wait(5):
            self._release_lock()
            raise CollectorError("collector did not start")
        if self._startup_error is not None:
            self._release_lock()
            raise CollectorError("collector endpoint could not be created") from self._startup_error

    def serve(self) -> None:
        if self.state.socket.exists():
            self.state.socket.unlink()
        listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._socket = listener
        try:
            listener.bind(str(self.state.socket))
        except OSError as exc:
            self._startup_error = exc
            self._ready.set()
            listener.close()
            self._socket = None
            return
        os.chmod(self.state.socket, 0o600)
        listener.listen(16)
        listener.settimeout(0.1)
        self._started_at_ms = time.time_ns() // 1_000_000
        # RS-E E2a-3/11 (review round 1): the owner's credential for record_launch and launch_status.
        self._owner_verifier = None
        with contextlib.suppress(Exception):
            from .service_enrollment import issue_collector_owner
            from .collector_paths import CollectorPaths
            self._owner_verifier = issue_collector_owner(CollectorPaths(self.state.root))
        # RS-E E2a-9: unknown projects are marked due before this collector reports ready (nothing starts here),
        # for at most WAKE_STARTUP_SECONDS; the wake thread finishes the rest at once.
        try:
            self._wake_cursor = ""
            self._reconcile_wakes(WAKE_STARTUP_SECONDS)
        except Exception as error:
            self.sweep_error = type(error).__name__
        # S1-H1a-6b: the sweeps run on their own thread, so no request waits behind one. G5: one that
        # cannot start is a start-up failure, before ready is published.
        try:
            sweeps = threading.Thread(target=self._sweep_loop, name="collector-sweeps", daemon=True)
            sweeps.start()
        except Exception as exc:
            self._startup_error = exc
            listener.close()  # closed and removed before start() is told, so it never sees them
            self._socket = None
            with contextlib.suppress(FileNotFoundError):
                self.state.socket.unlink()
            self._ready.set()
            return
        self._sweeps = sweeps
        # RS-E E2a-9: and once per sweep interval on a thread of its own (never inside a sweep's ledger hold).
        self._wakes = None
        with contextlib.suppress(Exception):
            self._wakes = threading.Thread(target=self._wake_loop, name="collector-wakes", daemon=True)
            self._wakes.start()
        # RS-E E2c: the starter (its own thread and workers; nothing of it runs before ready, E2c-3).
        self._starter = None
        with contextlib.suppress(Exception):
            from .project_start import ProjectStarter
            self._starter = ProjectStarter(self)
            self._starter.start()
        self._ready.set()
        try:
            while not self._stop.is_set():
                try:
                    connection, _ = listener.accept()
                except TimeoutError:
                    continue
                with connection:
                    response = self._handle(connection)
                    connection.settimeout(1)
                    with contextlib.suppress(OSError):
                        connection.sendall(canonical_json(response) + b"\n")
        except BaseException as error:
            self.thread_error = error
            raise
        finally:
            # Its own event, not _stop: the host reads _stop as "asked to stop" (C10d).
            self._sweeps_stop.set()
            self._sweeps.join(5)
            if getattr(self, "_wakes", None) is not None:
                self._wakes.join(5)
            if getattr(self, "_starter", None) is not None:
                self._starter.join(5)
            listener.close()
            self._socket = None
            with contextlib.suppress(FileNotFoundError):
                self.state.socket.unlink()

    def _sweep_loop(self) -> None:
        """Every WORKER_RESULT_SWEEP_SECONDS from the last cycle's start (as on the request loop), one
        sweep cycle. An unexpected error is recorded by type and the next cycle runs (S1-H1a-6b).
        O0b RS-A round 1 F12: while due account holds or event-retention batches remain, a bounded cycle runs every
        SWEEP_BATCH_GAP_SECONDS, each under its own hold of the ledger lock; a busy cycle is retried
        after SWEEP_BUSY_RETRY_SECONDS (never past the next cycle's start). A stop ends either wait.
        Round 2 G6: while idle, due holds are checked every SWEEP_IDLE_CHECK_SECONDS (never past the next
        cycle's start); holds found due start the batches at once."""
        due = time.monotonic() + WORKER_RESULT_SWEEP_SECONDS
        wait, full, draining = min(SWEEP_IDLE_CHECK_SECONDS, WORKER_RESULT_SWEEP_SECONDS), False, False
        health_due = False
        while not self._sweeps_stop.wait(max(0.0, wait)):
            now = time.monotonic()
            if now >= due:
                due, full, health_due = now + WORKER_RESULT_SWEEP_SECONDS, True, True
            if not (full or draining):  # G6: idle, so the cheap check first
                try:
                    draining = self._holds_due_idle()
                except Exception as error:
                    self.sweep_error = type(error).__name__
                if not draining:
                    wait = min(SWEEP_IDLE_CHECK_SECONDS, due - time.monotonic())
                    continue
            try:
                outcome = self._sweep_cycle(holds_only=not full)
            except Exception as error:
                self.sweep_error = type(error).__name__
                outcome = None
            if health_due and not self._sweeps_stop.is_set():
                # HM-0: once per full interval, after the cycle released the ledger lock, even when the ledger
                # was busy (a held ledger is something the monitor should still be running beside).
                health_due = False
                self._run_health_pass()
            if outcome == "busy":  # the same cycle again, soon
                wait = min(SWEEP_BUSY_RETRY_SECONDS, due - time.monotonic())
                continue
            full, draining = False, outcome == "more"
            wait = SWEEP_BATCH_GAP_SECONDS if draining else min(SWEEP_IDLE_CHECK_SECONDS, due - time.monotonic())

    def _owner_request(self, request: dict[str, Any], fields: tuple[str, ...]) -> bool:
        """E2a-3/11 (review round 1): whether the request carries the owner's proof for exactly these fields, its
        project root as the subject. Checked before anything is looked up; every failure is the same refusal."""
        verifier = getattr(self, "_owner_verifier", None)
        line = request.get("owner")
        if verifier is None or type(line) is not str:
            return False
        try:
            from .hosts import OWNER_CLIENT
            enrolled = verifier.verify(line.encode("ascii"))
            message = canonical_json({name: request[name] for name in fields})
        except Exception:
            return False
        return (enrolled.role == "account" and enrolled.host_client == OWNER_CLIENT
                and enrolled.subject == request["project_root"]
                and hmac.compare_digest(enrolled.request_digest, hashlib.sha256(message).hexdigest()))

    def _wake_loop(self) -> None:
        # A startup pass that ran out of time is finished at once; then once per sweep interval.
        wait = 0.0 if getattr(self, "_wake_cursor", "") else WORKER_RESULT_SWEEP_SECONDS
        while not self._sweeps_stop.wait(wait):
            try:
                self._reconcile_wakes()
            except Exception as error:
                self.sweep_error = type(error).__name__
            wait = 0.0 if getattr(self, "_wake_cursor", "") else WORKER_RESULT_SWEEP_SECONDS

    def _reconcile_wakes(self, budget_seconds: float = WAKE_PASS_SECONDS) -> int:
        """RS-E E2a-9: one pass over the active projects from the saved cursor, page by page. Each page is read and
        its unknown rows marked under the ledger lock, each in its own short hold; whether a live host serves a
        candidate (and whether a clean stop's service left an unpublished-write marker) is checked between, off the
        lock. Past `budget_seconds` the pass stops and keeps its cursor for the next pass. Returns how many were
        marked due. Nothing is started."""
        from .wake_contracts import WAKE_MARKER
        end = time.monotonic() + budget_seconds
        cursor, marked = getattr(self, "_wake_cursor", "") or "", 0
        while True:
            now = time.time_ns() // 1_000_000
            page, following = self.ledger.wake_reconcile_page(after=cursor)
            unserved, stopped = [], False
            for project_id, root, status, epoch, seq, state, due in page:
                if time.monotonic() >= end:
                    stopped = True
                    break
                if status != "active" or (due is not None and due <= now):
                    cursor = project_id
                    continue  # not a project, or already due
                marker = False
                if state == "clean_stop":
                    # A clean stop is trusted unless a service wrote with no acknowledged publication.
                    marker = _wake_marked(self.state.root / "projects" / project_id / WAKE_MARKER)
                    if not marker:
                        cursor = project_id
                        continue
                # Decision 179: each probe waits at most what is left of the pass, and one the budget cut short
                # is not counted: the next pass (the wake thread, at once) probes that project again.
                with probe_deadline(end):
                    serving = project_host_serving(self.state.root, root)
                if time.monotonic() >= end:
                    stopped = True
                    break
                cursor = project_id
                if not serving:
                    unserved.append((project_id, root, epoch, seq, marker))
            if unserved:
                marked += self.ledger.mark_wakes_due(unserved, now_ms=now)
            if stopped:
                self._wake_cursor = cursor  # the next pass resumes after the last row handled
                return marked
            if following is None:
                self._wake_cursor = ""
                return marked
            cursor = following

    def _run_health_pass(self) -> None:
        """HM-0: one bounded health pass, never under the ledger lock. A failure of the runner itself is
        recorded by type like any sweep error; a check's own failure is a finding, not an error."""
        try:
            self.health_monitor.run_pass(should_stop=self._sweeps_stop.is_set)
        except Exception as error:
            self.sweep_error = type(error).__name__

    def _holds_due_idle(self) -> bool:
        """O0b RS-A round 2 G6: the idle check, whether any account hold is due. The ledger lock is taken
        without waiting: a held ledger, or a reader or transaction inside, means not now (the next idle check
        comes SWEEP_IDLE_CHECK_SECONDS later), and is not a lock refusal."""
        lock = self.ledger._lock
        if not lock.acquire(blocking=False):
            return False
        try:
            if self.ledger._readers() or self.ledger._connection.in_transaction:
                return False
            return self.ledger.account_holds_due()
        finally:
            lock.release()

    def _sweep_cycle(self, *, holds_only: bool = False) -> str | None:
        """The sweeps in their old order, at most one event batch under one ledger hold, and none while a
        reader (which spans several holds) or a transaction is active (review 040-h1a6-design). The
        lock is never waited on past a stop. O0b RS-A round 1 F12: `holds_only` runs the account hold
        release plus any pending event batch; returns "busy" when nothing ran for a held ledger or a reader inside,
        "more" when either filled its batch (more may be due), else None. Event rows are the durable cursor:
        each committed batch disappears, so a later collector resumes without a separate checkpoint."""
        lock = self.ledger._lock
        deadline = time.monotonic() + LEDGER_LOCK_WAIT_MS / 1000  # E1a-2: a busy ledger skips the cycle
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:  # checked before each attempt, and no attempt runs past it
                self.ledger._lock_waits.refused("sweeps")
                return "busy"
            if lock.acquire(timeout=min(0.1, remaining)):
                break
            if self._sweeps_stop.is_set():
                return None
        try:
            if self.ledger._readers() or self.ledger._connection.in_transaction:
                return "busy"
            loose = (LedgerError, OSError, sqlite3.Error, ValueError, KeyError)
            released = []

            def release_holds():
                released.append(self.ledger.release_due_account_holds(limit=ACCOUNT_HOLD_RELEASE_BATCH))
            # Kept worker results expire on time even while the collector is the only process holding
            # the ledger; raw events past their weight's period are summarised and removed, a small batch
            # at a time; finished account rows past their retention go too (0.3.4 R6).
            # O0b RS-A-4: due account holds are released here, with no client action, in batches of 64. Until
            # M4b E1b's owner thread exists this runs where the other account sweeps run, under the ledger lock.
            def drain_event_retention():
                # LOCKHOLD-1: one whole transaction per cycle. The loop schedules
                # the next batch after releasing the outer lock and waiting its
                # cancellable gap. None still means nothing removed (decision 220).
                # A suppressed failure ends this pass until the next full interval.
                self._event_retention_more = False
                self._event_retention_more = (self.ledger.sweep_event_retention() or 0) >= EVENT_SWEEP_BATCH
            sweeps = [(self.ledger.sweep_worker_results, (LedgerError, OSError, sqlite3.Error)),
                      (drain_event_retention, loose),
                      (self.ledger.sweep_learning_retention, loose),  # O0c P8: cases and candidates past the window
                      (self.ledger.sweep_superseded_attestations, loose),  # O0c P9: only the latest attestation stays
                      (self.ledger.sweep_account_retention, loose),
                      (release_holds, loose)]
            pending_events = getattr(self, "_event_retention_more", False)
            selected = ([sweeps[1], sweeps[5]] if pending_events else sweeps[5:]) if holds_only else sweeps
            for sweep, errors in selected:
                if self._sweeps_stop.is_set():
                    return None
                with contextlib.suppress(*errors):
                    sweep()
            return "more" if (released == [ACCOUNT_HOLD_RELEASE_BATCH]
                              or getattr(self, "_event_retention_more", False)) else None
        finally:
            lock.release()

    def _handle(self, connection: socket.socket) -> dict[str, Any]:
        raw = bytearray()
        deadline = time.monotonic() + COLLECTOR_REQUEST_DEADLINE_SECONDS
        while b"\n" not in raw:
            # One absolute deadline for the whole request, not per receive.
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return {"ok": False, "code": "request_timeout"}
            connection.settimeout(remaining)
            try:
                chunk = connection.recv(8192)
            except TimeoutError:
                return {"ok": False, "code": "request_timeout"}
            if not chunk:
                break
            raw.extend(chunk)
            if len(raw) > MAX_REQUEST_BYTES:
                return {"ok": False, "code": "request_oversized"}
        try:
            request = parse_bounded_json(
                bytes(raw).split(b"\n", 1)[0], max_bytes=MAX_REQUEST_BYTES
            )
        except ContractError:
            return {"ok": False, "code": "request_invalid"}
        if not isinstance(request, dict) or request.get("protocol") != COLLECTOR_PROTOCOL_VERSION:
            return {"ok": False, "code": "protocol_mismatch"}
        # M4b E1a (revision 3c): the request's ledger waits share one deadline, which starts once the
        # whole frame is here (receiving uses its own deadline above) and is restored on return.
        with ledger_waits.request():
            return self._dispatch(request)

    def _dispatch(self, request: dict[str, Any]) -> dict[str, Any]:
        try:
            drained_stop = False
            if request.get("op") == "shutdown_if_drained":
                # UPG-5: the drained stop is how a newer build hands over from this collector, so it is
                # accepted from a caller of another runtime (any well-formed digest, or none). It still
                # refuses while a run is active and changes nothing else; every other mutating
                # operation keeps the exact digest gate below (decision 129.3).
                offered = request.get("runtime_digest")
                if offered is None or (type(offered) is str and re.fullmatch(r"[0-9a-f]{64}", offered)):
                    request = {key: value for key, value in request.items() if key != "runtime_digest"}
                    drained_stop = True
            if request.get("op") in COLLECTOR_MUTATING_OPERATIONS and not drained_stop:
                if request.get("runtime_digest") != COLLECTOR_RUNTIME_DIGEST:
                    return {"ok": False, "code": "runtime_upgrade_required",
                            "message": RUNTIME_UPGRADE_MESSAGE, "update_command": RUNTIME_UPDATE_COMMAND}
                # Check the original envelope before any side effect, then retain the closed
                # operation-specific shapes below. Never mutate the caller's request object.
                request = {key: value for key, value in request.items() if key != "runtime_digest"}
            if request.get("op") == "bind" and set(request) == {
                "protocol",
                "op",
                "project_root",
                "session_id",
                "producer",
                "client_version",
            }:
                now_ms = time.time_ns() // 1_000_000
                self._bindings = {
                    key: value
                    for key, value in self._bindings.items()
                    if value.expires_at_ms > now_ms
                }
                if len(self._bindings) >= 4096:
                    return {"ok": False, "code": "binding_capacity"}
                client = self._clients.get(request["client_version"])
                if client is None or request["client_version"].startswith(
                    "codex-eval-fixture-"
                ):
                    return {"ok": False, "code": "client_unvalidated"}
                producer = request["producer"]
                if producer not in client.get("producers", []):
                    return {"ok": False, "code": "producer_rejected"}
                if producer == "hook":
                    coverage = client["hook_coverage"]
                    event_codes = frozenset(value[0] for value in HOOK_EVENTS.values())
                elif producer == "app_server":
                    coverage = client["app_server_coverage"]
                    event_codes = frozenset(
                        {
                            "turn_started", "turn_completed", "turn_failed",
                            "turn_interrupted", "item_completed", "model_rerouted",
                            "usage_snapshot",
                        }
                    )
                else:
                    return {"ok": False, "code": "operation_rejected"}
                project_id, session_digest, root_run_id = self.ledger.bind_session(
                    Path(request["project_root"]),
                    request["session_id"],
                    request["producer"],
                    request["client_version"],
                )
                token = f"bnd_{secrets.token_hex(24)}"
                self._bindings[token] = SessionBinding(
                    token,
                    project_id,
                    session_digest,
                    request["producer"],
                    root_run_id,
                    coverage,
                    event_codes,
                    now_ms + 300_000,
                )
                return {"ok": True, "binding_token": token}
            if request.get("op") == "ingest" and set(request) == {
                "protocol",
                "op",
                "binding_token",
                "record",
            }:
                binding = self._bindings.pop(request["binding_token"], None)
                if not binding or binding.expires_at_ms <= time.time_ns() // 1_000_000:
                    return {"ok": False, "code": "binding_invalid"}
                record = validate_learning_record(request["record"])
                if record["record_type"] != "event" or not (
                    record["run_id"] == binding.root_run_id
                    or record["parent_run_id"] == binding.root_run_id
                ):
                    return {"ok": False, "code": "provenance_mismatch"}
                if (
                    record["coverage"] != binding.coverage
                    or record["event_code"] not in binding.event_codes
                ):
                    return {"ok": False, "code": "capability_mismatch"}
                try:
                    result = self.ledger.append(
                        binding.project_id, record, producer=binding.producer
                    )
                except LedgerError as exc:
                    if str(exc) == "record identifier conflicts with existing content":
                        return {"ok": False, "code": "record_conflict"}
                    raise
                return {"ok": True, **result}
            if request.get("op") == "issue_result_repair" and set(request) == {
                "protocol",
                "op",
                "project_root",
                "assignment_digest",
                "reason_code",
            }:
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                receipt_id = self.ledger.issue_result_repair_receipt(
                    project_id,
                    request["assignment_digest"],
                    request["reason_code"],
                )
                return {"ok": True, "receipt_id": receipt_id}
            if request.get("op") == "register" and set(request) == {
                "protocol", "op", "project_root",
            }:
                # The owner's registration on the running compatible collector, so
                # another project's running children keep their collector.
                project_id = self.ledger.register_project(Path(request["project_root"]))
                # RS-E E2a-5: the project's wake credential, as the account host issues one at its start.
                with contextlib.suppress(Exception):
                    from .service_enrollment import keep_wake_capability
                    from .collector_paths import CollectorPaths
                    # UPDFIX-5 (L1.2): a valid key is kept, so registering again changes no file.
                    keep_wake_capability(CollectorPaths(self.state.root), Path(request["project_root"]), project_id)
                return {"ok": True, "project_id": project_id}
            if request.get("op") == "launch_status" and set(request) == {"protocol", "op", "project_root", "owner"}:
                # RS-E E2a-11: whether setup's launch record exists for this registered root (read only). Review
                # round 1: only for the owner's proof naming this root, checked before any lookup.
                if not self._owner_request(request, ("op", "project_root")):
                    return {"ok": False, "code": "operation_rejected"}
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                return {"ok": True, "recorded": self.ledger.launch_record(project_id) is not None}
            if request.get("op") in {"start_status", "start_unpark"} and set(request) == {
                "protocol", "op", "project_root", "owner",
            }:
                # RS-E E2c-9/E2c-4: the starter's status line for this root (read only), or the owner's start
                # command ending its park. Only for the owner's proof naming this root, checked before any lookup.
                if not self._owner_request(request, ("op", "project_root")):
                    return {"ok": False, "code": "operation_rejected"}
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                if request["op"] == "start_unpark":
                    self.ledger.unpark_start(project_id, now_ms=time.time_ns() // 1_000_000)
                    return {"ok": True}
                from .project_start import recovery_line
                return {"ok": True, "recovery": recovery_line(self.ledger.start_record(project_id),
                                                              request["project_root"], time.time_ns() // 1_000_000)}
            if request.get("op") == "record_launch" and set(request) == {
                "protocol", "op", "project_root", "launch_copy", "launch_digest", "owner",
            }:
                # RS-E E2a-3: setup's launch record for its registered project. Review round 1: the owner's proof
                # first, then the collector verifies the whole target itself at its trusted copy root (this
                # project's protected copy under the account's ~/.codex, bound to it, byte for byte), off the lock.
                if not self._owner_request(request, ("op", "project_root", "launch_copy", "launch_digest")):
                    return {"ok": False, "code": "operation_rejected"}
                from .host_commands import launch_target_problem
                if (type(request["launch_copy"]) is not str or type(request["project_root"]) is not str
                        or launch_target_problem(Path(request["launch_copy"]), Path(request["project_root"]))
                        is not None):
                    return {"ok": False, "code": "operation_rejected"}
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                self.ledger.record_launch(project_id, request["launch_copy"], request["launch_digest"])
                return {"ok": True}
            if request.get("op") in {
                "owner_record_payload", "commit_owner_record", "verify_owner_record", "confirm_legacy_slot",
            } and set(request) == {
                "protocol", "op", "project_root", "record",
                *({"signature_b64"} if request.get("op") != "owner_record_payload" else ()),
            }:
                from .learning_engine import OwnerGrantAuthority
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                record = request["record"]
                if type(record) is not dict:
                    return {"ok": False, "code": "operation_rejected"}
                if request["op"] == "owner_record_payload":
                    payload = OwnerGrantAuthority.for_state(self.ledger.state).owner_record_payload(project_id, record)
                    return {"ok": True, "signing_payload_b64": base64.b64encode(payload).decode("ascii")}
                if request["op"] == "verify_owner_record":
                    # For a project's own service, which stores the record itself: the
                    # owner key and its check stay with this owner. Nothing is stored here.
                    checked = validate_learning_record(record)
                    signature = base64.b64decode(request["signature_b64"], validate=True)
                    return {"ok": True, "valid": checked["record_type"] == "feedback" and bool(
                        OwnerGrantAuthority.for_state(self.ledger.state).verify_owner_record(
                            project_id, checked, signature))}
                if request["op"] == "confirm_legacy_slot" and record.get("record_type") != "run_slot_confirmation":
                    return {"ok": False, "code": "operation_rejected"}
                # The owner's signature is the authority; the ledger verifies it.
                signature = base64.b64decode(request["signature_b64"], validate=True)
                committed = self.ledger.commit_owner_record(project_id, record=record, signature=signature)
                return {"ok": True, "committed": committed}
            if request.get("op") == "project" and set(request) == {
                "protocol", "op", "project_root",
            }:
                # Registry lookup only: an unregistered root is never registered here.
                return {
                    "ok": True,
                    "project_id": self.ledger.project_for_root(Path(request["project_root"])),
                }
            if request.get("op") == "health" and set(request) in (
                {"protocol", "op"},
                {"protocol", "op", "project_root"},
            ):
                response: dict[str, Any] = {
                    "ok": True,
                    "schema_version": LEDGER_SCHEMA_VERSION,
                    "runtime_version": PACKAGE_VERSION,
                    "runtime_digest": COLLECTOR_RUNTIME_DIGEST,
                    # The loaded code against the files now on disk: Python never reloads a module.
                    "runtime_stale": collector_code_stale(),
                    "started_at_ms": self._started_at_ms,
                    "previous_exit": self.previous_exit,
                    "startup_phases": self.startup_phases,
                    "account_services": self.account_services,
                    "account_restart": self.account_restart,
                    "account_restart_last": self.account_restart_last,
                    # M4b E1a-3: refused ledger-lock waits by caller, read without the ledger lock.
                    "ledger_waits": self.ledger.lock_refusals(),
                }
                if self.account_lanes is not None:
                    try:
                        response["account_lanes"] = self.account_lanes()
                    except Exception:
                        response["account_lanes"] = {"available": False}
                project_id = None
                if "project_root" in request:
                    project_root = Path(request["project_root"])
                    # Read from the filesystem before the hold, so it covers ledger reads only.
                    client_failures = client_health_snapshot(self.ledger.state, project_root)
                    # S1-H1a-6a: one bounded hold for every project read (they re-enter it at once);
                    # when it is not free in time, none is read and the reply says so.
                    if not self.ledger._lock.acquire(timeout=HEALTH_LEDGER_WAIT_MS / 1000):
                        self.ledger._lock_waits.refused("health")  # E1a-3
                        response["ledger_busy"] = True
                        return response
                    try:
                        project_id = self.ledger.project_for_root(project_root)
                        project = {
                            "provider_attestations": self.ledger.provider_attestation_status(project_id),
                            "collector_health": self.ledger.health_snapshot(project_id),
                            "account_capacity": self.ledger.account_capacity(project_id),
                            "account_slots": self.ledger.account_slot_health(project_id),  # S1-H1a
                            "ingestion": self.ledger.ingestion_snapshot(project_id, client_failures=client_failures),
                        }
                    finally:
                        self.ledger._lock.release()
                    response.update(project)
                try:  # HM-0: this project's findings and the machine's, never another project's
                    response["health_monitor"] = self.health_monitor.view(project_id)
                except Exception:
                    pass  # a failing view leaves the section out; health itself never fails for it
                return response
            if request.get("op") == "learning_migration" and set(request) == {
                "protocol", "op", "project_root",
            }:
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                return {
                    "ok": True,
                    "moved": self.ledger.learning_moved(project_id),
                    "has_learning": self.ledger.has_learning_history(project_id),
                    "drained": self.ledger.drained(),
                    "activation_pending": self.ledger.learning_activation_pending(project_id),
                    "earlier_version_runs": self.ledger.earlier_version_runs(),
                }
            if request.get("op") == "learning_moved_if_empty" and set(request) == {
                "protocol", "op", "project_root",
            }:
                project_id = self.ledger.project_for_root(Path(request["project_root"]))
                return {"ok": True, "moved": self.ledger.mark_learning_moved_if_empty(project_id)}
            if request.get("op") == "shutdown_if_drained" and set(request) == {"protocol", "op"}:
                # For a migration tool: never taken away from under an active run. Runs an
                # earlier version left never ran under a collector, so they do not count.
                if not self.ledger.drained(children_only=True):
                    return {"ok": False, "code": "collector_busy"}
                self._stop.set()
                return {"ok": True}
            if request.get("op") == "shutdown" and set(request) == {"protocol", "op"}:
                self._stop.set()
                return {"ok": True}
            return {"ok": False, "code": "operation_invalid"}
        except ProjectNotRegisteredError:
            return {"ok": False, "code": "project_unregistered"}
        except (LedgerError, StateError, TypeError, ValueError):
            return {"ok": False, "code": "operation_rejected"}
        except (SQLReadError, sqlite3.OperationalError) as error:
            # A passing refusal fails only this request (C12e). Anything else is a defect
            # or a broken connection: it stops the collector, which records why (C10).
            if not _passing_refusal(error):
                raise
            return {"ok": False, "code": "operation_rejected"}

    def stop(self) -> None:
        self._stop.set()
        self._sweeps_stop.set()  # G1: no sweep cycle starts after a stop, even mid-request
        if self._thread:
            self._thread.join(5)
            if self._thread.is_alive() or (self._sweeps is not None and self._sweeps.is_alive()):
                raise CollectorError("collector did not stop")
        self._release_lock()

    def _release_lock(self) -> None:
        with self.ledger._lock:
            self.ledger._collector_active = False

    def wait(self, timeout: float | None = None) -> bool:
        """Wait for the collector thread; return true when it has stopped, its sweeps too (G2: not
        stopped while a sweep still uses the ledger)."""

        if self._thread is None:
            return True
        self._thread.join(timeout)
        if self._thread.is_alive():
            return False
        if self._sweeps is not None:
            self._sweeps.join(0 if timeout is not None else None)
            return not self._sweeps.is_alive()
        return True
















def _wait_for_writer_release(state: LearningState, deadline: float) -> bool:
    """Wait until the previous collector has released the ledger writer lock."""

    if fcntl is None:
        return True
    descriptor = os.open(
        state.lock,
        os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    try:
        os.fchmod(descriptor, 0o600)
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.flock(descriptor, fcntl.LOCK_UN)
                return True
            except OSError:
                if time.monotonic() >= deadline:
                    return False
                time.sleep(0.02)
    finally:
        os.close(descriptor)


def _wait_for_collector_shutdown(
    client: CollectorClient,
    state: LearningState,
    deadline: float,
) -> bool:
    while time.monotonic() < deadline:
        try:
            client.health()
        except CollectorVersionError:
            time.sleep(0.02)
            continue
        except CollectorError:
            return _wait_for_writer_release(state, deadline)
        time.sleep(0.02)
    return False


# How long one owner-key change waits for another to finish.
OWNER_KEY_TURN_SECONDS = 10.0
# How long a collector that accepted a stop but outlived the caller's wait is
# given before it is started again.
STOP_RECOVERY_SECONDS = 3.0
# How long a command waits for another command's maintenance to end. The other
# one stops the collector, does its work and waits for the collector to start
# again, so this is longer than a start; the wait ends as soon as the lock is free.
MAINTENANCE_LOCK_SECONDS = 20.0


class CollectorMaintenance:
    """Temporarily quiesce an active collector for one direct ledger command."""

    def __init__(
        self,
        state: LearningState,
        cli_path: Path,
        project_root: Path,
        descriptor: int | None,
        restart: bool,
    ) -> None:
        self.state = state
        self.cli_path = cli_path
        self.project_root = project_root
        self.descriptor = descriptor
        self.restart = restart

    @classmethod
    def acquire(
        cls,
        state: LearningState,
        cli_path: Path,
        project_root: Path,
        *,
        timeout: float = 2.0,
        lock_timeout: float = MAINTENANCE_LOCK_SECONDS,
        owner_registration: bool = False,
    ) -> "CollectorMaintenance":
        """Stop the collector for one direct ledger command, never from under a run.

        The collector stops only if no run is active or unsettled anywhere;
        otherwise this raises with code `collector_busy` and everything keeps
        running. A collector from before that check existed drives no runs.
        """
        if not owner_registration:
            require_authorized_collector_runtime(state)
        if fcntl is None:
            return cls(state, cli_path, project_root, None, False)
        descriptor = os.open(
            state.runtime_lock,
            os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        os.fchmod(descriptor, 0o600)
        deadline = time.monotonic() + lock_timeout
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if time.monotonic() >= deadline:
                    os.close(descriptor)
                    raise CollectorError("collector maintenance lock is busy") from exc
                time.sleep(0.02)
        # The collector's stop is timed from here, whatever the lock took.
        deadline = time.monotonic() + timeout
        transferred = False
        try:
            client = CollectorClient(state.socket)
            earlier_health = None
            try:
                client.health()
            except CollectorUpgradeRequired as health_error:
                if not owner_registration:
                    raise
                earlier_health = health_error
            except CollectorVersionError:
                raise
            except CollectorError:
                if _wait_for_writer_release(state, deadline):
                    transferred = True
                    return cls(state, cli_path, project_root, descriptor, False)
                raise CollectorError("collector writer did not stop for maintenance")
            try:
                client.shutdown(only_if_drained=True)
            except CollectorError as error:
                if error.code == "collector_busy":
                    raise CollectorError(
                        "a child run is active; nothing was changed, try again when none is running",
                        code="collector_busy",
                    ) from None
                if error.code == "runtime_upgrade_required" and owner_registration:
                    # UPG-6: a 0.8.56-0.8.58 collector judges the stop by its own digest. Once, for a
                    # collector older than this build that reported the digest it loaded, echo it; the
                    # maintenance hand-over is the only caller. Otherwise it fails closed as before.
                    loaded = getattr(earlier_health, "loaded_digest", None)
                    try:
                        reported = _version_tuple(client._request(
                            {"protocol": COLLECTOR_PROTOCOL_VERSION, "op": "health"}
                        ).get("runtime_version"))
                    except CollectorError:
                        reported = None
                    own = _version_tuple(PACKAGE_VERSION)
                    if loaded is None or reported is None or own is None or reported >= own:
                        raise
                    try:
                        client.shutdown(only_if_drained=True, echo_digest=loaded)
                    except CollectorError as echoed:
                        if echoed.code == "collector_busy":
                            raise CollectorError(
                                "a child run is active; nothing was changed, try again when none is running",
                                code="collector_busy",
                            ) from None
                        raise
                else:
                    # Only a collector of a release from before project services may
                    # lack the drained stop: those drive no runs (their CLIs run
                    # children themselves and pause the collector for every command).
                    # Anything else, this version with an older schema included,
                    # fails closed.
                    if error.code != "operation_invalid" or not owner_registration:
                        raise
                    try:
                        reported = _version_tuple(client._request(
                            {"protocol": COLLECTOR_PROTOCOL_VERSION, "op": "health"}
                        ).get("runtime_version"))
                    except CollectorError:
                        reported = None
                    if reported is None:
                        raise
                    if reported >= FIRST_RUN_DRIVING_VERSION:
                        # UPG-1: a release that drives runs but predates the runtime-identity key on its
                        # stop (decision 129.3) takes the same drained stop in its own bare shape; a busy
                        # one still refuses. A collector of this build or newer is never sent that shape.
                        own = _version_tuple(PACKAGE_VERSION)
                        if own is None or reported >= own:
                            raise
                        try:
                            client.shutdown(only_if_drained=True, earlier_collector=True)
                        except CollectorError as earlier_error:
                            if earlier_error.code == "collector_busy":
                                raise CollectorError(
                                    "a child run is active; nothing was changed, try again when none is running",
                                    code="collector_busy",
                                ) from None
                            raise
                    else:
                        client.shutdown()
            # The stop was accepted: a collector that is slow to go down is waited
            # for a little longer than the caller asked before this gives up.
            if (_wait_for_collector_shutdown(client, state, deadline)
                    or _wait_for_collector_shutdown(client, state, time.monotonic() + STOP_RECOVERY_SECONDS)):
                transferred = True
                return cls(state, cli_path, project_root, descriptor, True)
            # It may still go down after this returns. Start it again if it already
            # has, and say which it is: nothing here can wait for it for ever, and
            # any later command starts a collector that is missing.
            # Asked plainly first, whatever version answers: a collector this runtime may
            # not start (another version's, during an update) can still be the one running.
            try:
                client._request({"protocol": COLLECTOR_PROTOCOL_VERSION, "op": "health"})
            except CollectorError:
                pass
            else:
                raise CollectorError("collector did not stop for maintenance; it is still running")
            try:
                _start_collector_locked(state, cli_path, project_root=project_root)
            except (CollectorError, StateError, OSError):
                raise CollectorError(
                    "collector did not stop for maintenance and is not answering; the next command starts it "
                    "again, or run setup if it does not") from None
            raise CollectorError(
                "collector stopped too late for this command and was started again; run the command again")
        finally:
            if not transferred:
                with contextlib.suppress(OSError):
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
                os.close(descriptor)

    def resume(self) -> None:
        descriptor = self.descriptor
        self.descriptor = None
        try:
            if self.restart:
                _start_collector_locked(
                    self.state,
                    self.cli_path,
                    project_root=self.project_root,
                )
        finally:
            if descriptor is not None:
                with contextlib.suppress(OSError):
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
                os.close(descriptor)
