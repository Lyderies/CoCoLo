"""Strict validation for task, result, and evaluation contracts."""

from __future__ import annotations

import math
import re
from typing import Any


class LedgerError(RuntimeError):
    """Controlled owner/API failures without exposing persisted record content."""


TASK_FAMILIES = {
    "inventory",
    "research",
    "planning",
    "coding",
    "security",
    "verification",
}
COMPLEXITIES = {"low", "medium", "high", "extreme"}
RISKS = {"low", "medium", "high", "critical"}
OPERATIONS = {
    "mechanical",
    "exploration",
    "implementation",
    "diagnosis",
    "synthesis",
    "review",
    "end_to_end",
}
AMBIGUITIES = {"known", "partial", "high", "unknown"}
CONTEXT_BREADTHS = {"narrow", "repository", "cross_system", "unknown"}
ACCEPTANCE_STRENGTHS = {
    "deterministic",
    "executable",
    "independent_judgment",
    "owner_decision",
}
RESULT_STATUSES = {"completed", "failed", "blocked", "interrupted", "cancelled"}
EXECUTION_STATES = {
    "completed",
    "failed",
    "timed_out",
    "interrupted",
    "cancelled",
    "invalid",
}
SEMANTIC_VERDICTS = {
    "pass",
    "ready",
    "ready-with-corrections",
    "not-ready",
    "blocked",
    "reject",
    "not-applicable",
}
ADMISSION_STATES = {"unverified", "accepted", "rejected", "pending"}
EVIDENCE_TYPES = {"command", "source", "artifact", "review", "observation"}
EVIDENCE_OUTCOMES = {"pass", "fail", "observed", "not_run"}
# Most severe first: one criterion's entry takes the most severe of its findings.
EVIDENCE_OUTCOME_SEVERITY = ("fail", "not_run", "observed", "pass")
# Stated to the primary in result-preflight and to a bridged child in its prompt.
ONE_EVIDENCE_ENTRY_RULE = (
    "each required criterion has exactly one evidence entry: put several findings for "
    "it in that entry's details, and set its outcome to the most severe of them ("
    + ", then ".join(EVIDENCE_OUTCOME_SEVERITY) + ")"
)
# O10 VF-3: the exact fields of an evidence entry (the validator's evidence_fields).
EVIDENCE_FIELDS_RULE = (
    "each evidence entry has exactly the fields criterion_id, type, outcome, reference and details: "
    "put severity, impact, corrections and anything else in details"
)
FAILURE_REASONS = {
    "result_contract",
    "transient",
    "corrected_input",
    "semantic",
    "reasoning",
    "authority",
}
FAILURE_REFERENCE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$")
# A recorded host outcome is named by the SHA-256 of its canonical content, as
# learning-record-host-result prints it in `host_outcome_digest`.
HOST_OUTCOME_DIGEST = re.compile(r"^[0-9a-f]{64}$")
VERIFIED_FAILURE_REFERENCE = re.compile(r"^verification:[0-9a-f]{64}$")
RESULT_VALIDATION_REASON_CODES = {
    "assignment_mismatch",
    "duplicate_criterion",
    "failed_completed_evidence",
    "invalid_evidence",
    "invalid_shape",
    "invalid_status",
    "invalid_usage",
    "missing_evidence",
    "missing_required_evidence",
    "missing_required_fields",
    "unknown_criterion",
    "unknown_fields",
    # 0.4.0 item 0.5 (VF-INV-b): the old `inconsistent_axes` is split by branch, each a fixed,
    # content-free code. `inconsistent_axes` itself is no longer produced; it stays a readable
    # diagnostic of older ledgers (RESULT_DIAGNOSTIC_REASON_CODES).
    "axes_status_verdict_mismatch",
    "axes_verdict_without_completion",
    "axes_admission_without_completion",
    "axes_retry_lineage",
    "child_set_admission",
    "child_set_timeout",
    # RV1: which evidence rule a result broke, each a fixed, content-free code.
    "evidence_missing_fields",
    "evidence_unknown_fields",
    "evidence_unsupported_type",
    "evidence_empty_criterion",
    "evidence_empty_reference",
    "evidence_unsupported_outcome",
    "evidence_details_not_text",
    # O10 VF-2: a Claude child's client gave no schema-valid result.
    "structured_output_missing",
}
# Durable bridge diagnostics also cover validators that raise an untyped error.
# Never add exception text or caller-selected values to this vocabulary.
RESULT_DIAGNOSTIC_REASON_CODES = frozenset(
    RESULT_VALIDATION_REASON_CODES | {"contract_validation_failed", "inconsistent_axes"}
)
BOUND_FIELDS = {
    "max_attempts",
    "max_steers_per_attempt",
    "max_no_progress_events",
    "wait_seconds",
    "timeout_seconds",
    "max_tool_calls",
}


class ContractError(ValueError):
    """Raised when a contract is missing or contains unsupported data.

    `field`, when set, is what the CLI prints. It is built only from names in this
    code and list indexes, never from a key or value in the input; the message may
    hold either and is not printed.
    """

    def __init__(self, *args: object, field: str | None = None) -> None:
        super().__init__(*args)
        self.field = field


class ResultContractError(ContractError):
    """A result-contract rejection with a bounded, content-free reason code."""

    def __init__(self, reason_code: str, message: str) -> None:
        if reason_code not in RESULT_VALIDATION_REASON_CODES:
            raise ValueError("unsupported result validation reason code")
        super().__init__(message)
        self.reason_code = reason_code


def _required(data: dict[str, Any], keys: set[str], label: str) -> None:
    missing = sorted(keys - data.keys())
    if missing:
        raise ContractError(
            f"{label} missing required fields: {', '.join(missing)}",
            field=f"{label}.{missing[0]}",
        )


def _nonempty_string(value: Any, field: str, reported: str | None = None) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(f"{field} must be a non-empty string", field=reported)


def _validate_permissions(data: Any, label: str) -> dict[str, Any]:
    fields = {"tools", "filesystem", "network", "mcps", "external_effects"}
    if not isinstance(data, dict):
        raise ContractError(f"{label} must be an object", field=label)
    _required(data, fields, label)
    unknown = sorted(data.keys() - fields)
    if unknown:
        raise ContractError(f"{label} has unknown fields: {', '.join(unknown)}", field=label)
    for field in ("tools", "filesystem", "mcps"):
        value = data[field]
        if (
            not isinstance(value, list)
            or not all(isinstance(item, str) and item for item in value)
            or len(value) != len(set(value))
        ):
            raise ContractError(
                f"{label}.{field} must be an array of unique strings",
                field=f"{label}.{field}",
            )
    for field in ("network", "external_effects"):
        if not isinstance(data[field], bool):
            raise ContractError(f"{label}.{field} must be boolean", field=f"{label}.{field}")
    if data["mcps"]:
        raise ContractError(
            f"{label}.mcps must be empty in version 1; pinned MCP identity is unavailable",
            field=f"{label}.mcps",
        )
    return data


def validate_parent_grant(data: Any) -> dict[str, Any]:
    """Validate the manager's declared maximum child authority."""

    return _validate_permissions(data, "parent_grant")


def validate_task(data: Any, *, allow_unadjudicated_failures: bool = False) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ContractError("task must be an object", field="task")
    required = {
        "id",
        "objective",
        "family",
        "complexity",
        "risk",
        "operation",
        "ambiguity",
        "context_breadth",
        "acceptance_strength",
        "routing_evidence_refs",
        "meaningful",
        "deterministic_validation",
        "independent_parts",
        "parallel_safe",
        "failed_attempts",
        "failure_events",
    }
    allowed = required | {
        "owned_paths",
        "required_capabilities",
        "prohibited_actions",
        "verification_for_family",
        "verification_for_provider",
        "verification_for_outcome",
        "review_phase",
        "parent_review_id",
        "expanded_scope",
    }
    _required(data, required, "task")
    unknown = sorted(data.keys() - allowed)
    if unknown:
        raise ContractError(f"task has unknown fields: {', '.join(unknown)}", field="task")
    _nonempty_string(data["id"], "id", "task.id")
    _nonempty_string(data["objective"], "objective", "task.objective")
    if not isinstance(data["family"], str) or data["family"] not in TASK_FAMILIES:
        raise ContractError(f"unsupported family: {data['family']}", field="task.family")
    if "review_phase" in data and (
        not isinstance(data["review_phase"], str)
        or data["review_phase"] not in {"first", "delta", "confirmation"}
    ):
        raise ContractError("unsupported review_phase", field="task.review_phase")
    if "parent_review_id" in data:
        _nonempty_string(data["parent_review_id"], "parent_review_id", "task.parent_review_id")
    if "expanded_scope" in data and not isinstance(data["expanded_scope"], bool):
        raise ContractError("expanded_scope must be boolean", field="task.expanded_scope")
    verification_for_family = data.get("verification_for_family")
    if verification_for_family is not None:
        if data["family"] != "verification":
            raise ContractError(
                "verification_for_family is valid only for verification tasks",
                field="task.verification_for_family",
            )
        if (
            not isinstance(verification_for_family, str)
            or verification_for_family not in TASK_FAMILIES - {"verification"}
        ):
            raise ContractError(
                "verification_for_family is unsupported",
                field="task.verification_for_family",
            )
    verification_for_provider = data.get("verification_for_provider")
    if verification_for_provider is not None:
        if data["family"] != "verification":
            raise ContractError(
                "verification_for_provider is valid only for verification tasks",
                field="task.verification_for_provider",
            )
        if not isinstance(verification_for_provider, str) or (
            verification_for_provider not in {"codex", "claude"}
        ):
            raise ContractError(
                "verification_for_provider is unsupported",
                field="task.verification_for_provider",
            )
    verification_for_outcome = data.get("verification_for_outcome")
    if verification_for_outcome is not None:
        # The worker's host outcome digest, exactly as learning-record-host-result
        # prints it; the ledger resolves it, so the task only names it.
        if data["family"] != "verification":
            raise ContractError(
                "verification_for_outcome is valid only for verification tasks",
                field="task.verification_for_outcome",
            )
        if not isinstance(verification_for_outcome, str) or not HOST_OUTCOME_DIGEST.fullmatch(
            verification_for_outcome
        ):
            raise ContractError(
                "verification_for_outcome must be a host_outcome_digest",
                field="task.verification_for_outcome",
            )
        if verification_for_family is None or verification_for_provider is None:
            raise ContractError(
                "verification_for_outcome requires verification_for_family "
                "and verification_for_provider",
                field=(
                    "task.verification_for_family" if verification_for_family is None
                    else "task.verification_for_provider"
                ),
            )
    if not isinstance(data["complexity"], str) or data["complexity"] not in COMPLEXITIES:
        raise ContractError(
            f"unsupported complexity: {data['complexity']}", field="task.complexity"
        )
    if not isinstance(data["risk"], str) or data["risk"] not in RISKS:
        raise ContractError(f"unsupported risk: {data['risk']}", field="task.risk")
    for field, supported in (
        ("operation", OPERATIONS),
        ("ambiguity", AMBIGUITIES),
        ("context_breadth", CONTEXT_BREADTHS),
        ("acceptance_strength", ACCEPTANCE_STRENGTHS),
    ):
        if not isinstance(data[field], str) or data[field] not in supported:
            raise ContractError(f"unsupported {field}: {data[field]}", field=f"task.{field}")
    routing_evidence_refs = data["routing_evidence_refs"]
    if (
        not isinstance(routing_evidence_refs, list)
        or len(routing_evidence_refs) > 16
        or not all(
            isinstance(reference, str) and FAILURE_REFERENCE.fullmatch(reference)
            for reference in routing_evidence_refs
        )
        or len(routing_evidence_refs) != len(set(routing_evidence_refs))
    ):
        raise ContractError(
            "routing_evidence_refs must be at most 16 unique safe references",
            field="task.routing_evidence_refs",
        )
    for field in ("meaningful", "deterministic_validation", "parallel_safe"):
        if not isinstance(data[field], bool):
            raise ContractError(f"{field} must be boolean", field=f"task.{field}")
    if (
        data["acceptance_strength"] == "deterministic"
        and not data["deterministic_validation"]
    ):
        raise ContractError(
            "deterministic acceptance requires deterministic_validation",
            field="task.deterministic_validation",
        )
    if data["risk"] in {"high", "critical"} and not data["meaningful"]:
        raise ContractError(
            "high and critical risk tasks must be meaningful", field="task.meaningful"
        )
    if not isinstance(data["independent_parts"], int) or data["independent_parts"] < 1:
        raise ContractError(
            "independent_parts must be an integer of at least 1",
            field="task.independent_parts",
        )
    if not isinstance(data["failed_attempts"], int) or not 0 <= data["failed_attempts"] <= 2:
        raise ContractError(
            "failed_attempts must be an integer from 0 to 2", field="task.failed_attempts"
        )
    failure_events = data["failure_events"]
    if not isinstance(failure_events, list):
        raise ContractError("failure_events must be an array", field="task.failure_events")
    minimum_events = data["failed_attempts"]
    maximum_events = data["failed_attempts"] * 2
    if not minimum_events <= len(failure_events) <= maximum_events:
        raise ContractError(
            "failure_events must contain one or two events per failed attempt",
            field="task.failure_events",
        )
    seen_events: set[tuple[int, str, tuple[str, ...]]] = set()
    seen_reasoning_references: set[str] = set()
    event_attempts: list[int] = []
    for index, event in enumerate(failure_events):
        if not isinstance(event, dict) or set(event) != {
            "attempt",
            "reason",
            "evidence_refs",
        }:
            raise ContractError(
                f"failure_events[{index}] must contain exactly attempt, reason, and evidence_refs",
                field=f"task.failure_events[{index}]",
            )
        attempt = event["attempt"]
        if (
            not isinstance(attempt, int)
            or isinstance(attempt, bool)
            or not 1 <= attempt <= data["failed_attempts"]
        ):
            raise ContractError(
                f"failure_events[{index}].attempt is invalid",
                field=f"task.failure_events[{index}].attempt",
            )
        event_attempts.append(attempt)
        reason = event["reason"]
        if not isinstance(reason, str) or reason not in FAILURE_REASONS:
            raise ContractError(
                f"failure_events[{index}].reason is unsupported",
                field=f"task.failure_events[{index}].reason",
            )
        evidence_refs = event["evidence_refs"]
        if (
            not isinstance(evidence_refs, list)
            or not evidence_refs
            or len(evidence_refs) > 16
            or not all(
                isinstance(reference, str) and FAILURE_REFERENCE.fullmatch(reference)
                for reference in evidence_refs
            )
            or len(evidence_refs) != len(set(evidence_refs))
        ):
            raise ContractError(
                f"failure_events[{index}].evidence_refs must be one to 16 unique safe references",
                field=f"task.failure_events[{index}].evidence_refs",
            )
        event_key = (attempt, reason, tuple(sorted(evidence_refs)))
        if event_key in seen_events:
            raise ContractError(
                "failure_events must not repeat the same event",
                field=f"task.failure_events[{index}]",
            )
        seen_events.add(event_key)
        if reason in {"semantic", "reasoning"}:
            # A claim may precede adjudication. Only verification digests qualify it
            # for escalation; retaining a safe host reference does not confirm it.
            if not allow_unadjudicated_failures and not all(
                VERIFIED_FAILURE_REFERENCE.fullmatch(reference) for reference in evidence_refs
            ):
                raise ContractError(
                    "semantic and reasoning failures require verification record digests",
                    field=f"task.failure_events[{index}].evidence_refs",
                )
            reused = seen_reasoning_references.intersection(evidence_refs)
            if reused:
                raise ContractError(
                    "semantic and reasoning failures need distinct evidence references",
                    field=f"task.failure_events[{index}].evidence_refs",
                )
            seen_reasoning_references.update(evidence_refs)
    if set(event_attempts) != set(range(1, data["failed_attempts"] + 1)) or any(
        event_attempts.count(attempt) > 2 for attempt in set(event_attempts)
    ):
        raise ContractError(
            "failure_events must contain one or two events for each failed attempt",
            field="task.failure_events",
        )
    for field in ("owned_paths", "required_capabilities", "prohibited_actions"):
        if field in data and (
            not isinstance(data[field], list)
            or not all(isinstance(item, str) for item in data[field])
        ):
            raise ContractError(f"{field} must be an array of strings", field=f"task.{field}")
    return data


def routing_task_slice(data: Any) -> str:
    """Return the explicit task-shape slice used for verified routing learning."""

    task = validate_task(data)
    return "-".join(
        task[field]
        for field in (
            "family",
            "complexity",
            "risk",
            "operation",
            "ambiguity",
            "context_breadth",
            "acceptance_strength",
        )
    )


def model_selection_slice(data: Any) -> str:
    """Return the risk-neutral task shape used for model/effort learning."""

    task = validate_task(data)
    return "-".join(
        (
            task["family"],
            task["complexity"],
            task["operation"],
            task["ambiguity"],
            task["context_breadth"],
            task["acceptance_strength"],
        )
    )


def _execution_limits_shape(limits: Any) -> dict[str, int]:
    if not isinstance(limits, dict) or not limits or set(limits) - {
        "max_model_turns", "max_tool_calls",
    }:
        raise ContractError("execution_limits must name supported bound units",
                            field="assignment.execution_limits")
    for name, value in limits.items():
        minimum = 0 if name == "max_tool_calls" else 1
        if type(value) is not int or not minimum <= value <= 2**31 - 1:
            raise ContractError("execution limit is outside its integer range",
                                field=f"assignment.execution_limits.{name}")
    return limits


def validate_assignment_execution_limits(
    assignment: dict[str, Any], route: dict[str, Any],
) -> dict[str, int]:
    """Check optional exact-unit requests without widening legacy ceilings.

    The historical bounds.max_tool_calls projection remains a compatibility
    ceiling, not a tool-execution guarantee. An explicit request is never silently
    projected to a different unit or treated as an observed-event cutoff.
    """

    if "execution_limits" not in assignment:
        return {}
    limits = _execution_limits_shape(assignment["execution_limits"])
    if "max_tool_calls" in limits:
        raise ContractError("exact tool-call limits are unavailable for this route",
                            field="assignment.execution_limits.max_tool_calls")
    if not isinstance(route, dict):
        raise ContractError("route must be an object", field="route")
    if route.get("provider") != "claude" or route.get("dispatch") != "bridge":
        raise ContractError("model-turn limits are unavailable for this route",
                            field="assignment.execution_limits.max_model_turns")
    for label, item in (("route", route), ("assignment", assignment)):
        bounds = item.get("bounds")
        if (not isinstance(bounds, dict) or type(bounds.get("max_tool_calls")) is not int
                or bounds["max_tool_calls"] < 0):
            raise ContractError("legacy ceiling must be a nonnegative integer",
                                field=f"{label}.bounds.max_tool_calls")
    ceiling = max(1, min(route["bounds"]["max_tool_calls"],
                         assignment["bounds"]["max_tool_calls"]))
    if limits["max_model_turns"] > ceiling:
        raise ContractError("model-turn limit exceeds the legacy dispatch ceiling",
                            field="assignment.execution_limits.max_model_turns")
    return limits


def validate_assignment_shape(data: Any) -> dict[str, Any]:
    """Validate the closed assignment contract without granting any authority."""

    if not isinstance(data, dict):
        raise ContractError("assignment must be an object", field="assignment")
    required = {
        "assignment_id",
        "task_id",
        "objective",
        "role",
        "model",
        "effort",
        "attempt",
        "meaningful",
        "owned_paths",
        "context",
        "permissions",
        "expected_output",
        "required_evidence",
        "verification_required",
        "bounds",
        "stopping_conditions",
        "prohibited_actions",
    }
    _required(data, required, "assignment")
    unknown = sorted(data.keys() - required - {"retry_of_assignment_id", "execution_limits"})
    if unknown:
        raise ContractError(
            f"assignment has unknown fields: {', '.join(unknown)}", field="assignment"
        )
    if "execution_limits" in data:
        _execution_limits_shape(data["execution_limits"])
    for field in (
        "assignment_id",
        "task_id",
        "objective",
        "role",
        "model",
        "effort",
        "expected_output",
    ):
        _nonempty_string(data[field], field, f"assignment.{field}")
    if type(data["attempt"]) is not int or data["attempt"] < 1:
        raise ContractError("attempt must be a positive integer", field="assignment.attempt")
    retry_of = data.get("retry_of_assignment_id")
    if data["attempt"] == 1 and retry_of is not None:
        raise ContractError(
            "first assignment attempt cannot have a retry predecessor",
            field="assignment.retry_of_assignment_id",
        )
    if data["attempt"] > 1 and (
        not isinstance(retry_of, str) or not retry_of.strip()
    ):
        raise ContractError(
            "retry assignment requires its predecessor identifier",
            field="assignment.retry_of_assignment_id",
        )
    for field in ("meaningful", "verification_required"):
        if not isinstance(data[field], bool):
            raise ContractError(f"{field} must be boolean", field=f"assignment.{field}")
    for field in (
        "owned_paths",
        "context",
        "stopping_conditions",
        "prohibited_actions",
    ):
        if not isinstance(data[field], list) or not all(
            isinstance(item, str) for item in data[field]
        ):
            raise ContractError(
                f"{field} must be an array of strings", field=f"assignment.{field}"
            )
    required_evidence = data["required_evidence"]
    if not isinstance(required_evidence, list) or not required_evidence:
        raise ContractError(
            "required_evidence must be a non-empty array", field="assignment.required_evidence"
        )
    evidence_ids: set[str] = set()
    for index, criterion in enumerate(required_evidence):
        if not isinstance(criterion, dict) or set(criterion) != {"id", "description"}:
            raise ContractError(
                f"required_evidence[{index}] must contain exactly id and description",
                field=f"assignment.required_evidence[{index}]",
            )
        reported = f"assignment.required_evidence[{index}]"
        _nonempty_string(criterion["id"], f"required_evidence[{index}].id", f"{reported}.id")
        _nonempty_string(
            criterion["description"],
            f"required_evidence[{index}].description",
            f"{reported}.description",
        )
        if criterion["id"] in evidence_ids:
            raise ContractError(
                f"duplicate required evidence id: {criterion['id']}", field=f"{reported}.id"
            )
        evidence_ids.add(criterion["id"])
    _validate_permissions(data["permissions"], "assignment.permissions")
    bounds = data["bounds"]
    if not isinstance(bounds, dict):
        raise ContractError("bounds must be an object", field="assignment.bounds")
    _required(bounds, BOUND_FIELDS, "assignment.bounds")
    bounds_unknown = sorted(bounds.keys() - BOUND_FIELDS)
    if bounds_unknown:
        raise ContractError(
            f"bounds has unknown fields: {', '.join(bounds_unknown)}", field="assignment.bounds"
        )
    for field in BOUND_FIELDS:
        minimum = 0 if field in {"max_steers_per_attempt", "max_tool_calls"} else 1
        if type(bounds[field]) is not int or bounds[field] < minimum:
            raise ContractError(
                f"bounds.{field} must be an integer of at least {minimum}",
                field=f"assignment.bounds.{field}",
            )
    return data


def validate_assignment(
    data: Any,
    *,
    task: Any,
    route: Any,
    parent_grant: Any,
) -> dict[str, Any]:
    data = validate_assignment_shape(data)
    permissions = data["permissions"]
    parent = validate_parent_grant(parent_grant)
    checked_task = validate_task(task)
    if not isinstance(route, dict):
        raise ContractError("route must be an object", field="route")
    for field in ("tools", "filesystem", "mcps"):
        excess = sorted(set(permissions[field]) - set(parent[field]))
        if excess:
            raise ContractError(
                f"permissions.{field} exceeds parent grant: {', '.join(excess)}",
                field=f"assignment.permissions.{field}",
            )
    for field in ("network", "external_effects"):
        if permissions[field] and not parent[field]:
            raise ContractError(
                f"permissions.{field} exceeds parent grant",
                field=f"assignment.permissions.{field}",
            )
    invalid_filesystem = [
        item
        for item in permissions["filesystem"]
        if not item.endswith(":read") and not item.endswith(":write")
    ]
    if invalid_filesystem:
        raise ContractError(
            "version 1 child filesystem permissions are invalid",
            field="assignment.permissions.filesystem",
        )
    write_requested = any(
        item.endswith(":write") for item in permissions["filesystem"]
    )
    if write_requested and (
        checked_task["family"] not in {"coding", "verification"}
        or route.get("sandbox_mode") != "workspace-write"
        or "project_agent_mapping_digest" not in route
    ):
        raise ContractError(
            "version 1 child filesystem writes require an explicitly mapped "
            "workspace-write coding or verification route",
            field="assignment.permissions.filesystem",
        )
    if permissions["network"] or permissions["external_effects"]:
        raise ContractError(
            "version 1 child network and external effects must be false",
            field=(
                "assignment.permissions.network" if permissions["network"]
                else "assignment.permissions.external_effects"
            ),
        )
    bounds = data["bounds"]
    for field in ("task_id", "role", "model", "effort", "verification_required", "bounds"):
        if field not in route:
            raise ContractError(f"route missing required field: {field}", field=f"route.{field}")
    exact = {
        "task_id": checked_task["id"],
        "role": route["role"],
        "model": route["model"],
        "effort": route["effort"],
        "meaningful": checked_task["meaningful"],
        "verification_required": route["verification_required"],
    }
    for field, expected in exact.items():
        if data[field] != expected:
            raise ContractError(
                f"assignment {field} does not match routed value", field=f"assignment.{field}"
            )
    expected_attempt = checked_task["failed_attempts"] + 1
    if data["attempt"] != expected_attempt:
        raise ContractError(
            "assignment attempt does not match task failure history", field="assignment.attempt"
        )
    if data["attempt"] > bounds["max_attempts"]:
        raise ContractError(
            "attempt exceeds assignment max_attempts", field="task.failed_attempts"
        )
    route_bounds = route["bounds"]
    if not isinstance(route_bounds, dict) or set(route_bounds) != BOUND_FIELDS:
        raise ContractError("route bounds are invalid", field="route.bounds")
    for field in BOUND_FIELDS:
        minimum = 0 if field in {"max_steers_per_attempt", "max_tool_calls"} else 1
        if type(route_bounds[field]) is not int or route_bounds[field] < minimum:
            raise ContractError("route bound must be an integer in its declared range",
                                field=f"route.bounds.{field}")
    validate_assignment_execution_limits(data, route)
    for field in BOUND_FIELDS:
        if bounds[field] > route_bounds[field]:
            raise ContractError(
                f"bounds.{field} exceeds routed policy bound", field=f"assignment.bounds.{field}"
            )
    task_paths = set(checked_task.get("owned_paths", []))
    if not set(data["owned_paths"]).issubset(task_paths):
        raise ContractError("owned_paths exceed task ownership", field="assignment.owned_paths")
    required_prohibitions = set(checked_task.get("prohibited_actions", []))
    if not required_prohibitions.issubset(data["prohibited_actions"]):
        raise ContractError(
            "assignment omits task prohibited actions", field="assignment.prohibited_actions"
        )
    return data


def _is_review_role(role: Any) -> bool:
    """A role whose result is a review (a security reviewer or a verification worker)."""

    return isinstance(role, str) and role.endswith(("_security_reviewer", "_verification_worker"))


def _legacy_result_axes(status: str) -> tuple[str, str, str]:
    """Project a legacy status without pretending a negative review failed to run."""

    return {
        "completed": ("completed", "pass", "unverified"),
        "failed": ("failed", "not-applicable", "unverified"),
        "blocked": ("completed", "blocked", "unverified"),
        "interrupted": ("interrupted", "not-applicable", "unverified"),
        "cancelled": ("cancelled", "not-applicable", "unverified"),
    }[status]


def legacy_result_status(execution_state: str, semantic_verdict: str) -> str:
    """Return the stable v1 status projection for v2 result axes."""

    if execution_state == "completed":
        return "blocked" if semantic_verdict == "blocked" else "completed"
    return {
        "failed": "failed",
        "timed_out": "failed",
        "interrupted": "interrupted",
        "cancelled": "cancelled",
        "invalid": "failed",
    }[execution_state]


def result_axes(
    data: dict[str, Any],
    *,
    attempt: int = 1,
    retry_of_assignment_id: str | None = None,
) -> dict[str, Any]:
    """Read explicit result axes or a lossless legacy projection."""

    legacy = _legacy_result_axes(data["status"])
    return {
        "execution_state": data.get("execution_state", legacy[0]),
        "semantic_verdict": data.get("semantic_verdict", legacy[1]),
        "admission_state": data.get("admission_state", legacy[2]),
        "retry": data.get(
            "retry",
            {
                "attempt": attempt,
                "retry_of_assignment_id": retry_of_assignment_id,
            },
        ),
    }


def result_preflight(assignment: Any) -> dict[str, Any]:
    """Return the exact, non-mutating result contract before an attempt starts."""

    try:
        assignment = validate_assignment_shape(assignment)
    except ContractError as exc:
        raise ResultContractError(
            "assignment_mismatch", "a validated assignment is required"
        ) from exc
    required_evidence = assignment.get("required_evidence")
    if not isinstance(required_evidence, list) or not required_evidence:
        raise ResultContractError(
            "assignment_mismatch", "assignment has no structured required evidence"
        )
    criteria = []
    for item in required_evidence:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("id"), str)
            or not isinstance(item.get("description"), str)
        ):
            raise ResultContractError(
                "assignment_mismatch", "assignment required evidence is invalid"
            )
        criteria.append({"id": item["id"], "description": item["description"]})
    return {
        "assignment_id": assignment["assignment_id"],
        "template": {
            "assignment_id": assignment["assignment_id"],
            "status": "completed",
            "execution_state": "completed",
            "semantic_verdict": "pass",
            "admission_state": "unverified",
            "retry": {
                "attempt": assignment.get("attempt", 1),
                "retry_of_assignment_id": assignment.get("retry_of_assignment_id"),
            },
            "summary": "",
            "artifacts": [],
            "evidence": [
                {
                    "criterion_id": item["id"],
                    "type": "artifact",
                    "reference": "",
                    "outcome": "observed",
                    "details": "",
                }
                for item in criteria
            ],
            "unverified_claims": [],
            "remaining_risks": [],
            "usage": None,
        },
        "required_evidence": criteria,
        "evidence_types": sorted(EVIDENCE_TYPES),
        "evidence_outcomes": sorted(EVIDENCE_OUTCOMES),
        "execution_states": sorted(EXECUTION_STATES),
        "semantic_verdicts": sorted(SEMANTIC_VERDICTS),
        "admission_states": sorted(ADMISSION_STATES),
        "consistency_rules": [
            "status must equal the legacy projection of execution_state and semantic_verdict",
            "only completed execution may carry a substantive semantic verdict",
            "accepted admission requires completed execution; verdict remains independent",
            "completed execution must cover every required criterion",
            ONE_EVIDENCE_ENTRY_RULE,
            EVIDENCE_FIELDS_RULE,
            "negative verdicts may contain fail or not_run evidence",
        ],
    }


def validate_result(data: Any, *, assignment: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ResultContractError("invalid_shape", "result must be an object")
    required = {
        "assignment_id",
        "status",
        "summary",
        "artifacts",
        "evidence",
        "unverified_claims",
        "remaining_risks",
    }
    allowed = required | {
        "usage",
        "execution_state",
        "semantic_verdict",
        "admission_state",
        "retry",
    }
    missing = sorted(required - data.keys())
    if missing:
        raise ResultContractError(
            "missing_required_fields",
            f"result missing required fields: {', '.join(missing)}",
        )
    unknown = sorted(data.keys() - allowed)
    if unknown:
        raise ResultContractError("unknown_fields", "result has unknown fields")
    try:
        _nonempty_string(data["assignment_id"], "assignment_id")
    except ContractError as exc:
        raise ResultContractError("invalid_shape", str(exc)) from exc
    if not isinstance(assignment, dict) or not isinstance(
        assignment.get("assignment_id"), str
    ):
        raise ResultContractError(
            "assignment_mismatch", "a validated assignment is required"
        )
    if data["assignment_id"] != assignment["assignment_id"]:
        raise ResultContractError(
            "assignment_mismatch", "result assignment_id does not match assignment"
        )
    if not isinstance(data["status"], str) or data["status"] not in RESULT_STATUSES:
        raise ResultContractError("invalid_status", "result status is unsupported")
    if (_is_review_role(assignment.get("role"))
            and data.get("execution_state", _legacy_result_axes(data["status"])[0]) == "completed"
            and data.get("semantic_verdict") is None):
        # A review that completed states its verdict; a missing or null one is never filled in, whether the
        # legacy status is "completed" (read as "pass") or "blocked" (read as "blocked").
        raise ResultContractError(
            "missing_required_fields", "result missing required fields: semantic_verdict"
        )
    axes = result_axes(
        data,
        attempt=assignment.get("attempt", 1),
        retry_of_assignment_id=assignment.get("retry_of_assignment_id"),
    )
    execution_state = axes["execution_state"]
    semantic_verdict = axes["semantic_verdict"]
    admission_state = axes["admission_state"]
    if not isinstance(execution_state, str) or execution_state not in EXECUTION_STATES:
        raise ResultContractError("invalid_status", "execution_state is unsupported")
    if not isinstance(semantic_verdict, str) or semantic_verdict not in SEMANTIC_VERDICTS:
        raise ResultContractError("invalid_status", "semantic_verdict is unsupported")
    if not isinstance(admission_state, str) or admission_state not in ADMISSION_STATES:
        raise ResultContractError("invalid_status", "admission_state is unsupported")
    if data["status"] != legacy_result_status(execution_state, semantic_verdict):
        raise ResultContractError(
            "axes_status_verdict_mismatch", "legacy result status disagrees with explicit axes"
        )
    substantive = SEMANTIC_VERDICTS - {"not-applicable"}
    if execution_state != "completed" and semantic_verdict in substantive:
        raise ResultContractError(
            "axes_verdict_without_completion", "non-completed execution cannot claim a semantic verdict"
        )
    if admission_state == "accepted" and execution_state != "completed":
        raise ResultContractError(
            "axes_admission_without_completion", "accepted admission requires completed execution"
        )
    retry = axes["retry"]
    if (
        not isinstance(retry, dict)
        or set(retry) != {"attempt", "retry_of_assignment_id"}
        or not isinstance(retry["attempt"], int)
        or isinstance(retry["attempt"], bool)
        or retry["attempt"] < 1
        or (
            retry["retry_of_assignment_id"] is not None
            and (
                not isinstance(retry["retry_of_assignment_id"], str)
                or not retry["retry_of_assignment_id"].strip()
            )
        )
    ):
        raise ResultContractError("invalid_shape", "retry lineage is invalid")
    if retry["attempt"] != assignment.get("attempt", 1):
        raise ResultContractError(
            "assignment_mismatch", "retry attempt does not match assignment"
        )
    if retry["attempt"] == 1 and retry["retry_of_assignment_id"] is not None:
        raise ResultContractError(
            "axes_retry_lineage", "first attempt cannot reference a retry predecessor"
        )
    if retry["attempt"] > 1 and retry["retry_of_assignment_id"] is None:
        raise ResultContractError(
            "axes_retry_lineage", "retry attempt requires its predecessor assignment"
        )
    if retry["retry_of_assignment_id"] != assignment.get("retry_of_assignment_id"):
        raise ResultContractError(
            "assignment_mismatch", "retry predecessor does not match assignment"
        )
    if not isinstance(data["summary"], str):
        raise ResultContractError("invalid_shape", "summary must be a string")
    for field in ("artifacts", "unverified_claims", "remaining_risks"):
        if not isinstance(data[field], list) or not all(
            isinstance(item, str) for item in data[field]
        ):
            raise ResultContractError(
                "invalid_shape", f"{field} must be an array of strings"
            )
    if not isinstance(data["evidence"], list) or not all(
        isinstance(item, dict) for item in data["evidence"]
    ):
        raise ResultContractError(
            "invalid_evidence", "evidence must be an array of objects"
        )
    if execution_state == "completed" and not data["evidence"]:
        raise ResultContractError(
            "missing_evidence", "completed result must contain evidence"
        )
    evidence_fields = {"criterion_id", "type", "reference", "outcome", "details"}
    required_criteria = {
        item["id"]
        for item in assignment.get("required_evidence", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    if not required_criteria:
        raise ResultContractError(
            "assignment_mismatch", "assignment has no structured required evidence"
        )
    covered_criteria: set[str] = set()
    for index, item in enumerate(data["evidence"]):
        missing_evidence_fields = sorted(evidence_fields - item.keys())
        if missing_evidence_fields:
            raise ResultContractError(
                "evidence_missing_fields",
                f"evidence[{index}] missing required fields",
            )
        unknown_evidence = sorted(item.keys() - evidence_fields)
        if unknown_evidence:
            raise ResultContractError(
                "evidence_unknown_fields",
                f"evidence[{index}] has unknown fields: {', '.join(unknown_evidence)}"
            )
        if not isinstance(item["type"], str) or item["type"] not in EVIDENCE_TYPES:
            raise ResultContractError(
                "evidence_unsupported_type", f"evidence[{index}].type is unsupported"
            )
        try:
            _nonempty_string(item["criterion_id"], f"evidence[{index}].criterion_id")
        except ContractError as exc:
            raise ResultContractError("evidence_empty_criterion", str(exc)) from exc
        if item["criterion_id"] not in required_criteria:
            raise ResultContractError(
                "unknown_criterion",
                f"evidence[{index}].criterion_id is not required by the assignment"
            )
        if item["criterion_id"] in covered_criteria:
            raise ResultContractError(
                "duplicate_criterion",
                f"duplicate evidence criterion_id: {item['criterion_id']}"
            )
        covered_criteria.add(item["criterion_id"])
        try:
            _nonempty_string(item["reference"], f"evidence[{index}].reference")
        except ContractError as exc:
            raise ResultContractError("evidence_empty_reference", str(exc)) from exc
        if (
            not isinstance(item["outcome"], str)
            or item["outcome"] not in EVIDENCE_OUTCOMES
        ):
            raise ResultContractError(
                "evidence_unsupported_outcome", f"evidence[{index}].outcome is unsupported"
            )
        if not isinstance(item["details"], str):
            raise ResultContractError(
                "evidence_details_not_text", f"evidence[{index}].details must be a string"
            )
    if (
        execution_state == "completed"
        and semantic_verdict in {"pass", "ready"}
        and any(
        item["outcome"] in {"fail", "not_run"} for item in data["evidence"]
        )
    ):
        raise ResultContractError(
            "failed_completed_evidence",
            "completed result cannot contain failed or unrun evidence",
        )
    if execution_state == "completed" and covered_criteria != required_criteria:
        missing = sorted(required_criteria - covered_criteria)
        raise ResultContractError(
            "missing_required_evidence",
            "completed result is missing required evidence: " + ", ".join(missing)
        )
    usage = data.get("usage")
    if usage is not None:
        usage_fields = {
            "input_tokens",
            "cached_tokens",
            "output_tokens",
            "reasoning_tokens",
            "tool_calls",
            "latency_ms",
            "cost",
        }
        if not isinstance(usage, dict):
            raise ResultContractError(
                "invalid_usage", "usage must be null or an object"
            )
        usage_unknown = sorted(usage.keys() - usage_fields)
        if usage_unknown:
            raise ResultContractError(
                "invalid_usage",
                f"usage has unknown fields: {', '.join(usage_unknown)}",
            )
        for field, value in usage.items():
            if value is None:
                continue
            try:
                valid_number = (
                    isinstance(value, (int, float))
                    and not isinstance(value, bool)
                    and math.isfinite(value)
                    and value >= 0
                )
            except OverflowError:
                valid_number = False
            if not valid_number:
                raise ResultContractError(
                    "invalid_usage",
                    f"usage.{field} must be null or a non-negative number",
                )
    return dict(data)


def validate_evaluation_record(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ContractError("evaluation record must be an object")
    required = {
        "task_id",
        "family",
        "model",
        "effort",
        "baseline",
        "passed",
        "quality_score",
        "repairs",
        "latency_ms",
        "tool_calls",
    }
    optional = {
        "input_tokens",
        "cached_tokens",
        "output_tokens",
        "reasoning_tokens",
        "cost",
        "notes",
    }
    _required(data, required, "evaluation record")
    unknown = sorted(data.keys() - required - optional)
    if unknown:
        raise ContractError(f"evaluation record has unknown fields: {', '.join(unknown)}")
    for field in ("task_id", "family", "model", "effort"):
        _nonempty_string(data[field], field)
    for field in ("baseline", "passed"):
        if not isinstance(data[field], bool):
            raise ContractError(f"{field} must be boolean")
    score = data["quality_score"]
    if not isinstance(score, (int, float)) or isinstance(score, bool) or not 0 <= score <= 1:
        raise ContractError("quality_score must be a number from 0 to 1")
    for field in ("repairs", "latency_ms", "tool_calls"):
        if not isinstance(data[field], int) or data[field] < 0:
            raise ContractError(f"{field} must be a non-negative integer")
    for field in ("input_tokens", "cached_tokens", "output_tokens", "reasoning_tokens"):
        value = data.get(field)
        if value is not None and (not isinstance(value, int) or value < 0):
            raise ContractError(f"{field} must be null or a non-negative integer")
    cost = data.get("cost")
    if cost is not None and (
        not isinstance(cost, (int, float)) or isinstance(cost, bool) or cost < 0
    ):
        raise ContractError("cost must be null or a non-negative number")
    return data


def effective_dispatch_limits(route: dict[str, Any], assignment: dict[str, Any]) -> tuple[int, int]:
    """Existing hard-timeout/model-turn projection, shared with preflight.

    Inputs must have passed assignment/route validation. The historical
    max_tool_calls field is not an exact host-enforced tool-call budget.
    """

    route_bounds, assigned_bounds = route["bounds"], assignment["bounds"]
    explicit = validate_assignment_execution_limits(assignment, route)
    return (
        max(1, min(int(route_bounds["timeout_seconds"]), int(assigned_bounds["timeout_seconds"]))),
        explicit.get("max_model_turns", max(1, min(
            int(route_bounds["max_tool_calls"]), int(assigned_bounds["max_tool_calls"]),
        ))),
    )


def effective_dispatch_bounds(route: dict[str, Any], assignment: dict[str, Any]) -> dict[str, Any]:
    """The same requested/effective unit report for preflight and dispatch."""

    deadline, turns = effective_dispatch_limits(route, assignment)
    claude = route.get("provider") == "claude" and route.get("dispatch") == "bridge"
    codex = route.get("provider") == "codex" and route.get("dispatch") == "bridge"
    explicit = assignment.get("execution_limits", {})
    return {
        "execution_limit_contract": "explicit" if explicit else "legacy",
        "requested_execution_limits": dict(explicit),
        "hard_timeout_seconds": deadline,
        "nominal_max_tool_calls": min(route["bounds"]["max_tool_calls"],
                                      assignment["bounds"]["max_tool_calls"]),
        "exact_tool_call_limit": None,
        # 0.4.0 item 0.5 (VF-INV-e): the host counts a Codex child's command items and stops the run
        # above the nominal limit; a Claude child is bounded by its client's turn limit instead.
        "command_limit": min(route["bounds"]["max_tool_calls"], assignment["bounds"]["max_tool_calls"])
        if codex else None,
        "command_limit_enforcement": "host counts command items and stops the run above the limit"
        if codex else "unavailable",
        "model_turn_limit": turns if claude else None,
        "model_turn_enforcement": "client --max-turns" if claude else "unavailable",
        "model_turn_limit_source": (
            "execution_limits.max_model_turns" if explicit else "legacy max_tool_calls projection"
        ) if claude else "unavailable",
    }
