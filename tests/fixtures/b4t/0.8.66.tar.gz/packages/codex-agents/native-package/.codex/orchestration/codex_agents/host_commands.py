"""The Codex command rule that lets a sandboxed Codex primary run the orchestrator.

Codex runs a primary's shell commands inside its workspace-write sandbox, which
blocks the learning collector's local socket and its state directory. A Codex
command rule (``prefix_rule`` with ``decision = "allow"``) in the user's rules
layer runs a matching command outside that sandbox without prompting.

The rule matches an exact argument prefix, so it pins an absolute, trusted base
interpreter, its isolation flags and an absolute CLI: the sandboxed model can
write files elsewhere in the workspace and in temporary directories, so a
relative path, a virtual environment's interpreter or a startup that reads the
environment or site-packages would let it run its own code outside the sandbox.
It allows only the primary-host subcommands below. Owner commands (registration,
attestation, owner keys, grants, backups, canaries, promotion and the like) are
never listed, so they stay sandboxed.

The CLI the rule names is not the project's own ``.codex/orchestration/cli.py``.
Codex keeps ``.codex`` read-only only at the top of a session's writable root, so
a session opened on a parent folder could rewrite the project's copy and run it
through the rule. The owner's setup instead copies the installed runtime into
``~/.codex/agent-orchestration/<project>/<runtime>/``, next to
the rules directory itself: a session that could change that copy could already
write a rule that allows anything. Only the real `~/.codex` qualifies: a
`CODEX_HOME` elsewhere or a symlinked `~/.codex` may resolve into a folder a
session can write. The copy holds exactly this package's runtime files
(`runtime_files.RUNTIME_FILES`, a constant, never the project's manifest), is
verified byte for byte against the project's installed files, carries a binding
to its project, and is what the rule runs.

The rule leaves every later argument to the CLI. The copy therefore pins these
commands to its bound project, the default learning state and its installed
policy, refusing ``--project-root``, ``--root``, ``--state-root`` or ``--policy``
values that would move them (``cli._require_own_roots``).
"""

from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import secrets
import shlex
import stat
import sys
import unicodedata
from collections.abc import Mapping
from pathlib import Path, PurePosixPath

from .host_paths import (
    PYTHON_ISOLATION_FLAGS,
    HostPathError,
    account_home,
    install_location_problem,
    open_private_directories,
    remove_tree_at,
    temp_roots,
    trusted_location_problem,
    within,
)
from .runtime_files import (
    ORCHESTRATION_PREFIX,
    PACKAGE_DATA_FILES,
    PROJECT_FILES,
    RUNTIME_FILES,
    runtime_digest,
)

# The subcommands a primary host runs during an orchestration. Defined once; the
# rule's allowlist and its tests read it from here.
PRIMARY_HOST_COMMANDS = (
    "validate",
    "inventory",
    "route",
    "learning-route",
    "validate-assignment",
    "result-preflight",
    "dispatch-preflight",
    "validate-result",
    "learning-status",
    "learning-open-orchestration",
    "learning-checkpoint-orchestration",
    "learning-pause-orchestration",
    "learning-resume-orchestration",
    "learning-close-orchestration",
    "learning-orchestration-report",
    "learning-orchestration-status",
    "learning-open-host-run",
    "learning-run-status",
    "learning-cancel-run",
    "learning-bind-host-agent",
    "learning-observe-host-run",
    "learning-classify-host-run-abandoned",
    "learning-record-host-result",
    "dispatch",
    "provider-observe",
    "learning-run-operational-checks",
    "learning-record-operational-qa",
    "learning-review",
)
CLI_RELATIVE = Path(".codex") / "orchestration" / "cli.py"
MANIFEST_RELATIVE = ".codex/orchestration/install-manifest.json"
# Present only in a protected runtime copy, never in a project or the source tree.
BINDING_RELATIVE = ".codex/orchestration/runtime-binding.json"
RUNTIME_CONTAINER = "agent-orchestration"
BINDING_FORMAT = 2
MAX_MANIFEST_BYTES = 1_048_576
MAX_MANIFEST_FILES = 4096
MAX_RUNTIME_FILE_BYTES = 8 * 1_048_576
MAX_BINDING_BYTES = 4096
# The one package path under .claude, as the installer owns it.
CLAUDE_SKILL_PREFIX = (".claude", "skills", "agent-orchestration")
_HEX = frozenset("0123456789abcdef")
# Isolated mode, no bytecode written into `.codex`, and no site-packages (see
# host_paths): the CLI needs only the standard library and its own package.
PYTHON_FLAGS = PYTHON_ISOLATION_FLAGS
RULE_FILE_PREFIX = "agent-orchestration-"
RULE_JUSTIFICATION = (
    "Agent orchestration: this project's everyday orchestrator commands need the "
    "local learning collector, which the Codex sandbox blocks."
)
MAX_RULE_BYTES = 65_536
# Line breaks, other control characters, invisible format characters and
# unpaired surrogates never reach a rule file, even quoted.
_REFUSED_CATEGORIES = {"Cc", "Cf", "Cs", "Zl", "Zp"}
_SHELL_SPECIAL = frozenset(" \t\n'\"\\$`&;|<>()*?[]{}!")
_SHELL_SPECIAL_FIRST = frozenset("~#")


class HostCommandError(RuntimeError):
    """A rule cannot be built or written safely; messages never carry paths."""


class CodexHomeUnsupported(HostCommandError):
    """The Codex home is not the plain `~/.codex` folder the rule and copy require."""


class OwnRootRefused(HostCommandError):
    """An installed CLI's primary-host command named another project, state or policy.

    Messages name the refused option, never its value.
    """


def _checked_text(value: str, what: str) -> str:
    if not value or any(unicodedata.category(ch) in _REFUSED_CATEGORIES for ch in value):
        raise HostCommandError(f"{what} contains a character a Codex rule cannot hold")
    return value


def _starlark_string(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _starlark_list(values: list[str]) -> str:
    return "[" + ", ".join(_starlark_string(value) for value in values) + "]"


def project_cli(project_root: Path) -> tuple[Path, Path]:
    """Return the resolved project root and its installed CLI, both absolute."""

    try:
        root = Path(project_root).resolve(strict=True)
    except OSError as exc:
        raise HostCommandError("project root is unavailable") from exc
    if not root.is_dir():
        raise HostCommandError("project root is not a directory")
    _checked_text(str(root), "project root")
    cli = root / CLI_RELATIVE
    try:
        info = cli.lstat()
        resolved = cli.resolve(strict=True)
    except OSError as exc:
        raise HostCommandError("project CLI is not installed") from exc
    if not stat.S_ISREG(info.st_mode) or resolved != cli:
        raise HostCommandError("project CLI is a symlink or not a regular file")
    # The rule runs this file outside the sandbox, so a project a Codex session can
    # rewrite wholesale (one in a temporary directory) never gets one, and neither
    # does a CLI another user could replace.
    temporary = list(temp_roots())
    if any(within(root, item) for item in temporary):
        raise HostCommandError(
            "the project lies in a temporary directory, which Codex sessions can change"
        )
    problem = trusted_location_problem(cli, temporary)
    if problem is not None:
        raise HostCommandError(f"the project CLI cannot be trusted: {problem}")
    return root, cli


def interpreter_path(
    interpreter: str | None = None, *, project_root: Path | None = None
) -> str:
    """The trusted base interpreter the rule names, as Python reports it.

    It is ``sys.executable``, or the base interpreter of a virtual environment,
    whose files the project or the model could change, pinned as its realpath:
    no symlink on the way remains that could later be retargeted, and a Python
    upgrade that moves the build makes the rule stale until setup runs again.
    It is refused when it or its standard library prefix is inside the project
    or a temporary directory, or when any component belongs to another user or
    is writable by anyone else. The wizard and a Codex primary both start
    ``python3`` from PATH, so they resolve to the same path.

    An explicit `interpreter` is a test seam: it is checked as text only.
    """

    if interpreter is not None:
        if not os.path.isabs(interpreter):
            raise HostCommandError("interpreter path is not absolute")
        return _checked_text(interpreter, "interpreter path")
    value = sys.executable
    if sys.prefix != sys.base_prefix:
        value = getattr(sys, "_base_executable", "") or ""
        if not value or within(
            Path(os.path.realpath(value)), Path(os.path.realpath(sys.prefix))
        ):
            raise HostCommandError(
                "Python runs in a virtual environment; run setup with the base Python"
            )
    if not value or not os.path.isabs(value):
        raise HostCommandError("interpreter path is not absolute")
    value = os.path.realpath(value)
    _checked_text(value, "interpreter path")
    if sys.platform == "darwin" and os.path.dirname(value) == "/usr/bin":
        # Every developer tool there is an xcrun shim, which reads a lookup
        # cache under $TMPDIR; the real interpreter it would run is elsewhere.
        raise HostCommandError("the Python interpreter cannot be trusted: it is an xcrun shim")
    untrusted = [*temp_roots(), *([project_root] if project_root is not None else [])]
    prefix = Path(os.path.realpath(sys.base_prefix))
    for path in (Path(value), prefix):
        problem = trusted_location_problem(path, untrusted)
        # The interpreter and its standard library come from a trusted
        # installation folder; a Linux system Python's prefix is /usr itself.
        if problem is None and not (path == prefix and prefix == Path("/usr")):
            problem = install_location_problem(path)
        if problem is not None:
            raise HostCommandError(f"the Python interpreter cannot be trusted: {problem}")
    return value


def _home_folder(environ: Mapping[str, str]) -> Path:
    """The home folder the environment names (HOME), or the account's own."""

    value = environ.get("HOME") if "HOME" in environ else str(account_home())
    if not value or not os.path.isabs(value):
        raise CodexHomeUnsupported("the home folder is not an absolute path")
    return Path(os.path.normpath(value))


def configured_codex_home(environ: Mapping[str, str] | None = None) -> Path:
    """Where Codex keeps its settings in this environment: CODEX_HOME or ~/.codex."""

    environ = os.environ if environ is None else environ
    configured = environ.get("CODEX_HOME")
    if not configured:
        return _home_folder(environ) / ".codex"
    home = Path(configured).expanduser()
    if not home.is_absolute():
        raise CodexHomeUnsupported("CODEX_HOME is not an absolute path")
    return Path(os.path.normpath(home))


def codex_home(environ: Mapping[str, str] | None = None) -> Path:
    """The protected Codex home the rule and its copy require: the real `$HOME/.codex`.

    A session opened on the home folder keeps `~/.codex` read-only (it is that
    workspace's own `.codex`), and a session opened inside a project cannot
    reach it. A `CODEX_HOME` elsewhere, or a `~/.codex` that is a symlink, may
    resolve into a folder a home-folder session can write, so neither is
    supported, and neither is a HOME other than the account's home folder in
    the system account database. The home folder must be canonical, with no
    symlink and no component another user could change, and `~/.codex`, when
    present, a real directory of this user's that no one else can write.
    """

    environ = os.environ if environ is None else environ
    home = _home_folder(environ)
    expected = home / ".codex"
    if configured_codex_home(environ) != expected:
        raise CodexHomeUnsupported(
            "CODEX_HOME points somewhere other than ~/.codex; the Codex rule and its "
            "protected copy work only in ~/.codex"
        )
    _checked_text(str(home), "home folder")
    if Path(os.path.realpath(home)) != home:
        raise CodexHomeUnsupported(
            "the home folder's path passes through a symbolic link; the Codex rule "
            "needs a home folder at its real path"
        )
    if home != account_home():
        raise CodexHomeUnsupported(
            "HOME is not this account's home folder; the Codex rule and its protected "
            "copy work only in the account's own ~/.codex"
        )
    problem = trusted_location_problem(home, [])
    if problem is not None:
        raise CodexHomeUnsupported(f"the home folder cannot be trusted: {problem}")
    try:
        info = os.lstat(expected)
    except FileNotFoundError:
        return expected
    except OSError as exc:
        raise CodexHomeUnsupported("~/.codex is unavailable") from exc
    if stat.S_ISLNK(info.st_mode):
        raise CodexHomeUnsupported(
            "~/.codex is a symbolic link; the Codex rule and its protected copy need a "
            "real ~/.codex folder"
        )
    if not stat.S_ISDIR(info.st_mode):
        raise CodexHomeUnsupported("~/.codex is not a folder")
    if info.st_uid != os.geteuid() or info.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
        raise CodexHomeUnsupported(
            "~/.codex belongs to another user or others can change it"
        )
    return expected


def project_digest(root: Path) -> str:
    """The short digest of a resolved project root that names its rule and copy."""

    return hashlib.sha256(str(root).encode("utf-8")).hexdigest()[:12]


def _read_nofollow(root: Path, relative: str, limit: int) -> bytes | None:
    """Read `<root>/<relative>` through no-follow descriptors; None when absent.

    A symlink at or below `root`, a non-regular file or more than `limit` bytes
    refuses. `root` itself is opened as given (callers pass canonical paths).
    """

    parts = PurePosixPath(relative).parts
    try:
        descriptor = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise HostCommandError("a runtime file is unavailable") from exc
    try:
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        handle = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
    except FileNotFoundError:
        os.close(descriptor)
        return None
    except OSError as exc:
        os.close(descriptor)
        raise HostCommandError("a runtime file is a symlink or unavailable") from exc
    os.close(descriptor)
    try:
        if not stat.S_ISREG(os.fstat(handle).st_mode):
            raise HostCommandError("a runtime file is not a regular file")
        chunks = []
        received = 0
        while chunk := os.read(handle, 1_048_576):
            received += len(chunk)
            if received > limit:
                raise HostCommandError("a runtime file is too large")
            chunks.append(chunk)
        return b"".join(chunks)
    finally:
        os.close(handle)


def _manifest_files(raw: bytes) -> dict[str, str]:
    """The installer manifest's file map, with every path checked as the installer does."""

    try:
        manifest = json.loads(raw)
    except (UnicodeError, ValueError) as exc:
        raise HostCommandError("the install manifest is invalid") from exc
    if (
        not isinstance(manifest, dict)
        or set(manifest) != {"format", "version", "files"}
        or manifest["format"] != 1
        or not isinstance(manifest["version"], str)
        or not isinstance(manifest["files"], dict)
        or len(manifest["files"]) > MAX_MANIFEST_FILES
    ):
        raise HostCommandError("the install manifest is invalid")
    for relative, digest in manifest["files"].items():
        parts = PurePosixPath(relative).parts if isinstance(relative, str) else ()
        if (
            not parts
            or relative.startswith("/")
            or any(part in {"", ".", ".."} for part in parts)
            or "\\" in relative
            or relative in {MANIFEST_RELATIVE, BINDING_RELATIVE}
            or not (
                parts[0] in {".agents", ".codex"}
                or (len(parts) > 3 and parts[:3] == CLAUDE_SKILL_PREFIX)
            )
            or not isinstance(digest, str)
            or len(digest) != 64
            or not set(digest) <= _HEX
        ):
            raise HostCommandError("the install manifest is invalid")
    if CLI_RELATIVE.as_posix() not in manifest["files"]:
        raise HostCommandError("the install manifest does not list the CLI")
    return manifest["files"]


def _manifest_version(raw: bytes) -> str:
    _manifest_files(raw)
    return json.loads(raw)["version"]


def _require_manifest(root: Path) -> bytes:
    raw = _read_nofollow(root, MANIFEST_RELATIVE, MAX_MANIFEST_BYTES)
    if raw is None:
        raise HostCommandError("the project has no install manifest; install the package first")
    _manifest_files(raw)
    return raw


def _runtime_contents(root: Path) -> dict[str, bytes]:
    """This package's runtime files (RUNTIME_FILES, a constant) as they sit under `root`."""

    contents: dict[str, bytes] = {}
    for relative in RUNTIME_FILES:
        content = _read_nofollow(root, ORCHESTRATION_PREFIX + relative, MAX_RUNTIME_FILE_BYTES)
        if content is None:
            raise HostCommandError("an installed runtime file is missing")
        contents[relative] = content
    return contents


def unexpected_entries(
    base: Path, files: set[str], *, ignore_finder: bool = False, limit: int = 64
) -> list[str]:
    """The entries under `base` other than `files` and the directories that hold them.

    A `__pycache__` directory, a module or package of any kind, an extension module, a
    symlink or any other extra entry counts. Paths are relative to `base`, in walk order,
    at most `limit` of them; an extra directory is reported once, not its contents.
    """

    directories = {
        PurePosixPath(*PurePosixPath(item).parts[:index]).as_posix()
        for item in files
        for index in range(1, len(PurePosixPath(item).parts))
    }
    found: list[str] = []
    for current, subdirectories, names in os.walk(base, followlinks=False):
        here = Path(current).relative_to(base)
        for name in sorted(subdirectories):
            relative = (here / name).as_posix()
            if os.path.islink(Path(current, name)) or relative not in directories:
                found.append(relative)
        subdirectories[:] = sorted(
            name for name in subdirectories
            if not os.path.islink(Path(current, name)) and (here / name).as_posix() in directories
        )
        for name in sorted(names):
            path = Path(current, name)
            if ignore_finder and name == ".DS_Store" and not os.path.islink(path):
                continue
            if (here / name).as_posix() not in files or os.path.islink(path):
                found.append((here / name).as_posix())
        if len(found) >= limit:
            return found[:limit]
    return found


def _unexpected_entries(base: Path, files: set[str], *, ignore_finder: bool = False) -> bool:
    return bool(unexpected_entries(base, files, ignore_finder=ignore_finder, limit=1))


def project_extra_files(root: Path, also_allowed: set[str] | None = None) -> list[str]:
    """What the project's `.codex/orchestration` holds beyond the package's files.

    Only this package's runtime and data files and the project's own configuration
    (and `also_allowed`, paths relative to that folder) may be there: a planted
    top-level module (`socket.py`), a package, bytecode or an extension module would be
    a sign of tampering. Finder's `.DS_Store`, which nothing imports, is ignored.
    """

    allowed = {*RUNTIME_FILES, *PACKAGE_DATA_FILES, *PROJECT_FILES, *(also_allowed or ())}
    return unexpected_entries(root / ".codex" / "orchestration", allowed, ignore_finder=True)


def _project_holds_extra_files(root: Path) -> bool:
    """Whether the project's `.codex/orchestration` holds files the package does not."""

    return bool(project_extra_files(root))


def _copy_manifest(version: str, contents: dict[str, bytes]) -> bytes:
    """The manifest a copy carries: exactly the runtime files and their digests."""

    manifest = {
        "format": 1,
        "version": version,
        "files": {
            ORCHESTRATION_PREFIX + relative: hashlib.sha256(contents[relative]).hexdigest()
            for relative in RUNTIME_FILES
        },
    }
    return (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _copy_files() -> set[str]:
    return {
        *(ORCHESTRATION_PREFIX + relative for relative in RUNTIME_FILES),
        MANIFEST_RELATIVE,
        BINDING_RELATIVE,
    }


def _copy_root(root: Path, digest: str, environ: Mapping[str, str] | None) -> Path:
    home = codex_home(environ)
    copy = home / RUNTIME_CONTAINER / project_digest(root) / digest
    if any(within(copy, item) for item in [root, *temp_roots()]):
        raise HostCommandError(
            "the runtime copy would lie in the project or a temporary directory, "
            "which Codex sessions can change"
        )
    return copy


def runtime_copy_root(project_root: Path, environ: Mapping[str, str] | None = None) -> Path:
    """Where the protected copy of the project's current installed runtime lives.

    `~/.codex/agent-orchestration/<project digest>/<runtime digest>`, where
    the runtime digest covers every file the copy holds (RUNTIME_FILES), so a
    package update names a new copy and leaves the rule stale until setup
    runs again. A project without an install manifest has no runtime to copy.
    """

    root, _cli = project_cli(project_root)
    _require_manifest(root)
    return _copy_root(root, runtime_digest(_runtime_contents(root)), environ)


def installer_root(orchestration_root: Path) -> Path:
    """The orchestrator clone a CLI runs from (or the project, for an installed CLI)."""

    parts = orchestration_root.parts
    if parts[-5:] == ("packages", "codex-agents", "native-package", ".codex", "orchestration"):
        return Path(*parts[:-5])
    return orchestration_root.parent.parent


def _binding_bytes(root: Path, digest: str, version: str, clone: Path) -> bytes:
    binding = {
        "format": BINDING_FORMAT,
        "project_root": str(root),
        "runtime_digest": digest,
        "version": version,
        # The clone that installed the copy: no session may write it (session_guard).
        "clone_root": str(clone),
    }
    return (json.dumps(binding, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _parse_binding(raw: bytes) -> dict[str, str]:
    try:
        binding = json.loads(raw)
    except (UnicodeError, ValueError) as exc:
        raise HostCommandError("the protected runtime binding is invalid") from exc
    if (
        not isinstance(binding, dict)
        or set(binding) != {
            "format", "project_root", "runtime_digest", "version", "clone_root",
        }
        or binding["format"] != BINDING_FORMAT
        or not isinstance(binding["project_root"], str)
        or not os.path.isabs(binding["project_root"])
        or not isinstance(binding["clone_root"], str)
        or not os.path.isabs(binding["clone_root"])
        or not isinstance(binding["runtime_digest"], str)
        or len(binding["runtime_digest"]) != 64
        or not set(binding["runtime_digest"]) <= _HEX
        or not isinstance(binding["version"], str)
    ):
        raise HostCommandError("the protected runtime binding is invalid")
    _checked_text(binding["project_root"], "bound project root")
    return binding


def runtime_binding(orchestration_root: Path) -> dict[str, str] | None:
    """A protected copy's verified binding (see `bound_project_root`); None elsewhere."""

    copy = orchestration_root.parent.parent
    if bound_project_root(orchestration_root) is None:
        return None
    raw = _read_nofollow(copy, BINDING_RELATIVE, MAX_BINDING_BYTES)
    if raw is None:
        raise HostCommandError("the protected runtime binding is unavailable")
    return _parse_binding(raw)


def bound_project_root(orchestration_root: Path) -> Path | None:
    """The project a protected runtime copy serves, from its binding; None elsewhere.

    The binding, the manifest and the code all sit in the owner-only copy, so
    the bound root is as trustworthy as the CLI reading it. The copy must sit
    at exactly the path its binding implies, its manifest must carry the bound
    version, and the project must still be a canonical directory. A project or
    source tree has no binding and keeps using its own location. The full
    byte check is `runtime_copy_problem`, which every primary-host command runs.
    """

    copy = orchestration_root.parent.parent
    if not os.path.lexists(copy / BINDING_RELATIVE):
        return None
    raw = _read_nofollow(copy, BINDING_RELATIVE, MAX_BINDING_BYTES)
    if raw is None:
        raise HostCommandError("the protected runtime binding is unavailable")
    binding = _parse_binding(raw)
    root = Path(binding["project_root"])
    if (
        copy.name != binding["runtime_digest"]
        or copy.parent.name != project_digest(root)
        or copy.parent.parent.name != RUNTIME_CONTAINER
    ):
        raise HostCommandError("the protected runtime copy is not where its binding says")
    manifest = _read_nofollow(copy, MANIFEST_RELATIVE, MAX_MANIFEST_BYTES)
    if manifest is None or _manifest_version(manifest) != binding["version"]:
        raise HostCommandError("the protected runtime copy differs from its binding")
    if Path(os.path.realpath(root)) != root or not root.is_dir():
        raise HostCommandError("the bound project is unavailable")
    return root


def runtime_copy_problem(copy: Path, root: Path) -> str | None:
    """Why `copy` is not the protected copy of `root`'s current runtime, or None.

    The copy must sit where no workspace or temporary directory reaches and
    hold exactly the runtime files, its manifest and its binding. Its binding
    must name `root`, its name and binding the digest of those files, and its
    manifest exactly those files at the bound version. Every runtime file must
    be byte-for-byte the project's, and the project's manifest version the
    bound one. Messages carry no paths.
    """

    try:
        problem = trusted_location_problem(copy / CLI_RELATIVE, [root, *temp_roots()])
        if problem is not None:
            return f"the runtime copy cannot be trusted: {problem}"
        if _unexpected_entries(copy, _copy_files()):
            return "the runtime copy holds files it should not, such as bytecode"
        raw = _read_nofollow(copy, BINDING_RELATIVE, MAX_BINDING_BYTES)
        if raw is None:
            return "the runtime copy has no binding"
        binding = _parse_binding(raw)
        if binding["project_root"] != str(root) or binding["runtime_digest"] != copy.name:
            return "the runtime copy is bound to another project or runtime"
        ours = _runtime_contents(copy)
        if runtime_digest(ours) != copy.name:
            return "the runtime copy's files differ from its name"
        if _read_nofollow(copy, MANIFEST_RELATIVE, MAX_MANIFEST_BYTES) != _copy_manifest(
            binding["version"], ours
        ):
            return "the runtime copy's manifest differs from its files"
        project_manifest = _read_nofollow(root, MANIFEST_RELATIVE, MAX_MANIFEST_BYTES)
        if project_manifest is None:
            return "the project has no install manifest"
        if _manifest_version(project_manifest) != binding["version"]:
            return "the project's installed version differs from the runtime copy's"
        if _runtime_contents(root) != ours:
            return "the runtime copy differs from the project's installed files"
    except HostCommandError as exc:
        return str(exc)
    return None


def argv_prefix(
    project_root: Path,
    interpreter: str | None = None,
    environ: Mapping[str, str] | None = None,
) -> list[str]:
    """The exact command prefix a Codex primary must use: it names the protected copy."""

    root, _cli = project_cli(project_root)
    python = interpreter_path(interpreter, project_root=root)
    copy = runtime_copy_root(root, environ)
    return [python, *PYTHON_FLAGS, str(copy / CLI_RELATIVE)]


def shell_command(argv: list[str]) -> str:
    """`argv` as one line of shell, quoting only a word that cannot run without it."""

    # Not shlex.join: its ASCII allowlist also quotes words such as a non-ASCII path.
    return " ".join(
        word if word and word[0] not in _SHELL_SPECIAL_FIRST and not set(word) & _SHELL_SPECIAL
        else shlex.quote(word)
        for word in argv
    )


def rule_file_name(project_root: Path) -> str:
    root, _cli = project_cli(project_root)
    return f"{RULE_FILE_PREFIX}{project_digest(root)}.rules"


def rule_path(project_root: Path, environ: Mapping[str, str] | None = None) -> Path:
    return codex_home(environ) / "rules" / rule_file_name(project_root)


def render_rule(
    project_root: Path,
    interpreter: str | None = None,
    environ: Mapping[str, str] | None = None,
) -> str:
    """The complete rule file for one project, with Codex's own load-time self-tests."""

    root, cli = project_cli(project_root)
    prefix = argv_prefix(root, interpreter, environ)
    python = prefix[0]
    relative_cli = CLI_RELATIVE.as_posix()
    commands = "".join(
        f"            {_starlark_string(command)},\n" for command in PRIMARY_HOST_COMMANDS
    )
    match = [[*prefix, "learning-status", "--project-root", str(root)]]
    not_match = [
        # An owner command stays in the sandbox.
        [*prefix, "learning-register", "--project-root", str(root)],
        # The project's own CLI stays sandboxed: a session can change it.
        [python, *PYTHON_FLAGS, str(cli), "learning-status", "--project-root", str(root)],
        # Relative forms could name a look-alike the model wrote.
        ["python3", relative_cli, "learning-status", "--project-root", str(root)],
        [python, *PYTHON_FLAGS, relative_cli, "learning-status", "--project-root", str(root)],
        # Without the isolation flags, startup could load code the model wrote.
        [python, prefix[-1], "learning-status", "--project-root", str(root)],
        # Without the bytecode prefix, a planted `.pyc` beside a module could load.
        [python, "-I", "-B", "-S", prefix[-1], "learning-status", "--project-root", str(root)],
    ]
    return (
        "# Agent orchestration: Codex command rule for one project.\n"
        "# Written by ./setup.sh (Codex commands step) with the owner's consent.\n"
        "# It lets Codex run only this project's everyday orchestrator commands\n"
        "# outside the Codex sandbox, so they can reach the local learning collector.\n"
        "# They run from an owner-only copy of the installed runtime, kept next to\n"
        "# this rules directory, which no project workspace can change.\n"
        "# Owner commands are not listed and stay sandboxed.\n"
        "# To remove it, delete this file and the runtime copy it names;\n"
        "# ./setup.sh can create both again.\n"
        "\n"
        "prefix_rule(\n"
        "    pattern = [\n"
        + "".join(f"        {_starlark_string(token)},\n" for token in prefix)
        + "        [\n"
        f"{commands}"
        "        ],\n"
        "    ],\n"
        '    decision = "allow",\n'
        f"    justification = {_starlark_string(RULE_JUSTIFICATION)},\n"
        "    match = [\n"
        + "".join(f"        {_starlark_list(example)},\n" for example in match)
        + "    ],\n"
        "    not_match = [\n"
        + "".join(f"        {_starlark_list(example)},\n" for example in not_match)
        + "    ],\n"
        ")\n"
    )


def _open_rules_directory(home: Path, *, create: bool) -> int | None:
    """Open the rules directory without following a symlink; None when absent.

    Codex home itself may be a symlink (dotfile setups often link it); the rules
    directory and the rule file may not.
    """

    rules = home / "rules"
    try:
        info = os.lstat(rules)
    except FileNotFoundError:
        if not create:
            return None
        home.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            os.mkdir(rules, 0o700)
        except FileExistsError:
            pass  # another setup created it first; it is checked below like any other
        info = os.lstat(rules)
    if stat.S_ISLNK(info.st_mode):
        raise HostCommandError("Codex rules directory is a symlink")
    if not stat.S_ISDIR(info.st_mode):
        raise HostCommandError("Codex rules directory is not a directory")
    descriptor = os.open(rules, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    if os.fstat(descriptor).st_uid != os.geteuid():
        os.close(descriptor)
        raise HostCommandError("Codex rules directory belongs to another user")
    return descriptor


def _read_rule(directory: int, name: str) -> bytes | None:
    """Read the existing rule without following a symlink; None when absent."""

    try:
        info = os.stat(name, dir_fd=directory, follow_symlinks=False)
    except FileNotFoundError:
        return None
    if stat.S_ISLNK(info.st_mode):
        raise HostCommandError("Codex rule file is a symlink")
    if not stat.S_ISREG(info.st_mode):
        raise HostCommandError("Codex rule file is not a regular file")
    descriptor = os.open(
        name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory
    )
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise HostCommandError("Codex rule file is not a regular file")
        return os.read(descriptor, MAX_RULE_BYTES + 1)
    finally:
        os.close(descriptor)


def rule_status(
    project_root: Path,
    environ: Mapping[str, str] | None = None,
    interpreter: str | None = None,
) -> str:
    """``installed``, ``missing`` or ``stale``.

    ``installed`` only when the rule file is exactly a fresh render, which
    names the protected copy of the project's current install manifest, and
    that copy is bound to this project and byte-for-byte its installed files.
    A rule naming the project's own CLI (written before the copy existed), a
    missing or differing copy, an updated package and a project without an
    install manifest are all ``stale``; ``missing`` means no rule file.
    """

    root, _cli = project_cli(project_root)
    python = interpreter_path(interpreter, project_root=root)
    name = rule_file_name(root)
    home = codex_home(environ)
    try:
        directory = _open_rules_directory(home, create=False)
        if directory is None:
            return "missing"
        try:
            current = _read_rule(directory, name)
        finally:
            os.close(directory)
    except HostCommandError:
        # A symlinked or foreign rule is never reported as ours.
        return "stale"
    if current is None:
        return "missing"
    try:
        copy = runtime_copy_root(root, environ)
        expected = render_rule(root, python, environ).encode("utf-8")
    except HostCommandError:
        return "stale"
    if current != expected or runtime_copy_problem(copy, root) is not None:
        return "stale"
    return "installed"


def write_rule(
    project_root: Path,
    environ: Mapping[str, str] | None = None,
    interpreter: str | None = None,
    *,
    replace: bool = False,
) -> str:
    """Write the rule atomically (mode 0600) and return what happened.

    ``unchanged`` when the file already holds this rule, ``created`` or
    ``replaced`` after a write, and ``differs`` when another rule is there and
    ``replace`` was not given, including one that appears while this call runs:
    a new rule is published with a hard link, which never overwrites. Symlinks
    are refused, never followed.
    """

    content = render_rule(project_root, interpreter, environ).encode("utf-8")
    name = rule_file_name(project_root)
    directory = _open_rules_directory(codex_home(environ), create=True)
    if directory is None:  # pragma: no cover - create=True always opens or raises.
        raise HostCommandError("Codex rules directory is unavailable")
    try:
        current = _read_rule(directory, name)
        if current == content:
            return "unchanged"
        if current is not None and not replace:
            return "differs"
        temporary = f".{name}.{secrets.token_hex(8)}.tmp"
        descriptor = os.open(
            temporary,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
            0o600,
            dir_fd=directory,
        )
        try:
            try:
                os.fchmod(descriptor, 0o600)
                view = memoryview(content)
                while view:
                    view = view[os.write(descriptor, view):]
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            if current is None:
                # Publish without replacing: another setup may have written a rule
                # since it was read, and only --replace may overwrite one.
                try:
                    os.link(
                        temporary, name, src_dir_fd=directory, dst_dir_fd=directory,
                        follow_symlinks=False,
                    )
                except FileExistsError:
                    outcome = (
                        "unchanged" if _read_rule(directory, name) == content else "differs"
                    )
                else:
                    outcome = "created"
            else:
                os.rename(temporary, name, src_dir_fd=directory, dst_dir_fd=directory)
                outcome = "replaced"
        finally:
            try:
                os.unlink(temporary, dir_fd=directory)
            except FileNotFoundError:
                pass
        os.fsync(directory)
        return outcome
    finally:
        os.close(directory)


def _write_new_file(directory: int, relative: str, content: bytes) -> None:
    """Create `relative` under `directory` (0700 directories, a 0600 file), never following."""

    parts = PurePosixPath(relative).parts
    descriptor = os.dup(directory)
    try:
        for part in parts[:-1]:
            try:
                os.mkdir(part, 0o700, dir_fd=descriptor)
            except FileExistsError:
                pass
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        handle = os.open(
            parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600,
            dir_fd=descriptor,
        )
        try:
            os.fchmod(handle, 0o600)
            view = memoryview(content)
            while view:
                view = view[os.write(handle, view):]
            os.fsync(handle)
        finally:
            os.close(handle)
    finally:
        os.close(descriptor)


def _validate_runtime(cli: Path) -> None:
    """Require the installed runtime at `cli` to be exactly this package's recorded runtime.

    The manifest's file digests must hold, and the version and collector
    runtime digest must equal the ones this package records for itself (and
    `runtime-releases.json` records for its version).
    """

    from .collector_contracts import CollectorAuthorizationError
    from .collector_runtime import validate_collector_runtime

    try:
        validate_collector_runtime(cli)
    except CollectorAuthorizationError as exc:
        raise HostCommandError(
            "the installed runtime differs from this package's recorded runtime; "
            "update the install first"
        ) from exc


def install_runtime_copy(
    project_root: Path,
    environ: Mapping[str, str] | None = None,
    clone_root: Path | None = None,
) -> tuple[Path, str]:
    """Copy the project's installed runtime to its protected location; return it and what happened.

    ``created``, ``unchanged`` (a verified copy was already there) or
    ``replaced`` (a copy at that name failed verification and was rebuilt).
    The copy is staged in a private sibling directory, verified, then renamed
    into place, so the rule never names a partial copy. Every directory is
    created owner-only through no-follow descriptors.
    """

    from .collector_client import COLLECTOR_RUNTIME_DIGEST, PACKAGE_VERSION

    root, cli = project_cli(project_root)
    codex_home(environ)
    manifest = _require_manifest(root)
    _validate_runtime(cli)
    if _project_holds_extra_files(root):
        raise HostCommandError(
            "the project's .codex/orchestration folder holds files the package does not "
            "install, such as bytecode or extra modules; remove them, update the install "
            "and run setup again"
        )
    # The copy is exactly this package's runtime file set, read once, and its bytes
    # must be the runtime this code records for itself; the project's manifest only
    # supplies the version.
    files = _runtime_contents(root)
    digest = runtime_digest(files)
    version = _manifest_version(manifest)
    if digest != COLLECTOR_RUNTIME_DIGEST or version != PACKAGE_VERSION:
        raise HostCommandError(
            "the installed runtime differs from this package's recorded runtime; "
            "update the install first"
        )
    copy = _copy_root(root, digest, environ)
    home = copy.parent.parent.parent
    try:
        home.mkdir(mode=0o700, parents=True, exist_ok=True)
        container = open_private_directories(
            home, (RUNTIME_CONTAINER, copy.parent.name), create=True
        )
    except (OSError, HostPathError) as exc:
        raise HostCommandError(f"the runtime copy directory is unavailable: {exc}") from exc
    if container is None:  # pragma: no cover - create=True always opens or raises.
        raise HostCommandError("the runtime copy directory is unavailable")
    outcome = "created"
    token = secrets.token_hex(8)
    staging = f".{copy.name}.{token}.tmp"
    aside = f".{copy.name}.{token}.old"
    clone = Path(os.path.realpath(clone_root)) if clone_root is not None else root
    held = None
    project_lock = None
    try:
        # RS-E E2a-4 (review round 1): a replacement takes the project's stable lock, as prune, removal and pins do.
        project_lock = _take_project_lock(container)
        if os.path.lexists(copy):
            if runtime_copy_problem(copy, root) is None and (
                    _bound_clone(copy) == clone or _registered(container, copy.name)):
                # Decision 179: the registered copy (the one the launch record names) is never replaced while it
                # verifies; only where setup ran differs, which a launch target does not consult (E2a-3).
                return copy, "unchanged"
            # RS-E E2a-4: never replace a copy a launcher holds in use.
            held = _lock_copy(container, copy.name, exclusive=True)
            if held is None:
                raise HostCommandError("the runtime copy is in use by a starting service; run setup again shortly")
            os.rename(copy.name, aside, src_dir_fd=container, dst_dir_fd=container)
            outcome = "replaced"
        os.mkdir(staging, 0o700, dir_fd=container)
        staged = os.open(staging, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=container)
        try:
            for relative in RUNTIME_FILES:
                _write_new_file(staged, ORCHESTRATION_PREFIX + relative, files[relative])
            _write_new_file(staged, MANIFEST_RELATIVE, _copy_manifest(version, files))
            _write_new_file(
                staged, BINDING_RELATIVE, _binding_bytes(root, digest, version, clone)
            )
        finally:
            os.close(staged)
        try:
            os.rename(staging, copy.name, src_dir_fd=container, dst_dir_fd=container)
        except OSError:
            # Another setup published this copy first; it must verify like any other.
            if runtime_copy_problem(copy, root) is not None:
                raise HostCommandError("a differing runtime copy appeared while setup ran") from None
            outcome = "unchanged"
    except OSError as exc:
        raise HostCommandError("the runtime copy could not be written") from exc
    finally:
        for leftover in (staging, aside):
            try:
                remove_tree_at(container, leftover)
            except OSError:
                pass
        if held is not None:
            _unpin(container, copy.name, held)
        if project_lock is not None:
            os.close(project_lock)
        os.close(container)
    problem = runtime_copy_problem(copy, root)
    if problem is not None:
        raise HostCommandError(f"the runtime copy could not be verified: {problem}")
    _validate_runtime(copy / CLI_RELATIVE)
    return copy, outcome


def _bound_clone(copy: Path) -> Path | None:
    raw = _read_nofollow(copy, BINDING_RELATIVE, MAX_BINDING_BYTES)
    return None if raw is None else Path(_parse_binding(raw)["clone_root"])


# RS-E E2a-4: pins beside the copies, in `.pins` (removed once empty). The project's stable lock is its copies'
# folder itself (a directory is never replaced while its project's copies exist): prune, replacement, removal and
# the registered marks take it, exclusive and in turn, so a mark and a removal never interleave. `<digest>.lock` is held shared by a launcher from its
# verification until its child serves, and exclusive (never waited for) by a prune, replacement or removal of that
# copy; an acquirer checks that the path still names the inode it locked, so a lock file a remover dropped is never
# taken as a pin. `<digest>.registered` marks the copy the collector's launch record names: setup adds the new mark
# before its record commits and drops the earlier one only after it.
PINS = ".pins"


def _pins_directory(container: int, *, create: bool) -> int | None:
    try:
        if create:
            with contextlib.suppress(FileExistsError):
                os.mkdir(PINS, 0o700, dir_fd=container)
        descriptor = os.open(PINS, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=container)
    except FileNotFoundError:
        return None
    info = os.fstat(descriptor)
    if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o077:
        os.close(descriptor)
        raise HostCommandError("the runtime copy pins are not private")
    return descriptor


def _take_project_lock(container: int) -> int:
    """The project's stable lock (its copies' folder), exclusive (a short wait for another setup step); the
    returned descriptor holds it."""
    descriptor = os.open(".", os.O_RDONLY | os.O_DIRECTORY, dir_fd=container)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX)
    except OSError:
        os.close(descriptor)
        raise
    return descriptor


@contextlib.contextmanager
def _project_locked(container: int):
    descriptor = _take_project_lock(container)
    try:
        yield
    finally:
        os.close(descriptor)


def _lock_copy(container: int, name: str, *, exclusive: bool) -> int | None:
    """The copy's pin lock, taken without waiting; its descriptor holds it, or None when someone else holds it or
    the lock file this opened was dropped meanwhile."""
    pins = _pins_directory(container, create=True)
    if pins is None:
        return None  # its pins folder was removed between its creation and its open
    try:
        try:
            descriptor = os.open(name + ".lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=pins)
        except FileNotFoundError:
            return None  # its pins folder was just emptied and removed
        try:
            fcntl.flock(descriptor, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB)
            try:
                named = os.stat(name + ".lock", dir_fd=pins, follow_symlinks=False)
            except FileNotFoundError:
                named = None
            opened = os.fstat(descriptor)
            if named is None or (named.st_dev, named.st_ino) != (opened.st_dev, opened.st_ino):
                raise BlockingIOError()
        except OSError:
            os.close(descriptor)
            return None
        return descriptor
    finally:
        os.close(pins)


def _unpin(container: int, name: str, held: int) -> None:
    """Drop a removed or replaced copy's lock file while still holding it (a later acquirer sees the new inode),
    and the pins folder once it is empty."""
    try:
        pins = _pins_directory(container, create=False)
        if pins is not None:
            try:
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(name + ".lock", dir_fd=pins)
            finally:
                os.close(pins)
            with contextlib.suppress(OSError):
                os.rmdir(PINS, dir_fd=container)
    finally:
        os.close(held)


def _registered(container: int, name: str) -> bool:
    pins = _pins_directory(container, create=False)
    if pins is None:
        return False
    try:
        os.stat(name + ".registered", dir_fd=pins, follow_symlinks=False)
        return True
    except FileNotFoundError:
        return False
    finally:
        os.close(pins)


def _set_mark(container: int, name: str) -> None:
    """Under the project lock: mark an existing copy registered (durably)."""
    try:
        os.stat(name, dir_fd=container, follow_symlinks=False)
    except FileNotFoundError:
        raise HostCommandError("the runtime copy is gone") from None
    pins = _pins_directory(container, create=True)  # under the project lock: nothing removes it meanwhile
    if pins is None:
        raise HostCommandError("the runtime copy pins are unavailable")
    try:
        os.close(os.open(name + ".registered", os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW, 0o600, dir_fd=pins))
        os.fsync(pins)
    finally:
        os.close(pins)


def _drop_marks(container: int, *, keep: str | None = None, only: str | None = None) -> None:
    """Under the project lock: drop every mark but `keep`'s, or only `only`'s."""
    pins = _pins_directory(container, create=False)
    if pins is None:
        return
    try:
        for entry in os.listdir(pins):
            if entry.endswith(".registered") and entry != f"{keep}.registered" and (
                    only is None or entry == f"{only}.registered"):
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(entry, dir_fd=pins)
        os.fsync(pins)
    finally:
        os.close(pins)
    with contextlib.suppress(OSError):
        os.rmdir(PINS, dir_fd=container)


def _copy_container(copy: Path, *, create: bool = False) -> int:
    copy = Path(copy)
    if copy.parent.parent.name != RUNTIME_CONTAINER:
        raise HostCommandError("the launch target is not a protected runtime copy")
    try:
        container = open_private_directories(copy.parent.parent.parent, (RUNTIME_CONTAINER, copy.parent.name),
                                             create=create)
    except (OSError, HostPathError) as exc:
        raise HostCommandError("the runtime copy directory is unavailable") from exc
    if container is None:
        raise HostCommandError("the runtime copy directory is unavailable")
    return container


@contextlib.contextmanager
def pin_runtime_copy(copy: Path):
    """Hold `copy` in use (shared, never waited for): no prune, replacement or removal takes it meanwhile."""
    container = _copy_container(copy)
    try:
        held = _lock_copy(container, Path(copy).name, exclusive=False)
    finally:
        os.close(container)
    if held is None:
        raise HostCommandError("the runtime copy is being changed by setup; try again")
    try:
        yield Path(copy)
    finally:
        os.close(held)


def mark_registered_copy(copy: Path) -> None:
    """Mark `copy` as the one the collector's launch record names; the project's earlier mark goes."""
    container = _copy_container(copy)
    try:
        with _project_locked(container):
            _set_mark(container, Path(copy).name)
            _drop_marks(container, keep=Path(copy).name)
    finally:
        os.close(container)


def launch_target_problem(
    copy: Path, project_root: Path, environ: Mapping[str, str] | None = None
) -> str | None:
    """RS-E E2a-3: why `copy` cannot be this project's launch target, or None.

    It must be this project's protected copy at the place setup writes it, named by its digest, bound to this
    project and verifying byte for byte (`runtime_copy_problem`). Where setup ran (`clone_root`) is not consulted.
    """
    try:
        root, _cli = project_cli(project_root)
        copy = Path(copy)
        if copy != _copy_root(root, copy.name, environ):
            return "the launch target is not this project's protected runtime copy"
    except HostCommandError as exc:
        return str(exc)
    return runtime_copy_problem(copy, root)


def _record_target(copy, project_root, record_launch, environ) -> str:
    """RS-E E2a-3: the collector's launch record names this copy only once it is a valid launch target. E2a-4: the
    copy is marked registered before the record commits and the earlier mark dropped only after, so no prune ever
    removes the copy a record names. A refused record keeps the earlier record and mark (and drops only a mark it
    added). Decision 179: the project lock is held from the mark to the cleanup, so concurrent setups take turns and
    none clears the mark of the record that won; a record whose outcome is unknown (its reply lost after a possible
    commit) keeps both marks until the next record that succeeds."""
    try:
        container = _copy_container(copy)
    except HostCommandError:
        return "not_recorded"
    try:
        with _project_locked(container):
            earlier = _registered(container, copy.name)
            _set_mark(container, copy.name)
            outcome = "refused"
            try:
                if launch_target_problem(copy, project_root, environ) is None:
                    record_launch(copy, copy.name)
                    outcome = "recorded"
            except Exception as error:
                outcome = "unknown" if _outcome_unknown(error) else "refused"
            if outcome == "recorded":
                _drop_marks(container, keep=copy.name)
            elif outcome == "refused" and not earlier:
                _drop_marks(container, only=copy.name)
        return "recorded" if outcome == "recorded" else "not_recorded"
    except (OSError, HostCommandError):
        return "not_recorded"
    finally:
        os.close(container)


def _outcome_unknown(error: Exception) -> bool:
    """Decision 179: whether a failed record may still have committed: the collector exchange failed after the
    request may have been delivered (a transport failure, or a reply it could not read: invalid or oversized).
    A refusal the collector named, setup's own check and a failure before any write are known to change nothing."""
    from .collector_contracts import CollectorError, CollectorTransportError
    if isinstance(error, CollectorTransportError):
        return True
    return isinstance(error, CollectorError) and error.code in {None, "response_invalid", "transport_unavailable"}


def record_setup_launch(project_root: Path, record_launch, environ: Mapping[str, str] | None = None,
                        clone_root: Path | None = None) -> str:
    """RS-E E2a-10 (decision 171): setup's registration step, for every project (Codex rule or not): install the
    protected runtime copy and record it as the launch target. `recorded` or `not_recorded`; never raises."""
    try:
        copy, _outcome = install_runtime_copy(project_root, environ, clone_root)
    except Exception:
        return "not_recorded"
    return _record_target(copy, project_root, record_launch, environ)


def prune_runtime_copies(
    project_root: Path, keep: Path, environ: Mapping[str, str] | None = None
) -> list[str]:
    """Remove this project's other runtime copies once the rule names `keep`.

    RS-E E2a-4: the registered copy and copies held in use are skipped, as is the pins folder.
    """

    root, _cli = project_cli(project_root)
    home = codex_home(environ)
    container = open_private_directories(
        home, (RUNTIME_CONTAINER, project_digest(root)), create=False
    )
    if container is None:
        return []
    removed = []
    project_lock = None
    try:
        project_lock = _take_project_lock(container)
        with os.scandir(container) as entries:
            names = sorted(entry.name for entry in entries)
        for name in names:
            if name in {keep.name, PINS} or _registered(container, name):
                continue
            held = _lock_copy(container, name, exclusive=True)
            if held is None:
                continue  # in use by a launcher: kept
            try:
                if remove_tree_at(container, name):
                    removed.append(str(keep.parent / name))
            finally:
                _unpin(container, name, held)
    finally:
        if project_lock is not None:
            os.close(project_lock)
        os.close(container)
    return removed


def install_rule(
    project_root: Path,
    environ: Mapping[str, str] | None = None,
    interpreter: str | None = None,
    *,
    replace: bool = False,
    clone_root: Path | None = None,
    record_launch=None,
) -> dict[str, str]:
    """Owner setup: write the protected runtime copy, then the rule that names it.

    The copy comes first, so the rule never names a missing runtime. Once the
    rule names it (created, replaced or unchanged), the project's older copies
    are removed; when another rule is left in place (``differs``), they stay.
    """

    copy, copy_outcome = install_runtime_copy(project_root, environ, clone_root)
    outcome = write_rule(project_root, environ, interpreter, replace=replace)
    launch = None if record_launch is None else _record_target(copy, project_root, record_launch, environ)
    if outcome != "differs":
        try:
            prune_runtime_copies(project_root, copy, environ)
        except (OSError, HostPathError, HostCommandError):
            pass  # an older copy no rule names is inert; the next setup retries
    report = {
        "codex_rule": outcome,
        "runtime_copy": str(copy),
        "runtime_copy_status": copy_outcome,
    }
    if launch is not None:
        report["launch_record"] = launch
    return report


def remove_rule(
    project_root: Path, environ: Mapping[str, str] | None = None
) -> list[str]:
    """Owner removal: delete this project's rule file and every runtime copy for it.

    The project need not still hold an installed package (removal may come
    after the package files are gone, or the project may sit in a temporary
    folder), so only its resolved path is used. It looks in the account's
    `~/.codex` and, for rules an earlier version wrote, under a different HOME
    or `CODEX_HOME`. Symlinks
    are never followed: a symlinked rules or copy directory refuses. Returns
    the paths removed, or an empty list when there was nothing.
    """

    environ = os.environ if environ is None else environ
    root = Path(os.path.realpath(Path(project_root).expanduser()))
    _checked_text(str(root), "project root")
    digest = project_digest(root)
    homes = [account_home() / ".codex"]
    candidates = []
    for named in (_home_folder, configured_codex_home):
        try:
            candidates.append(named(environ) / ".codex" if named is _home_folder
                              else named(environ))
        except CodexHomeUnsupported:
            pass  # an unusable HOME or CODEX_HOME never held a rule of ours
    for candidate in candidates:
        if all(os.path.realpath(candidate) != os.path.realpath(seen) for seen in homes):
            homes.append(candidate)
    removed: list[str] = []
    for home in homes:
        removed.extend(_remove_from(home, digest))
    return removed


def _remove_from(home: Path, digest: str) -> list[str]:
    removed: list[str] = []
    directory = _open_rules_directory(home, create=False)
    if directory is not None:
        name = f"{RULE_FILE_PREFIX}{digest}.rules"
        try:
            if _read_rule(directory, name) is not None:
                os.unlink(name, dir_fd=directory)
                os.fsync(directory)
                removed.append(str(home / "rules" / name))
        finally:
            os.close(directory)
    canonical = Path(os.path.realpath(home))
    if not os.path.lexists(canonical / RUNTIME_CONTAINER):
        return removed
    try:
        container = open_private_directories(canonical, (RUNTIME_CONTAINER,), create=False)
    except HostPathError as exc:
        raise HostCommandError(f"the runtime copy directory cannot be removed: {exc}") from exc
    if container is None:
        return removed
    try:
        # RS-E E2a-4: a copy held in use, or the registered one, is left in place (and so is its folder); the others
        # go. All under the project's stable lock.
        held, busy = [], []
        project = None
        try:
            project = open_private_directories(canonical, (RUNTIME_CONTAINER, digest), create=False)
        except HostPathError:
            project = None
        if project is not None:
            try:
                held.append(_take_project_lock(project))
                with os.scandir(project) as entries:
                    names = sorted(entry.name for entry in entries if entry.name != PINS)
                for name in names:
                    if _registered(project, name):
                        busy.append(name)
                        continue
                    descriptor = _lock_copy(project, name, exclusive=True)
                    if descriptor is None:
                        busy.append(name)
                    else:
                        held.append(descriptor)
                if busy:
                    for name in names:
                        if name not in busy and remove_tree_at(project, name):
                            removed.append(str(canonical / RUNTIME_CONTAINER / digest / name))
            finally:
                os.close(project)
        try:
            if not busy and remove_tree_at(container, digest):
                removed.append(str(canonical / RUNTIME_CONTAINER / digest))
        finally:
            for descriptor in held:
                os.close(descriptor)
    finally:
        os.close(container)
    return removed
