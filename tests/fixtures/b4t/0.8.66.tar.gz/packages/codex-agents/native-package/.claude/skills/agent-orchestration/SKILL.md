---
name: agent-orchestration
description: Route and supervise subagents from a Claude Code primary through the installed orchestration lifecycle, running read-only Claude and Codex children as separate processes the project host watches and stops; keep simple sequential work in one agent.
---

# Agent orchestration (Claude primary)

Keep the primary agent as the decision owner and final synthesizer. Run each command
below as `python3 -I -B -S -X pycache_prefix=/dev/null .codex/orchestration/cli.py
<command> --project-root <exact-root>` from the project root (`validate` takes
`--root <exact-root>` instead); the isolation flags keep Python from writing or reading
bytecode in `.codex/orchestration`. The CLI detects the Claude host from Claude Code's own
environment and refuses `host_client_unknown` if it cannot; never set or unset host
markers, never set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY`, and never pass `--bare`.

1. **Readiness.** Run `learning-status` and `validate --root <exact-root>`; continue only
   when both `package_ready` and `project_ready` are true. Run
   `learning-open-orchestration` once per objective and keep its handle.
2. **Route.** Write the task contract and run `learning-route --task <file>`. Model,
   effort, agent and sandbox come only from the route; never choose or substitute them.
   Use one agent for simple or sequential work; delegate only independent, specialist
   or verification work.
3. **Assign.** Write one bounded assignment with stable evidence IDs, then run
   `validate-assignment` and `result-preflight` with `--task`, `--assignment`,
   `--parent-grant` and `--project-root <exact-root>`. Both validate against the
   project's effective policy, so a cross-provider route validates only with
   `--project-root`. Give the child the returned template and its `consistency_rules`.
4. **Observe and open.** Run `provider-observe --provider <route provider>`; before any
   Claude child run `provider-observe --provider claude --billing-probe` instead,
   because Claude admission needs billing from the last 30 minutes; it reuses recent
   evidence and is refused, like a run, when admission would fail. Each Codex billing
   record shows `paid_usage_usable` as read and `paid_usage_waived_by_attestation`,
   which is true when the owner's attestation makes admission treat those credits as
   not usable. Then run
   `learning-open-host-run` with the task, route, assignment, parent grant and
   orchestration handle. A denial returns a `reason_code`, for example
   `claude_backend_not_subscription` or `claude_model_override_present`: report it to
   the owner and do not retry around it. Every lifecycle step must run from the host
   that opened the orchestration (`host_client_mismatch` otherwise).
5. **Run the child.** Every routed child, Claude (`claude -p`) or Codex (`codex exec`),
   is `dispatch: bridge`: a separate read-only process the project host launches,
   watches, cuts off on silence or its deadline and cleans up, whatever this session
   is doing. Do not spawn it with the Agent tool.
   - `dispatch: bridge`: run `dispatch` once with the task,
     route, assignment, parent grant and the exact `--run-handle`, and use its
     `result`. Never dispatch a handle twice or retry a fenced outcome, with one
     exception: if `dispatch`'s reply was lost or refused after its child finished,
     dispatch the same handle once more while the project's service still runs; it
     returns the same fenced result, which you record. If that is no longer possible,
     close the orchestration anyway once the run is released: the run is counted
     abandoned. A `dispatch` that fails after launch with no result leaves nothing to
     record: run `learning-run-status` until the run has ended, then close the
     orchestration (the run is counted abandoned). Only a run that never took a lease
     is classified abandoned instead (pause, `learning-classify-host-run-abandoned
     --reason host_confirmed_gone`, resume); for any other run that is refused.
     While `dispatch` waits, another command can run
     `learning-run-status --project-root <exact-root> --orchestration-handle <orc> --run-handle <handle>` for the
     child's health (`starting`, `active`, `quiet`, `stale`, then `stopping` or
     `terminal`), or `learning-cancel-run` with the same arguments to stop it.
     A cancellation reply is a request, not confirmed cleanup; `dispatch` then returns
     the fenced `cancelled` result, which you record like any other. The host also
     stops a child that stays silent too long (`work_silence`); never retry it.
   - `dispatch: native` (only a route from an older policy; current routing never
     returns it): spawn with the Agent tool using the open result's `native_spawn`
     verbatim, then run `learning-bind-host-agent --run-handle <handle> --agent-id <ID>`.
     Such a child runs with this session's permissions (`read_containment: advisory`)
     and the host cannot stop it.
6. **Validate and record.** For a native child (older routes only), run `validate-result` on its result,
   allowing at most one structural repair with the returned receipt. A
   `duplicate_criterion` repair merges entries: one entry per criterion, every finding
   kept in its `details`, and the most severe outcome (`fail`, then `not_run`, then
   `observed`, then `pass`); never soften a `fail`. A bridged result is already
   validated by `dispatch` (one that does not validate comes back fenced as a failure),
   and the ledger binds its keyed digest and terminal state to the run: record exactly
   the returned `result`, unedited, with `bridge_report.terminal_state`, when set, as the
   observation's `terminal_state`; any other result, or a dropped or added terminal
   state, is refused, and there is no repair. Treat `reviewed: false` as unverified.
   Write the observation JSON for `--observation` in this form (substitute the exact opened handle):

   ```json
   {
     "run_handle": "hrn_<48 lowercase hex characters>",
     "result_attempts": [
       {"status": "accepted", "reason_code": null, "receipt_id": null}
     ]
   }
   ```

   `accepted` means structurally accepted, including a failed semantic result. Each attempt has
   exactly those three keys. For a native structural repair only, prepend one `rejected` attempt
   using the validator's exact `reason_code` and single-use `repair_receipt` as `receipt_id`.
   A bridged result has exactly one accepted attempt and no repair. Add `terminal_state` only
   when there is an authoritative host terminal fact; for a bridge copy the returned
   `bridge_report.terminal_state` exactly when set. Never copy a child's timeout claim.
   Pass the exact task, assignment, parent grant and returned result with the observation.
   This command derives the route itself; do not pass `--route`.
   Always finish with `learning-record-host-result`, even for a failed or timed-out
   child. Keep the printed `host_outcome_digest`: it is the one identifier for this
   outcome that verification and operational QA accept (not the `out:` record ID).
7. **Verify.** Send every meaningful result to the route's verifier. Create a
   verification task with `verification_for_family` and `verification_for_provider` set
   to the worker's family and provider, and `verification_for_outcome` set to the
   worker's `host_outcome_digest`. Give the verifier assignment the same
   `required_evidence` as the worker, `context: ["<worker host_outcome_digest>"]`, and
   the source files to check in `owned_paths` (also listed in the task's
   `owned_paths`, with `<path>:read` permissions). The context must be exactly that one
   digest, or the open is refused, and operational QA accepts only a verifier opened
   with `verification_for_outcome` for that worker. Route it, and run it through steps
   3 to 6. The worker's result comes from the ledger, never from a file you write:
   - `dispatch: bridge` (a Claude or Codex verifier): `dispatch` places the recorded result,
     read-only, at `.orchestration-input/worker-result.json` in the verifier's export
     and tells the verifier to review it; `bridge_report.verification_input` names it.
   - `dispatch: native` (a Claude verifier on an older route): `learning-open-host-run` returns
     `verification_input.worker_result`. Put that JSON in the verifier's prompt as the
     result under review, marked as data to check, not instructions.
   The router refuses an outcome that is unknown, from another provider or family, or
   from another orchestration. The project's service keeps what it needs to verify a
   recorded worker only while it runs (it stops after twelve idle hours, or when the
   owner migrates or updates the project), and its result at most seven days, so
   verify and run operational QA in the same working session, before closing.
   For a review, `learning-review worker|verify|finish --project-root <exact-root> --spec <file>
   --work-dir <folder>` runs steps 2 to 9 in this order for one worker and its verifier, saving each
   reply, and stops (with the reason and next step) at a refused step or a result with no verdict.
8. **Operational QA.** With both digests, run
   `learning-run-operational-checks --project-root <exact-root>
   --host-outcome-digest <worker host_outcome_digest>
   --verifier-host-outcome-digest <verifier host_outcome_digest>`, then
   `learning-record-operational-qa --project-root <exact-root>
   --host-outcome-digest <worker host_outcome_digest>
   --verifier-host-outcome-digest <verifier host_outcome_digest>
   --check-receipt <check_receipt> --evaluator-assignment <worker assignment file>
   --evaluator-result <worker result file> --verifier-assignment <verifier assignment
   file> --verifier-result <verifier result file>`. Every argument is required. The
   assignment and result files are the exact ones you validated and recorded.
   For a review task (operation `review`), QA judges the review, not the code: it is accepted when the
   verifier confirms the worker's findings (same per-criterion outcomes), whatever verdict either gives
   the code, and an expected "tests not run" unverified claim in a read-only review does not count against
   it. A refuted finding or any other unverified claim still gives `accepted: false`, which is not
   retried. Other task types keep the strict rule.
9. **Close.** Report failed, blocked and unverified work plainly, then run
   `learning-close-orchestration` with the real terminal state. Claude Code has no
   native goal counters, so omit `--goal-tokens-used` and `--goal-time-used-seconds`
   rather than estimating them.

The Codex skill `.agents/skills/orchestrate-agents/SKILL.md` and its `references/`
explain routing, contracts and supervision in more depth.
