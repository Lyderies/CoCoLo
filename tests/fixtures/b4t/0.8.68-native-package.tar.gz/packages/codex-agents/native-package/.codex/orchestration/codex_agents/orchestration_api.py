"""Closed project lifecycle protocol; no SQLite or native caller authority.

The endpoint and owning primary must be independently authenticated. A committed
receipt, including a known old active snapshot, is metadata, never a new launch
grant. Current execution checks read the persistence owner's current state.
"""
from dataclasses import asdict, dataclass
import hashlib
import secrets
from pathlib import Path

from .history_contracts import (HistoryError, HISTORY_REASON_CODES, MAX_SEQUENCE, _ID, _PROJECT, _DIGEST, _ORCHESTRATION,
                                matches, valid_integer)
from .learning_contracts import canonical_json, parse_bounded_json
from .service_transport import MAX_TIMEOUT_SECONDS, SERVICE_REFUSALS, ServiceTransportError, exchange_frame

ORCHESTRATION_PROTOCOL_VERSION = 1
MAX_ORCHESTRATION_FRAME_BYTES = 16_384
MAX_ORCHESTRATION_CHECKPOINT_BYTES = 8192
MAX_RESUME_STATE_BYTES = 2048
ORCHESTRATION_OPERATIONS = frozenset('orchestration.' + name for name in (
    'open', 'pause', 'resume', 'checkpoint', 'close', 'status', 'rollover', 'packet'))
ORCHESTRATION_TERMINAL_STATES = frozenset({'completed', 'failed', 'interrupted', 'cancelled', 'rolled_over'})
ORCHESTRATION_STATES = ORCHESTRATION_TERMINAL_STATES | {'active', 'paused'}
HOST_CLIENT_VERSIONS = frozenset({'codex-host-v1', 'claude-host-v1'})
SCOPE_FIELDS = ('project_id', 'primary_session_id', 'runtime_digest', 'supervisor_instance_id', 'supervisor_generation')


@dataclass(frozen=True)
class OrchestrationScope:
    project_id: str
    primary_session_id: str
    runtime_digest: str
    supervisor_instance_id: str
    supervisor_generation: int

    def as_data(self):
        if (not matches(self.project_id, _PROJECT) or not matches(self.primary_session_id, _ID)
                or not matches(self.runtime_digest, _DIGEST) or not matches(self.supervisor_instance_id, _ID)
                or not valid_integer(self.supervisor_generation, minimum=1)):
            raise HistoryError('history_invalid_input')
        return asdict(self)

    def __post_init__(self):
        self.as_data()

    def matches_attempt(self, binding):
        return self.as_data() == {name: getattr(binding, name) for name in SCOPE_FIELDS}


@dataclass(frozen=True)
class OrchestrationLimits:
    max_orchestrations: int
    max_events: int

    def __post_init__(self):
        if (not valid_integer(self.max_orchestrations, minimum=1, maximum=65_536)
                or not valid_integer(self.max_events, minimum=3, maximum=65_536)):
            raise HistoryError('history_invalid_input')


@dataclass(frozen=True)
class OrchestrationRequest:
    protocol_version: int
    operation: str
    request_id: str
    scope: OrchestrationScope
    payload: dict

    def __post_init__(self):
        # Hold a private canonical copy so a caller alias cannot change identity.
        raw = encode_orchestration_request(self)
        object.__setattr__(self, 'payload', parse_bounded_json(raw, max_bytes=MAX_ORCHESTRATION_FRAME_BYTES - 1)['payload'])


def _closed(value, fields):
    return type(value) is dict and value.keys() == fields


def checked_resume_state(value):
    if type(value) is not dict or len(canonical_json(value)) > MAX_RESUME_STATE_BYTES:
        raise HistoryError('history_invalid_request')
    return value


def checked_handoff(value):
    fields = {'version', 'handoff_id', 'request_digest', 'previous_handle', 'next_handle',
              'session_id', 'next_session_id', 'cause'}
    if (not _closed(value, fields) or type(value['version']) is not int or value['version'] != 1
            or not matches(value['handoff_id'], _DIGEST) or not matches(value['request_digest'], _DIGEST)
            or any(not matches(value[n], _ORCHESTRATION) for n in ('previous_handle', 'next_handle'))
            or value['previous_handle'] == value['next_handle']
            or any(not matches(value[n], _ID) for n in ('session_id', 'next_session_id'))
            or value['cause'] not in {'session', 'capacity'}
            or (value['cause'] == 'capacity' and value['session_id'] != value['next_session_id'])):
        raise HistoryError('history_invalid_response')
    return value


def encode_orchestration_request(request):
    invalid = False
    try:
        if (type(request) is not OrchestrationRequest or type(request.protocol_version) is not int
                or request.protocol_version != 1 or request.operation not in ORCHESTRATION_OPERATIONS
                or not matches(request.request_id, _ID) or type(request.scope) is not OrchestrationScope):
            raise ValueError()
        scope = request.scope.as_data()
        operation, payload = request.operation, request.payload
        if operation == 'orchestration.open':
            if not _closed(payload, set()):
                raise ValueError()
        else:
            fields = {'orchestration_handle'}
            if operation not in {'orchestration.status', 'orchestration.packet'}:
                fields.add('expected_sequence')
            if operation in {'orchestration.checkpoint', 'orchestration.close'}:
                fields |= {'goal_tokens_used', 'goal_time_used_seconds'}
            if operation == 'orchestration.close':
                fields.add('status')
            if operation == 'orchestration.checkpoint' and type(payload) is dict and 'resume_state' in payload:
                fields.add('resume_state')
                checked_resume_state(payload['resume_state'])
            if operation == 'orchestration.rollover':
                fields |= {'session_id', 'next_session_id', 'cause'}
                if (payload['cause'] not in {'session', 'capacity'}
                        or any(not matches(payload[n], _ID) for n in ('session_id', 'next_session_id'))
                        or (payload['cause'] == 'capacity' and payload['session_id'] != payload['next_session_id'])
                        or (payload['cause'] == 'session' and payload['session_id'] == payload['next_session_id'])):
                    raise ValueError()
            if not _closed(payload, fields) or not matches(payload['orchestration_handle'], _ORCHESTRATION):
                raise ValueError()
            if (operation not in {'orchestration.status', 'orchestration.packet'}
                    and not valid_integer(payload['expected_sequence'], minimum=1, maximum=MAX_SEQUENCE - 1)):
                raise ValueError()
            if operation == 'orchestration.close' and payload['status'] not in ORCHESTRATION_TERMINAL_STATES:
                raise ValueError()
            if operation in {'orchestration.checkpoint', 'orchestration.close'}:
                for name in ('goal_tokens_used', 'goal_time_used_seconds'):
                    if not (operation == 'orchestration.close' and payload[name] is None) and not valid_integer(payload[name]):
                        raise ValueError()
        raw = canonical_json({'protocol_version': 1, 'operation': operation, 'request_id': request.request_id,
                              'scope': scope, 'payload': payload})
    except Exception:
        invalid = True
    if invalid:
        raise HistoryError('history_invalid_request')
    if len(raw) + 1 > MAX_ORCHESTRATION_FRAME_BYTES:
        raise HistoryError('history_request_too_large')
    return raw


def decode_orchestration_request(raw):
    invalid = False
    try:
        if type(raw) is not bytes or len(raw) + 1 > MAX_ORCHESTRATION_FRAME_BYTES:
            raise ValueError()
        data = parse_bounded_json(raw, max_bytes=MAX_ORCHESTRATION_FRAME_BYTES - 1)
        if not _closed(data, {'protocol_version', 'operation', 'request_id', 'scope', 'payload'}) or type(data['scope']) is not dict:
            raise ValueError()
        request = OrchestrationRequest(**{**data, 'scope': OrchestrationScope(**data['scope'])})
    except Exception:
        invalid = True
    if invalid:
        raise HistoryError('history_invalid_request')
    return request


def orchestration_request_digest(request):
    return hashlib.sha256(encode_orchestration_request(request)).hexdigest()


def checked_orchestration_view(value):
    if not _closed(value, {'snapshot', 'checkpoint_digest'}) or not matches(value['checkpoint_digest'], _DIGEST):
        raise HistoryError('history_invalid_response')
    s = value['snapshot']
    fields = {'scope', 'orchestration_handle', 'orchestration_id', 'client_version', 'status', 'sequence',
              'started_at_ms', 'observed_at_ms', 'ended_at_ms', 'goal_tokens_used', 'goal_time_used_seconds'}
    if not _closed(s, fields) or not _closed(s['scope'], set(SCOPE_FIELDS)):
        raise HistoryError('history_invalid_response')
    try:
        OrchestrationScope(**s['scope'])
    except HistoryError:
        raise HistoryError('history_invalid_response') from None
    if (not matches(s['orchestration_handle'], _ORCHESTRATION) or not matches(s['orchestration_id'], _ID)
            or type(s['client_version']) is not str or s['client_version'] not in HOST_CLIENT_VERSIONS
            or type(s['status']) is not str or s['status'] not in ORCHESTRATION_STATES
            or not valid_integer(s['sequence'], minimum=1) or not valid_integer(s['started_at_ms'])
            or not valid_integer(s['observed_at_ms'], minimum=s['started_at_ms'])
            or (s['status'] in {'active', 'paused'} and s['ended_at_ms'] is not None)
            or (s['status'] in ORCHESTRATION_TERMINAL_STATES
                and (not valid_integer(s['ended_at_ms']) or s['ended_at_ms'] != s['observed_at_ms']))
            or any(s[n] is not None and not valid_integer(s[n]) for n in ('goal_tokens_used', 'goal_time_used_seconds'))
            # A successor's first checkpoint may inherit pause and cumulative usage.
            # Ordinary open receipts still require active, unmeasured state below.
            or (s['sequence'] == 1 and (s['status'] not in {'active', 'paused'}
                                        or s['observed_at_ms'] != s['started_at_ms']))):
        raise HistoryError('history_invalid_response')
    return value


def _same(left, right):
    # JSON equality without Python's bool/int/float coercion.
    return canonical_json(left) == canonical_json(right)


_RECEIPT_STATUS = {'orchestration.open': {'active'}, 'orchestration.pause': {'paused'},
                   'orchestration.resume': {'active'}, 'orchestration.checkpoint': {'active', 'paused'}}


def _check_receipt(request, receipt, current, known, *, successor=False):
    # The receipt is the original committed result; current is separately read
    # state. A known receipt is metadata only and never a new execution grant.
    committed, now, payload = receipt['snapshot'], current['snapshot'], request.payload
    expected = {payload['status']} if request.operation == 'orchestration.close' else _RECEIPT_STATUS[request.operation]
    if request.operation == 'orchestration.open':
        if successor:
            expected = {'active', 'paused'}
        elif any(committed[n] is not None for n in ('goal_tokens_used', 'goal_time_used_seconds')):
            raise ValueError()
    sequence = 1 if request.operation == 'orchestration.open' else payload['expected_sequence'] + 1
    if committed['status'] not in expected or committed['sequence'] != sequence:
        raise ValueError()
    for name in ('goal_tokens_used', 'goal_time_used_seconds'):
        if payload.get(name) is not None and committed[name] != payload[name]:
            raise ValueError()
    if not known:
        if not _same(receipt, current):
            raise ValueError()
    elif (any(not _same(committed[n], now[n])
              for n in ('scope', 'orchestration_handle', 'orchestration_id', 'client_version', 'started_at_ms'))
            or now['sequence'] < committed['sequence'] or now['observed_at_ms'] < committed['observed_at_ms']
            or (now['sequence'] == committed['sequence']) != _same(receipt, current)
            or (committed['status'] in ORCHESTRATION_TERMINAL_STATES and not _same(receipt, current))
            or any(committed[n] is not None and (now[n] is None or now[n] < committed[n])
                   for n in ('goal_tokens_used', 'goal_time_used_seconds'))):
        raise ValueError()


def decode_orchestration_response(raw, request):
    invalid = False
    try:
        encode_orchestration_request(request)
        if type(raw) is not bytes or len(raw) + 1 > MAX_ORCHESTRATION_FRAME_BYTES:
            raise ValueError()
        response = parse_bounded_json(raw, max_bytes=MAX_ORCHESTRATION_FRAME_BYTES - 1)
        scope = request.scope.as_data()
        if (not _closed(response, {'protocol_version', 'request_id', 'request_digest', 'scope', 'ready', 'result', 'reason_code'})
                or type(response['protocol_version']) is not int or response['protocol_version'] != 1
                or not matches(response['request_id'], _ID) or response['request_id'] != request.request_id
                or not _same(response['scope'], scope) or not matches(response['request_digest'], _DIGEST)
                or response['request_digest'] != orchestration_request_digest(request) or type(response['ready']) is not bool):
            raise ValueError()
        if response['ready']:
            result = response['result']
            if response['reason_code'] is not None:
                raise ValueError()
            if request.operation in {'orchestration.rollover', 'orchestration.packet'}:
                _check_lifetime_result(request, result)
                return result
            if not _closed(result, {'receipt', 'current', 'known'}) or type(result['known']) is not bool:
                raise ValueError()
            current = checked_orchestration_view(result['current'])
            if (not _same(current['snapshot']['scope'], scope)
                    or (request.operation != 'orchestration.open'
                        and current['snapshot']['orchestration_handle'] != request.payload['orchestration_handle'])):
                raise ValueError()
            if request.operation == 'orchestration.status':
                if result['receipt'] is not None or result['known'] is not False:
                    raise ValueError()
            else:
                _check_receipt(request, checked_orchestration_view(result['receipt']), current, result['known'])
        elif (response['result'] is not None or type(response['reason_code']) is not str
              or response['reason_code'] not in HISTORY_REASON_CODES):
            raise ValueError()
    except Exception:
        invalid = True
    if invalid:
        raise HistoryError('history_invalid_response')
    if not response['ready']:
        raise HistoryError(response['reason_code'])
    return response['result']


def _check_lifetime_result(request, result):
    scope, payload = request.scope.as_data(), request.payload
    current = checked_orchestration_view(result['current'])
    if not _same(current['snapshot']['scope'], scope):
        raise ValueError()
    if request.operation == 'orchestration.packet':
        if (not _closed(result, {'current', 'resume_state', 'handoff'})
                or current['snapshot']['orchestration_handle'] != payload['orchestration_handle']):
            raise ValueError()
        checked_resume_state(result['resume_state'])
        if result['handoff'] is not None:
            link = checked_handoff(result['handoff'])
            if current['snapshot']['orchestration_handle'] not in {link['previous_handle'], link['next_handle']}:
                raise ValueError()
        return
    if (not _closed(result, {'receipt', 'current', 'previous', 'handoff', 'known', 'rolled_over', 'note'})
            or type(result['known']) is not bool or type(result['rolled_over']) is not bool):
        raise ValueError()
    if not result['rolled_over']:
        if (any(result[n] is not None for n in ('receipt', 'previous', 'handoff')) or result['known']
                or result['note'] not in {None, 'Waiting for active work.'}
                or current['snapshot']['orchestration_handle'] != payload['orchestration_handle']
                or current['snapshot']['sequence'] != payload['expected_sequence']
                or current['snapshot']['status'] not in {'active', 'paused'}):
            raise ValueError()
        return
    receipt = checked_orchestration_view(result['receipt'])
    previous = checked_orchestration_view(result['previous'])
    link = checked_handoff(result['handoff'])
    if (result['note'] is not None or not _same(previous['snapshot']['scope'], scope)
            or link['previous_handle'] != payload['orchestration_handle']
            or previous['snapshot']['orchestration_handle'] != link['previous_handle']
            or receipt['snapshot']['orchestration_handle'] != link['next_handle']
            or any(link[n] != payload[n] for n in ('session_id', 'next_session_id', 'cause'))
            or link['request_digest'] != orchestration_request_digest(request)):
        raise ValueError()
    closing = OrchestrationRequest(1, 'orchestration.close', request.request_id, request.scope, {
        'orchestration_handle': payload['orchestration_handle'], 'expected_sequence': payload['expected_sequence'],
        'status': 'rolled_over', 'goal_tokens_used': None, 'goal_time_used_seconds': None})
    _check_receipt(closing, previous, previous, False)
    opening = OrchestrationRequest(1, 'orchestration.open', request.request_id, request.scope, {})
    _check_receipt(opening, receipt, current, result['known'], successor=True)
    if any(receipt['snapshot'][n] != previous['snapshot'][n]
           for n in ('goal_tokens_used', 'goal_time_used_seconds')):
        raise ValueError()


class OrchestrationClient:
    """One bounded exchange per call; no startup, retries or database fallback."""
    def __init__(self, endpoint: Path, scope: OrchestrationScope, *, timeout: float):
        if (not isinstance(endpoint, Path) or not endpoint.is_absolute() or type(scope) is not OrchestrationScope
                or type(timeout) not in {int, float} or not 0 < timeout <= MAX_TIMEOUT_SECONDS):
            raise HistoryError('history_invalid_input')
        self._endpoint, self._scope, self._timeout = endpoint, OrchestrationScope(**scope.as_data()), timeout

    def call(self, operation, payload, *, request_id=None):
        # Exactly one exchange. A lost or ambiguous reply may follow a commit and
        # is never resent; reconcile by explicitly reusing the same request_id.
        if request_id is None:
            request_id = 'orc-request:' + secrets.token_hex(16)
        request = OrchestrationRequest(1, operation, request_id, self._scope, payload)
        raw = encode_orchestration_request(request)
        request = decode_orchestration_request(raw)
        failed = None
        try:
            reply = exchange_frame(self._endpoint, raw, timeout=self._timeout, request_limit=MAX_ORCHESTRATION_FRAME_BYTES,
                                   response_limit=MAX_ORCHESTRATION_FRAME_BYTES)
        except ServiceTransportError as error:  # R7b: a service's own refusal reason is kept
            failed = error.reason_code if error.reason_code in SERVICE_REFUSALS else 'history_service_unavailable'
        if failed:
            raise HistoryError(failed)
        return decode_orchestration_response(reply, request)
